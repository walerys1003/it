import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, User, Building2 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { uploadCompanyLogo } from '../lib/fileStorage';

export default function Payment() {
  const location = useLocation();
  const navigate = useNavigate();
  const jobData = location.state?.jobData;
  const paymentId = location.state?.paymentId;
  const [transactionId] = useState(`TR${Date.now()}`);
  const [isProcessing, setIsProcessing] = useState(false);

  if (!jobData) {
    navigate('/dodaj-ogloszenie');
    return null;
  }

  const handleTestTransaction = async (success: boolean) => {
    try {
      setIsProcessing(true);
      
      if (!paymentId) {
        throw new Error('Payment ID is missing');
      }
      
      // Check if we have a logo file to upload
      let logoUrl = null;
      if (jobData.company.logoPreviewUrl && jobData.company.logoFile) {
        try {
          // Convert the data URL back to a file
          const response = await fetch(jobData.company.logoPreviewUrl);
          const blob = await response.blob();
          const file = new File([blob], jobData.company.logoFile.name, { 
            type: jobData.company.logoFile.type 
          });
          
          // Upload the logo file
          logoUrl = await uploadCompanyLogo(file, paymentId);
        } catch (uploadError) {
          console.error('Error uploading logo:', uploadError);
          // Continue with payment process even if logo upload fails
        }
      }

      if (!success) {
        // Call the update_payment_status function
        const { data, error } = await supabase
          .rpc('update_payment_status', {
            payment_id: paymentId,
            new_status: 'failed'
          });

        if (error) {
          console.error('Error updating payment status:', error);
          throw error;
        }

        alert(`Transakcja ${transactionId} zakończona niepowodzeniem. Spróbuj ponownie.`);
        navigate('/dodaj-ogloszenie');
      } else {
        // If we have a logo URL, update the job with it
        if (logoUrl) {
          try {
            // Get the job ID for the payment
            const { data: payment } = await supabase
              .from('payments')
              .select('job_id')
              .eq('id', paymentId)
              .single();
              
            if (payment?.job_id) {
              // Update the job with the logo URL
              await supabase
                .from('jobs')
                .update({ company_logo: logoUrl })
                .eq('id', payment.job_id);
            }
          } catch (updateError) {
            console.error('Error updating job with logo URL:', updateError);
            // Continue with payment process even if update fails
          }
        }
        
        // Call the update_payment_status function
        const { data, error } = await supabase
          .rpc('update_payment_status', {
            payment_id: paymentId,
            new_status: 'completed'
          });

        if (error) {
          console.error('Error updating payment status:', error);
          throw error;
        }

        // Get the job ID for the payment
        const { data: payment } = await supabase
          .from('payments')
          .select('job_id')
          .eq('id', paymentId)
          .single();

        if (!payment?.job_id) {
          throw new Error('Could not find job ID for payment');
        }

        alert(`Transakcja ${transactionId} zakończona sukcesem! Ogłoszenie zostanie opublikowane.`);
        navigate(`/oferta/${payment.job_id}`);
      }
    } catch (error) {
      console.error('Transaction error:', error);
      alert(`Wystąpił błąd podczas przetwarzania transakcji: ${error.message}`);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <button
          onClick={() => navigate(-1)}
          className="mb-6 flex items-center text-purple-600 hover:text-purple-800 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          <span>Wróć do podsumowania</span>
        </button>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          {/* Transaction ID */}
          <div className="bg-purple-50 rounded-xl p-6 mb-8">
            <div className="text-sm text-purple-600 mb-1">Numer transakcji:</div>
            <div className="font-mono text-purple-900 font-medium">{transactionId}</div>{paymentId}
          </div>

          {/* Client Info */}
          <div className="space-y-6 mb-8">
            {/* Contact Person */}
            <div className="bg-purple-50 rounded-xl p-6">
              <div className="flex items-center mb-3">
                <User className="w-5 h-5 text-purple-600 mr-2" />
                <span className="text-sm text-purple-600">Dane osoby kontaktowej:</span>
              </div>
              <div className="space-y-1">
                <div className="text-purple-900">{jobData.contact.name}</div>
                <div className="text-purple-700">{jobData.contact.position}</div>
                <div className="text-purple-700">{jobData.contact.email}</div>
                {jobData.contact.phone && (
                  <div className="text-purple-700">{jobData.contact.phone}</div>
                )}
              </div>
            </div>

            {/* Company Info */}
            <div className="bg-purple-50 rounded-xl p-6">
              <div className="flex items-center mb-3">
                <Building2 className="w-5 h-5 text-purple-600 mr-2" />
                <span className="text-sm text-purple-600">Dane firmy:</span>
              </div>
              <div className="space-y-1">
                <div className="text-purple-900">{jobData.company.name}</div>
                <div className="text-purple-700">{jobData.company.size}</div>
              </div>
            </div>
          </div>

          {/* Test Transaction Buttons */}
          <div className="grid grid-cols-2 gap-4">
            <button
              onClick={() => handleTestTransaction(true)}
              disabled={isProcessing}
              className="bg-green-600 text-white rounded-xl py-3 font-medium hover:bg-green-700 transition-colors"
            >
              {isProcessing ? 'Przetwarzanie...' : 'Symuluj udaną transakcję'}
            </button>
            <button
              onClick={() => handleTestTransaction(false)}
              disabled={isProcessing}
              className="bg-red-600 text-white rounded-xl py-3 font-medium hover:bg-red-700 transition-colors"
            >
              {isProcessing ? 'Przetwarzanie...' : 'Symuluj nieudaną transakcję'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}