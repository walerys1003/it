import React, { useEffect, useState } from 'react';
import { Link, Outlet } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { 
  Search, BookOpen, Users, MessageSquare, Star, Mail, Phone,
  Loader2, AlertCircle, Calendar, Clock, User, CheckCircle2, X
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { sendEmail } from '../lib/email';

type Settings = {
  contact_phone: string;
  contact_email: string;
};

type BlogPost = {
  id: string;
  title: string;
  subtitle: string;
  excerpt: string;
  thumbnail_url: string;
  author_name: string;
  author_role: string;
  author_avatar_url: string;
  published_at: string;
  is_featured: boolean;
  category_id: string;
  category_name?: string;
};

type Category = {
  id: string;
  name: string;
  type: string;
  post_count?: number;
};

export default function Blog() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [featuredPosts, setFeaturedPosts] = useState<BlogPost[]>([]);
  const [searchResults, setSearchResults] = useState<BlogPost[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);
  const [settings, setSettings] = useState<Settings>({
    contact_phone: '',
    contact_email: ''
  });

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch featured posts with their categories
        const { data: posts, error: postsError } = await supabase
          .from('blog_posts')
          .select(`
            *,
            category:category_id (
              name
            )
          `)
          .eq('is_published', true)
          .eq('is_featured', true)
          .order('published_at', { ascending: false })
          .limit(3);

        if (postsError) throw postsError;

        // Transform posts data to include category name
        const transformedPosts = posts.map(post => ({
          ...post,
          category_name: post.category?.name
        }));

        setFeaturedPosts(transformedPosts);

        // Fetch categories with post count
        const { data: cats, error: catsError } = await supabase
          .from('blog_taxonomies')
          .select('*')
          .eq('type', 'category');

        if (catsError) throw catsError;

        // Get post count for each category
        const categoriesWithCount = await Promise.all(
          cats.map(async (cat) => {
            const { count } = await supabase
              .from('blog_posts')
              .select('*', { count: 'exact', head: true })
              .eq('category_id', cat.id)
              .eq('is_published', true);

            return {
              ...cat,
              post_count: count || 0
            };
          })
        );

        setCategories(categoriesWithCount);
      } catch (err) {
        console.error('Error fetching blog data:', err);
        setError('Wystąpił błąd podczas ładowania danych. Spróbuj odświeżyć stronę.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('site_settings')
        .select('key, value')
        .in('key', [
          'contact_phone',
          'contact_email'
        ]);

      if (error) throw error;

      const settingsMap = data.reduce((acc, { key, value }) => {
        acc[key] = value;
        return acc;
      }, {} as Settings);

      setSettings(settingsMap);
    } catch (err) {
      console.error('Error fetching settings:', err);
    }
  };

  const performSearch = async (query: string) => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      setIsSearching(false);
      return;
    }

    setIsSearching(true);
    
    try {
      const { data: posts, error: searchError } = await supabase
        .from('blog_posts')
        .select(`
          *,
          category:category_id (
            name
          )
        `)
        .eq('is_published', true)
        .or(`title.ilike.%${query}%,content.ilike.%${query}%,excerpt.ilike.%${query}%`)
        .order('published_at', { ascending: false });

      if (searchError) throw searchError;

      // Transform posts data to include category name
      const transformedPosts = posts.map(post => ({
        ...post,
        category_name: post.category?.name
      }));

      setSearchResults(transformedPosts);
    } catch (err) {
      console.error('Error searching posts:', err);
      setError('Wystąpił błąd podczas wyszukiwania. Spróbuj ponownie.');
    }
  };

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const query = e.target.value;
    setSearchQuery(query);
    setIsSearching(!!query.trim());

    // Clear previous timeout
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    if (query.trim()) {
      // Set new timeout to perform search after 300ms of no typing
      setSearchTimeout(
        setTimeout(() => {
          performSearch(query);
        }, 300)
      );
    }
  };

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) return;

    setIsSubmitting(true);
    setSubmitStatus('idle');
    setErrorMessage('');

    try {
      const { error } = await supabase
        .from('newsletter_subscribers')
        .insert([{ email }]);

      if (error) {
        if (error.code === '23505') { // Unique violation
          throw new Error('Ten adres email jest już zapisany do newslettera.');
        }
        throw error;
      }
      
      // Send confirmation email
      const template = {
        subject: 'Dziękujemy za zapisanie się do newslettera StartJob.IT',
        message: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #4a3471;">Witaj w społeczności StartJob.IT!</h2>
            
            <p>Dziękujemy za zapisanie się do naszego newslettera.</p>
            
            <p>Od teraz będziesz otrzymywać:</p>
            <ul style="color: #666;">
              <li>Najnowsze oferty pracy w IT</li>
              <li>Artykuły i porady dla specjalistów</li>
              <li>Informacje o trendach w branży</li>
              <li>Zaproszenia na wydarzenia branżowe</li>
            </ul>
            
            <p style="margin-top: 30px; color: #666; font-size: 14px;">
              Pozdrawiamy,<br>
              Zespół StartJob.IT
            </p>
          </div>
        `
      };
      
      const emailSent = await sendEmail(email, template);
      if (!emailSent) {
        throw new Error('Nie udało się wysłać emaila potwierdzającego.');
      }

      setSubmitStatus('success');
      setEmail('');
    } catch (error) {
      console.error('Newsletter subscription error:', error);
      setSubmitStatus('error');
      setErrorMessage(error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie treści...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Wystąpił błąd
          </h2>
          <p className="text-purple-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Schema.org structured data for blog page */}
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Blog',
            'name': 'Blog StartJob.IT',
            'description': 'Blog StartJob.IT - Wiedza i Trendy dla Branży IT. Najnowsze artykuły, porady i informacje z branży IT.',
            'url': window.location.href,
            'publisher': {
              '@type': 'Organization',
              'name': 'StartJob.IT',
              'logo': {
                '@type': 'ImageObject',
                'url': 'https://startjob.it/logo.png'
              }
            },
            'blogPost': featuredPosts.map(post => ({
              '@type': 'BlogPosting',
              'headline': post.title,
              'description': post.excerpt,
              'image': post.thumbnail_url,
              'datePublished': post.published_at,
              'author': {
                '@type': 'Person',
                'name': post.author_name,
                'jobTitle': post.author_role
              },
              'url': `https://startjob.it/blog/${post.id}`
            }))
          })}
        </script>
      </Helmet>

      {/* Hero Section */}
      <div className="bg-gradient-hero text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="bg-yellow-400 bg-opacity-20 rounded-full p-4">
                <BookOpen className="w-12 h-12 text-yellow-400" />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Blog StartJob.IT
            </h1>
            <p className="text-xl text-purple-200">
              Wiedza i Trendy dla Branży IT
            </p>
          </div>
        </div>
      </div>

      {/* Search Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 relative z-10">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="max-w-2xl mx-auto">
            <div className="relative">
              <input
                type="text"
                placeholder="Szukaj artykułów..."
                value={searchQuery}
                onChange={handleSearchChange}
                className="w-full px-4 py-3 pl-12 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
              <Search className="absolute left-4 top-3.5 h-5 w-5 text-purple-400" />
            </div>
          </div>
        </div>
      </div>

      {/* Featured Articles */}
      {!isSearching ? (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <h2 className="text-3xl font-bold text-purple-900 mb-12">Polecane artykuły</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {featuredPosts.map((post) => (
              <Link
                key={post.id}
                to={`/blog/${post.id}`}
                className="bg-white rounded-2xl shadow-lg overflow-hidden transform hover:scale-102 transition-all duration-300"
              >
                <div className="relative h-48">
                  <img
                    src={post.thumbnail_url}
                    alt={post.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="bg-purple-600 text-white px-3 py-1 rounded-full text-sm">
                      {post.category_name}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-purple-900 mb-2">
                    {post.title}
                  </h3>
                  <p className="text-purple-600 mb-4">
                    {post.excerpt}
                  </p>
                  <div className="flex items-center justify-between text-sm">
                    <div className="flex items-center">
                      <img
                        src={post.author_avatar_url}
                        alt={post.author_name}
                        className="w-8 h-8 rounded-full mr-2"
                      />
                      <span className="text-purple-700">{post.author_name}</span>
                    </div>
                    <span className="text-purple-500">
                      {new Date(post.published_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      ) : (
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <h2 className="text-3xl font-bold text-purple-900 mb-4">
            Wyniki wyszukiwania
          </h2>
          <p className="text-purple-600 mb-8">
            Znaleziono {searchResults.length} {searchResults.length === 1 ? 'artykuł' : 'artykuły'} dla "{searchQuery}"
          </p>
          
          {searchResults.length > 0 ? (
            <div className="grid md:grid-cols-3 gap-8">
              {searchResults.map((post) => (
                <Link
                  key={post.id}
                  to={`/blog/${post.id}`}
                  className="bg-white rounded-2xl shadow-lg overflow-hidden transform hover:scale-102 transition-all duration-300"
                >
                  <div className="relative h-48">
                    <img
                      src={post.thumbnail_url}
                      alt={post.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="bg-purple-600 text-white px-3 py-1 rounded-full text-sm">
                        {post.category_name}
                      </span>
                    </div>
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-purple-900 mb-2">
                      {post.title}
                    </h3>
                    <p className="text-purple-600 mb-4">
                      {post.excerpt}
                    </p>
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center">
                        <img
                          src={post.author_avatar_url}
                          alt={post.author_name}
                          className="w-8 h-8 rounded-full mr-2"
                        />
                        <span className="text-purple-700">{post.author_name}</span>
                      </div>
                      <span className="text-purple-500">
                        {new Date(post.published_at).toLocaleDateString()}
                      </span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-2xl shadow-lg">
              <AlertCircle className="w-12 h-12 text-purple-400 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-purple-900 mb-2">
                Brak wyników
              </h3>
              <p className="text-purple-600">
                Nie znaleziono artykułów pasujących do zapytania "{searchQuery}"
              </p>
            </div>
          )}
        </div>
      )}

      {/* Categories */}
      <div className="bg-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-purple-900 mb-12">Kategorie Bloga</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categories.map((category) => (
              <Link
                key={category.id}
                to={`/blog/category/${category.id}`}
                className="bg-gradient-to-br from-purple-50 to-white rounded-2xl shadow-lg p-8 transform hover:scale-102 transition-all duration-300"
              >
                <div className="bg-purple-100 rounded-full p-4 inline-block mb-6">
                  <Star className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold text-purple-900 mb-3">
                  {category.name}
                </h3>
                <p className="text-purple-600 mb-4">
                  {category.post_count} {category.post_count === 1 ? 'artykuł' : 'artykuły'}
                </p>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Newsletter */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="bg-gradient-hero rounded-2xl text-white p-12">
          <form onSubmit={handleNewsletterSubmit} className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-6">
              Bądź na bieżąco z branżą IT!
            </h2>
            <p className="text-xl text-purple-200 mb-8">
              Zapisz się do naszego newslettera, aby otrzymywać najnowsze artykuły, 
              porady i informacje o trendach w branży IT.
            </p>
            <div className="flex flex-col md:flex-row gap-4 max-w-xl mx-auto">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="Twój adres email"
                required
                className="flex-1 px-6 py-3 rounded-xl bg-white bg-opacity-10 border border-purple-400 text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-yellow-400"
              />
              <button 
                type="submit"
                disabled={isSubmitting}
                className="bg-yellow-400 text-purple-900 px-8 py-3 rounded-xl hover:bg-yellow-300 transition-colors font-medium disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? 'Zapisywanie...' : 'Zapisz się'}
              </button>
            </div>
            {submitStatus === 'success' && (
              <div className="mt-4 flex items-center justify-center text-green-400">
                <CheckCircle2 className="w-5 h-5 mr-2" />
                <span>Dziękujemy za zapisanie się do newslettera!</span>
              </div>
            )}
            {submitStatus === 'error' && (
              <div className="mt-4 flex items-center justify-center text-red-400">
                <AlertCircle className="w-5 h-5 mr-2" />
                <span>{errorMessage || 'Wystąpił błąd. Spróbuj ponownie.'}</span>
              </div>
            )}
          </form>
        </div>
      </div>

      {/* Contact */}
      <div className="bg-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold text-purple-900 mb-8">
              Masz pytania lub sugestie?
            </h2>
            <div className="flex justify-center space-x-8">
              <a
                href={`mailto:${settings.contact_email}`}
                className="flex items-center text-purple-600 hover:text-purple-700"
              >
                <Mail className="w-6 h-6 mr-2" />
                {settings.contact_email}
              </a>
              <a
                href={`tel:${settings.contact_phone}`}
                className="flex items-center text-purple-600 hover:text-purple-700"
              >
                <Phone className="w-6 h-6 mr-2" />
                {settings.contact_phone}
              </a>
            </div>
          </div>
        </div>
      </div>
      
      {/* Outlet for nested routes */}
      <Outlet />
    </div>
  );
}