import React, { useState } from 'react';
import { Search, ArrowRight, MapPinned } from 'lucide-react';
import { useEffect } from 'react';
import { supabase } from '../lib/supabase';

type CompanyType = {
  id: string;
  name: string;
  code: string;
};

const technologiesCategories = {
  '🖥 Języki programowania i technologie front-end': [
    'JavaScript', 'TypeScript', 'HTML', 'CSS', 'React.js', 'Angular', 'Vue.js', 'Sass', 'Bootstrap'
  ],
  '🛠 Języki programowania i technologie back-end': [
    'Python', 'Java', 'C# (.NET)', 'C++', 'C', 'PHP', 'Ruby', 'Node.js', 'Express.js',
    'Go (Golang)', 'Scala', 'Elixir', 'Rust', 'Perl', 'Shell/Bash'
  ],
  '📱 Programowanie mobilne': [
    'Swift', 'Kotlin', 'React Native', 'Flutter', 'Objective-C', 'Dart'
  ],
  '🌐 Technologie chmurowe i DevOps': [
    'AWS', 'Microsoft Azure', 'Google Cloud Platform', 'Docker', 'Kubernetes', 'Terraform',
    'Ansible', 'Jenkins', 'Prometheus', 'Grafana'
  ],
  '🗄 Bazy danych i zarządzanie danymi': [
    'MySQL', 'PostgreSQL', 'MongoDB', 'Redis', 'Elasticsearch', 'SQLite', 'Firebase', 'Oracle'
  ],
  '🔌 API i technologie komunikacyjne': [
    'REST API', 'GraphQL', 'gRPC', 'SOAP'
  ],
  '🤖 Uczenie maszynowe i sztuczna inteligencja': [
    'TensorFlow', 'PyTorch', 'Scikit-Learn', 'OpenAI API', 'Apache Spark', 'Hadoop'
  ],
  '🔒 Bezpieczeństwo IT': [
    'SSL/TLS', 'OAuth', 'JWT', 'SIEM'
  ],
  '📊 Narzędzia do analizy danych': [
    'Power BI', 'Tableau', 'Jupyter Notebook', 'Apache Kafka'
  ],
  '🔧 Inne popularne technologie i narzędzia': [
    '.NET Core', 'Spring Boot', 'Laravel', 'WordPress', 'Selenium', 'Solidity', 'Unity', 'Blender'
  ],
  '📋 Zarządzanie projektami i współpraca': [
    'Git & GitHub', 'Jira', 'Confluence', 'Slack', 'Trello'
  ],
  '🚀 Technologie przyszłości': [
    'Blockchain', 'IoT', 'AR/VR', '5G'
  ]
};

type Category = {
  id: string;
  name: string;
  parent_id: string | null;
};

type WorkMode = {
  id: string;
  name: string;
  code: string;
};

type ExperienceLevel = {
  id: string;
  name: string;
  code: string;
};

type ContractType = {
  id: string;
  name: string;
  code: string;
};

type Benefit = {
  id: string;
  name: string;
  code: string;
  icon?: string;
};

type CategoryMap = {
  [key: string]: string[];
};

export type JobFilters = {
  search: string;
  location: {
    country: string;
    voivodeship: string;
    city: string;
  };
  categories: string[];
  workModes: string[];
  experienceLevels: string[];
  contractTypes: string[];
  technologies: string[];
  salaryRange: {
    from: number | null;
    to: number | null;
  };
  companyTypes: string[];
  benefits: string[];
  onlySalaryVisible: boolean;
};

type SearchFiltersProps = {
  onFiltersChange: (filters: JobFilters) => void;
  initialFilters?: JobFilters;
};

export default function SearchFilters({ onFiltersChange, initialFilters }: SearchFiltersProps) {
  const [categories, setCategories] = useState<Category[]>([]);
  const [workModes, setWorkModes] = useState<WorkMode[]>([]);
  const [companyTypes, setCompanyTypes] = useState<CompanyType[]>([]);
  const [experienceLevels, setExperienceLevels] = useState<ExperienceLevel[]>([]);
  const [contractTypes, setContractTypes] = useState<ContractType[]>([]);
  const [benefits, setBenefits] = useState<Benefit[]>([]);
  const [categoriesMap, setCategoriesMap] = useState<CategoryMap>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [
        { data: categoriesData },
        { data: workModesData },
        { data: experienceLevelsData },
        { data: contractTypesData },
        { data: benefitsData },
        { data: companyTypesData }
      ] = await Promise.all([
        supabase.from('job_categories').select('*').order('name'),
        supabase.from('working_modes').select('*').order('name'),
        supabase.from('experience_levels').select('*').order('name'),
        supabase.from('contract_types').select('*').order('name'),
        supabase.from('benefits').select('*').order('name'),
        supabase.from('company_sizes').select('*').order('name')
      ]);

      setCategories(categoriesData || []);
      setWorkModes(workModesData || []);
      setExperienceLevels(experienceLevelsData || []);
      setContractTypes(contractTypesData || []);
      setBenefits(benefitsData || []);
      setCompanyTypes(companyTypesData || []);

      // Create categories map
      const mainCategories = categoriesData?.filter(c => !c.parent_id) || [];
      const subCategories = categoriesData?.filter(c => c.parent_id) || [];
      
      const map: CategoryMap = {};
      mainCategories.forEach(main => {
        map[main.name] = subCategories
          .filter(sub => sub.parent_id === main.id)
          .map(sub => sub.name);
      });
      
      setCategoriesMap(map);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  const [filters, setFilters] = useState<JobFilters>(initialFilters || {
    search: '',
    location: {
      country: '',
      voivodeship: '',
      city: ''
    },
    categories: [],
    workModes: [],
    experienceLevels: [],
    contractTypes: [],
    technologies: [],
    salaryRange: {
      from: null,
      to: null
    },
    companyTypes: [],
    benefits: [],
    onlySalaryVisible: false
  });

  const updateFilters = (newFilters: Partial<JobFilters>) => {
    const updatedFilters = { ...filters, ...newFilters };
    setFilters(updatedFilters);
    onFiltersChange(updatedFilters);
  };

  const clearFilters = () => {
    const emptyFilters: JobFilters = {
      search: '',
      location: {
        country: '',
        voivodeship: '',
        city: ''
      },
      categories: [],
      workModes: [],
      experienceLevels: [],
      contractTypes: [],
      technologies: [],
      salaryRange: {
        from: null,
        to: null
      },
      companyTypes: [],
      benefits: [],
      onlySalaryVisible: false
    };
    setFilters(emptyFilters);
    onFiltersChange(emptyFilters);
  };

  return (
    <div className="space-y-6 bg-white lg:bg-transparent rounded-none lg:rounded-2xl">
      <div className="bg-white p-6 rounded-none lg:rounded-2xl shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-lg font-semibold text-purple-900">Filtruj oferty pracy</h2>
          <button 
            onClick={clearFilters}
            className="text-sm text-purple-700 hover:text-purple-900 font-medium"
          >
            Wyczyść filtry
          </button>
        </div>
        
        <div className="space-y-5">
          {/* Location Filter */}
          <div>
            <label className="flex items-center text-sm font-medium text-purple-900 mb-3 lg:mb-2">
              <MapPinned className="w-4 h-4 mr-2 text-purple-700" />
              Lokalizacja
            </label>
            <div className="space-y-3">
              {/* Country Selection */}
              <div>
                <select
                  className="w-full px-4 py-3 border border-purple-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-white text-purple-900"
                  value={filters.location.country}
                  onChange={(e) => {
                    updateFilters({
                      location: {
                        ...filters.location,
                        country: e.target.value,
                        voivodeship: e.target.value !== 'pl' ? '' : filters.location.voivodeship
                      }
                    });
                  }}
                >
                  <option value="">Wybierz kraj</option>
                  <option value="polska">Polska</option>
                  <option value="remote">Zdalnie</option>
                  <option value="abroad">Zagranica</option>
                </select>
              </div>
              
              {/* Voivodeship Selection */}
              <div>
                <select
                  id="wojewodztwo-select"
                  className="w-full px-4 py-3 border border-purple-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-white text-purple-900 disabled:bg-gray-100 disabled:text-gray-500"
                  disabled={filters.location.country !== 'polska'}
                  value={filters.location.voivodeship}
                  onChange={(e) => updateFilters({
                    location: { ...filters.location, voivodeship: e.target.value }
                  })}
                >
                  <option value="">Wybierz województwo</option>
                  <option value="dolnoslaskie">Dolnośląskie</option>
                  <option value="kujawsko-pomorskie">Kujawsko-pomorskie</option>
                  <option value="lubelskie">Lubelskie</option>
                  <option value="lubuskie">Lubuskie</option>
                  <option value="lodzkie">Łódzkie</option>
                  <option value="malopolskie">Małopolskie</option>
                  <option value="mazowieckie">Mazowieckie</option>
                  <option value="opolskie">Opolskie</option>
                  <option value="podkarpackie">Podkarpackie</option>
                  <option value="podlaskie">Podlaskie</option>
                  <option value="pomorskie">Pomorskie</option>
                  <option value="slaskie">Śląskie</option>
                  <option value="swietokrzyskie">Świętokrzyskie</option>
                  <option value="warminsko-mazurskie">Warmińsko-mazurskie</option>
                  <option value="wielkopolskie">Wielkopolskie</option>
                  <option value="zachodniopomorskie">Zachodniopomorskie</option>
                </select>
              </div>
              
              {/* City Input */}
              <div>
                <input
                  type="text"
                  placeholder="Wpisz nazwę miejscowości"
                  value={filters.location.city}
                  onChange={(e) => updateFilters({
                    location: { ...filters.location, city: e.target.value }
                  })}
                  className="w-full px-4 py-3 border border-purple-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-white text-purple-900"
                />
              </div>
            </div>
          </div>

          {/* Job Categories */}
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-3 lg:mb-2">
              Kategorie ofert pracy
            </label>
            <div className="space-y-2 max-h-[60vh] lg:max-h-96 overflow-y-auto">
              {Object.entries(categoriesMap).map(([category, subcategories]) => (
                <div key={category} className="border border-purple-100 rounded-xl overflow-hidden">
                  <button
                    className="w-full px-4 py-3 text-left bg-purple-50 hover:bg-purple-100 flex justify-between items-center"
                    onClick={(e) => {
                      const content = e.currentTarget.nextElementSibling;
                      if (content) {
                        content.style.display = content.style.display === 'none' ? 'block' : 'none';
                      }
                    }}
                  >
                    <span className="font-medium text-purple-900">{category}</span>
                    <ArrowRight className="w-4 h-4 min-w-[16px] min-h-[16px] transform transition-transform text-purple-700" />
                  </button>
                  <div className="p-4 border-t border-purple-100" style={{ display: 'none' }}>
                    {subcategories.map((subcat) => (
                      <label key={subcat} className="flex items-center py-1.5">
                        <input
                          type="checkbox"
                          checked={filters.categories.includes(subcat)}
                          onChange={(e) => {
                            const newCategories = e.target.checked
                              ? [...filters.categories, subcat]
                              : filters.categories.filter(cat => cat !== subcat);
                            updateFilters({ categories: newCategories });
                          }}
                          className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                        />
                        <span className="ml-2 text-sm text-purple-800">{subcat}</span>
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Search */}
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-3 lg:mb-2">
              Słowo kluczowe
            </label>
            <div className="relative">
              <input
                type="text"
                placeholder="Stanowisko, technologia, firma..."
                value={filters.search}
                onChange={(e) => updateFilters({ search: e.target.value })}
                className="w-full px-4 py-3 border border-purple-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              />
              <Search className="absolute right-3 top-3 h-5 w-5 text-purple-400" />
            </div>
          </div>

          {/* Work Mode */}
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-3 lg:mb-2">
              Tryb pracy
            </label>
            <div className="space-y-2">
              {workModes.map((mode: WorkMode) => (
                <label key={mode.id} className="flex items-center py-1">
                  <input
                    type="checkbox"
                    checked={filters.workModes.includes(mode.code)}
                    onChange={(e) => {
                      const newModes = e.target.checked
                        ? [...filters.workModes, mode.code]
                        : filters.workModes.filter(m => m !== mode.code);
                      updateFilters({ workModes: newModes });
                    }}
                    className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                  />
                  <span className="ml-2 text-sm text-purple-800">{mode.name}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Experience Level */}
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-3 lg:mb-2">
              Poziom doświadczenia
            </label>
            <div className="space-y-2">
              {experienceLevels.map((level: ExperienceLevel) => (
                <label key={level.id} className="flex items-center py-1">
                  <input
                    type="checkbox"
                    checked={filters.experienceLevels.includes(level.code)}
                    onChange={(e) => {
                      const newLevels = e.target.checked
                        ? [...filters.experienceLevels, level.code]
                        : filters.experienceLevels.filter(l => l !== level.code);
                      updateFilters({ experienceLevels: newLevels });
                    }}
                    className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                  />
                  <span className="ml-2 text-sm text-purple-800">{level.name}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Employment Type */}
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-3 lg:mb-2">
              Typ umowy
            </label>
            <div className="space-y-2">
              {contractTypes.map((type: ContractType) => (
                <label key={type.id} className="flex items-center py-1">
                  <input
                    type="checkbox"
                    checked={filters.contractTypes.includes(type.code)}
                    onChange={(e) => {
                      const newTypes = e.target.checked
                        ? [...filters.contractTypes, type.code]
                        : filters.contractTypes.filter(t => t !== type.code);
                      updateFilters({ contractTypes: newTypes });
                    }}
                    className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                  />
                  <span className="ml-2 text-sm text-purple-800">{type.name}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Technologies */}
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-3 lg:mb-2">
              Technologie
            </label>
            <div className="space-y-2">
              <input
                type="text"
                placeholder="Szukaj technologii..."
                value={filters.search}
                onChange={(e) => updateFilters({ search: e.target.value })}
                className="w-full px-4 py-3 border border-purple-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 mb-2 text-purple-900"
              />
              <div className="space-y-2 max-h-96 overflow-y-auto pr-2">
                {Object.entries(technologiesCategories).map(([category, techs]) => (
                  <div key={category} className="border border-purple-100 rounded-xl overflow-hidden">
                    <button
                      className="w-full px-4 py-3 text-left bg-purple-50 hover:bg-purple-100 flex justify-between items-center"
                      onClick={(e) => {
                        const content = e.currentTarget.nextElementSibling;
                        if (content) {
                          content.style.display = content.style.display === 'none' ? 'block' : 'none';
                        }
                      }}
                    >
                      <span className="font-medium text-purple-900">{category}</span>
                      <ArrowRight className="w-4 h-4 min-w-[16px] min-h-[16px] transform transition-transform text-purple-700" />
                    </button>
                    <div className="p-4 border-t border-purple-100" style={{ display: 'none' }}>
                      {techs.map((tech) => (
                        <label key={tech} className="flex items-center py-1.5">
                          <input
                            type="checkbox"
                            checked={filters.technologies.includes(tech)}
                            onChange={(e) => {
                              const newTechs = e.target.checked
                                ? [...filters.technologies, tech]
                                : filters.technologies.filter(t => t !== tech);
                              updateFilters({ technologies: newTechs });
                            }}
                            className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                          />
                          <span className="ml-2 text-sm text-purple-800">{tech}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Salary Range */}
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-3 lg:mb-2">
              Wynagrodzenie (PLN)
            </label>
            <div className="space-y-3">
              <div className="flex gap-4">
                <input
                  type="number"
                  placeholder="Od"
                  value={filters.salaryRange.from || ''}
                  onChange={(e) => updateFilters({
                    salaryRange: {
                      ...filters.salaryRange,
                      from: e.target.value ? parseInt(e.target.value) : null
                    }
                  })}
                  className="w-full px-3 py-3 border border-purple-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
                <input
                  type="number"
                  placeholder="Do"
                  value={filters.salaryRange.to || ''}
                  onChange={(e) => updateFilters({
                    salaryRange: {
                      ...filters.salaryRange,
                      to: e.target.value ? parseInt(e.target.value) : null
                    }
                  })}
                  className="w-full px-3 py-3 border border-purple-200 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
              </div>
              <label className="flex items-center">
                <input
                  type="checkbox"
                  checked={filters.onlySalaryVisible}
                  onChange={(e) => updateFilters({ onlySalaryVisible: e.target.checked })}
                  className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                />
                <span className="ml-2 text-sm text-purple-600">
                  Tylko oferty z widełkami
                </span>
              </label>
            </div>
          </div>

          {/* Company Type */}
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-3 lg:mb-2">
              Typ firmy
            </label>
            <div className="space-y-2">
              {companyTypes.map((type) => (
                <label key={type.id} className="flex items-center py-1">
                  <input
                    type="checkbox"
                    checked={filters.companyTypes.includes(type.code)}
                    onChange={(e) => {
                      const newTypes = e.target.checked
                        ? [...filters.companyTypes, type.code]
                        : filters.companyTypes.filter(t => t !== type.code);
                      updateFilters({ companyTypes: newTypes });
                    }}
                    className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                  />
                  <span className="ml-2 text-sm text-purple-800">{type.name}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Benefits */}
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-3 lg:mb-2">
              Benefity
            </label>
            <div className="space-y-2">
              {benefits.map((benefit: Benefit) => (
                <label key={benefit.id} className="flex items-center py-1">
                  <input
                    type="checkbox"
                    checked={filters.benefits.includes(benefit.code)}
                    onChange={(e) => {
                      const newBenefits = e.target.checked
                        ? [...filters.benefits, benefit.code]
                        : filters.benefits.filter(b => b !== benefit.code);
                      updateFilters({ benefits: newBenefits });
                    }}
                    className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                  />
                  <span className="ml-2 text-sm text-purple-800">{benefit.name}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Save Search */}
          <div className="pt-4 border-t border-purple-100">
            <button className="w-full bg-purple-700 text-white px-4 py-3 rounded-xl hover:bg-purple-800 transition-colors font-medium">
              Zapisz wyszukiwanie
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}