import React from 'react';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Mail, Phone, Target, Video, Globe, Users, Search, Facebook, Star } from 'lucide-react';
import { supabase } from '../lib/supabase';

type Settings = {
  contact_phone: string;
  contact_email: string;
  promotion_services: Array<{
    id: string;
    name: string;
    price: number;
  }>;
};

const promotionStats = [
  { value: '20 000+', label: 'aktywnych specjalistów IT' },
  { value: '94%', label: 'skuteczność kampanii' },
  { value: '72h', label: 'średni czas rekrutacji' }
];

const serviceIcons = {
  'advertising-campaigns': <Target className="w-6 h-6" />,
  'video-listing': <Video className="w-6 h-6" />,
  'geo-targeted': <Globe className="w-6 h-6" />,
  'headhunting-premium': <Search className="w-6 h-6" />,
  'email-marketing': <Mail className="w-6 h-6" />,
  'social-pack': <Facebook className="w-6 h-6" />
};

const serviceFeatures = {
  'advertising-campaigns': [
    'Reklamy w social mediach (Facebook, Instagram, LinkedIn)',
    'Kampanie Google Ads i YouTube',
    'Precyzyjne targetowanie do programistów',
    'Profesjonalne projekty graficzne',
    'Raportowanie wyników kampanii'
  ],
  'video-listing': [
    'Produkcja dynamicznego 30-60 sekundowego wideo',
    'Profesjonalny montaż i grafika',
    'Publikacja w social mediach i na stronie',
    'Min. 15 000 wyświetleń',
    'Możliwość wykorzystania na stronie WWW'
  ],
  'geo-targeted': [
    'Zasięg reklam od 1 do 10 km od Twojego biura',
    'Targetowanie po specjalizacji',
    'Reklamy display oraz w social mediach',
    'Raportowanie wyników i optymalizacja kampanii'
  ],
  'headhunting-premium': [
    'Do 10 wyselekcjonowanych kandydatów',
    'Weryfikacja doświadczenia i umiejętności',
    'Wstępne rozmowy kwalifikacyjne',
    'Rekomendacje najlepszych specjalistów IT',
    'Wsparcie w całym procesie rekrutacji'
  ],
  'email-marketing': [
    'Wysyłka do bazy aktywnych programistów',
    'Personalizowane wiadomości',
    'Profesjonalnie zaprojektowany mailing',
    'Raport z wysyłki i efektywności kampanii',
    'Możliwość follow-upu'
  ],
  'social-pack': [
    'Publikacja na profilu StartJob.IT',
    'Promocja w branżowych grupach',
    'Minimum 15 000 wyświetleń',
    'Optymalizacja treści i grafiki',
    'Raportowanie wyników kampanii'
  ]
};

const highlightedServices = ['headhunting-premium'];

export default function PromotionServices() {
  const [settings, setSettings] = useState<Settings>({
    contact_phone: '',
    contact_email: '',
    promotion_services: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('site_settings')
        .select('key, value')
        .in('key', [
          'contact_phone',
          'contact_email',
          'promotion_services'
        ]);

      if (error) throw error;

      const settingsMap = data.reduce((acc, { key, value }) => {
        acc[key] = value;
        return acc;
      }, {} as Settings);

      setSettings(settingsMap);
    } catch (err) {
      console.error('Error fetching settings:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Schema.org structured data for promotion services page */}
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Service',
            'name': 'Usługi Promocji StartJob.IT',
            'description': 'Usługi promocji ogłoszeń o pracę w IT. Zwiększ widoczność swoich ofert pracy.',
            'provider': {
              '@type': 'Organization',
              'name': 'StartJob.IT',
              'url': 'https://startjob.it'
            },
            'serviceType': 'Job Promotion Service',
            'offers': settings.promotion_services?.map(service => ({
              '@type': 'Offer',
              'name': service.name,
              'price': service.price,
              'priceCurrency': 'PLN',
              'availability': 'https://schema.org/InStock'
            })) || []
          })}
        </script>
      </Helmet>

      {/* Hero Section */}
      <div className="bg-gradient-hero text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="bg-yellow-400 bg-opacity-20 rounded-full p-4">
                <Star className="w-12 h-12 text-yellow-400" />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Usługi Promocji
            </h1>
            <p className="text-xl text-purple-200">
              Maksymalna Widoczność Twojego Ogłoszenia na StartJob.IT!
            </p>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 relative z-10">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="grid md:grid-cols-3 gap-8">
            {promotionStats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl font-bold text-purple-900 mb-2">{stat.value}</div>
                <div className="text-purple-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Services Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {settings.promotion_services.map((service) => (
            <div
              key={service.id}
              className={`bg-white rounded-2xl shadow-lg p-8 ${
                highlightedServices.includes(service.id)
                  ? 'ring-2 ring-purple-500 transform hover:scale-105'
                  : 'transform hover:scale-102'
              } transition-all duration-300`}
            >
              <div className="flex items-start justify-between mb-6">
                <div className="bg-purple-100 rounded-full p-3">
                  {serviceIcons[service.id as keyof typeof serviceIcons]}
                </div>
                {highlightedServices.includes(service.id) && (
                  <span className="bg-purple-100 text-purple-700 text-sm font-medium px-3 py-1 rounded-full">
                    Polecane
                  </span>
                )}
              </div>
              <h3 className="text-xl font-bold text-purple-900 mb-4">{service.name}</h3>
              <div className="mb-6">
                <span className="text-3xl font-bold text-purple-900">{service.price}</span>
                <span className="text-purple-600 ml-2">zł netto</span>
              </div>
              <ul className="space-y-3">
                {serviceFeatures[service.id as keyof typeof serviceFeatures]?.map((feature, featureIndex) => (
                  <li key={featureIndex} className="flex items-start">
                    <Star className="w-5 h-5 text-yellow-400 mr-3 flex-shrink-0 mt-1" />
                    <span className="text-purple-700">{feature}</span>
                  </li>
                ))}
              </ul>
              <Link 
                to="/kontakt" 
                className="w-full mt-8 bg-purple-600 text-white rounded-xl py-3 font-medium hover:bg-purple-700 transition-colors inline-block text-center"
              >
                Zamów teraz
              </Link>
            </div>
          ))}
        </div>
      </div>

      {/* Contact Section */}
      <div className="bg-gradient-hero text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-8">Zwiększ skuteczność swojej rekrutacji!</h2>
            <p className="text-xl text-purple-200 mb-12">
              Skontaktuj się z nami, aby dobrać najlepszą strategię promocji Twoich ofert pracy!
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 sm:gap-8">
              <a
                href={`mailto:${settings.contact_email}`}
                className="flex items-center justify-center bg-white bg-opacity-10 rounded-xl px-6 py-4 hover:bg-opacity-20 transition-colors w-full sm:w-auto"
              >
                <Mail className="w-6 h-6 mr-3" />
                <span>{settings.contact_email}</span>
              </a>
              <a
                href={`tel:${settings.contact_phone}`}
                className="flex items-center justify-center bg-white bg-opacity-10 rounded-xl px-6 py-4 hover:bg-opacity-20 transition-colors w-full sm:w-auto"
              >
                <Phone className="w-6 h-6 mr-3" />
                <span>{settings.contact_phone}</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}