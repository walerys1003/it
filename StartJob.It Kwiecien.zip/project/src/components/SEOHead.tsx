import React, { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { supabase } from '../lib/supabase';

type SEOPage = {
  title: string;
  description: string;
  keywords: string;
  og_title: string;
  og_description: string;
  og_image: string;
  og_type: string;
  schema_type: string;
  schema_data: any;
};

// Default SEO values
const defaultSEO: SEOPage = {
  title: 'StartJob.IT - Znajdź swoją wymarzoną pracę w IT',
  description: 'StartJob.IT to platforma łącząca specjalistów IT z najlepszymi pracodawcami. Znajdź swoją wymarzoną pracę w branży IT.',
  keywords: 'praca IT, oferty pracy, programista, developer, IT jobs',
  og_title: 'StartJob.IT - Znajdź swoją wymarzoną pracę w IT',
  og_description: 'StartJob.IT to platforma łącząca specjalistów IT z najlepszymi pracodawcami. Znajdź swoją wymarzoną pracę w branży IT.',
  og_image: '',
  og_type: 'website',
  schema_type: 'WebPage',
  schema_data: {}
};

export default function SEOHead() {
  const location = useLocation();
  const [seo, setSEO] = useState<SEOPage>(defaultSEO);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchSEO = async () => {
      try {
        setLoading(true);
        
        // Try to get SEO data for current path
        const { data, error } = await supabase
          .from('seo_pages')
          .select('*')
          .eq('path', location.pathname)
          .maybeSingle();

        if (error) {
          console.error('Error fetching SEO data:', error);
          return;
        }

        if (data) {
          setSEO(data);
        } else {
          // If no specific SEO data for this path, try to get homepage data as fallback
          const { data: homeData } = await supabase
            .from('seo_pages')
            .select('*')
            .eq('path', '/')
            .maybeSingle();

          if (homeData) {
            // Use home data but with current path in title
            const pathName = location.pathname.substring(1) || 'Home';
            const formattedPathName = pathName.charAt(0).toUpperCase() + pathName.slice(1);
            
            setSEO({
              ...homeData,
              title: `${formattedPathName} | StartJob.IT`,
              og_title: `${formattedPathName} | StartJob.IT`
            });
          } else {
            // Fallback to defaults
            setSEO(defaultSEO);
          }
        }
      } catch (err) {
        console.error('Error in SEO component:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchSEO();
  }, [location.pathname]);

  if (loading) {
    return null;
  }

  // Prepare schema.org JSON-LD
  const schemaData = {
    '@context': 'https://schema.org',
    '@type': seo.schema_type,
    ...(seo.schema_data || {})
  };

  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{seo.title}</title>
      <meta name="description" content={seo.description} />
      {seo.keywords && <meta name="keywords" content={seo.keywords} />}
      
      {/* OpenGraph Tags */}
      <meta property="og:title" content={seo.og_title || seo.title} />
      <meta property="og:description" content={seo.og_description || seo.description} />
      <meta property="og:type" content={seo.og_type} />
      <meta property="og:url" content={window.location.href} />
      {seo.og_image && <meta property="og:image" content={seo.og_image} />}
      
      {/* Twitter Card Tags */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={seo.og_title || seo.title} />
      <meta name="twitter:description" content={seo.og_description || seo.description} />
      {seo.og_image && <meta name="twitter:image" content={seo.og_image} />}
      
      {/* Schema.org JSON-LD */}
      <script type="application/ld+json">
        {JSON.stringify(schemaData)}
      </script>
    </Helmet>
  );
}