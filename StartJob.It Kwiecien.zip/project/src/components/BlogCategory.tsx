import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { 
  Loader2, AlertCircle, ArrowLeft, Calendar, User,
  BookOpen, ChevronRight
} from 'lucide-react';
import { supabase } from '../lib/supabase';

type BlogPost = {
  id: string;
  title: string;
  subtitle: string;
  excerpt: string;
  thumbnail_url: string;
  author_name: string;
  author_role: string;
  author_avatar_url: string;
  published_at: string;
  is_featured: boolean;
};

type Category = {
  id: string;
  name: string;
  type: string;
  post_count?: number;
};

export default function BlogCategory() {
  const { categoryId } = useParams();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [category, setCategory] = useState<Category | null>(null);

  useEffect(() => {
    const fetchCategoryAndPosts = async () => {
      try {
        // Fetch category details
        const { data: categoryData, error: categoryError } = await supabase
          .from('blog_taxonomies')
          .select('*')
          .eq('id', categoryId)
          .single();

        if (categoryError) throw categoryError;
        setCategory(categoryData);

        // Fetch posts in this category
        const { data: postsData, error: postsError } = await supabase
          .from('blog_posts')
          .select('*')
          .eq('category_id', categoryId)
          .eq('is_published', true)
          .order('published_at', { ascending: false });

        if (postsError) throw postsError;
        setPosts(postsData);

      } catch (err) {
        console.error('Error fetching category data:', err);
        setError('Wystąpił błąd podczas ładowania danych. Spróbuj odświeżyć stronę.');
      } finally {
        setLoading(false);
      }
    };

    if (categoryId) {
      fetchCategoryAndPosts();
    }
  }, [categoryId]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie treści...</p>
        </div>
      </div>
    );
  }

  if (error || !category) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Nie znaleziono kategorii
          </h2>
          <p className="text-purple-600">{error || 'Kategoria nie istnieje.'}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Schema.org structured data for blog category page */}
      {category && (
        <Helmet>
          <title>{category.name} - Blog StartJob.IT</title>
          <meta name="description" content={`Artykuły z kategorii ${category.name} na blogu StartJob.IT. Wiedza i trendy dla branży IT.`} />
          <meta name="keywords" content={`${category.name}, blog IT, artykuły, trendy IT, kariera IT`} />
          
          {/* OpenGraph Tags */}
          <meta property="og:title" content={`${category.name} - Blog StartJob.IT`} />
          <meta property="og:description" content={`Artykuły z kategorii ${category.name} na blogu StartJob.IT. Wiedza i trendy dla branży IT.`} />
          <meta property="og:type" content="website" />
          <meta property="og:url" content={window.location.href} />
          
          {/* Schema.org JSON-LD */}
          <script type="application/ld+json">
            {JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'CollectionPage',
              'name': `${category.name} - Blog StartJob.IT`,
              'description': `Artykuły z kategorii ${category.name} na blogu StartJob.IT`,
              'url': window.location.href,
              'publisher': {
                '@type': 'Organization',
                'name': 'StartJob.IT',
                'logo': {
                  '@type': 'ImageObject',
                  'url': 'https://startjob.it/logo.png'
                }
              },
              'mainEntity': {
                '@type': 'ItemList',
                'itemListElement': posts.map((post, index) => ({
                  '@type': 'ListItem',
                  'position': index + 1,
                  'item': {
                    '@type': 'BlogPosting',
                    'headline': post.title,
                    'description': post.excerpt,
                    'image': post.thumbnail_url,
                    'datePublished': post.published_at,
                    'author': {
                      '@type': 'Person',
                      'name': post.author_name
                    },
                    'url': `https://startjob.it/blog/${post.id}`
                  }
                }))
              }
            })}
          </script>
        </Helmet>
      )}

      {/* Hero Section */}
      <div className="bg-gradient-hero text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="bg-yellow-400 bg-opacity-20 rounded-full p-4">
                <BookOpen className="w-12 h-12 text-yellow-400" />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              {category.name}
            </h1>
            <p className="text-xl text-purple-200">
              {posts.length} {posts.length === 1 ? 'artykuł' : 'artykuły'} w tej kategorii
            </p>
          </div>
        </div>
      </div>

      {/* Breadcrumbs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center space-x-2 text-sm text-purple-600">
          <Link to="/blog" className="hover:text-purple-900 flex items-center">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Blog
          </Link>
          <ChevronRight className="w-4 h-4" />
          <span>{category.name}</span>
        </div>
      </div>

      {/* Posts Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        <div className="grid md:grid-cols-3 gap-8">
          {posts.map((post) => (
            <Link
              key={post.id}
              to={`/blog/${post.id}`}
              className="bg-white rounded-2xl shadow-lg overflow-hidden transform hover:scale-102 transition-all duration-300"
            >
              <div className="relative h-48">
                <img
                  src={post.thumbnail_url}
                  alt={post.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-purple-900 mb-2">
                  {post.title}
                </h3>
                <p className="text-purple-600 mb-4">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center">
                    <img
                      src={post.author_avatar_url}
                      alt={post.author_name}
                      className="w-8 h-8 rounded-full mr-2"
                    />
                    <span className="text-purple-700">{post.author_name}</span>
                  </div>
                  <span className="text-purple-500">
                    {new Date(post.published_at).toLocaleDateString()}
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>

        {posts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-purple-600">
              Brak artykułów w tej kategorii.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}