import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  Calendar, Clock, User, Share2, Facebook, Twitter, Linkedin, 
  BookOpen, ArrowLeft, MessageSquare, ThumbsUp, Bookmark,
  Tag, ChevronRight, Loader2, AlertCircle
} from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { supabase } from '../lib/supabase';

// Calculate reading time based on content length
const calculateReadingTime = (content: string): string => {
  const wordsPerMinute = 200;
  const wordCount = content.trim().split(/\s+/).length;
  const minutes = Math.ceil(wordCount / wordsPerMinute);
  return `${minutes} min`;
};

type BlogPost = {
  id: string;
  title: string;
  subtitle: string;
  content: string;
  thumbnail_url: string;
  author_name: string;
  author_role: string;
  author_avatar_url: string;
  published_at: string;
  category_id: string;
  category_name?: string;
  tags?: { id: string; name: string; }[];
  seo_title?: string;
  seo_description?: string;
  seo_keywords?: string;
  og_title?: string;
  og_description?: string;
  og_image?: string;
  schema_type?: string;
  schema_data?: any;
  excerpt?: string;
};

export default function BlogPost() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [post, setPost] = useState<BlogPost | null>(null);
  const [relatedPosts, setRelatedPosts] = useState<BlogPost[]>([]);

  useEffect(() => {
    const fetchPost = async () => {
      try {
        // Fetch post with its category name
        const { data: postData, error: postError } = await supabase
          .from('blog_posts')
          .select(`
            *,
            category:category_id (
              name
            )
          `)
          .eq('id', id)
          .single();

        if (postError) throw postError;

        // Fetch post tags
        const { data: tagsData, error: tagsError } = await supabase
          .from('blog_post_tags')
          .select(`
            tag:tag_id (
              id,
              name
            )
          `)
          .eq('post_id', id);

        if (tagsError) throw tagsError;

        // Transform post data
        const transformedPost = {
          ...postData,
          category_name: postData.category?.name,
          tags: tagsData?.map(t => t.tag)
        };

        setPost(transformedPost);

        // Fetch related posts from the same category
        if (postData.category_id) {
          const { data: relatedData, error: relatedError } = await supabase
            .from('blog_posts')
            .select('*')
            .eq('category_id', postData.category_id)
            .eq('is_published', true)
            .neq('id', id)
            .order('published_at', { ascending: false })
            .limit(2);

          if (relatedError) throw relatedError;
          setRelatedPosts(relatedData);
        }
      } catch (err) {
        console.error('Error fetching blog post:', err);
        setError('Wystąpił błąd podczas ładowania artykułu. Spróbuj odświeżyć stronę.');
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchPost();
    }
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie artykułu...</p>
        </div>
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Nie znaleziono artykułu
          </h2>
          <p className="text-purple-600">{error || 'Artykuł nie istnieje lub został usunięty.'}</p>
        </div>
      </div>
    );
  }

  // Prepare schema data
  const schemaData = {
    '@context': 'https://schema.org',
    '@type': post.schema_type || 'BlogPosting',
    'headline': post.title,
    'description': post.excerpt || post.subtitle,
    'image': post.thumbnail_url,
    'datePublished': post.published_at,
    'dateModified': post.updated_at,
    'author': {
      '@type': 'Person',
      'name': post.author_name,
      'jobTitle': post.author_role,
      'image': post.author_avatar_url
    },
    'publisher': {
      '@type': 'Organization',
      'name': 'StartJob.IT',
      'logo': {
        '@type': 'ImageObject',
        'url': 'https://startjob.it/logo.png'
      }
    },
    'mainEntityOfPage': {
      '@type': 'WebPage',
      '@id': window.location.href
    },
    ...(post.schema_data || {})
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Schema.org structured data for blog post */}
        <Helmet>
          <title>{post.seo_title || `${post.title} | Blog StartJob.IT`}</title>
          <meta name="description" content={post.seo_description || post.excerpt || post.subtitle || ''} />
          {post.seo_keywords && <meta name="keywords" content={post.seo_keywords} />}
          
          {/* OpenGraph Tags */}
          <meta property="og:title" content={post.og_title || `${post.title} | Blog StartJob.IT`} />
          <meta property="og:description" content={post.og_description || post.excerpt || post.subtitle || ''} />
          <meta property="og:type" content="article" />
          <meta property="og:url" content={window.location.href} />
          {(post.og_image || post.thumbnail_url) && <meta property="og:image" content={post.og_image || post.thumbnail_url} />}
          
          <script type="application/ld+json">
            {JSON.stringify(schemaData)}
          </script>
        </Helmet>

        {/* Breadcrumbs */}
        <div className="flex items-center space-x-2 text-sm text-purple-600 mb-8">
          <Link to="/blog" className="hover:text-purple-900 flex items-center">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Powrót do bloga
          </Link>
          <ChevronRight className="w-4 h-4" />
          <Link 
            to={`/blog/category/${post.category_id}`} 
            className="hover:text-purple-900"
          >
            {post.category_name}
          </Link>
        </div>

        {/* Article Header */}
        <header className="mb-12">
          <div className="flex items-center space-x-4 mb-6">
            <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium">
              {post.category_name}
            </span>
            <div className="flex items-center text-purple-600 text-sm">
              <Clock className="w-4 h-4 mr-1" />
              {calculateReadingTime(post.content)} czytania
            </div>
          </div>
          
          <h1 className="text-4xl font-bold text-purple-900 mb-4">
            {post.title}
          </h1>
          {post.subtitle && (
            <p className="text-xl text-purple-700 mb-8">
              {post.subtitle}
            </p>
          )}

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <img
                src={post.author_avatar_url}
                alt={post.author_name}
                className="w-12 h-12 rounded-full"
              />
              <div>
                <div className="font-medium text-purple-900">{post.author_name}</div>
                <div className="text-sm text-purple-600">{post.author_role}</div>
              </div>
            </div>
            <div className="flex items-center space-x-2 text-purple-600">
              <Calendar className="w-5 h-5" />
              <span>{new Date(post.published_at).toLocaleDateString()}</span>
            </div>
          </div>
        </header>

        {/* Featured Image */}
        <div className="relative h-96 rounded-2xl overflow-hidden mb-12">
          <img
            src={post.thumbnail_url}
            alt={post.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Article Content */}
        <article className="prose prose-purple max-w-none mb-12">
          <div dangerouslySetInnerHTML={{ __html: post.content }} />
        </article>

        {/* Tags */}
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-12">
            {post.tags.map((tag) => (
              <span
                key={tag.id}
                className="bg-purple-50 text-purple-700 px-3 py-1 rounded-full text-sm flex items-center"
              >
                <Tag className="w-4 h-4 mr-1" />
                {tag.name}
              </span>
            ))}
          </div>
        )}

        {/* Share and Actions */}
        <div className="flex items-center justify-between py-6 border-t border-b border-purple-100 mb-12">
          <div className="flex items-center space-x-4">
            <button className="text-purple-600 hover:text-purple-900">
              <ThumbsUp className="w-6 h-6" />
            </button>
            <button className="text-purple-600 hover:text-purple-900">
              <Bookmark className="w-6 h-6" />
            </button>
            <button className="text-purple-600 hover:text-purple-900">
              <MessageSquare className="w-6 h-6" />
            </button>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-purple-600">Udostępnij:</span>
            <button className="text-blue-600 hover:text-blue-700">
              <Facebook className="w-5 h-5" />
            </button>
            <button className="text-blue-400 hover:text-blue-500">
              <Twitter className="w-5 h-5" />
            </button>
            <button className="text-blue-700 hover:text-blue-800">
              <Linkedin className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Related Posts */}
        {relatedPosts.length > 0 && (
          <div className="mb-12">
            <h2 className="text-2xl font-bold text-purple-900 mb-6">
              Podobne artykuły
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {relatedPosts.map((relatedPost) => (
                <Link
                  key={relatedPost.id}
                  to={`/blog/${relatedPost.id}`}
                  className="group block bg-white rounded-xl shadow-lg overflow-hidden transform hover:scale-102 transition-all duration-300"
                >
                  <div className="relative h-48">
                    <img
                      src={relatedPost.thumbnail_url}
                      alt={relatedPost.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-purple-900 mb-2">
                      {relatedPost.title}
                    </h3>
                    <div className="flex items-center justify-between text-sm text-purple-600">
                      <span>{relatedPost.author_name}</span>
                      <span>{new Date(relatedPost.published_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}