import React, { useState, useEffect } from 'react';
import { X, Shield, BarChart3, Target } from 'lucide-react';
import { Link } from 'react-router-dom';

type CookieSettings = {
  necessary: boolean;
  analytics: boolean;
  marketing: boolean;
};

export default function CookieConsent() {
  const [isVisible, setIsVisible] = useState(false);
  const [showDetails, setShowDetails] = useState(false);
  const [settings, setSettings] = useState<CookieSettings>({
    necessary: true, // Always true and cannot be changed
    analytics: false,
    marketing: false
  });

  useEffect(() => {
    // Check if user has already set cookie preferences
    const savedSettings = localStorage.getItem('cookieSettings');
    if (!savedSettings) {
      setIsVisible(true);
    } else {
      setSettings(JSON.parse(savedSettings));
    }
  }, []);

  const handleAcceptAll = () => {
    const newSettings = {
      necessary: true,
      analytics: true,
      marketing: true
    };
    localStorage.setItem('cookieSettings', JSON.stringify(newSettings));
    setSettings(newSettings);
    setIsVisible(false);
  };

  const handleSavePreferences = () => {
    localStorage.setItem('cookieSettings', JSON.stringify(settings));
    setIsVisible(false);
  };

  const handleRejectOptional = () => {
    const newSettings = {
      necessary: true,
      analytics: false,
      marketing: false
    };
    localStorage.setItem('cookieSettings', JSON.stringify(newSettings));
    setSettings(newSettings);
    setIsVisible(false);
  };

  if (!isVisible) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-white rounded-t-2xl sm:rounded-2xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-xl font-semibold text-purple-900">Ustawienia prywatności</h2>
            <button
              onClick={() => setIsVisible(false)}
              className="p-1 text-purple-400 hover:text-purple-600 rounded-lg"
              aria-label="Zamknij"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="text-purple-700 mb-6">
            Szanujemy Twoją prywatność. Używamy plików cookie i podobnych technologii na naszej
            stronie, aby zapewnić Ci najlepsze doświadczenia. Niektóre z nich są niezbędne do
            funkcjonowania strony, podczas gdy inne pomagają nam zrozumieć, w jaki sposób z niej
            korzystasz.
          </p>

          {showDetails && (
            <div className="space-y-6 mb-6">
              {/* Necessary Cookies */}
              <div className="flex items-start justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    <Shield className="w-5 h-5 text-purple-600 mr-2" />
                    <h3 className="font-medium text-purple-900">Niezbędne</h3>
                  </div>
                  <p className="text-sm text-purple-600">
                    Te pliki cookie są niezbędne do działania strony i nie mogą być wyłączone.
                  </p>
                </div>
                <div className="ml-4">
                  <div className="w-12 h-6 bg-purple-600 rounded-full relative">
                    <div className="w-4 h-4 bg-white rounded-full absolute top-1 right-1"></div>
                  </div>
                </div>
              </div>

              {/* Analytics Cookies */}
              <div className="flex items-start justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    <BarChart3 className="w-5 h-5 text-purple-600 mr-2" />
                    <h3 className="font-medium text-purple-900">Analityczne</h3>
                  </div>
                  <p className="text-sm text-purple-600">
                    Pomagają nam zrozumieć, jak użytkownicy korzystają z naszej strony.
                  </p>
                </div>
                <div className="ml-4">
                  <button
                    onClick={() => setSettings(s => ({ ...s, analytics: !s.analytics }))}
                    className={`w-12 h-6 ${settings.analytics ? 'bg-purple-600' : 'bg-gray-300'} rounded-full relative transition-colors`}
                  >
                    <div 
                      className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                        settings.analytics ? 'right-1' : 'left-1'
                      }`}
                    ></div>
                  </button>
                </div>
              </div>

              {/* Marketing Cookies */}
              <div className="flex items-start justify-between p-4 bg-gray-50 rounded-xl">
                <div className="flex-1">
                  <div className="flex items-center mb-2">
                    <Target className="w-5 h-5 text-purple-600 mr-2" />
                    <h3 className="font-medium text-purple-900">Marketingowe</h3>
                  </div>
                  <p className="text-sm text-purple-600">
                    Używane do wyświetlania spersonalizowanych reklam i treści.
                  </p>
                </div>
                <div className="ml-4">
                  <button
                    onClick={() => setSettings(s => ({ ...s, marketing: !s.marketing }))}
                    className={`w-12 h-6 ${settings.marketing ? 'bg-purple-600' : 'bg-gray-300'} rounded-full relative transition-colors`}
                  >
                    <div 
                      className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-transform ${
                        settings.marketing ? 'right-1' : 'left-1'
                      }`}
                    ></div>
                  </button>
                </div>
              </div>
            </div>
          )}

          <div className="flex flex-col gap-3 mt-6">
            {showDetails ? (
              <>
                <button
                  onClick={() => setShowDetails(false)}
                  className="w-full px-4 py-3 sm:py-2 border border-purple-200 text-purple-700 rounded-lg hover:bg-purple-50 transition-colors"
                >
                  Ukryj szczegóły
                </button>
                <button
                  onClick={handleRejectOptional}
                  className="w-full px-4 py-3 sm:py-2 border border-purple-200 text-purple-700 rounded-lg hover:bg-purple-50 transition-colors"
                >
                  Odrzuć opcjonalne
                </button>
                <button
                  onClick={handleSavePreferences}
                  className="w-full px-4 py-3 sm:py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  Zapisz preferencje
                </button>
              </>
            ) : (
              <>
                <button
                  onClick={() => setShowDetails(true)}
                  className="w-full px-4 py-3 sm:py-2 border border-purple-200 text-purple-700 rounded-lg hover:bg-purple-50 transition-colors"
                >
                  Pokaż szczegóły
                </button>
                <button
                  onClick={handleRejectOptional}
                  className="w-full px-4 py-3 sm:py-2 border border-purple-200 text-purple-700 rounded-lg hover:bg-purple-50 transition-colors"
                >
                  Odrzuć opcjonalne
                </button>
                <button
                  onClick={handleAcceptAll}
                  className="w-full px-4 py-3 sm:py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  Akceptuj wszystkie
                </button>
              </>
            )}
          </div>

          <div className="mt-6 text-center">
            <Link
              to="/polityka-prywatnosci"
              className="text-sm text-purple-600 hover:text-purple-800"
              onClick={() => setIsVisible(false)}
            >
              Dowiedz się więcej w Polityce Prywatności
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}