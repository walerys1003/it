import React, { useState, useEffect } from 'react';
import { 
  CreditCard, TrendingUp, CheckCircle2, XCircle, 
  RefreshCcw, Calendar, ArrowUpDown, DollarSign
} from 'lucide-react';
import { supabase } from '../../../lib/supabase';

type PaymentStats = {
  totalRevenue: number;
  completedPayments: number;
  failedPayments: number;
  refundedPayments: number;
  averageValue: number;
  conversionRate: number;
};

type PaymentsByDay = {
  date: string;
  revenue: number;
  count: number;
};

type PaymentsByType = {
  type: string;
  count: number;
  revenue: number;
};

export default function PaymentAnalytics() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [stats, setStats] = useState<PaymentStats>({
    totalRevenue: 0,
    completedPayments: 0,
    failedPayments: 0,
    refundedPayments: 0,
    averageValue: 0,
    conversionRate: 0
  });
  const [paymentsByDay, setPaymentsByDay] = useState<PaymentsByDay[]>([]);
  const [paymentsByType, setPaymentsByType] = useState<PaymentsByType[]>([]);
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d'>('30d');

  useEffect(() => {
    fetchPaymentStats();
  }, [dateRange]);

  const fetchPaymentStats = async () => {
    try {
      setLoading(true);

      // Calculate date range
      const endDate = new Date();
      const startDate = new Date();
      switch (dateRange) {
        case '7d':
          startDate.setDate(startDate.getDate() - 7);
          break;
        case '30d':
          startDate.setDate(startDate.getDate() - 30);
          break;
        case '90d':
          startDate.setDate(startDate.getDate() - 90);
          break;
      }

      // Fetch all payments within date range
      const { data: payments, error: paymentsError } = await supabase
        .from('payments')
        .select('*')
        .gte('created_at', startDate.toISOString())
        .lte('created_at', endDate.toISOString());

      if (paymentsError) throw paymentsError;

      // Calculate stats
      const completed = payments.filter(p => p.status === 'completed');
      const failed = payments.filter(p => p.status === 'failed');
      const refunded = payments.filter(p => p.status === 'refunded');

      const totalRevenue = completed.reduce((sum, p) => sum + p.amount, 0);
      const averageValue = completed.length > 0 ? totalRevenue / completed.length : 0;
      const conversionRate = payments.length > 0 
        ? (completed.length / payments.length) * 100 
        : 0;

      setStats({
        totalRevenue,
        completedPayments: completed.length,
        failedPayments: failed.length,
        refundedPayments: refunded.length,
        averageValue,
        conversionRate
      });

      // Calculate payments by day
      const dailyPayments = new Map<string, { revenue: number; count: number }>();
      
      for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
        const dateStr = d.toISOString().split('T')[0];
        dailyPayments.set(dateStr, { revenue: 0, count: 0 });
      }

      completed.forEach(payment => {
        const date = new Date(payment.created_at).toISOString().split('T')[0];
        const current = dailyPayments.get(date) || { revenue: 0, count: 0 };
        dailyPayments.set(date, {
          revenue: current.revenue + payment.amount,
          count: current.count + 1
        });
      });

      setPaymentsByDay(
        Array.from(dailyPayments.entries()).map(([date, data]) => ({
          date,
          revenue: data.revenue,
          count: data.count
        }))
      );

      // Calculate payments by type
      const typeStats = payments.reduce((acc, payment) => {
        const type = payment.package_type;
        if (!acc[type]) {
          acc[type] = { count: 0, revenue: 0 };
        }
        if (payment.status === 'completed') {
          acc[type].revenue += payment.amount;
        }
        acc[type].count++;
        return acc;
      }, {} as Record<string, { count: number; revenue: number }>);

      setPaymentsByType(
        Object.entries(typeStats).map(([type, data]) => ({
          type,
          count: data.count,
          revenue: data.revenue
        }))
      );

    } catch (err) {
      console.error('Error fetching payment stats:', err);
      setError('Wystąpił błąd podczas ładowania statystyk płatności.');
    } finally {
      setLoading(false);
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('pl-PL', {
      style: 'currency',
      currency: 'PLN'
    }).format(amount);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-purple-600">Ładowanie statystyk płatności...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 text-red-600 p-4 rounded-xl">
        <p>{error}</p>
        <p className="text-sm mt-2">Spróbuj odświeżyć stronę.</p>
      </div>
    );
  }

  return (
      <div className="space-y-8">

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Total Revenue */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-purple-900">
                Przychód całkowity
              </h3>
              <DollarSign className="w-6 h-6 text-purple-600" />
            </div>
            <div className="text-3xl font-bold text-green-600">
              {formatCurrency(stats.totalRevenue)}
            </div>
            <div className="text-sm text-purple-600 mt-2">
              Średnia wartość: {formatCurrency(stats.averageValue)}
            </div>
          </div>
          
          {/* Package Type Distribution */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold text-purple-900 mb-6">
              Rozkład pakietów
            </h3>
            <div className="space-y-4">
              {paymentsByType.map((type) => (
                <div key={type.type} className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="font-medium text-purple-900">
                      {type.type === 'standard' ? 'Standard' : 'Premium'}
                    </span>
                    <span className="text-purple-600">
                      {type.count} transakcji
                    </span>
                  </div>
                  <div className="relative pt-1">
                    <div className="flex mb-2 items-center justify-between">
                      <div>
                        <span className="text-xs font-semibold inline-block text-purple-600">
                          {formatCurrency(type.revenue)}
                        </span>
                      </div>
                    </div>
                    <div className="overflow-hidden h-2 text-xs flex rounded bg-purple-200">
                      <div
                        style={{ width: `${(type.revenue / stats.totalRevenue) * 100}%` }}
                        className="shadow-none flex flex-col text-center whitespace-nowrap text-white justify-center bg-purple-600"
                      ></div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Completed Payments */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-purple-900">
                Udane transakcje
              </h3>
              <CheckCircle2 className="w-6 h-6 text-green-500" />
            </div>
            <div className="text-3xl font-bold text-purple-900">
              {stats.completedPayments}
            </div>
            <div className="text-sm text-purple-600 mt-2">
              Skuteczność: {stats.conversionRate.toFixed(1)}%
            </div>
          </div>

          {/* Failed/Refunded Payments */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-purple-900">
                Nieudane/Zwrócone
              </h3>
              <XCircle className="w-6 h-6 text-red-500" />
            </div>
            <div className="flex justify-between">
              <div>
                <div className="text-3xl font-bold text-purple-900">
                  {stats.failedPayments}
                </div>
                <div className="text-sm text-purple-600">Nieudane</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-purple-900">
                  {stats.refundedPayments}
                </div>
                <div className="text-sm text-purple-600">Zwrócone</div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-6">
          {/* Daily Revenue Chart */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h3 className="text-lg font-semibold text-purple-900 mb-6">
              Dzienny przychód
            </h3>
            <div className="h-80">
              <div className="relative h-full">
                <div className="absolute inset-0">
                  {paymentsByDay.length > 0 && (
                    <>
                      {/* Y-axis */}
                      <div className="absolute left-0 top-0 bottom-8 w-16 flex flex-col justify-between text-sm text-purple-600">
                        {[...Array(6)].map((_, i) => {
                          const max = Math.max(...paymentsByDay.map(d => d.revenue));
                          const value = (max / 5) * (5 - i);
                          return (
                            <div key={i} className="flex items-center justify-end pr-2 h-6">
                              {formatCurrency(value).split('PLN')[0]}
                            </div>
                          );
                        })}
                      </div>

                      {/* Chart */}
                      <div className="absolute left-16 right-4 top-0 bottom-8">
                        <svg className="w-full h-full">
                          <defs>
                            <linearGradient id="gradient" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="0%" stopColor="#7C69BE" stopOpacity="0.1" />
                              <stop offset="100%" stopColor="#7C69BE" stopOpacity="0" />
                            </linearGradient>
                          </defs>
                          
                          {/* Background grid */}
                          <g>
                            {[...Array(6)].map((_, i) => (
                              <line
                                key={i}
                                x1="0"
                                y1={`${(i * 100) / 5}%`}
                                x2="100%"
                                y2={`${(i * 100) / 5}%`}
                                stroke="#E9D5FF"
                                strokeWidth="1"
                                strokeDasharray="4"
                              />
                            ))}
                          </g>

                          {/* Revenue line */}
                          {paymentsByDay.length > 1 && (
                            <g>
                              {/* Area under the line */}
                              <path
                                d={`
                                  M ${paymentsByDay.map((day, i) => {
                                    const x = (i / (paymentsByDay.length - 1)) * 100;
                                    const max = Math.max(...paymentsByDay.map(d => d.revenue));
                                    const y = max > 0 ? 100 - (day.revenue / max) * 100 : 0;
                                    return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                                  }).join(' ')}
                                  L 100 100
                                  L 0 100
                                  Z
                                `}
                                fill="url(#gradient)"
                              />
                              
                              {/* Line */}
                              <path
                                d={paymentsByDay.map((day, i) => {
                                  const x = (i / (paymentsByDay.length - 1)) * 100;
                                  const max = Math.max(...paymentsByDay.map(d => d.revenue));
                                  const y = max > 0 ? 100 - (day.revenue / max) * 100 : 0;
                                  return `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                                }).join(' ')}
                                fill="none"
                                stroke="#7C69BE"
                                strokeWidth="2"
                              />
                              
                              {/* Data points */}
                              {paymentsByDay.map((day, i) => {
                                const x = (i / (paymentsByDay.length - 1)) * 100;
                                const max = Math.max(...paymentsByDay.map(d => d.revenue));
                                const y = max > 0 ? 100 - (day.revenue / max) * 100 : 0;
                                return (
                                  <circle
                                    key={i}
                                    cx={`${x}%`}
                                    cy={`${y}%`}
                                    r="4"
                                    fill="#7C69BE"
                                    stroke="white"
                                    strokeWidth="2"
                                  />
                                );
                              })}
                            </g>
                          )}
                        </svg>
                      </div>

                      {/* X-axis */}
                      <div className="absolute left-16 right-4 bottom-0 flex justify-between text-sm text-purple-600">
                        {paymentsByDay.map((day, i) => {
                          // Show every nth label to avoid overlapping
                          const step = Math.ceil(paymentsByDay.length / Math.min(6, paymentsByDay.length));
                          if (i % step === 0 || i === paymentsByDay.length - 1) {
                            const date = new Date(day.date);
                            return (
                              <div key={i} className="text-center" style={{ width: '60px', marginLeft: i === 0 ? 0 : '-30px' }}>
                                {date.toLocaleDateString('pl-PL', { day: 'numeric', month: 'short' })}
                              </div>
                            );
                          }
                          return null;
                        })}
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
  );
}