import React from 'react';

type PromotionService = {
  id: string;
  name: string;
  price: number;
};

type PricingSettingsProps = {
  settings: {
    job_posting_price_standard: number;
    job_posting_price_premium: number;
    promotion_services: PromotionService[];
  };
  onInputChange: (key: string, value: any) => void;
  onPromotionServiceChange: (index: number, field: string, value: any) => void;
};

export default function PricingSettings({ settings, onInputChange, onPromotionServiceChange }: PricingSettingsProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-purple-900 mb-6">
        Cennik
      </h2>
      
      <div className="space-y-6">
        <div>
          <h3 className="text-lg font-medium text-purple-900 mb-4">
            Ogłoszenia
          </h3>
          <div className="grid grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Cena ogłoszenia standardowego (zł)
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={settings.job_posting_price_standard}
                  onChange={(e) => onInputChange('job_posting_price_standard', parseInt(e.target.value))}
                  className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Cena ogłoszenia premium (zł)
              </label>
              <div className="relative">
                <input
                  type="number"
                  value={settings.job_posting_price_premium}
                  onChange={(e) => onInputChange('job_posting_price_premium', parseInt(e.target.value))}
                  className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
              </div>
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-lg font-medium text-purple-900 mb-4">
            Usługi promocji
          </h3>
          <div className="space-y-4">
            {settings.promotion_services?.map((service: PromotionService, index: number) => (
              <div key={service.id} className="bg-purple-50 p-4 rounded-xl">
                <div className="grid grid-cols-4 gap-4">
                  <div className="col-span-3">
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Nazwa usługi
                    </label>
                    <input
                      type="text"
                      value={service.name}
                      onChange={(e) => onPromotionServiceChange(index, 'name', e.target.value)}
                      className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Cena
                    </label>
                    <div className="relative">
                      <input
                        type="number"
                        value={service.price}
                        onChange={(e) => onPromotionServiceChange(index, 'price', parseInt(e.target.value))}
                        className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}