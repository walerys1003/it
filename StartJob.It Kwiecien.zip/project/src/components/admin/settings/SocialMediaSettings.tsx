import React from 'react';
import { Facebook, Linkedin, Instagram } from 'lucide-react';

type SocialMediaSettingsProps = {
  settings: {
    social_media: {
      facebook: string;
      linkedin: string;
      instagram: string;
    };
  };
  onNestedChange: (key: string, nestedKey: string, value: any) => void;
};

export default function SocialMediaSettings({ settings, onNestedChange }: SocialMediaSettingsProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-purple-900 mb-6">
        Media społecznościowe
      </h2>
      <div className="grid grid-cols-3 gap-6">
        <div>
          <label className="block text-sm font-medium text-purple-900 mb-2">
            Facebook
          </label>
          <div className="relative">
            <Facebook className="absolute left-3 top-3 h-5 w-5 text-purple-400" />
            <input
              type="url"
              value={settings.social_media?.facebook}
              onChange={(e) => onNestedChange('social_media', 'facebook', e.target.value)}
              className="pl-10 w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              placeholder="https://facebook.com/..."
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-purple-900 mb-2">
            LinkedIn
          </label>
          <div className="relative">
            <Linkedin className="absolute left-3 top-3 h-5 w-5 text-purple-400" />
            <input
              type="url"
              value={settings.social_media?.linkedin}
              onChange={(e) => onNestedChange('social_media', 'linkedin', e.target.value)}
              className="pl-10 w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              placeholder="https://linkedin.com/..."
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-purple-900 mb-2">
            Instagram
          </label>
          <div className="relative">
            <Instagram className="absolute left-3 top-3 h-5 w-5 text-purple-400" />
            <input
              type="url"
              value={settings.social_media?.instagram}
              onChange={(e) => onNestedChange('social_media', 'instagram', e.target.value)}
              className="pl-10 w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              placeholder="https://instagram.com/..."
            />
          </div>
        </div>
      </div>
    </div>
  );
}