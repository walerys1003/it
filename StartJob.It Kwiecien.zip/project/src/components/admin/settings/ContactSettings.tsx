import React from 'react';
import { Mail, Phone } from 'lucide-react';

type ContactSettingsProps = {
  settings: {
    contact_phone: string;
    contact_email: string;
    contact_address: {
      street: string;
      city: string;
      postal_code: string;
      country: string;
    };
  };
  onInputChange: (key: string, value: any) => void;
  onNestedChange: (key: string, nestedKey: string, value: any) => void;
};

export default function ContactSettings({ settings, onInputChange, onNestedChange }: ContactSettingsProps) {
  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-purple-900 mb-6">
        Dane kontaktowe
      </h2>
      <div className="grid grid-cols-2 gap-6">
        <div>
          <label className="block text-sm font-medium text-purple-900 mb-2">
            Telefon
          </label>
          <div className="relative">
            <Phone className="absolute left-3 top-3 h-5 w-5 text-purple-400" />
            <input
              type="text"
              value={settings.contact_phone}
              onChange={(e) => onInputChange('contact_phone', e.target.value)}
              className="pl-10 w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-purple-900 mb-2">
            Email
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-3 h-5 w-5 text-purple-400" />
            <input
              type="email"
              value={settings.contact_email}
              onChange={(e) => onInputChange('contact_email', e.target.value)}
              className="pl-10 w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
        </div>
      </div>

      <div className="mt-6">
        <h3 className="text-lg font-medium text-purple-900 mb-4">
          Adres
        </h3>
        <div className="grid grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-2">
              Ulica
            </label>
            <input
              type="text"
              value={settings.contact_address?.street}
              onChange={(e) => onNestedChange('contact_address', 'street', e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-2">
              Miasto
            </label>
            <input
              type="text"
              value={settings.contact_address?.city}
              onChange={(e) => onNestedChange('contact_address', 'city', e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-2">
              Kod pocztowy
            </label>
            <input
              type="text"
              value={settings.contact_address?.postal_code}
              onChange={(e) => onNestedChange('contact_address', 'postal_code', e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-2">
              Kraj
            </label>
            <input
              type="text"
              value={settings.contact_address?.country}
              onChange={(e) => onNestedChange('contact_address', 'country', e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
          </div>
        </div>
      </div>
    </div>
  );
}