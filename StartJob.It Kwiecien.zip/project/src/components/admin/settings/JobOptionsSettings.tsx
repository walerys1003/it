import React from 'react';
import { X, Plus, ChevronRight, ChevronDown } from 'lucide-react';
import { supabase } from '../../../lib/supabase';
import { useState, useRef } from 'react';

type JobOption = {
  id: string;
  name: string;
  code: string;
  parent_id?: string | null;
  icon?: string;
  range_from?: number;
  range_to?: number;
  native_name?: string;
  category?: string;
};

type JobOptionsSettingsProps = {
  settings: {
    job_categories: JobOption[];
    working_modes: JobOption[];
    experience_levels: JobOption[];
    contract_types: JobOption[];
    benefits: JobOption[];
    languages: JobOption[];
    company_sizes: JobOption[];
    technologies: JobOption[];
  };
  onSettingsChange: (key: string, value: JobOption[]) => void;
  onAdd: (table: string) => void;
  onDelete: (table: string, id: string, name: string) => void;
};

export default function JobOptionsSettings({ settings, onSettingsChange, onAdd, onDelete }: JobOptionsSettingsProps) {
  const [error, setError] = useState<string | null>(null);
  const [newSubcategoryName, setNewSubcategoryName] = useState<{[key: string]: string}>({});
  const [expandedCategories, setExpandedCategories] = useState<{[key: string]: boolean}>({});

  const handleCategoryChange = async (category: JobOption, newName: string) => {
    try {
      const { data, error } = await supabase
        .rpc('manage_job_category', {
          p_id: category.id,
          p_name: newName,
          p_code: newName.toLowerCase().replace(/\s+/g, '-'),
          p_parent_id: category.parent_id
        });

      if (error) throw error;

      const newCategories = [...settings.job_categories];
      const index = newCategories.findIndex(c => c.id === category.id);
      newCategories[index] = {
        ...category,
        name: newName,
        code: newName.toLowerCase().replace(/\s+/g, '-')
      };
      onSettingsChange('job_categories', newCategories);
      setError(null);
    } catch (err) {
      console.error('Error updating category:', err);
      setError('Wystąpił błąd podczas aktualizacji kategorii');
    }
  };

  const handleAddSubcategory = async (parentId: string) => {
    try {
      const newName = newSubcategoryName[parentId];
      
      if (!newName || newName.trim() === '') {
        throw new Error('Nazwa podkategorii nie może być pusta');
      }
      
      const { data, error } = await supabase
        .rpc('manage_job_category', {
          p_id: null,
          p_name: newName,
          p_code: newName.toLowerCase().replace(/\s+/g, '-'),
          p_parent_id: parentId
        });

      if (error) throw error;

      const newCategories = [...settings.job_categories];
      newCategories.push({
        id: data,
        name: newName,
        code: newName.toLowerCase().replace(/\s+/g, '-'),
        parent_id: parentId
      });
      onSettingsChange('job_categories', newCategories);
      setNewSubcategoryName(prev => ({ ...prev, [parentId]: '' }));
      setError(null);
    } catch (err) {
      console.error('Error adding subcategory:', err);
      setError(err.message || 'Wystąpił błąd podczas dodawania podkategorii');
    }
  };

  const handleDeleteCategory = async (id: string, name: string) => {
    try {
      const { data, error } = await supabase
        .rpc('delete_job_category', {
          p_id: id
        });

      if (error) throw error;

      const newCategories = settings.job_categories.filter(c => c.id !== id);
      onSettingsChange('job_categories', newCategories);
      setError(null);
    } catch (err) {
      console.error('Error deleting category:', err);
      setError('Wystąpił błąd podczas usuwania kategorii');
    }
  };
  
  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryId]: !prev[categoryId]
    }));
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-purple-900 mb-6">
        Opcje ogłoszeń
      </h2>
      
      {error && (
        <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-xl">
          {error}
        </div>
      )}
      
      <div className="space-y-8">
        {/* Job Categories */}
        <div>
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-medium text-purple-900">
              Kategorie
            </h3>
            <button
              onClick={() => onAdd('job_categories')}
              className="text-purple-600 hover:text-purple-700"
            >
              + Dodaj kategorię
            </button>
          </div>
          <div className="space-y-4">
            {/* Main Categories */}
            {settings.job_categories
              .filter(category => !category.parent_id)
              .map((category) => (
                <div key={category.id} className="border border-purple-100 rounded-xl overflow-hidden">
                  <div className="bg-purple-50 p-4">
                    <div className="flex items-center gap-4">
                      <button
                        onClick={() => toggleCategory(category.id)}
                        className="text-purple-600 hover:text-purple-800 p-1 rounded"
                      >
                        {expandedCategories[category.id] ? (
                          <ChevronDown className="w-5 h-5" />
                        ) : (
                          <ChevronRight className="w-5 h-5" />
                        )}
                      </button>
                      <input
                        type="text"
                        value={category.name}
                        onChange={(e) => handleCategoryChange(category, e.target.value)}
                        className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 bg-white"
                        placeholder="Nazwa kategorii"
                      />
                      <button
                        onClick={() => handleDeleteCategory(category.id, category.name)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                        title="Usuń kategorię"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                  
                  {/* Subcategories - only show when expanded */}
                  <div className={`pl-8 pr-4 py-4 space-y-3 border-t border-purple-100 transition-all duration-300 ${
                    expandedCategories[category.id] ? 'block' : 'hidden'
                  }`}>
                    {/* New Subcategory Input */}
                    <div className="flex items-center gap-4">
                      <ChevronRight className="w-4 h-4 text-purple-400" />
                      <input
                        type="text"
                        value={newSubcategoryName[category.id] || ''}
                        onChange={(e) => setNewSubcategoryName(prev => ({
                          ...prev,
                          [category.id]: e.target.value
                        }))}
                        className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                        placeholder="Nazwa nowej podkategorii..."
                      />
                      <button
                        onClick={() => handleAddSubcategory(category.id)}
                        className="p-2 text-purple-600 hover:bg-purple-100 rounded-lg"
                        title="Dodaj podkategorię"
                      >
                        <Plus className="w-5 h-5" />
                      </button>
                    </div>

                    {settings.job_categories
                      .filter(subcat => subcat.parent_id === category.id)
                      .map((subcategory) => (
                        <div key={subcategory.id} className="flex items-center gap-4">
                          <ChevronRight className="w-4 h-4 text-purple-400" />
                          <input
                            type="text"
                            value={subcategory.name}
                            onChange={(e) => handleCategoryChange(subcategory, e.target.value)}
                            className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                            placeholder="Nazwa podkategorii"
                          />
                          <button
                            onClick={() => handleDeleteCategory(subcategory.id, subcategory.name)}
                            className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                          >
                            <X className="w-5 h-5" />
                          </button>
                        </div>
                      ))}
                  </div>
                </div>
              ))}
          </div>
        </div>

        {/* Working Modes */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-purple-900">
              Tryby pracy
            </h3>
            <button
              onClick={() => onAdd('working_modes')}
              className="text-purple-600 hover:text-purple-700"
            >
              + Dodaj tryb pracy
            </button>
          </div>
          <div className="space-y-4">
            {settings.working_modes.map((mode) => (
              <div key={mode.id} className="flex items-center gap-4">
                <input
                  type="text"
                  value={mode.name}
                  onChange={(e) => {
                    const newModes = [...settings.working_modes];
                    const index = newModes.findIndex(m => m.id === mode.id);
                    newModes[index] = {
                      ...mode,
                      name: e.target.value,
                      code: e.target.value.toLowerCase().replace(/\s+/g, '-')
                    };
                    onSettingsChange('working_modes', newModes);
                  }}
                  className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Nazwa trybu pracy"
                />
                <button
                  onClick={() => onDelete('working_modes', mode.id, mode.name)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Experience Levels */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-purple-900">
              Poziomy doświadczenia
            </h3>
            <button
              onClick={() => onAdd('experience_levels')}
              className="text-purple-600 hover:text-purple-700"
            >
              + Dodaj poziom
            </button>
          </div>
          <div className="space-y-4">
            {settings.experience_levels.map((level) => (
              <div key={level.id} className="flex items-center gap-4">
                <input
                  type="text"
                  value={level.name}
                  onChange={(e) => {
                    const newLevels = [...settings.experience_levels];
                    const index = newLevels.findIndex(l => l.id === level.id);
                    newLevels[index] = {
                      ...level,
                      name: e.target.value,
                      code: e.target.value.toLowerCase().replace(/\s+/g, '-')
                    };
                    onSettingsChange('experience_levels', newLevels);
                  }}
                  className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Nazwa poziomu"
                />
                <button
                  onClick={() => onDelete('experience_levels', level.id, level.name)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Contract Types */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-purple-900">
              Typy umów
            </h3>
            <button
              onClick={() => onAdd('contract_types')}
              className="text-purple-600 hover:text-purple-700"
            >
              + Dodaj typ umowy
            </button>
          </div>
          <div className="space-y-4">
            {settings.contract_types.map((type) => (
              <div key={type.id} className="flex items-center gap-4">
                <input
                  type="text"
                  value={type.name}
                  onChange={(e) => {
                    const newTypes = [...settings.contract_types];
                    const index = newTypes.findIndex(t => t.id === type.id);
                    newTypes[index] = {
                      ...type,
                      name: e.target.value,
                      code: e.target.value.toLowerCase().replace(/\s+/g, '-')
                    };
                    onSettingsChange('contract_types', newTypes);
                  }}
                  className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Nazwa typu umowy"
                />
                <button
                  onClick={() => onDelete('contract_types', type.id, type.name)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Benefits */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-purple-900">
              Benefity
            </h3>
            <button
              onClick={() => onAdd('benefits')}
              className="text-purple-600 hover:text-purple-700"
            >
              + Dodaj benefit
            </button>
          </div>
          <div className="space-y-4">
            {settings.benefits.map((benefit) => (
              <div key={benefit.id} className="flex items-center gap-4">
                <input
                  type="text"
                  value={benefit.name}
                  onChange={(e) => {
                    const newBenefits = [...settings.benefits];
                    const index = newBenefits.findIndex(b => b.id === benefit.id);
                    newBenefits[index] = {
                      ...benefit,
                      name: e.target.value,
                      code: e.target.value.toLowerCase().replace(/\s+/g, '-')
                    };
                    onSettingsChange('benefits', newBenefits);
                  }}
                  className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Nazwa benefitu"
                />
                <input
                  type="text"
                  value={benefit.icon}
                  onChange={(e) => {
                    const newBenefits = [...settings.benefits];
                    const index = newBenefits.findIndex(b => b.id === benefit.id);
                    newBenefits[index] = {
                      ...benefit,
                      icon: e.target.value
                    };
                    onSettingsChange('benefits', newBenefits);
                  }}
                  className="w-32 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Ikona"
                />
                <button
                  onClick={() => onDelete('benefits', benefit.id, benefit.name)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Languages */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-purple-900">
              Języki
            </h3>
            <button
              onClick={() => onAdd('languages')}
              className="text-purple-600 hover:text-purple-700"
            >
              + Dodaj język
            </button>
          </div>
          <div className="space-y-4">
            {settings.languages.map((language) => (
              <div key={language.id} className="flex items-center gap-4">
                <input
                  type="text"
                  value={language.name}
                  onChange={(e) => {
                    const newLanguages = [...settings.languages];
                    const index = newLanguages.findIndex(l => l.id === language.id);
                    newLanguages[index] = {
                      ...language,
                      name: e.target.value,
                      code: e.target.value.toLowerCase().replace(/\s+/g, '-')
                    };
                    onSettingsChange('languages', newLanguages);
                  }}
                  className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Nazwa języka"
                />
                <input
                  type="text"
                  value={language.native_name}
                  onChange={(e) => {
                    const newLanguages = [...settings.languages];
                    const index = newLanguages.findIndex(l => l.id === language.id);
                    newLanguages[index] = {
                      ...language,
                      native_name: e.target.value
                    };
                    onSettingsChange('languages', newLanguages);
                  }}
                  className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Nazwa natywna"
                />
                <button
                  onClick={() => onDelete('languages', language.id, language.name)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Technologies */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium text-purple-900">
              Technologie
            </h3>
            <button
              onClick={() => onAdd('technologies')}
              className="text-purple-600 hover:text-purple-700"
            >
              + Dodaj technologię
            </button>
          </div>
          <div className="space-y-4">
            {settings.technologies.map((tech) => (
              <div key={tech.id} className="flex items-center gap-4">
                <input
                  type="text"
                  value={tech.name}
                  onChange={(e) => {
                    const newTechs = [...settings.technologies];
                    const index = newTechs.findIndex(t => t.id === tech.id);
                    newTechs[index] = {
                      ...tech,
                      name: e.target.value,
                      code: e.target.value.toLowerCase().replace(/\s+/g, '-')
                    };
                    onSettingsChange('technologies', newTechs);
                  }}
                  className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Nazwa technologii"
                />
                <select
                  value={tech.category}
                  onChange={(e) => {
                    const newTechs = [...settings.technologies];
                    const index = newTechs.findIndex(t => t.id === tech.id);
                    newTechs[index] = {
                      ...tech,
                      category: e.target.value
                    };
                    onSettingsChange('technologies', newTechs);
                  }}
                  className="w-64 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                  <option value="Języki programowania i technologie front-end">Frontend</option>
                  <option value="Języki programowania i technologie back-end">Backend</option>
                  <option value="Programowanie mobilne">Mobile</option>
                  <option value="Technologie chmurowe i DevOps">Cloud & DevOps</option>
                  <option value="Bazy danych i zarządzanie danymi">Databases</option>
                  <option value="API i technologie komunikacyjne">API</option>
                  <option value="Uczenie maszynowe i sztuczna inteligencja">AI/ML</option>
                  <option value="Bezpieczeństwo IT">Security</option>
                  <option value="Narzędzia do analizy danych">Data Analysis</option>
                  <option value="Inne popularne technologie i narzędzia">Other Tools</option>
                  <option value="Zarządzanie projektami i współpraca">Project Management</option>
                  <option value="Technologie przyszłości">Future Tech</option>
                </select>
                <button
                  onClick={() => onDelete('technologies', tech.id, tech.name)}
                  className="p-2 text-red-600 hover:bg-red-50 rounded-lg"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}