import React, { useState, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import {
  Briefcase, MapPin, Building2, Users, FileText, Code, Globe, Gift, 
  Loader2, AlertCircle, Info, Crown, Check, Star, Mail, Phone, Image
} from 'lucide-react';
import { supabase } from '../lib/supabase';

// Store form data in sessionStorage to persist between navigations
const FORM_DATA_STORAGE_KEY = 'jobPostingFormData';

const workModeIcons = {
  remote: <Globe className="w-5 h-5" />,
  hybrid: <Users className="w-5 h-5" />,
  office: <Building2 className="w-5 h-5" />
};

const workModeLabels = {
  remote: 'Praca zdalna',
  hybrid: 'Praca hybrydowa',
  office: 'Praca w biurze'
};

const contractTypeLabels = {
  employment: 'Umowa o pracę',
  b2b: 'Kontrakt B2B',
  mandate: 'Umowa zlecenie',
  work: 'Umowa o dzieło'
};

const experienceLevelLabels = {
  junior: 'Junior',
  mid: 'Mid',
  senior: 'Senior',
  lead: 'Lead'
};

export default function JobPostingSummary() {
  const location = useLocation();
  const navigate = useNavigate();
  const jobData = location.state?.jobData;
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [workModes, setWorkModes] = useState<Array<{id: string, name: string, code: string}>>([]);
  const [contractTypes, setContractTypes] = useState<Array<{id: string, name: string, code: string}>>([]);
  const [benefits, setBenefits] = useState<Array<{id: string, name: string, code: string}>>([]);
  const [categories, setCategories] = useState<Array<{id: string, name: string, code: string, parent_id?: string}>>([]);
  const [categoryName, setCategoryName] = useState<string>('');

  // Store job data in session storage when component mounts
  useEffect(() => {
    if (jobData) {
      sessionStorage.setItem(FORM_DATA_STORAGE_KEY, JSON.stringify(jobData));
    }
  }, [jobData]);

  if (!jobData) {
    navigate('/dodaj-ogloszenie');
    return null;
  }

  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const [
          { data: workModesData },
          { data: contractTypesData },
          { data: benefitsData },
          { data: categoriesData }
        ] = await Promise.all([
          supabase.from('working_modes').select('*'),
          supabase.from('contract_types').select('*'),
          supabase.from('benefits').select('*'),
          supabase.from('job_categories').select('*')
        ]);

        setWorkModes(workModesData || []);
        setContractTypes(contractTypesData || []);
        setBenefits(benefitsData || []);
        setCategories(categoriesData || []);
        
        // Find category name based on code
        if (jobData.category && categoriesData) {
          const category = categoriesData.find(cat => cat.code === jobData.category);
          if (category) {
            setCategoryName(category.name);
          }
        }
      } catch (err) {
        console.error('Error fetching options:', err);
      }
    };

    fetchOptions();
  }, []);

  const handlePayment = async () => {
    try {
      setIsProcessing(true);
      setError(null);

      // Prepare payment data
      const paymentData = {
        paymentMethod: 'card',
        invoiceData: {
          companyName: jobData.company.name,
          address: jobData.location.city,
          city: jobData.location.city,
          postalCode: '00-000',
          country: 'Poland',
          vatId: 'PL0000000000',
          email: jobData.contact.email
        }
      };

      // Call the RPC function to handle job and payment creation
      const { data: paymentId, error: rpcError } = await supabase
        .rpc('handle_job_payment', {
          job_data: jobData,
          payment_data: paymentData,
        });

      if (rpcError) {
        console.error('Error creating job:', rpcError);
        throw rpcError;
      }

      if (!paymentId) {
        console.error('No payment ID returned');
        throw new Error('No payment ID returned from server');
      }

      // Navigate to payment page with payment ID
      navigate('/platnosc', { 
        state: { 
          jobData,
          paymentId
        }
      });
    } catch (error) {
      console.error('Error creating job:', error);
      setError('Wystąpił błąd podczas tworzenia ogłoszenia. Spróbuj ponownie.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleBackToEdit = () => {
    // Store the current step in session storage to return to the correct step
    const currentFormData = JSON.parse(sessionStorage.getItem(FORM_DATA_STORAGE_KEY) || '{}');
    
    // Make sure we preserve the category value
    const updatedFormData = {
      ...currentFormData,
      category: jobData.category,
      _returnToStep: 7 // Always return to step 7 (contact and publish)
    };
    
    sessionStorage.setItem(FORM_DATA_STORAGE_KEY, JSON.stringify({
      ...updatedFormData
    }));
    
    navigate('/dodaj-ogloszenie');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          {/* Success Message */}
          <div className="text-center mb-8">
            <div className="bg-green-100 rounded-full p-4 inline-block mb-4">
              <FileText className="w-8 h-8 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold text-purple-900 mb-2">
              Podsumowanie ogłoszenia
            </h1>
            <p className="text-purple-600">
              Sprawdź poprawność wprowadzonych danych przed publikacją ogłoszenia.
            </p>
          </div>

          {/* Job Details */}
          <div className="space-y-8">
            {/* Basic Information */}
            <div>
              <div className="flex items-start">
                <img
                  src={jobData.company.logoPreviewUrl || jobData.company.logo}
                  alt={jobData.company.name}
                  className="w-20 h-20 rounded-xl object-cover"
                />
                <div className="ml-6">
                  <h2 className="text-2xl font-bold text-purple-900 mb-2">
                    {jobData.title}
                  </h2>
                  <p className="text-lg text-purple-700">
                    {jobData.company.name}
                  </p>
                  {categoryName && (
                    <p className="text-sm text-purple-600 mt-1">
                      Kategoria: {categoryName}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Key Information */}
            <div className="grid grid-cols-2 gap-6">
              <div className="flex items-center">
                {workModeIcons[jobData.workMode]}
                <span className="ml-2 text-purple-900">
                  {workModes.find(mode => mode.code === jobData.workMode)?.name || workModeLabels[jobData.workMode] || jobData.workMode}
                </span>
              </div>
              <div className="flex items-center">
                <MapPin className="w-5 h-5" />
                <span className="ml-2 text-purple-900">
                  {jobData.location.city}
                </span>
              </div>
              <div className="flex items-center">
                <FileText className="w-5 h-5" />
                <span className="ml-2 text-purple-900">
                  {contractTypes.find(type => type.code === jobData.contractType)?.name || contractTypeLabels[jobData.contractType] || jobData.contractType}
                </span>
              </div>
              <div className="flex items-center">
                <Users className="w-5 h-5" />
                <span className="ml-2 text-purple-900">
                  {experienceLevelLabels[jobData.experienceLevel]}
                </span>
              </div>
            </div>

            {/* Salary */}
            <div className="bg-purple-50 p-6 rounded-xl">
              <h3 className="text-lg font-bold text-purple-900 mb-2">
                Wynagrodzenie
              </h3>
              <div className="text-2xl font-bold text-green-600">
                {jobData.salaryFrom} - {jobData.salaryTo} PLN
                <span className="text-sm font-normal text-purple-600 ml-2">
                  netto/msc
                </span>
              </div>
            </div>

            {/* Description */}
            <div>
              <h3 className="text-lg font-bold text-purple-900 mb-4">
                Opis stanowiska
              </h3>
              <p className="text-purple-700 whitespace-pre-line">
                {jobData.description}
              </p>
            </div>

            {/* Requirements */}
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-bold text-purple-900 mb-4">
                  Wymagania
                </h3>
                <ul className="space-y-2">
                  {jobData.requirements.map((req, index) => (
                    <li key={index} className="flex items-start">
                      <Check className="w-5 h-5 text-green-500 mr-2 mt-1" />
                      <span className="text-purple-700">{req}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-bold text-purple-900 mb-4">
                  Obowiązki
                </h3>
                <ul className="space-y-2">
                  {jobData.responsibilities.map((resp, index) => (
                    <li key={index} className="flex items-start">
                      <Check className="w-5 h-5 text-green-500 mr-2 mt-1" />
                      <span className="text-purple-700">{resp}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Nice to Have */}
            {jobData.niceToHave && jobData.niceToHave.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-purple-900 mb-4">
                  Mile widziane
                </h3>
                <ul className="space-y-2">
                  {jobData.niceToHave.map((item, index) => (
                    <li key={index} className="flex items-start">
                      <Star className="w-5 h-5 text-yellow-400 mr-2 mt-1" />
                      <span className="text-purple-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Technologies */}
            <div>
              <h3 className="text-lg font-bold text-purple-900 mb-4">
                Technologie
              </h3>
              <div className="flex flex-wrap gap-2">
                {jobData.technologies.map((tech, index) => (
                  <span
                    key={index}
                    className="inline-flex items-center px-3 py-1 rounded-full bg-purple-100 text-purple-700"
                  >
                    <Code className="w-4 h-4 mr-2" />
                    {tech}
                  </span>
                ))}
              </div>
            </div>

            {/* Benefits */}
            {Array.isArray(jobData.benefits) && jobData.benefits.length > 0 && (
              <div>
                <h3 className="text-lg font-bold text-purple-900 mb-4">
                  Benefity
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  {jobData.benefits.map((benefit, index) => (
                    <div
                      key={index}
                      className="flex items-center p-4 bg-green-50 rounded-xl"
                    >
                      <Gift className="w-5 h-5 text-green-500 mr-3" />
                      <span className="text-green-700">
                        {benefits.find(b => b.code === benefit)?.name || benefit}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Company Info */}
            <div className="bg-purple-50 p-6 rounded-xl mb-8">
              <h3 className="text-lg font-bold text-purple-900 mb-4">
                Informacje o firmie
              </h3>
              <div className="space-y-4">
                <div>
                  <p className="font-medium text-purple-900">Wielkość firmy:</p>
                  <p className="text-purple-700">
                    {jobData.company.size}
                  </p>
                </div>
                <div>
                  <p className="font-medium text-purple-900">Opis firmy:</p>
                  <p className="text-purple-700 whitespace-pre-line">{jobData.company.description}</p>
                </div>
                <div>
                  <p className="font-medium text-purple-900">Logo firmy:</p>
                  <div className="flex items-center mt-2">
                    <div className="w-12 h-12 rounded-lg overflow-hidden mr-3 bg-purple-50 flex items-center justify-center">
                      {jobData.company.logoPreviewUrl || jobData.company.logo ? (
                        <img 
                          src={jobData.company.logoPreviewUrl || jobData.company.logo} 
                          alt="Logo firmy" 
                          className="w-full h-full object-contain"
                        />
                      ) : (
                        <Image className="w-6 h-6 text-purple-300" />
                      )}
                    </div>
                    <span className="text-purple-700">
                      {jobData.company.logoFile?.name || 'Logo firmy'}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Contact Information */}
            <div className="bg-purple-50 p-6 rounded-xl">
              <h3 className="text-lg font-bold text-purple-900 mb-4">
                Dane kontaktowe
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <p className="font-medium text-purple-900">
                    {jobData.contact.name}
                  </p>
                  <p className="text-purple-700">{jobData.contact.position}</p>
                </div>
                <div className="space-y-2">
                  <a
                    href={`mailto:${jobData.contact.email}`}
                    className="flex items-center text-purple-700 hover:text-purple-900"
                  >
                    <Mail className="w-5 h-5 mr-2" />
                    {jobData.contact.email}
                  </a>
                  {jobData.contact.phone && (
                    <a
                      href={`tel:${jobData.contact.phone}`}
                      className="flex items-center text-purple-700 hover:text-purple-900"
                    >
                      <Phone className="w-5 h-5 mr-2" />
                      {jobData.contact.phone}
                    </a>
                  )}
                </div>
              </div>
            </div>

            {/* Package Type */}
            <div className={`p-6 rounded-xl ${
              jobData.packageType === 'premium' 
                ? 'bg-gradient-to-br from-purple-500 to-purple-700 text-white'
                : 'bg-purple-50 text-purple-900'
            }`}>
              <div className="flex items-center mb-2">
                {jobData.packageType === 'premium' ? (
                  <>
                    <Crown className="w-6 h-6 text-yellow-400 mr-2" />
                    <h3 className="text-lg font-bold">Ogłoszenie Premium</h3>
                  </>
                ) : (
                  <>
                    <Briefcase className="w-6 h-6 text-purple-600 mr-2" />
                    <h3 className="text-lg font-bold">Ogłoszenie Standard</h3>
                  </>
                )}
              </div>
              <div className="text-2xl font-bold mb-2">
                {jobData.packageType === 'premium' ? '899 zł' : '599 zł'}
                <span className={`text-sm font-normal ml-1 ${
                  jobData.packageType === 'premium' ? 'text-purple-200' : 'text-purple-600'
                }`}>z VAT</span>
              </div>
              <ul className="space-y-2">
                <li className="flex items-center">
                  <Check className={`w-4 h-4 mr-2 ${
                    jobData.packageType === 'premium' ? 'text-yellow-400' : 'text-green-500'
                  }`} />
                  <span className={jobData.packageType === 'premium' ? 'text-purple-200' : 'text-purple-600'}>
                    {jobData.packageType === 'premium' ? '90 dni widoczności' : '60 dni widoczności'}
                  </span>
                </li>
                {jobData.packageType === 'premium' && (
                  <>
                    <li className="flex items-center">
                      <Check className="w-4 h-4 mr-2 text-yellow-400" />
                      <span className="text-purple-200">Wyróżnienie na liście</span>
                    </li>
                    <li className="flex items-center">
                      <Check className="w-4 h-4 mr-2 text-yellow-400" />
                      <span className="text-purple-200">Promocja w social media</span>
                    </li>
                  </>
                )}
              </ul>
            </div>

            {/* Actions */}
            <div className="flex justify-between pt-8 border-t border-purple-100">
              {error && (
                <div className="mb-4 text-red-600 text-sm">
                  {error}
                </div>
              )}
              <button
                onClick={handleBackToEdit}
                className="px-6 py-3 bg-purple-100 text-purple-700 rounded-xl hover:bg-purple-200 transition-colors"
              >
                Wróć do edycji
              </button>
              <button
                onClick={handlePayment}
                disabled={isProcessing}
                className="px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors"
              >
                {isProcessing ? 'Przetwarzanie...' : 'Przejdź do płatności'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}