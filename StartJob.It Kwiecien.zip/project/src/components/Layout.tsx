import React from 'react';
import { Link, Outlet, useLocation } from 'react-router-dom';
import { Briefcase, Facebook, Twitter, Linkedin, Instagram, Mail, Phone, Code, Server, Cpu, Wifi, Loader2, CheckCircle2, AlertCircle, Menu, X } from 'lucide-react';
import { MapPin as LocationIcon } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { sendEmail } from '../lib/email';
import { useState, useEffect } from 'react';
import CookieConsent from './CookieConsent';
import SEOHead from './SEOHead';

type Settings = {
  contact_phone: string;
  contact_email: string;
  contact_address: {
    street: string;
    city: string;
    postal_code: string;
    country: string;
  };
  social_media: {
    facebook: string;
    linkedin: string;
    instagram: string;
  };
};

export default function Layout() {
  const [email, setEmail] = React.useState('');
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [submitStatus, setSubmitStatus] = React.useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = React.useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);
  const [settings, setSettings] = useState<Settings>({
    contact_phone: '',
    contact_email: '',
    contact_address: {
      street: '',
      city: '',
      postal_code: '',
      country: ''
    },
    social_media: {
      facebook: '',
      linkedin: '',
      instagram: ''
    }
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('site_settings')
        .select('key, value')
        .in('key', [
          'contact_phone',
          'contact_email',
          'contact_address',
          'social_media'
        ]);

      if (error) throw error;

      const settingsMap = data.reduce((acc, { key, value }) => {
        acc[key] = value;
        return acc;
      }, {} as Settings);

      setSettings(settingsMap);
    } catch (err) {
      console.error('Error fetching settings:', err);
    }
  };

  const handleNewsletterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email) return;

    setIsSubmitting(true);
    setSubmitStatus('idle');
    setErrorMessage('');

    try {
      const { error } = await supabase
        .from('newsletter_subscribers')
        .insert([{ email }]);

      if (error) {
        if (error.code === '23505') { // Unique violation
          throw new Error('Ten adres email jest już zapisany do newslettera.');
        }
        throw error;
      }
      
      // Send confirmation email
      const template = {
        subject: 'Dziękujemy za zapisanie się do newslettera StartJob.IT',
        message: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #4a3471;">Witaj w społeczności StartJob.IT!</h2>
            
            <p>Dziękujemy za zapisanie się do naszego newslettera.</p>
            
            <p>Od teraz będziesz otrzymywać:</p>
            <ul style="color: #666;">
              <li>Najnowsze oferty pracy w IT</li>
              <li>Artykuły i porady dla specjalistów</li>
              <li>Informacje o trendach w branży</li>
              <li>Zaproszenia na wydarzenia branżowe</li>
            </ul>
            
            <p style="margin-top: 30px; color: #666; font-size: 14px;">
              Pozdrawiamy,<br>
              Zespół StartJob.IT
            </p>
          </div>
        `
      };
      
      const emailSent = await sendEmail(email, template);
      if (!emailSent) {
        throw new Error('Nie udało się wysłać emaila potwierdzającego.');
      }

      setSubmitStatus('success');
      setEmail('');
    } catch (error) {
      console.error('Newsletter subscription error:', error);
      setSubmitStatus('error');
      setErrorMessage(error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <SEOHead />
      {/* Header */}
      <header className="bg-gradient-hero text-white border-b border-purple-900 relative">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center">
              <Link to="/" className="flex items-center">
                <Briefcase className="h-8 w-8 text-yellow-400" />
                <span className="ml-2 text-xl font-bold text-white">StartJob.IT</span>
              </Link>
              
              {/* Desktop menu */}
              <div className="hidden lg:flex lg:items-center lg:ml-8 lg:space-x-6">
                <Link to="/" className="text-white hover:text-yellow-400 font-medium">Oferty pracy</Link>
                <Link to="/cennik" className="text-white hover:text-yellow-400 font-medium">Cennik</Link>
                <Link to="/uslugi-promocji" className="text-white hover:text-yellow-400 font-medium">Usługi Promocji</Link>
                <Link to="/blog" className="text-white hover:text-yellow-400 font-medium">Blog</Link>
                <Link to="/social-media" className="text-white hover:text-yellow-400 font-medium">Social Media</Link>
                <Link to="/kontakt" className="text-white hover:text-yellow-400 font-medium">Kontakt</Link>
              </div>
            </div>
            
            <div className="flex items-center space-x-4">
              {/* Add Job button - visible only on desktop/tablet */}
              <Link 
                to="/dodaj-ogloszenie" 
                className="hidden sm:block bg-yellow-400 text-purple-900 px-5 py-2 rounded-full hover:bg-yellow-300 font-medium transition-colors"
              >
                Dodaj ogłoszenie
              </Link>
              
              {/* Tablet/Mobile menu button */}
              <div className="lg:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-white hover:text-yellow-400 focus:outline-none"
                aria-label="Menu"
              >
                {isMobileMenuOpen ? (
                  <X className="block h-6 w-6" />
                ) : (
                  <Menu className="block h-6 w-6" />
                )}
              </button>
              </div>
            </div>
          </div>
          
          {/* Mobile menu */}
          <div 
            className={`
              fixed inset-0 z-50 lg:hidden bg-gradient-hero transform transition-transform duration-300 ease-in-out
              ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full'}
            `}
          >
            <div className="flex flex-col h-full">
              <div className="flex items-center justify-between p-4 border-b border-purple-800">
                <Link 
                  to="/" 
                  className="flex items-center"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <Briefcase className="h-8 w-8 text-yellow-400" />
                  <span className="ml-2 text-xl font-bold text-white">StartJob.IT</span>
                </Link>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 rounded-md text-white hover:text-yellow-400 focus:outline-none"
                >
                  <X className="block h-6 w-6" />
                </button>
              </div>
              
              <div className="flex-1 px-4 py-6 space-y-6 overflow-y-auto">
                <Link 
                  to="/" 
                  className="block text-lg font-medium text-white hover:text-yellow-400"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Oferty pracy
                </Link>
                <Link 
                  to="/cennik" 
                  className="block text-lg font-medium text-white hover:text-yellow-400"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Cennik
                </Link>
                <Link 
                  to="/uslugi-promocji" 
                  className="block text-lg font-medium text-white hover:text-yellow-400"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Usługi Promocji
                </Link>
                <Link 
                  to="/blog" 
                  className="block text-lg font-medium text-white hover:text-yellow-400"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Blog
                </Link>
                <Link 
                  to="/social-media" 
                  className="block text-lg font-medium text-white hover:text-yellow-400"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Social Media
                </Link>
                <Link 
                  to="/kontakt" 
                  className="block text-lg font-medium text-white hover:text-yellow-400"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Kontakt
                </Link>
              </div>
              
              <div className="p-4 border-t border-purple-800">
                <Link
                  to="/dodaj-ogloszenie"
                  className="block w-full text-center bg-yellow-400 text-purple-900 px-5 py-3 rounded-full hover:bg-yellow-300 font-medium transition-colors"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  Dodaj ogłoszenie
                </Link>
              </div>
            </div>
          </div>
        </nav>
      </header>

      {/* Main Content */}
      <Outlet />

      {/* Footer */}
      <footer className="bg-gradient-footer text-white mt-16 relative">
        {/* Straight line separator */}
        <div className="w-full h-1 bg-gradient-to-r from-pink-500 via-purple-600 to-indigo-700"></div>
        
        {/* Network animation container */}
        <div id="network-animation" className="absolute inset-0 overflow-hidden pointer-events-none">
          {/* Network nodes will be added here via JavaScript */}
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
            <div>
              <div className="mb-6 flex flex-col items-center md:items-start text-center md:text-left">
                <div className="flex items-center">
                  <Briefcase className="h-8 w-8 text-pink-500" />
                  <span className="ml-2 text-xl font-bold text-white">StartJob.IT</span>
                </div>
                <p className="text-purple-200 mt-4 max-w-sm">
                  Platforma łącząca specjalistów IT z najlepszymi pracodawcami w branży technologicznej.
                </p>
              </div>
              <div className="flex justify-center md:justify-start space-x-4 mt-6">
                <a 
                  href={settings.social_media?.facebook} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-indigo-900 bg-opacity-30 p-2 rounded-full hover:bg-opacity-50 transition-all"
                >
                  <Facebook className="w-5 h-5 text-white" />
                </a>
                <a 
                  href={settings.social_media?.linkedin} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-indigo-900 bg-opacity-30 p-2 rounded-full hover:bg-opacity-50 transition-all"
                >
                  <Linkedin className="w-5 h-5 text-white" />
                </a>
                <a 
                  href={settings.social_media?.instagram} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="bg-indigo-900 bg-opacity-30 p-2 rounded-full hover:bg-opacity-50 transition-all"
                >
                  <Instagram className="w-5 h-5 text-white" />
                </a>
              </div>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-6 text-white text-center md:text-left">Przydatne linki</h3>
              <ul className="space-y-3 text-purple-200">
                <li><Link to="/" className="footer-link hover:text-pink-400 transition-colors">Oferty pracy</Link></li>
                <li><Link to="/dodaj-ogloszenie" className="footer-link hover:text-pink-400 transition-colors">Dla pracodawców</Link></li>
                <li><Link to="/blog" className="footer-link hover:text-pink-400 transition-colors">Blog technologiczny</Link></li>
                <li><Link to="/polityka-prywatnosci" className="footer-link hover:text-pink-400 transition-colors">Polityka prywatności</Link></li>
                <li><Link to="/regulamin" className="footer-link hover:text-pink-400 transition-colors">Regulamin</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-6 text-white text-center md:text-left">Kontakt</h3>
              <ul className="space-y-4 text-purple-200">
                <li className="flex items-start justify-center md:justify-start">
                  <a href={`tel:${settings.contact_phone}`} className="flex items-start text-purple-200 hover:text-pink-400 transition-colors">
                    <Phone className="w-5 h-5 mr-3 mt-0.5 text-pink-400" />
                    <span>{settings.contact_phone}</span>
                  </a>
                </li>
                <li className="flex items-start justify-center md:justify-start">
                  <a href={`mailto:${settings.contact_email}`} className="flex items-start text-purple-200 hover:text-pink-400 transition-colors">
                    <Mail className="w-5 h-5 mr-3 mt-0.5 text-pink-400" />
                    <span>{settings.contact_email}</span>
                  </a>
                </li>
                <li className="flex items-start justify-center md:justify-start">
                  <LocationIcon className="w-5 h-5 mr-3 mt-0.5 text-pink-400" />
                  <span>{settings.contact_address.street}<br />{settings.contact_address.postal_code} {settings.contact_address.city}</span>
                </li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-6 text-white text-center md:text-left">Newsletter</h3>
              <p className="text-purple-200 mb-4">
                Zapisz się, aby otrzymywać najnowsze oferty pracy i aktualności z branży IT
              </p>
              <form onSubmit={handleNewsletterSubmit} className="flex flex-col space-y-3">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Twój adres email"
                  required
                  className="px-4 py-3 rounded-lg bg-indigo-900 bg-opacity-30 border border-indigo-800 text-white placeholder-purple-300 focus:outline-none focus:ring-2 focus:ring-pink-500"
                />
                <button 
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 px-4 py-3 rounded-lg text-white font-medium transition-all flex items-center justify-center"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Zapisywanie...
                    </>
                  ) : (
                    'Zapisz się'
                  )}
                </button>
                {submitStatus === 'success' && (
                  <div className="flex items-center text-green-400">
                    <CheckCircle2 className="w-5 h-5 mr-2" />
                    <span>Dziękujemy za zapisanie się do newslettera!</span>
                  </div>
                )}
                {submitStatus === 'error' && (
                  <div className="flex items-center text-red-400">
                    <AlertCircle className="w-5 h-5 mr-2" />
                    <span>{errorMessage || 'Wystąpił błąd. Spróbuj ponownie.'}</span>
                  </div>
                )}
              </form>
            </div>
          </div>
          
          <div className="mt-16 pt-8 border-t border-indigo-800">
            <div className="flex flex-col md:flex-row justify-between items-center space-y-6 md:space-y-0">
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-6 mb-4 md:mb-0">
                <span className="text-purple-300 flex items-center">
                  <Code className="w-5 h-5 mr-2 text-pink-500" /> Frontend
                </span>
                <span className="text-purple-300 flex items-center">
                  <Server className="w-5 h-5 mr-2 text-pink-500" /> Backend
                </span>
                <span className="text-purple-300 flex items-center">
                  <Cpu className="w-5 h-5 mr-2 text-pink-500" /> DevOps
                </span>
                <span className="text-purple-300 flex items-center">
                  <Wifi className="w-5 h-5 mr-2 text-pink-500" /> Mobile
                </span>
              </div>
              <p className="text-purple-300 text-sm text-center md:text-left">
                &copy; {new Date().getFullYear()} StartJob.IT. Wszystkie prawa zastrzeżone.
              </p>
            </div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute bottom-0 right-0 opacity-10">
          <svg width="200" height="200" viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="100" cy="100" r="100" fill="#E879F9" />
          </svg>
        </div>
        <div className="absolute top-20 left-20 opacity-5">
          <svg width="300" height="300" viewBox="0 0 300 300" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="150" cy="150" r="150" fill="#818CF8" />
          </svg>
        </div>
      </footer>
      <CookieConsent />
    </div>
  );
}