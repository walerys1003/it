import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { 
  Briefcase, MapPin, Building2, Clock, Users, FileText, Wallet, Mail, 
  Phone, Code, Globe, Star, CheckCircle2, AlertCircle, Crown, Gift, ArrowLeft,
  Upload, Send, Loader2, PaperclipIcon, Tag
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { emailTemplates, sendEmail } from '../lib/email';
import { Helmet } from 'react-helmet-async';
import { contractTypes } from '../data/jobPostingData';

const workModeIcons = {
  remote: <Globe className="w-5 h-5" />,
  hybrid: <Users className="w-5 h-5" />,
  office: <Building2 className="w-5 h-5" />
};

const workModeLabels = {
  remote: 'Praca zdalna',
  hybrid: 'Praca hybrydowa',
  office: 'Praca w biurze'
};

const getContractTypeLabel = (type: string) => {
  const contractType = contractTypes.find(t => t.value === type);
  return contractType ? contractType.label : type;
};

const benefitLabels = {
  'flexible-hours': 'Elastyczne godziny pracy',
  '4-day-week': '4-dniowy tydzień pracy',
  'training-budget': 'Budżet na szkolenia',
  'medical': 'Prywatna opieka medyczna',
  'sports-card': 'Pakiet sportowy',
  'stock-options': 'Opcje na akcje',
  'equipment': 'Sprzęt firmowy',
  'abroad': 'Możliwość pracy za granicą'
};

export default function JobPostingPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const location = useLocation();
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [benefits, setBenefits] = useState<Array<{id: string, name: string, code: string}>>([]);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitSuccess, setSubmitSuccess] = useState<boolean>(false);
  const [categories, setCategories] = useState<Array<{id: string, name: string, code: string, parent_id?: string}>>([]);
  const [formData, setFormData] = useState({
    name: '' as string,
    email: '' as string,
    phone: '' as string,
    message: 'Jestem zainteresowany(a) tą ofertą pracy i chętnie porozmawiam o szczegółach.' as string,
    cv_file: null as File | null,
    consent: false as boolean
  });

  // Effect to handle successful submission
  useEffect(() => {
    if (submitSuccess) {
      resetForm();
    }
  }, [submitSuccess]);

  // Track view event when job is loaded
  useEffect(() => {
    const trackViewEvent = async () => {
      if (job?.id) {
        try {
          await supabase
            .from('job_events')
            .insert([{
              job_id: job.id,
              event_type: 'view'
            }]);
        } catch (error) {
          console.error('Error tracking view event:', error);
        }
      }
    };

    trackViewEvent();
  }, [job?.id]);

  useEffect(() => {
    fetchJob();
    fetchBenefits();
    fetchCategories();
  }, [id]);

  const fetchBenefits = async () => {
    try {
      const { data } = await supabase.from('benefits').select('*');
      if (data) {
        setBenefits(data);
      }
    } catch (err) {
      console.error('Error fetching benefits:', err);
    }
  };

  const fetchCategories = async () => {
    try {
      const { data } = await supabase.from('job_categories').select('*');
      if (data) {
        setCategories(data);
      }
    } catch (err) {
      console.error('Error fetching categories:', err);
    }
  };

  const fetchJob = async () => {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      setJob(data);
    } catch (err) {
      console.error('Error fetching job:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  // Reset form
  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      phone: '',
      message: 'Jestem zainteresowany(a) tą ofertą pracy i chętnie porozmawiam o szczegółach.',
      cv_file: null,
      consent: false
    });
    setSubmitSuccess(false);
    setSubmitError(null);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const extension = file.name.split('.').pop().toLowerCase();
      const allowedExtensions = ['pdf', 'docx', 'odt'];
      
      if (allowedExtensions.includes(extension)) {
        if (file.size > 10 * 1024 * 1024) { // 10MB limit
          setSubmitError('Plik CV nie może przekraczać 10MB');
          setFormData(prev => ({ ...prev, cv_file: null }));
          return;
        }
        setFormData(prev => ({ ...prev, cv_file: file }));
        setSubmitError(null);
      } else {
        setSubmitError('Dozwolone formaty plików: .pdf, .docx, .odt');
        setFormData(prev => ({ ...prev, cv_file: null }));
      }
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();

    // Clear previous errors
    setSubmitError(null);
    setSubmitSuccess(false);

    try {
      setSubmitting(true);

      // Validate required fields
      const errors = [];
      if (!formData.name?.trim()) {
        errors.push('Imię i nazwisko');
      }
      if (!formData.email?.trim()) {
        errors.push('Adres e-mail');
      }
      if (!formData.cv_file) {
        errors.push('CV');
      }
      if (!formData.consent) {
        errors.push('Zgoda RODO');
      }
      
      if (errors.length > 0) {
        throw new Error(`Wypełnij wymagane pola: ${errors.join(', ')}`);
      }

      // Track click event when starting application
      try {
        await supabase
          .from('job_events')
          .insert([{
            job_id: job.id,
            event_type: 'click'
          }]);
      } catch (error) {
        console.error('Error tracking click event:', error);
      }


      // Check if user already applied for this job
      const { count: applicationCount } = await supabase
        .from('applications')
        .select('*', { count: 'exact', head: true })
        .eq('job_id', job.id)
        .eq('candidate_email', formData.email.trim());

      if (applicationCount && applicationCount > 0) {
        throw new Error('Już aplikowałeś/aś na to ogłoszenie. Nie możesz aplikować ponownie.');
      }

      // Send confirmation email to candidate
      const candidateEmailTemplate = emailTemplates.jobApplication({
        candidateName: formData.name.trim(),
        jobTitle: job.title,
        companyName: job.company_name,
        message: formData.message.trim()
      });
      const candidateEmailSent = await sendEmail(formData.email.trim(), candidateEmailTemplate);
      if (!candidateEmailSent) {
        throw new Error('Nie udało się wysłać emaila z potwierdzeniem. Spróbuj ponownie później.');
      }

      // Send notification email to recruiter
      const recruiterEmailTemplate = emailTemplates.recruiterNotification({
        candidateName: formData.name.trim(),
        jobTitle: job.title,
        candidateEmail: formData.email.trim(),
        candidatePhone: formData.phone || undefined,
        message: formData.message.trim()
      });
      const recruiterEmailSent = await sendEmail(job.contact_email, recruiterEmailTemplate, formData.cv_file);
      if (!recruiterEmailSent) {
        throw new Error('Nie udało się wysłać powiadomienia do rekrutera. Spróbuj ponownie później.');
      }

      // Insert application into database
      const { data, error } = await supabase
        .from('applications')
        .insert([{
          job_id: job.id,
          candidate_name: formData.name.trim(),
          candidate_email: formData.email.trim(),
          candidate_phone: formData.phone || null,
          message: formData.message.trim(),
          cv_url: formData.cv_file ? formData.cv_file.name : null
        }])
        .select()
        .single();

      if (error) {
        throw error;
      }

      // Track successful application event
      await supabase
        .from('job_events')
        .insert([{
          job_id: job.id,
          event_type: 'application'
        }]);
      console.log('przed:'+submitSuccess);
      setSubmitSuccess(true); // This will trigger the useEffect
      console.log('po:'+submitSuccess);
    } catch (error) {
      console.error('Error submitting application:', error.message);
      if (error.message.includes('Failed to fetch')) {
        setSubmitError('Nie można połączyć się z serwerem email. Sprawdź połączenie internetowe i spróbuj ponownie.');
      } else {
        setSubmitError(error.message || 'Wystąpił błąd podczas wysyłania aplikacji');
      }
      setSubmitSuccess(false);
    } finally {
      setSubmitting(false);
    }
  };

  const handleBack = () => {
    navigate(-1);
  };

  // Helper function to get category name from code
  const getCategoryName = (categoryCode: string): string => {
    const category = categories.find(cat => cat.code === categoryCode);
    return category?.name || categoryCode;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-purple-200 border-t-purple-600"></div>
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-purple-900 mb-2">
            Nie znaleziono ogłoszenia
          </h1>
          <p className="text-purple-600">
            Przepraszamy, ale ogłoszenie o podanym ID nie istnieje lub zostało usunięte.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-6 sm:py-12">
      <div className="max-w-7xl mx-auto px-4">
        {/* Schema.org structured data for job posting */}
        {job && (
          <Helmet>
            <script type="application/ld+json">
              {JSON.stringify({
                '@context': 'https://schema.org',
                '@type': 'JobPosting',
                'title': job.title,
                'description': job.description,
                'datePosted': job.created_at,
                'validThrough': job.valid_until,
                'employmentType': job.contract_type === 'employment' ? 'FULL_TIME' : 
                                 job.contract_type === 'b2b' ? 'CONTRACTOR' : 
                                 job.contract_type === 'mandate' ? 'PART_TIME' : 'OTHER',
                'hiringOrganization': {
                  '@type': 'Organization',
                  'name': job.company_name,
                  'logo': job.company_logo
                },
                'jobLocation': {
                  '@type': 'Place',
                  'address': {
                    '@type': 'PostalAddress',
                    'addressLocality': job.location_city,
                    'addressCountry': job.location_country
                  }
                },
                'baseSalary': {
                  '@type': 'MonetaryAmount',
                  'currency': job.currency,
                  'value': {
                    '@type': 'QuantitativeValue',
                    'minValue': job.salary_from,
                    'maxValue': job.salary_to,
                    'unitText': 'MONTH'
                  }
                },
                'skills': job.technologies.join(', '),
                'industry': 'Information Technology',
                'jobBenefits': job.benefits.join(', '),
                'workHours': 'Full-time',
                'experienceRequirements': job.experience_level,
                'applicantLocationRequirements': {
                  '@type': 'Country',
                  'name': job.location_country
                }
              })}
            </script>
          </Helmet>
        )}

        <button
          onClick={handleBack}
          className="mb-4 sm:mb-6 flex items-center text-purple-600 hover:text-purple-800 transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          <span>Powrót do listy ogłoszeń</span>
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 sm:gap-8">
          {/* Main Content */}
          <div className="lg:col-span-8">
            <div className="bg-white rounded-xl sm:rounded-2xl shadow-lg p-4 sm:p-8 mb-4 sm:mb-8">
              {/* Job Header */}
              <div className="flex flex-col sm:flex-row sm:items-start gap-4 sm:gap-6">
                <img
                  src={job.company_logo}
                  alt={job.company_name}
                  className="w-16 h-16 sm:w-20 sm:h-20 rounded-xl object-cover"
                />
                <div className="flex-1">
                  <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 sm:gap-4">
                    <div>
                      <h1 className="text-2xl font-bold text-purple-900">
                        {job.title}
                      </h1>
                      <div>
                        <span className="inline-flex items-center text-sm text-purple-600">
                          {getCategoryName(job.category)}
                        </span>
                      </div>
                    </div>
                    {job.is_featured && (
                      <div className="bg-yellow-400 text-purple-900 px-4 py-2 rounded-full flex items-center">
                        <Crown className="w-5 h-5 mr-2" />
                        <span className="font-medium">Premium</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="mt-4 flex flex-wrap gap-2 sm:gap-4">
                    <div className="flex items-center text-purple-600">
                      {workModeIcons[job.work_mode]}
                      <span className="ml-2">{workModeLabels[job.work_mode]}</span>
                    </div>
                    <div className="flex items-center text-purple-600">
                      <MapPin className="w-5 h-5 mr-2" />
                      {job.location_city}
                    </div>
                    <div className="flex items-center text-purple-600">
                      <FileText className="w-5 h-5 mr-2" />
                      {getContractTypeLabel(job.contract_type)}
                    </div>
                    <div className="flex items-center text-purple-600">
                      <Clock className="w-5 h-5 mr-2" />
                      Dodano: {new Date(job.created_at).toLocaleDateString()}
                    </div>
                  </div>

                  <div className="mt-4">
                    <div className="text-2xl font-bold text-green-600">
                      {job.salary_from} - {job.salary_to} {job.currency}
                      <span className="text-sm text-purple-600 ml-2">netto/msc</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Job Description */}
              <div className="mt-6 sm:mt-8">
                <h2 className="text-xl font-bold text-purple-900 mb-4">
                  Opis stanowiska
                </h2>
                <p className="text-purple-700 whitespace-pre-line">
                  {job.description}
                </p>
              </div>

              {/* Responsibilities */}
              <div className="mt-6 sm:mt-8">
                <h2 className="text-xl font-bold text-purple-900 mb-4">
                  Zakres obowiązków
                </h2>
                <ul className="space-y-3">
                  {job.responsibilities.map((resp, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-green-500 mr-3 mt-1" />
                      <span className="text-purple-700">{resp}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Requirements */}
              <div className="mt-6 sm:mt-8">
                <h2 className="text-xl font-bold text-purple-900 mb-4">
                  Wymagania
                </h2>
                <ul className="space-y-3">
                  {job.requirements.map((req, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-purple-500 mr-3 mt-1" />
                      <span className="text-purple-700">{req}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Nice to Have */}
              {job.nice_to_have && job.nice_to_have.length > 0 && (
                <div className="mt-6 sm:mt-8">
                  <h2 className="text-xl font-bold text-purple-900 mb-4">
                    Mile widziane
                  </h2>
                  <ul className="space-y-3">
                    {job.nice_to_have.map((item, index) => (
                      <li key={index} className="flex items-start">
                        <Star className="w-5 h-5 text-yellow-400 mr-3 mt-1" />
                        <span className="text-purple-700">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Technologies */}
              <div className="mt-6 sm:mt-8">
                <h2 className="text-xl font-bold text-purple-900 mb-4">
                  Technologie
                </h2>
                <div className="flex flex-wrap gap-1.5 sm:gap-2">
                  {job.technologies.map((tech, index) => (
                    <span
                      key={index}
                      className="inline-flex items-center px-3 py-1 rounded-full bg-purple-100 text-purple-700"
                    >
                      <Code className="w-4 h-4 mr-2" />
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

              {/* Benefits */}
              <div className="mt-6 sm:mt-8">
                <h2 className="text-xl font-bold text-purple-900 mb-4">
                  Benefity
                </h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-4">
                  {job.benefits.map((benefit, index) => (
                    <div
                      key={index}
                      className="flex items-center p-4 bg-green-50 rounded-xl"
                    >
                      <Gift className="w-5 h-5 text-green-500 mr-3" />
                      <span className="text-green-700">
                        {benefitLabels[benefit] || benefits.find(b => b.code === benefit)?.name || benefit}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-4 space-y-4 sm:space-y-8">
            {/* Company Info */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-purple-900 mb-4">
                O firmie
              </h2>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-purple-900">Nazwa</h3>
                  <p className="text-purple-700">{job.company_name}</p>
                </div>
                <div>
                  <h3 className="font-medium text-purple-900">Wielkość</h3>
                  <p className="text-purple-700">{job.company_size}</p>
                </div>
                {job.company_description && (
                  <div>
                    <h3 className="font-medium text-purple-900">Opis</h3>
                    <p className="text-purple-700">{job.company_description}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Quick Application Form */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-purple-900 mb-4">
                Aplikuj teraz
              </h2>
              {submitSuccess ? (
                <div className="mb-6 p-4 bg-green-50 text-green-700 rounded-xl">
                  <div className="text-center">
                    <div className="flex justify-center mb-4">
                      <div className="bg-green-100 rounded-full p-3">
                        <CheckCircle2 className="w-8 h-8 text-green-600" />
                      </div>
                    </div>
                    <h3 className="text-lg font-bold text-green-800 mb-2">
                      Aplikacja została wysłana!
                    </h3>
                    <p className="text-green-700 mb-4">
                      Dziękujemy za zainteresowanie ofertą. Skontaktujemy się z Tobą wkrótce.
                    </p>
                    <p className="text-sm text-green-600">
                      Sprawdź swoją skrzynkę email, wysłaliśmy Ci potwierdzenie aplikacji.
                    </p>
                  </div>
                </div>
              ) : (
                <>
                {submitError && (
                  <div className="mb-6 p-4 bg-red-50 text-red-700 rounded-xl">
                    <div className="flex items-center">
                      <AlertCircle className="w-5 h-5 mr-2" />
                      <p className="font-medium">Wystąpił błąd</p>
                    </div>
                    <p className="mt-1 text-sm">{submitError}</p>
                  </div>
                )}
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Imię i nazwisko
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-2 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Adres e-mail
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-2 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Numer telefonu (opcjonalnie)
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-4 py-2 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Załącz CV
                    </label>
                    <div className="relative flex items-center">
                      <input
                        type="file"
                        name="cv_file"
                        onChange={handleFileChange}
                        accept=".pdf,.docx,.odt"
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                        aria-label="Wybierz plik CV"
                        key={formData.cv_file ? 'file-selected' : 'no-file'} // Force re-render of input
                      />
                      <div className="w-full px-4 py-2 rounded-xl border border-purple-200 bg-white flex items-center">
                        <PaperclipIcon className="h-5 w-5 text-purple-400 mr-2" />
                        <span className="text-purple-700">
                          {formData.cv_file ? formData.cv_file.name : 'Wybierz plik CV'}
                        </span>
                      </div>
                    </div>
                    <p className={`mt-1 text-sm ${formData.cv_file ? 'text-green-600' : 'text-purple-600'}`}>
                      {formData.cv_file ? (
                        <span className="flex items-center">
                          <CheckCircle2 className="w-4 h-4 mr-1" />
                          Plik CV został załączony
                        </span>
                      ) : 'Obsługiwane formaty: .docx, .pdf, .odt (max 10MB)'}
                    </p>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Wiadomość do rekrutera (opcjonalnie)
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      rows={4}
                      className="w-full px-4 py-2 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>

                  <div className="mt-4">
                    <label className="flex items-start">
                      <input
                        type="checkbox"
                        checked={formData.consent}
                        onChange={(e) => setFormData(prev => ({ ...prev, consent: e.target.checked }))}
                        className="mt-1 rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                        required
                      />
                      <span className="ml-2 text-sm text-purple-700">
                        Klikając „Wyślij aplikację", wyrażasz zgodę na przetwarzanie danych osobowych na potrzeby procesu rekrutacji zgodnie z RODO.
                      </span>
                    </label>
                    {submitError && submitError.includes('Zgoda RODO') && (
                      <p className="mt-1 text-sm text-red-600">Wymagana jest zgoda na przetwarzanie danych osobowych</p>
                    )}
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-purple-600 text-white rounded-xl py-3 font-medium hover:bg-purple-700 transition-colors flex items-center justify-center"
                    disabled={submitting}
                  >
                    {submitting ? (
                      <>
                        <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                        Wysyłanie...
                      </>
                    ) : (
                      <>
                        <Send className="w-5 h-5 mr-2" />
                        Wyślij aplikację
                      </>
                    )}
                  </button>
                </form>
                </>
              )}
            </div>

            {/* Contact Info */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h2 className="text-xl font-bold text-purple-900 mb-4">
                Kontakt
              </h2>
              <div className="space-y-4">
                <div>
                  <h3 className="font-medium text-purple-900">
                    {job.contact_name}
                  </h3>
                  <p className="text-purple-700">{job.contact_position}</p>
                </div>
                <a
                  href={`mailto:${job.contact_email}`}
                  className="flex items-center text-purple-600 hover:text-purple-700"
                >
                  <Mail className="w-5 h-5 mr-2" />
                  {job.contact_email}
                </a>
                {job.contact_phone && (
                  <a
                    href={`tel:${job.contact_phone}`}
                    className="flex items-center text-purple-600 hover:text-purple-700"
                  >
                    <Phone className="w-5 h-5 mr-2" />
                    {job.contact_phone}
                  </a>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}