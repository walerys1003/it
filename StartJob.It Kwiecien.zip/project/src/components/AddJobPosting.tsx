import { useForm, useFieldArray, UseFormReturn } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { jobPostingSchema } from '../schemas/jobPostingSchema';
import { ArrowLeft, ArrowRight, Info, Loader2, Upload } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';

// Import step components
import BasicInformation from './new-job-form-steps/BasicInformation';
import RequirementsAndResponsibilities from './new-job-form-steps/RequirementsAndResponsibilities';
import TechnologiesAndSkills from './new-job-form-steps/TechnologiesAndSkills';
import EmploymentDetails from './new-job-form-steps/EmploymentDetails';
import Location from './new-job-form-steps/Location';
import CompanyInformation from './new-job-form-steps/CompanyInformation';
import ContactAndPublish from './new-job-form-steps/ContactAndPublish';

type JobOption = {
  id: string;
  name: string;
  code: string;
  category?: string;
};

type CitySuggestion = {
  city: string;
  count: number;
};

export default function AddJobPosting() {
  const navigate = useNavigate();
  const { register, control, handleSubmit, watch, formState: { errors }, setValue, trigger } = useForm({
    resolver: zodResolver(jobPostingSchema),
    defaultValues: {
      title: '',
      category: '',
      description: '',
      responsibilities: [''],
      requirements: [''],
      niceToHave: [''],
      technologies: [],
      workMode: undefined,
      experienceLevel: undefined,
      contractType: undefined,
      salaryFrom: undefined,
      salaryTo: undefined,
      currency: 'PLN',
      benefits: [] as string[],
      location: {
        country: '',
        voivodeship: '',
        city: ''
      },
      languages: [{ language: '', level: '' }],
      company: {
        name: '',
        description: '',
        size: ''
      },
      contact: {
        name: '',
        position: '',
        email: '',
        phone: ''
      },
      packageType: undefined
    }
  });

  const {
    fields: responsibilitiesFields,
    append: appendResponsibility,
    remove: removeResponsibility
  } = useFieldArray({
    control,
    name: "responsibilities"
  });

  const {
    fields: requirementsFields,
    append: appendRequirement,
    remove: removeRequirement
  } = useFieldArray({
    control,
    name: "requirements"
  });

  const {
    fields: niceToHaveFields,
    append: appendNiceToHave,
    remove: removeNiceToHave
  } = useFieldArray({
    control,
    name: "niceToHave"
  });

  const {
    fields: languagesFields,
    append: appendLanguage,
    remove: removeLanguage
  } = useFieldArray({
    control,
    name: "languages"
  });

  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 7;
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [citySuggestions, setCitySuggestions] = useState<CitySuggestion[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [citySearchQuery, setCitySearchQuery] = useState('');
  const [categories, setCategories] = useState<JobOption[]>([]);
  const [workModes, setWorkModes] = useState<JobOption[]>([]);
  const [experienceLevels, setExperienceLevels] = useState<JobOption[]>([]);
  const [contractTypes, setContractTypes] = useState<JobOption[]>([]);
  const [benefits, setBenefits] = useState<JobOption[]>([]);
  const [languages, setLanguages] = useState<JobOption[]>([]);
  const [technologies, setTechnologies] = useState<JobOption[]>([]);
  const [prices, setPrices] = useState({
    job_posting_price_standard: 599,
    job_posting_price_premium: 899
  });

  // Funkcja do walidacji pól dla danego kroku
  const validateStepFields = async (step: number): Promise<boolean> => {
    setIsValidating(true);
    let isValid = false;
    
    try {
      switch (step) {
        case 1:
          isValid = await trigger(['title', 'category', 'description'], { shouldFocus: true });
          break;
        case 2:
          isValid = await trigger(['responsibilities', 'requirements'], { shouldFocus: true });
          break;
        case 3:
          isValid = await trigger(['technologies', 'languages'], { shouldFocus: true });
          break;
        case 4:
          isValid = await trigger(['workMode', 'experienceLevel', 'contractType', 'salaryFrom', 'salaryTo'], { shouldFocus: true });
          break;
        case 5:
          isValid = await trigger(['location.country', 'location.voivodeship', 'location.city'], { shouldFocus: true });
          break;
        case 6:
          isValid = await trigger(['company.name', 'company.description', 'company.size', 'company.logo'], { shouldFocus: true });
          break;
        case 7:
          isValid = await trigger(['contact.name', 'contact.position', 'contact.email', 'packageType'], { shouldFocus: true });
          break;
        default:
          isValid = true;
      }
      return isValid;
    } finally {
      setIsValidating(false);
    }
  };

  // Funkcja do przejścia do następnego kroku
  const nextStep = async () => {
    if (currentStep >= totalSteps) return;
    
    const isValid = await validateStepFields(currentStep);
    
    if (isValid) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };

  const onSubmit = async (data) => {
    setIsSubmitting(true);
    
    // Create a copy of the data to avoid modifying the original
    const formData = { ...data };
    
    try {
      // Handle file upload if there's a logo file
      if (formData.company.logo && formData.company.logo instanceof File) {
        const logoFile = formData.company.logo;
        
        // We'll store the file information but not upload it yet
        // The actual upload will happen after payment is confirmed
        formData.company.logoFile = {
          name: logoFile.name,
          type: logoFile.type,
          size: logoFile.size,
          lastModified: logoFile.lastModified
        };
        
        // Create a temporary data URL for preview in the summary
        const reader = new FileReader();
        const logoUrlPromise = new Promise<string>((resolve) => {
          reader.onload = () => resolve(reader.result as string);
          reader.readAsDataURL(logoFile);
        });
        
        formData.company.logoPreviewUrl = await logoUrlPromise;
        
        // Remove the actual file object as it can't be serialized
        delete formData.company.logo;
      }
      
      // Serialize the form data and remove any circular references
      const serializedData = JSON.parse(JSON.stringify({
        ...formData,
        valid_until: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000).toISOString() // 60 days from now
      }));
      
      // Navigate to summary page with the data
      navigate('/dodaj-ogloszenie/podsumowanie', {
        state: { jobData: serializedData }
      });
    } catch (error) {
      console.error('Error creating job posting:', error);
      alert('Wystąpił błąd podczas dodawania ogłoszenia. Spróbuj ponownie.');
    } finally {
      setIsSubmitting(false);
    } 
  };

  // Form data storage key
  const FORM_DATA_STORAGE_KEY = 'jobPostingFormData';

  useEffect(() => {
    fetchJobOptions();
    fetchPrices();
    
    // Check for saved form data when component mounts
    const savedFormData = sessionStorage.getItem(FORM_DATA_STORAGE_KEY);
    if (savedFormData) {
      try {
        const parsedData = JSON.parse(savedFormData);
        
        // Set all form values at once
        const formValues = { ...parsedData };
        delete formValues._returnToStep; // Remove special key
        
        // Set all values at once
        setValue('title', formValues.title);
        setValue('category', formValues.category);
        setValue('description', formValues.description);
        setValue('responsibilities', formValues.responsibilities);
        setValue('requirements', formValues.requirements);
        setValue('niceToHave', formValues.niceToHave || []);
        setValue('technologies', formValues.technologies);
        setValue('workMode', formValues.workMode);
        setValue('experienceLevel', formValues.experienceLevel);
        setValue('contractType', formValues.contractType);
        setValue('salaryFrom', formValues.salaryFrom);
        setValue('salaryTo', formValues.salaryTo);
        setValue('currency', formValues.currency);
        setValue('benefits', formValues.benefits || []);
        setValue('location', formValues.location);
        setValue('languages', formValues.languages);
        setValue('company', formValues.company);
        setValue('contact', formValues.contact);
        setValue('packageType', formValues.packageType);
        
        console.log('Restored category:', formValues.category);
        
        // Set city search query if location.city exists
        if (formValues.location && formValues.location.city) {
          setCitySearchQuery(formValues.location.city);
        }
        
        // If returning from summary, go to the specified step
        if (parsedData._returnToStep) {
          setCurrentStep(parsedData._returnToStep);
        }
        
        // Don't clear storage to allow returning to edit again if needed
      } catch (error) {
        console.error('Error parsing saved form data:', error);
      }
    }
  }, []);

  const fetchJobOptions = async () => {
    try {
      const [
        { data: categoriesData, error: categoriesError },
        { data: workModesData },
        { data: experienceLevelsData },
        { data: contractTypesData },
        { data: benefitsData },
        { data: languagesData },
        { data: technologiesData }
      ] = await Promise.all([
        supabase.from('job_categories').select('*').order('name'),
        supabase.from('working_modes').select('*').order('name'),
        supabase.from('experience_levels').select('*').order('name'),
        supabase.from('contract_types').select('*').order('name'),
        supabase.from('benefits').select('*').order('name'),
        supabase.from('languages').select('*').order('name'),
        supabase.from('technologies').select('*').order('category', { ascending: true }).order('name', { ascending: true })
      ]);

      if (categoriesError) {
        console.error('Error fetching categories:', categoriesError);
      }
      
      setCategories(categoriesData || []);
      setWorkModes(workModesData || []);
      setExperienceLevels(experienceLevelsData || []);
      setContractTypes(contractTypesData || []);
      setBenefits(benefitsData || []);
      setLanguages(languagesData || []);
      setTechnologies(technologiesData || []);
    } catch (err) {
      console.error('Error fetching job options:', err);
    }
  };

  const fetchPrices = async () => {
    try {
      const { data, error } = await supabase
        .from('site_settings')
        .select('key, value')
        .in('key', ['job_posting_price_standard', 'job_posting_price_premium']);

      if (error) throw error;

      const pricesMap = data.reduce((acc, { key, value }) => {
        acc[key] = value;
        return acc;
      }, {} as any);

      setPrices(pricesMap);
    } catch (err) {
      console.error('Error fetching prices:', err);
    }
  };

  useEffect(() => {
    const fetchCitySuggestions = async () => {
      if (citySearchQuery.length < 2) {
        setCitySuggestions([]);
        setShowSuggestions(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .rpc('search_cities', {
            search_query: citySearchQuery
          });

        if (error) throw error;

        setCitySuggestions(data);
        setShowSuggestions(true);
      } catch (err) {
        console.error('Error fetching city suggestions:', err);
        setCitySuggestions([]);
      }
    };

    const timeoutId = setTimeout(fetchCitySuggestions, 300);
    return () => clearTimeout(timeoutId);
  }, [citySearchQuery]);

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <BasicInformation
            id="step-1" 
            register={register} 
            errors={errors} 
            categories={categories} 
            watch={watch}
          />
        );

      case 2:
        return (
          <RequirementsAndResponsibilities
            id="step-2"
            register={register}
            errors={errors}
            responsibilitiesArray={{
              fields: responsibilitiesFields,
              append: appendResponsibility,
              remove: removeResponsibility
            }}
            requirementsArray={{
              fields: requirementsFields,
              append: appendRequirement,
              remove: removeRequirement
            }}
            niceToHaveArray={{
              fields: niceToHaveFields,
              append: appendNiceToHave,
              remove: removeNiceToHave
            }}
          />
        );

      case 3:
        return (
          <TechnologiesAndSkills
            id="step-3"
            register={register}
            errors={errors}
            languagesArray={{
              fields: languagesFields,
              append: appendLanguage,
              remove: removeLanguage
            }}
            languages={languages}
            technologies={technologies}
          />
        );

      case 4:
        return (
          <EmploymentDetails
            id="step-4"
            register={register}
            errors={errors}
            workModes={workModes}
            experienceLevels={experienceLevels}
            contractTypes={contractTypes}
            benefits={benefits}
          />
        );

      case 5:
        return (
          <Location
            id="step-5"
            register={register}
            errors={errors}
            watch={watch}
            citySearchQuery={citySearchQuery}
            setCitySearchQuery={setCitySearchQuery}
            showSuggestions={showSuggestions}
            setShowSuggestions={setShowSuggestions}
            citySuggestions={citySuggestions}
            setValue={setValue}
          />
        );

      case 6:
        return (
          <CompanyInformation
            id="step-6"
            register={register}
            errors={errors}
            setValue={setValue}
            watch={watch}
          />
        );

      case 7:
        return (
          <ContactAndPublish
            id="step-7"
            register={register}
            errors={errors}
            prices={prices}
          />
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
            <div className="flex items-center justify-between mb-8">
              <h1 className="text-2xl font-bold text-purple-900">
                Dodaj ogłoszenie o pracę
              </h1>
              <div className="text-sm text-purple-600">
                Krok {currentStep} z {totalSteps}
              </div>
            </div>

            {/* Error Messages */}
            <div className="mt-6">
              {Object.keys(errors).length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                  <div className="flex items-center mb-2">
                    <Info className="w-5 h-5 text-red-500 mr-2" />
                    <h4 className="font-medium text-red-700">
                      Formularz zawiera błędy
                    </h4>
                  </div>
                  <ul className="space-y-1 text-sm text-red-600">
                    {errors.contact?.name && (
                      <li>• Imię i nazwisko: {errors.contact.name.message}</li>
                    )}
                    {errors.contact?.position && (
                      <li>• Stanowisko: {errors.contact.position.message}</li>
                    )}
                    {errors.contact?.email && (
                      <li>• Email: {errors.contact.email.message}</li>
                    )}
                    {errors.contact?.phone && (
                      <li>• Telefon: {errors.contact.phone.message}</li>
                    )}
                    {errors.packageType && (
                      <li>• {errors.packageType.message}</li>
                    )}
                    {Object.keys(errors).filter(key => !key.startsWith('contact')).map((key) => (
                      <li key={key}>• {errors[key].message}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="h-2 bg-purple-100 rounded-full mb-8">
              <div
                className="h-full bg-purple-600 rounded-full transition-all duration-300"
                style={{ width: `${(currentStep / totalSteps) * 100}%` }}
              />
            </div>

            {renderStep()}

            <div className="flex justify-between mt-8">
              {currentStep > 1 && (
                <button
                  type="button"
                  onClick={prevStep}
                  className="flex items-center px-6 py-3 bg-gray-100 text-purple-700 rounded-xl hover:bg-gray-200 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={isValidating}
                >
                  <ArrowLeft className="w-5 h-5 mr-2" />
                  Wstecz
                </button>
              )}
              {currentStep < totalSteps ? (
                <button
                  type="button"
                  onClick={nextStep}
                  className="flex items-center px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors ml-auto disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={isValidating}
                >
                  {isValidating ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Sprawdzanie...
                    </>
                  ) : (
                    <>
                      Dalej
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </>
                  )}
                </button>
              ) : (
                <button
                  type="submit"
                  className="flex items-center px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors ml-auto disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={isSubmitting || isValidating}
                  onClick={async () => {
                    // Waliduj ostatni krok przed wysłaniem formularza
                    const isValid = await validateStepFields(currentStep);
                    if (!isValid) {
                      // Zatrzymaj domyślne zachowanie przycisku submit jeśli walidacja nie przeszła
                      event.preventDefault();
                    }
                  }}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Przetwarzanie...
                    </>
                   ) : isValidating ? (
                     <>
                       <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                       Sprawdzanie...
                     </>
                  ) : (
                    <>
                      <ArrowRight className="w-5 h-5 mr-2" />
                      Przejdź do podsumowania
                    </>
                  )}
                </button>
              )}
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}