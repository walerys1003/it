import React from 'react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import {
  Check,
  Star,
  Zap,
  Target,
  Clock,
  Users,
  ArrowRight,
  Building2,
  Code,
  Rocket,
  Shield,
  Search,
  Phone,
  Mail,
  MessageSquare,
  Briefcase
} from 'lucide-react';
import { supabase } from '../lib/supabase';

type Settings = {
  job_posting_price_standard: number;
  job_posting_price_premium: number;
  contact_phone: string;
  contact_email: string;
};

const features = [
  { icon: <Clock className="w-5 h-5" />, text: 'Długa ekspozycja - 60 dni widoczności' },
  { icon: <Users className="w-5 h-5" />, text: 'Dotarcie do specjalistów IT' },
  { icon: <Target className="w-5 h-5" />, text: 'Szerszy zasięg w wyszukiwarce' },
  { icon: <Zap className="w-5 h-5" />, text: 'Łatwa publikacja w 5 minut' }
];

const premiumFeatures = [
  'Podświetlenie kolorystyczne ogłoszenia',
  'Specjalna etykieta "Ogłoszenie Premium"',
  'Wyższa pozycja w wynikach wyszukiwania',
  'Pogrubiona nazwa stanowiska',
  'Dodatkowa ikona wizualna ⭐',
  '90 dni widoczności'
];

const targetAudience = [
  {
    icon: <Building2 className="w-6 h-6" />,
    title: 'Firmy IT',
    description: 'Znajdź najlepszych programistów, analityków i administratorów'
  },
  {
    icon: <Rocket className="w-6 h-6" />,
    title: 'Startupy technologiczne',
    description: 'Rekrutuj kreatywnych specjalistów gotowych do nowych wyzwań'
  },
  {
    icon: <Code className="w-6 h-6" />,
    title: 'Software house\'y',
    description: 'Znajdź doświadczonych programistów, architektów IT i testerów'
  }
];

const specialists = {
  'Programiści': [
    'Frontend Developer',
    'Backend Developer',
    'Full Stack Developer',
    'Mobile Developer (iOS/Android)',
    'DevOps Engineer'
  ],
  'Specjaliści IT': [
    'Administrator sieci',
    'Specjalista ds. bezpieczeństwa',
    'Analityk danych',
    'Tester oprogramowania',
    'Project Manager',
    'UX/UI Designer'
  ]
};

const steps = [
  {
    icon: <Search className="w-6 h-6" />,
    title: 'Dodajesz ogłoszenie',
    description: 'Wybierasz stanowisko, wymagania i wynagrodzenie – to proste i intuicyjne!'
  },
  {
    icon: <Users className="w-6 h-6" />,
    title: 'Twoja oferta dociera do najlepszych kandydatów',
    description: 'Publikujemy Twoje ogłoszenie i promujemy je w odpowiednich miejscach'
  },
  {
    icon: <MessageSquare className="w-6 h-6" />,
    title: 'Otrzymujesz aplikacje',
    description: 'Kandydaci aplikują bezpośrednio przez portal lub kontaktują się telefonicznie'
  },
  {
    icon: <Shield className="w-6 h-6" />,
    title: 'Zatrudniasz najlepszych specjalistów IT',
    description: 'Szybko i skutecznie znajdujesz idealnego kandydata do swojej firmy'
  }
];

export default function Pricing() {
  const [settings, setSettings] = useState<Settings>({
    job_posting_price_standard: 599,
    job_posting_price_premium: 899,
    contact_phone: '',
    contact_email: ''
  });
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('site_settings')
        .select('key, value')
        .in('key', [
          'job_posting_price_standard',
          'job_posting_price_premium',
          'contact_phone',
          'contact_email'
        ]);

      if (error) throw error;

      const settingsMap = data.reduce((acc, { key, value }) => {
        acc[key] = value;
        return acc;
      }, {} as Settings);

      setSettings(settingsMap);
    } catch (err) {
      console.error('Error fetching settings:', err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Schema.org structured data for pricing page */}
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Service',
            'name': 'Usługi publikacji ogłoszeń o pracę w IT',
            'provider': {
              '@type': 'Organization',
              'name': 'StartJob.IT',
              'url': 'https://startjob.it'
            },
            'serviceType': 'Job Posting Service',
            'description': 'Publikacja ogłoszeń o pracę w branży IT, z opcjami pakietów Standard i Premium',
            'offers': [
              {
                '@type': 'Offer',
                'name': 'Pakiet Standard',
                'price': settings.job_posting_price_standard,
                'priceCurrency': 'PLN',
                'description': 'Ogłoszenie o pracę widoczne przez 60 dni',
                'availability': 'https://schema.org/InStock'
              },
              {
                '@type': 'Offer',
                'name': 'Pakiet Premium',
                'price': settings.job_posting_price_premium,
                'priceCurrency': 'PLN',
                'description': 'Ogłoszenie o pracę widoczne przez 90 dni z wyróżnieniem',
                'availability': 'https://schema.org/InStock'
              }
            ]
          })}
        </script>
      </Helmet>

      {/* Hero Section with improved wave */}
      <div className="bg-gradient-hero text-white relative pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-24">
          <div className="text-center max-w-4xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="bg-yellow-400 bg-opacity-20 rounded-full p-4">
                <Briefcase className="w-12 h-12 text-yellow-400" />
              </div>
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-8">
              Cennik usług StartJob.IT
            </h1>
            <div className="space-y-6 text-xl text-purple-200">
              <p className="text-2xl font-medium">
                🚀 StartJob.IT – Twój klucz do najlepszych specjalistów IT i sukcesu w branży technologicznej!
              </p>
              <p>
                W świecie IT czas to pieniądz, a skuteczna rekrutacja to fundament rozwoju każdej firmy technologicznej. 
                StartJob.IT to platforma stworzona z myślą o branży IT – łączy najlepszych specjalistów z wiodącymi pracodawcami.
              </p>
              <p>
                Szybkie, skuteczne i profesjonalne ogłoszenia o pracę dla programistów, administratorów, analityków, 
                testerów i innych ekspertów IT.
              </p>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 w-full">
          <svg className="w-full" viewBox="0 0 1440 120" preserveAspectRatio="none">
            <path 
              fill="#ffffff" 
              d="M0,64L80,69.3C160,75,320,85,480,80C640,75,800,53,960,48C1120,43,1280,53,1360,58.7L1440,64L1440,120L1360,120C1280,120,1120,120,960,120C800,120,640,120,480,120C320,120,160,120,80,120L0,120Z"
            ></path>
          </svg>
        </div>
      </div>

      {/* Pricing Cards */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-16 relative z-10">
        <div className="grid md:grid-cols-2 gap-8">
          {/* Standard Plan */}
          <div className="bg-white rounded-3xl shadow-xl p-8 transform hover:scale-105 transition-transform duration-300">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-2xl font-bold text-purple-900">Ogłoszenie Standard</h3>
                <p className="text-purple-600 mt-2">60 dni widoczności</p>
              </div>
              <div className="bg-purple-100 rounded-full p-3">
                <Zap className="w-6 h-6 text-purple-600" />
              </div>
            </div>
            <div className="mt-8">
              <span className="text-4xl font-bold text-purple-900">{settings.job_posting_price_standard} zł</span>
              <span className="text-purple-600 ml-2">z VAT</span>
            </div>
            <div className="mt-8 space-y-4">
              <div className="p-4 bg-purple-50 rounded-xl">
                <p className="text-purple-900 font-medium">
                  📢 OGŁOSZENIE NA 60 DNI
                </p>
              </div>
              <div className="space-y-3">
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Clock className="w-5 h-5 text-purple-500" />
                  </div>
                  <div className="ml-4">
                    <p className="font-medium text-purple-900">DŁUGA EKSPOZYCJA</p>
                    <p className="text-purple-600">Twoja oferta będzie widoczna przez 2 miesiące – nie zniknie w morzu innych ogłoszeń!</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Users className="w-5 h-5 text-purple-500" />
                  </div>
                  <div className="ml-4">
                    <p className="font-medium text-purple-900">DOTARCIE DO SPECJALISTÓW</p>
                    <p className="text-purple-600">Twoje ogłoszenie zobaczą programiści, administratorzy, analitycy i inni eksperci IT, gotowi do działania.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Target className="w-5 h-5 text-purple-500" />
                  </div>
                  <div className="ml-4">
                    <p className="font-medium text-purple-900">SZERSZY ZASIĘG</p>
                    <p className="text-purple-600">Promujemy Twoją ofertę w wyszukiwarce i kategoriach tematycznych, aby trafiła do najbardziej kompetentnych kandydatów.</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-1">
                    <Zap className="w-5 h-5 text-purple-500" />
                  </div>
                  <div className="ml-4">
                    <p className="font-medium text-purple-900">ŁATWA PUBLIKACJA</p>
                    <p className="text-purple-600">Intuicyjny system dodawania ofert – zajmie Ci to mniej niż 5 minut!</p>
                  </div>
                </div>
              </div>
            </div>
            <button
              onClick={() => navigate('/dodaj-ogloszenie')}
              className="mt-8 w-full bg-purple-600 text-white rounded-xl py-4 font-medium hover:bg-purple-700 transition-colors"
            >
              Dodaj ogłoszenie
            </button>
          </div>

          {/* Premium Plan */}
          <div className="bg-gradient-to-br from-purple-600 to-purple-900 rounded-3xl shadow-xl p-8 transform hover:scale-105 transition-transform duration-300 relative overflow-hidden">
            <div className="absolute top-4 right-4">
              <div className="bg-yellow-400 rounded-full p-2">
                <Star className="w-6 h-6 text-purple-900" />
              </div>
            </div>
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-2xl font-bold text-white">Ogłoszenie Premium</h3>
                <p className="text-purple-200 mt-2">90 dni widoczności</p>
              </div>
              <div className="bg-yellow-400 bg-opacity-20 rounded-full p-3">
                <Star className="w-6 h-6 text-yellow-400" />
              </div>
            </div>
            <div className="mt-8">
              <span className="text-4xl font-bold text-white">{settings.job_posting_price_premium} zł</span>
              <span className="text-purple-200 ml-2">z VAT</span>
            </div>
            <div className="mt-8 space-y-4">
              <div className="p-4 bg-white bg-opacity-10 rounded-xl backdrop-blur-lg">
                <p className="text-white font-medium">
                  ⭐ Wyróżnienie Premium na 90 dni
                </p>
              </div>
              <div className="space-y-3">
                {premiumFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center">
                    <Check className="w-5 h-5 text-yellow-400" />
                    <p className="ml-4 text-white">{feature}</p>
                  </div>
                ))}
              </div>
              <div className="p-4 bg-white bg-opacity-10 rounded-xl mt-6">
                <p className="text-white">
                  🚀 Zwiększ skuteczność swojego ogłoszenia i przyciągnij więcej kandydatów!
                  Dzięki wyróżnieniu Twoja oferta nie zniknie w tłumie – stanie się bardziej widoczna,
                  przyciągnie uwagę i szybciej znajdzie odpowiednich specjalistów IT.
                </p>
              </div>
            </div>
            <button
              onClick={() => navigate('/dodaj-ogloszenie')}
              className="mt-8 w-full bg-yellow-400 text-purple-900 rounded-xl py-4 font-medium hover:bg-yellow-300 transition-colors"
            >
              Wybierz Premium
            </button>
          </div>
        </div>
      </div>

      {/* Benefits Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <h2 className="text-3xl font-bold text-purple-900 text-center mb-16">
          Dlaczego warto publikować oferty pracy na StartJob.IT?
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-white p-6 rounded-2xl shadow-lg">
            <div className="bg-purple-100 rounded-full p-4 inline-block mb-4">
              <Code className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-bold text-purple-900 mb-3">Tworzony dla IT</h3>
            <p className="text-purple-600">
              Trafiasz bezpośrednio do programistów, analityków i specjalistów, którzy szukają pracy w Twojej branży.
            </p>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-lg">
            <div className="bg-purple-100 rounded-full p-4 inline-block mb-4">
              <Target className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-bold text-purple-900 mb-3">Precyzyjne targetowanie</h3>
            <p className="text-purple-600">
              Filtruj kandydatów według umiejętności, doświadczenia i lokalizacji.
            </p>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-lg">
            <div className="bg-purple-100 rounded-full p-4 inline-block mb-4">
              <Zap className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-bold text-purple-900 mb-3">Szybka publikacja</h3>
            <p className="text-purple-600">
              Dodaj ogłoszenie w mniej niż 3 minuty – bez zbędnych formalności!
            </p>
          </div>
          <div className="bg-white p-6 rounded-2xl shadow-lg">
            <div className="bg-purple-100 rounded-full p-4 inline-block mb-4">
              <Rocket className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-xl font-bold text-purple-900 mb-3">Maksymalna widoczność</h3>
            <p className="text-purple-600">
              Twoja oferta trafi do tysięcy aktywnych użytkowników i pojawi się w wynikach wyszukiwania Google.
            </p>
          </div>
        </div>
      </div>

      {/* How it Works */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <h2 className="text-3xl font-bold text-purple-900 text-center mb-16">
          Jak działa StartJob.IT?
        </h2>
        <div className="grid md:grid-cols-4 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <div className="bg-white rounded-2xl p-6 shadow-lg h-full">
                <div className="bg-purple-100 rounded-full p-4 inline-block mb-4">
                  {step.icon}
                </div>
                <h3 className="text-xl font-bold text-purple-900 mb-3">{step.title}</h3>
                <p className="text-purple-600">{step.description}</p>
              </div>
              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 right-0 transform translate-x-1/2 -translate-y-1/2">
                  <ArrowRight className="w-6 h-6 text-purple-400" />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Target Audience */}
      <div className="bg-gradient-hero text-white py-24 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-16">
            Dla kogo jest StartJob.IT?
          </h2>
          <div className="grid md:grid-cols-3 gap-8">
            {targetAudience.map((audience, index) => (
              <div key={index} className="bg-white bg-opacity-10 rounded-2xl p-8 backdrop-blur-lg">
                <div className="bg-purple-500 bg-opacity-20 rounded-full p-4 inline-block mb-6">
                  {audience.icon}
                </div>
                <h3 className="text-xl font-bold mb-4">{audience.title}</h3>
                <p className="text-purple-200">{audience.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Available Specialists */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <h2 className="text-3xl font-bold text-purple-900 text-center mb-16">
          Kogo możesz zatrudnić?
        </h2>
        <div className="grid md:grid-cols-2 gap-12">
          {Object.entries(specialists).map(([category, roles]) => (
            <div key={category} className="bg-white rounded-2xl shadow-lg p-8">
              <h3 className="text-2xl font-bold text-purple-900 mb-6">{category}</h3>
              <div className="space-y-3">
                {roles.map((role, index) => (
                  <div key={index} className="flex items-center">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="ml-3 text-purple-800">{role}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Contact Section */}
      <div className="bg-gradient-hero text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-4">Masz pytania?</h2>
            <p className="text-xl text-purple-200">Skontaktuj się z nami!</p>
          </div>
          <div className="flex flex-col sm:flex-row justify-center gap-4 sm:gap-8">
            <a href={`mailto:${settings.contact_email}`} 
              className="flex items-center justify-center bg-white bg-opacity-10 rounded-xl px-6 py-4 hover:bg-opacity-20 transition-colors w-full sm:w-auto"
            >
              <Mail className="w-6 h-6 mr-3" />
              <span>{settings.contact_email}</span>
            </a>
            <a href={`tel:${settings.contact_phone}`} 
              className="flex items-center justify-center bg-white bg-opacity-10 rounded-xl px-6 py-4 hover:bg-opacity-20 transition-colors w-full sm:w-auto"
            >
              <Phone className="w-6 h-6 mr-3" />
              <span>{settings.contact_phone}</span>
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}