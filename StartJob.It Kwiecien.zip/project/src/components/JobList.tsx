import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Building2, MapPin, Clock, Star, Globe, FileText, Tag,
  Gift, Code, Crown, Sparkles, Users
} from 'lucide-react';
import { JobFilters } from './SearchFilters';
import { contractTypes } from '../data/jobPostingData';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

const workModeIcons = {
  remote: <Globe className="w-4 h-4" />,
  hybrid: <Users className="w-4 h-4" />,
  office: <Building2 className="w-4 h-4" />
};

const workModeLabels = {
  remote: 'Praca zdalna',
  hybrid: 'Praca hybrydowa',
  office: 'Praca w biurze'
};

const benefitLabels = {
  'flexible-hours': 'Elastyczne godziny pracy',
  '4-day-week': '4-dniowy tydzień pracy',
  'training-budget': 'Budżet na szkolenia',
  'medical': 'Prywatna opieka medyczna',
  'sports-card': 'Pakiet sportowy',
  'stock-options': 'Opcje na akcje',
  'equipment': 'Sprzęt firmowy',
  'abroad': 'Możliwość pracy za granicą'
};

const getContractTypeLabel = (type: string) => {
  const contractType = contractTypes.find(t => t.value === type);
  return contractType ? contractType.label : type;
};

type JobListProps = {
  filters?: JobFilters;
};

type PaginationProps = {
  currentPage: number;
  totalPages: number;
  onPageChange: (page: number) => void;
};

function Pagination({ currentPage, totalPages, onPageChange }: PaginationProps) {
  // Calculate which page numbers to show
  const getVisiblePages = () => {
    const delta = 2; // Number of pages to show on each side of current page
    const range = [];
    const rangeWithDots = [];
    let l;

    for (let i = 1; i <= totalPages; i++) {
      if (
        i === 1 || 
        i === totalPages || 
        (i >= currentPage - delta && i <= currentPage + delta)
      ) {
        range.push(i);
      }
    }

    for (let i of range) {
      if (l) {
        if (i - l === 2) {
          rangeWithDots.push(l + 1);
        } else if (i - l !== 1) {
          rangeWithDots.push('...');
        }
      }
      rangeWithDots.push(i);
      l = i;
    }

    return rangeWithDots;
  };
  
  return (
    <div className="flex justify-center items-center space-x-1">
      {/* Previous page button */}
      <button
        onClick={() => onPageChange(currentPage - 1)}
        disabled={currentPage === 1}
        className="px-3 py-2 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed bg-white text-purple-600 hover:bg-purple-50"
      >
        ←
      </button>

      {/* Page numbers */}
      {getVisiblePages().map((page, index) => (
        typeof page === 'number' ? (
          <button
            key={index}
            onClick={() => onPageChange(page)}
            className={`
              min-w-[40px] px-3 py-2 rounded-lg font-medium transition-colors
              ${currentPage === page
                ? 'bg-purple-600 text-white'
                : 'bg-white text-purple-600 hover:bg-purple-50'
              }
            `}
          >
            {page}
          </button>
        ) : (
          <span key={index} className="px-2 text-purple-400">
            {page}
          </span>
        )
      ))}

      {/* Next page button */}
      <button
        onClick={() => onPageChange(currentPage + 1)}
        disabled={currentPage === totalPages}
        className="px-3 py-2 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed bg-white text-purple-600 hover:bg-purple-50"
      >
        →
      </button>
    </div>
  );
}

export default function JobList({ filters }: JobListProps) {
  const [jobs, setJobs] = useState([]);
  const [totalJobs, setTotalJobs] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [paginationKey, setPaginationKey] = useState(0);
  const [benefits, setBenefits] = useState<Array<{id: string, name: string, code: string}>>([]);
  const [categories, setCategories] = useState<Array<{id: string, name: string, code: string, parent_id?: string}>>([]);
  const jobsPerPage = 15;
  const navigate = useNavigate();

  useEffect(() => {
    const fetchOptions = async () => {
      try {
        const [
          { data: benefitsData },
          { data: categoriesData }
        ] = await Promise.all([
          supabase.from('benefits').select('*'),
          supabase.from('job_categories').select('*')
        ]);
        
        setBenefits(benefitsData || []);
        setCategories(categoriesData || []);
      } catch (err) {
        console.error('Error fetching options:', err);
      }
    };
    
    fetchOptions();
  }, []);

  useEffect(() => {
    const fetchJobs = async () => {
      let query = supabase
        .from('jobs')
        .select('*')
        .eq('is_active', true)
        .gt('valid_until', new Date().toISOString());

      // Apply filters
      if (filters) {
        if (filters.search) {
          query = query.or(`title.ilike.%${filters.search}%,description.ilike.%${filters.search}%,company_name.ilike.%${filters.search}%`);
        }

        if (filters.location.country) {
          // Handle different location types
          if (filters.location.country === 'polska') {
            query = query.eq('location_country', 'Polska');
          } else if (filters.location.country === 'remote') {
            query = query.eq('work_mode', 'remote');
          } else if (filters.location.country === 'abroad') {
            query = query.neq('location_country', 'Polska');
          }
        }

        if (filters.location.voivodeship) {
          query = query.eq('location_voivodeship', filters.location.voivodeship);
        }

        if (filters.location.city) {
          query = query.ilike('location_city', `%${filters.location.city}%`);
        }

        if (filters.categories.length > 0) {
          query = query.in('category', filters.categories);
        }

        if (filters.workModes.length > 0) {
          query = query.in('work_mode', filters.workModes);
        }

        if (filters.experienceLevels.length > 0) {
          query = query.in('experience_level', filters.experienceLevels);
        }

        if (filters.contractTypes.length > 0) {
          query = query.in('contract_type', filters.contractTypes);
        }

        if (filters.technologies.length > 0) {
          query = query.contains('technologies', filters.technologies);
        }

        if (filters.salaryRange.from) {
          query = query.gte('salary_from', filters.salaryRange.from);
        }

        if (filters.salaryRange.to) {
          query = query.lte('salary_to', filters.salaryRange.to);
        }

        if (filters.benefits.length > 0) {
          query = query.contains('benefits', filters.benefits);
        }

        if (filters.onlySalaryVisible) {
          query = query.not('salary_from', 'is', null);
        }
      }

      // Order results
      query = query
        .order('is_featured', { ascending: false })
        .order('created_at', { ascending: false })
        .range((currentPage - 1) * jobsPerPage, currentPage * jobsPerPage - 1);

      try {
        // Get total count
        const { count: totalCount } = await supabase
          .from('jobs')
          .select('*', { count: 'exact', head: true })
          .eq('is_active', true)
          .gt('valid_until', new Date().toISOString());

        setTotalJobs(totalCount || 0);

        // Get paginated data
        const { data, error } = await query;

        if (error) throw error;
        setJobs(data);
      } catch (err) {
        console.error('Error fetching jobs:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, [filters, currentPage]);

  // Reset pagination when filters change
  useEffect(() => {
    setCurrentPage(1);
    setPaginationKey(prev => prev + 1);
  }, [filters]);
  
  // Helper function to get category name from code
  const getCategoryName = (categoryCode: string): string => {
    const category = categories.find(cat => cat.code === categoryCode);
    return category?.name || categoryCode;
  };

  const handleJobClick = (jobId) => {
    navigate(`/oferta/${jobId}`);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-purple-200 border-t-purple-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 text-red-600 p-4 rounded-xl">
        <p>Wystąpił błąd podczas ładowania ofert pracy.</p>
        <p className="text-sm mt-2">Spróbuj odświeżyć stronę.</p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Total count */}
      <div className="text-sm text-purple-600">
        Znaleziono: <span className="font-medium">{totalJobs}</span> {totalJobs === 1 ? 'ogłoszenie' : 
          totalJobs % 10 >= 2 && totalJobs % 10 <= 4 && (totalJobs % 100 < 10 || totalJobs % 100 >= 20) ? 'ogłoszenia' : 'ogłoszeń'
        }
      </div>

      {jobs.map((job) => (
        <div
          key={job.id}
          onClick={() => handleJobClick(job.id)}
          className={`block relative bg-white rounded-2xl transition-all duration-300 transform hover:scale-[1.02] cursor-pointer ${
            job.is_featured 
              ? 'shadow-xl border-2 border-yellow-400/30' 
              : 'shadow-lg hover:shadow-xl'
          }`}
        >
          {/* Premium Banner */}
          {job.is_featured && (
            <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 whitespace-nowrap">
              <div className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-purple-900 px-4 py-1 rounded-full shadow-lg flex items-center space-x-2">
                <Crown className="w-4 h-4" />
                <span className="font-medium text-sm">Ogłoszenie Premium</span>
              </div>
            </div>
          )}

          <div className={`p-4 sm:p-6 ${job.is_featured ? 'pt-8' : ''}`}>
            <div className="flex flex-col gap-4 sm:gap-5">
              {/* Title Row - Logo and Title */}
              <div className="flex items-start gap-4">
              {/* Company Logo */}
                <div className="relative flex-shrink-0 w-12 h-12 sm:w-16 sm:h-16">
                <div className={`relative rounded-2xl overflow-hidden ${
                  job.is_featured ? 'ring-4 ring-yellow-400/20' : ''
                }`}>
                  <img
                    src={job.company_logo}
                    alt={job.company_name}
                    className="w-full h-full object-cover"
                  />
                  {job.is_featured && (
                    <div className="absolute inset-0 bg-gradient-to-br from-yellow-400/10 to-purple-600/10" />
                  )}
                </div>
                {job.is_featured && (
                  <div className="absolute -top-2 -right-2">
                    <div className="bg-yellow-400 rounded-full p-1 shadow-lg">
                      <Star className="w-4 h-4 text-purple-900" />
                    </div>
                  </div>
                )}
              </div>

                {/* Title and Company */}
                <div className="flex-1 min-w-0 overflow-hidden">
                  <h3 className={`text-lg sm:text-xl font-bold line-clamp-2 ${
                    job.is_featured ? 'text-purple-900' : 'text-purple-800'
                  }`}>
                    {job.title}
                  </h3>
                  <p className="text-purple-700 font-medium mt-1 text-ellipsis overflow-hidden whitespace-nowrap">{job.company_name}</p>
                  <div>
                    <span className="inline-flex items-center text-xs text-purple-600">
                      {getCategoryName(job.category)}
                    </span>
                  </div>
                </div>
              </div>

              {/* Job Details */}
              <div className="flex-1 min-w-0 overflow-hidden">
                {job.is_featured && (
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                      <Sparkles className="w-3 h-3 mr-1" />
                      Premium
                    </span>
                    <span className="text-xs text-purple-600">
                      do {new Date(job.valid_until).toLocaleDateString()}
                    </span>
                  </div>
                )}

                {/* Job Meta Info */}
                <div className="mt-4 flex flex-wrap gap-2 sm:gap-4 text-sm text-purple-600">
                  <div className="flex items-center">
                    {workModeIcons[job.work_mode]}
                    <span className="ml-1.5">{workModeLabels[job.work_mode]}</span>
                  </div>
                  <div className="flex items-center">
                    <MapPin className="w-4 h-4 mr-1.5" />
                    <span className="truncate max-w-[120px]">{job.location_city}</span>
                  </div>
                  <div className="flex items-center">
                    <FileText className="w-4 h-4 mr-1.5" />
                    <span className="truncate max-w-[120px]">{getContractTypeLabel(job.contract_type)}</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="w-4 h-4 mr-1.5" />
                    <span className="whitespace-nowrap">{new Date(job.created_at).toLocaleDateString()}</span>
                  </div>
                </div>

                {/* Salary */}
                <div className="mt-3">
                  <span className={`text-lg font-semibold whitespace-nowrap ${
                    job.is_featured ? 'text-green-600' : 'text-green-600'
                  }`}>
                    {job.salary_from} - {job.salary_to} {job.currency}
                  </span>
                  <span className="text-sm text-purple-600 ml-2">netto/msc</span>
                </div>

                {/* Technologies & Benefits */}
                <div className="mt-4 flex flex-wrap gap-1.5 sm:gap-2 overflow-hidden">
                  {job.technologies.map((tech, index) => (
                    <span
                      key={index}
                      className={`inline-flex items-center px-2 sm:px-3 py-1 rounded-full text-xs sm:text-sm font-medium ${
                        job.is_featured
                          ? 'bg-purple-100 text-purple-700'
                          : 'bg-purple-50 text-purple-700'
                      }`}
                    >
                      <Code className="w-4 h-4 mr-1" />
                      <span className="truncate max-w-[150px]">{tech}</span>
                    </span>
                  ))}
                </div>

                <div className="mt-3 flex flex-wrap gap-1.5 sm:gap-2 overflow-hidden">
                  {job.benefits.map((benefit, index) => (
                    <span
                      key={index}
                      className={`inline-flex items-center px-2 sm:px-3 py-1 rounded-full text-xs sm:text-sm ${
                        job.is_featured
                          ? 'bg-green-100 text-green-700'
                          : 'bg-green-50 text-green-700'
                      }`}
                    >
                      <Gift className="w-4 h-4 mr-1" />
                      <span className="truncate max-w-[150px]">
                        {benefitLabels[benefit] || benefit}
                      </span>
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      ))}

      {/* Pagination */}
      {totalJobs > jobsPerPage && (
        <Pagination
          key={paginationKey}
          currentPage={currentPage}
          totalPages={Math.ceil(totalJobs / jobsPerPage)}
          onPageChange={setCurrentPage}
        />
      )}
    </div>
  );
}