import React from 'react';
import { UseFormRegister, FieldErrors, UseFieldArrayReturn } from 'react-hook-form';
import { Plus, X } from 'lucide-react';

type RequirementsAndResponsibilitiesProps = {
  id?: string;
  register: UseFormRegister<any>;
  errors: FieldErrors;
  responsibilitiesArray: UseFieldArrayReturn;
  requirementsArray: UseFieldArrayReturn;
  niceToHaveArray: UseFieldArrayReturn;
};

export default function RequirementsAndResponsibilities({
  id,
  register,
  errors,
  responsibilitiesArray,
  requirementsArray,
  niceToHaveArray
}: RequirementsAndResponsibilitiesProps) {
  return (
    <div className="space-y-6" id={id}>
      <h2 className="text-xl font-bold text-purple-900">
        Wymagania i obowiązki
      </h2>

      {/* Responsibilities */}
      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Zakres obowiązków
          {errors.responsibilities && (
            <span className="text-sm text-red-600 ml-2">
              Dodaj minimum jeden obowiązek
            </span>
          )}
        </label>
        <p className="text-sm text-purple-600 mb-2">
          Dodaj minimum jeden obowiązek
        </p>
        <div className="space-y-3">
          {responsibilitiesArray.fields.map((field, index) => (
            <div key={field.id} className="flex gap-2">
              <input
                {...register(`responsibilities.${index}`)}
                className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. Rozwój aplikacji w React.js (min. 5 znaków)"
              />
              <button
                type="button"
                onClick={() => responsibilitiesArray.remove(index)}
                className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() => responsibilitiesArray.append('')}
            className="flex items-center text-purple-600 hover:text-purple-700"
          >
            <Plus className="w-5 h-5 mr-2" />
            Dodaj obowiązek
          </button>
        </div>
        {errors.responsibilities && (
          <p className="mt-1 text-sm text-red-600">{errors.responsibilities.message}</p>
        )}
      </div>

      {/* Requirements */}
      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Wymagania
          {errors.requirements && (
            <span className="text-sm text-red-600 ml-2">
              Dodaj minimum jedno wymaganie
            </span>
          )}
        </label>
        <p className="text-sm text-purple-600 mb-2">
          Dodaj minimum jedno wymaganie
        </p>
        <div className="space-y-3">
          {requirementsArray.fields.map((field, index) => (
            <div key={field.id} className="flex gap-2">
              <input
                {...register(`requirements.${index}`)}
                className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. Min. 3 lata doświadczenia w React.js (min. 5 znaków)"
              />
              <button
                type="button"
                onClick={() => requirementsArray.remove(index)}
                className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() => requirementsArray.append('')}
            className="flex items-center text-purple-600 hover:text-purple-700"
          >
            <Plus className="w-5 h-5 mr-2" />
            Dodaj wymaganie
          </button>
        </div>
        {errors.requirements && (
          <p className="mt-1 text-sm text-red-600">{errors.requirements.message}</p>
        )}
      </div>

      {/* Nice to Have */}
      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Mile widziane
        </label>
        <p className="text-sm text-purple-600 mb-2">
          Opcjonalne dodatkowe wymagania
        </p>
        <div className="space-y-3">
          {niceToHaveArray.fields.map((field, index) => (
            <div key={field.id} className="flex gap-2">
              <input
                {...register(`niceToHave.${index}`)}
                className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. Znajomość TypeScript (min. 5 znaków)"
              />
              <button
                type="button"
                onClick={() => niceToHaveArray.remove(index)}
                className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() => niceToHaveArray.append('')}
            className="flex items-center text-purple-600 hover:text-purple-700"
          >
            <Plus className="w-5 h-5 mr-2" />
            Dodaj mile widziane
          </button>
        </div>
      </div>
    </div>
  );
}