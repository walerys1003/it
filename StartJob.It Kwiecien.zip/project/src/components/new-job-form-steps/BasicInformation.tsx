import React from 'react';
import { UseFormRegister, FieldErrors } from 'react-hook-form';
import { useEffect, useState } from 'react';

type JobOption = {
  id: string;
  name: string;
  code: string;
};

type BasicInformationProps = {
  id?: string;
  register: UseFormRegister<any>;
  errors: FieldErrors;
  categories: JobOption[];
  watch?: any;
};

export default function BasicInformation({ id, register, errors, categories, watch }: BasicInformationProps) {
  const [mainCategories, setMainCategories] = useState<JobOption[]>([]);
  const [subCategories, setSubCategories] = useState<{[key: string]: JobOption[]}>({});
  const selectedCategory = watch ? watch('category') : '';
  
  useEffect(() => {
    // Separate main categories and subcategories
    const mains = categories.filter(category => !category.parent_id);
    setMainCategories(mains);
    
    // Group subcategories by parent_id
    const subs: {[key: string]: JobOption[]} = {};
    categories.filter(category => category.parent_id).forEach(subcat => {
      if (!subs[subcat.parent_id!]) {
        subs[subcat.parent_id!] = [];
      }
      subs[subcat.parent_id!].push(subcat);
    });
    setSubCategories(subs);
  }, [categories]);
  
  return (
    <div className="space-y-6" id={id}>
      <h2 className="text-xl font-bold text-purple-900">
        Podstawowe informacje
      </h2>
      
      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Stanowisko
        </label>
        <input
          type="text"
          {...register("title")}
          className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          placeholder="np. Senior React Developer (min. 10 znaków)"
        />
        {errors.title && (
          <p className="mt-1 text-sm text-red-600">{errors.title.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Kategoria
        </label>
        <select
          {...register("category")}
          className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          value={selectedCategory}
        >
          <option value="">Wybierz kategorię</option>
          {mainCategories.map((mainCategory) => {
            const subs = subCategories[mainCategory.id] || [];
            return (
              <optgroup key={mainCategory.id} label={mainCategory.name}>
                {subs.map((subCategory) => (
                  <option key={subCategory.id} value={subCategory.code}>
                    {subCategory.name}
                  </option>
                ))}
              </optgroup>
            );
          })}
        </select>
        {errors.category && (
          <p className="mt-1 text-sm text-red-600">{errors.category.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Opis stanowiska
        </label>
        <textarea
          {...register("description")}
          rows={6}
          className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          placeholder="Opisz szczegółowo stanowisko, zakres obowiązków i wymagania... (min. 100 znaków)"
        />
        {errors.description && (
          <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
        )}
      </div>
    </div>
  );
}