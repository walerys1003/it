import React from 'react';
import { UseFormRegister, FieldErrors } from 'react-hook-form';
import { Crown, Briefcase, Check } from 'lucide-react';

type Settings = {
  job_posting_price_standard: number;
  job_posting_price_premium: number;
};

type ContactAndPublishProps = {
  id?: string;
  register: UseFormRegister<any>;
  errors: FieldErrors;
  prices: Settings;
};

export default function ContactAndPublish({
  id,
  register,
  errors,
  prices
}: ContactAndPublishProps) {
  return (
    <div className="space-y-6" id={id}>
      <h2 className="text-xl font-bold text-purple-900">
        Dane kontaktowe i publikacja
      </h2>

      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Imię i nazwisko osoby kontaktowej
          <span className="text-red-600 ml-1">*</span>
        </label>
        <input
          type="text"
          {...register('contact.name')}
          className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          placeholder="np. Jan Kowalski"
        />
        {errors.contact?.name && (
          <p className="mt-1 text-sm text-red-600">{errors.contact.name.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Stanowisko
          <span className="text-red-600 ml-1">*</span>
        </label>
        <input
          type="text"
          {...register('contact.position')}
          className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          placeholder="np. HR Manager"
        />
        {errors.contact?.position && (
          <p className="mt-1 text-sm text-red-600">{errors.contact.position.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Email
          <span className="text-red-600 ml-1">*</span>
        </label>
        <input
          type="email"
          {...register('contact.email')}
          className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          placeholder="np. jan.kowalski@firma.pl"
        />
        {errors.contact?.email && (
          <p className="mt-1 text-sm text-red-600">{errors.contact.email.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Telefon
        </label>
        <input
          type="tel"
          {...register('contact.phone')}
          className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          placeholder="np. +48 500 600 700"
        />
        {errors.contact?.phone && (
          <p className="mt-1 text-sm text-red-600">{errors.contact.phone.message}</p>
        )}
      </div>

      <div className="bg-purple-50 p-6 rounded-xl space-y-4">
        <h3 className="font-medium text-purple-900 flex items-center">
          Wybierz pakiet ogłoszenia
          <span className="text-red-600 ml-1">*</span>
        </h3>
        
        <div className="grid grid-cols-2 gap-4">
          <label className="relative flex flex-col p-6 bg-white rounded-xl border-2 border-purple-200 cursor-pointer hover:border-purple-300">
            <input
              type="radio"
              {...register('packageType')}
              value="standard"
              className="absolute right-4 top-4"
            />
            <div className="flex items-center mb-4">
              <Briefcase className="w-6 h-6 text-purple-600 mr-2" />
              <span className="font-medium text-purple-900">Standard</span>
            </div>
            <div className="text-2xl font-bold text-purple-900 mb-2">
              {prices.job_posting_price_standard} zł
              <span className="text-sm font-normal text-purple-600 ml-1">z VAT</span>
            </div>
            <ul className="space-y-2 text-sm text-purple-600">
              <li className="flex items-center">
                <Check className="w-4 h-4 text-green-500 mr-2" />
                <span>60 dni widoczności</span>
              </li>
              <li className="flex items-center">
                <Check className="w-4 h-4 text-green-500 mr-2" />
                <span>Podstawowa promocja</span>
              </li>
            </ul>
          </label>

          <label className="relative flex flex-col p-6 bg-gradient-to-br from-purple-500 to-purple-700 rounded-xl border-2 border-purple-400 cursor-pointer hover:border-purple-300 text-white">
            <input
              type="radio"
              {...register('packageType')}
              value="premium"
              className="absolute right-4 top-4"
            />
            <div className="flex items-center mb-4">
              <Crown className="w-6 h-6 text-yellow-400 mr-2" />
              <span className="font-medium">Premium</span>
            </div>
            <div className="text-2xl font-bold mb-2">
              {prices.job_posting_price_premium} zł
              <span className="text-sm font-normal text-purple-200 ml-1">z VAT</span>
            </div>
            <ul className="space-y-2 text-sm text-purple-200">
              <li className="flex items-center">
                <Check className="w-4 h-4 text-yellow-400 mr-2" />
                <span>90 dni widoczności</span>
              </li>
              <li className="flex items-center">
                <Check className="w-4 h-4 text-yellow-400 mr-2" />
                <span>Wyróżnienie na liście</span>
              </li>
              <li className="flex items-center">
                <Check className="w-4 h-4 text-yellow-400 mr-2" />
                <span>Promocja w social media</span>
              </li>
            </ul>
          </label>
        </div>
        {errors.packageType && (
          <p className="mt-2 text-sm text-red-600">{errors.packageType.message}</p>
        )}
      </div>
    </div>
  );
}