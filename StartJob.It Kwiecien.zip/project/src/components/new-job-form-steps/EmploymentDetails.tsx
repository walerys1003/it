import React from 'react';
import { UseFormRegister, FieldErrors } from 'react-hook-form';

type JobOption = {
  id: string;
  name: string;
  code: string;
};

type EmploymentDetailsProps = {
  id?: string;
  register: UseFormRegister<any>;
  errors: FieldErrors;
  workModes: JobOption[];
  experienceLevels: JobOption[];
  contractTypes: JobOption[];
  benefits: JobOption[];
};

export default function EmploymentDetails({
  id,
  register,
  errors,
  workModes,
  experienceLevels,
  contractTypes,
  benefits
}: EmploymentDetailsProps) {
  return (
    <div className="space-y-6" id={id}>
      <h2 className="text-xl font-bold text-purple-900">
        Warunki zatrudnienia
      </h2>

      {/* Work Mode */}
      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Tryb pracy
          {errors.workMode?.message && (
            <span className="text-sm text-red-600 ml-2">
              {errors.workMode.message}
            </span>
          )}
        </label>
        <div className="grid grid-cols-3 gap-4">
          {workModes.map((mode) => (
            <label
              key={mode.id}
              className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
            >
              <input
                type="radio"
                {...register('workMode')}
                value={mode.code}
                className="mr-3 text-purple-600 focus:ring-purple-500"
              />
              {mode.name}
            </label>
          ))}
        </div>
        {errors.workMode && (
          <p className="mt-1 text-sm text-red-600">{errors.workMode.message}</p>
        )}
      </div>

      {/* Experience Level */}
      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Poziom doświadczenia
          {errors.experienceLevel && (
            <span className="text-sm text-red-600 ml-2">
              {errors.experienceLevel.message}
            </span>
          )}
        </label>
        <div className="grid grid-cols-2 gap-4">
          {experienceLevels.map((level) => (
            <label
              key={level.id}
              className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
            >
              <input
                type="radio"
                {...register('experienceLevel')}
                value={level.code}
                className="mr-3 text-purple-600 focus:ring-purple-500"
              />
              {level.name}
            </label>
          ))}
        </div>
        {errors.experienceLevel && (
          <p className="mt-1 text-sm text-red-600">{errors.experienceLevel.message}</p>
        )}
      </div>

      {/* Contract Type */}
      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Typ umowy
          {errors.contractType && (
            <span className="text-sm text-red-600 ml-2">
              {errors.contractType.message}
            </span>
          )}
        </label>
        <div className="grid grid-cols-2 gap-4">
          {contractTypes.map((type) => (
            <label
              key={type.id}
              className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
            >
              <input
                type="radio"
                {...register('contractType')}
                value={type.code}
                className="mr-3 text-purple-600 focus:ring-purple-500"
              />
              {type.name}
            </label>
          ))}
        </div>
        {errors.contractType && (
          <p className="mt-1 text-sm text-red-600">{errors.contractType.message}</p>
        )}
      </div>

      {/* Salary Range */}
      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Wynagrodzenie (PLN netto/msc)
          {(errors.salaryFrom || errors.salaryTo) && (
            <span className="text-sm text-red-600 ml-2">
              {errors.salaryFrom?.message || errors.salaryTo?.message}
            </span>
          )}
        </label>
        <div className="flex gap-4 items-center">
          <input
            type="number"
            {...register('salaryFrom', { valueAsNumber: true })}
            className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            placeholder="Od"
          />
          <span className="text-purple-600">-</span>
          <input
            type="number"
            {...register('salaryTo', { valueAsNumber: true })}
            className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            placeholder="Do"
          />
        </div>
        {(errors.salaryFrom || errors.salaryTo) && (
          <p className="mt-1 text-sm text-red-600">
            {errors.salaryFrom?.message || errors.salaryTo?.message}
          </p>
        )}
      </div>

      {/* Benefits */}
      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Benefity
        </label>
        <div className="grid grid-cols-2 gap-4">
          {benefits.map((benefit) => (
            <label
              key={benefit.id}
              className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
            >
              <input
                type="checkbox"
                {...register('benefits', { required: false })}
                value={benefit.code}
                className="mr-3 rounded border-purple-300 text-purple-600 focus:ring-purple-500"
              />
              {benefit.name}
            </label>
          ))}
        </div>
      </div>
    </div>
  );
}