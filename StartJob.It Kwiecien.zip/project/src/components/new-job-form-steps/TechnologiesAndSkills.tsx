import React from 'react';
import { UseFormRegister, FieldErrors, UseFieldArrayReturn } from 'react-hook-form';
import { Plus, X } from 'lucide-react';

type JobOption = {
  id: string;
  name: string;
  code: string;
  category?: string;
};

type TechnologiesAndSkillsProps = {
  id?: string;
  register: UseFormRegister<any>;
  errors: FieldErrors;
  languagesArray: UseFieldArrayReturn;
  languages: JobOption[];
  technologies: JobOption[];
};

export default function TechnologiesAndSkills({
  id,
  register,
  errors,
  languagesArray,
  languages,
  technologies
}: TechnologiesAndSkillsProps) {
  // Group technologies by category
  const groupedTechnologies = technologies.reduce((acc, tech) => {
    if (!tech.category) return acc;
    if (!acc[tech.category]) {
      acc[tech.category] = [];
    }
    acc[tech.category].push(tech);
    return acc;
  }, {} as Record<string, JobOption[]>);

  return (
    <div className="space-y-6" id={id}>
      <h2 className="text-xl font-bold text-purple-900">
        Technologie i umiejętności
      </h2>

      {/* Technologies */}
      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Wymagane technologie
          {errors.technologies && (
            <span className="text-sm text-red-600 ml-2">
              Wybierz minimum jedną technologię
            </span>
          )}
        </label>
        <div className="space-y-5">
          {Object.entries(groupedTechnologies).map(([category, techs]) => (
            <div key={category} className="space-y-2">
              <h3 className="text-sm font-medium text-purple-700">{category}</h3>
              <div className="flex flex-wrap gap-2">
                {techs.map((tech) => (
                  <label
                    key={tech.id}
                    className="inline-flex items-center px-4 py-2 rounded-xl border border-purple-200 hover:bg-purple-50 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      {...register('technologies')}
                      value={tech.code}
                      className="mr-2 rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                    />
                    {tech.name}
                  </label>
                ))}
              </div>
            </div>
          ))}
        </div>
        {errors.technologies && (
          <p className="mt-1 text-sm text-red-600">{errors.technologies.message}</p>
        )}
      </div>

      {/* Languages */}
      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Wymagane języki
          {errors.languages && (
            <span className="text-sm text-red-600 ml-2">
              Dodaj minimum jeden język
            </span>
          )}
        </label>
        <div className="space-y-3">
          {languagesArray.fields.map((field, index) => (
            <div key={field.id} className="flex gap-4">
              <select
                {...register(`languages.${index}.language`)}
                className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              >
                <option value="">Wybierz język</option>
                {languages.map((lang) => (
                  <option key={lang.id} value={lang.code}>
                    {lang.name}
                  </option>
                ))}
              </select>
              <select
                {...register(`languages.${index}.level`)}
                className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              >
                <option value="">Poziom</option>
                <option value="A1">A1 - Początkujący</option>
                <option value="A2">A2 - Podstawowy</option>
                <option value="B1">B1 - Średniozaawansowany</option>
                <option value="B2">B2 - Wyższy średniozaawansowany</option>
                <option value="C1">C1 - Zaawansowany</option>
                <option value="C2">C2 - Biegły</option>
                <option value="native">Ojczysty</option>
              </select>
              <button
                type="button"
                onClick={() => languagesArray.remove(index)}
                className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() => languagesArray.append({ language: '', level: '' })}
            className="flex items-center text-purple-600 hover:text-purple-700"
          >
            <Plus className="w-5 h-5 mr-2" />
            Dodaj język
          </button>
        </div>
        {errors.languages && (
          <p className="mt-1 text-sm text-red-600">{errors.languages.message}</p>
        )}
      </div>
    </div>
  );
}