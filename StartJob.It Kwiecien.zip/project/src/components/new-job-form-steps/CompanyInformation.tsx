import React from 'react';
import { UseFormRegister, FieldErrors, UseFormSetValue, UseFormWatch } from 'react-hook-form';
import { Image, Upload, X } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';

type CompanyInformationProps = {
  id?: string;
  register: UseFormRegister<any>;
  errors: FieldErrors;
  setValue: UseFormSetValue<any>;
  watch: UseFormWatch<any>;
};

// Hardcoded company sizes
const companySizes = [
  { code: '1-10', name: '1-10 pracowników' },
  { code: '11-50', name: '11-50 pracowników' },
  { code: '51-200', name: '51-200 pracowników' },
  { code: '201-500', name: '201-500 pracowników' },
  { code: '501-1000', name: '501-1000 pracowników' },
  { code: '1000+', name: '1000+ pracowników' }
];

export default function CompanyInformation({
  id,
  register,
  errors,
  setValue,
  watch
}: CompanyInformationProps) {
  const [dragActive, setDragActive] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Watch company logo to detect changes
  const companyLogo = watch('company.logo');
  
  // Set up preview URL if logo already exists (for edit mode)
  useEffect(() => {
    if (companyLogo && typeof companyLogo === 'string' && !previewUrl) {
      setPreviewUrl(companyLogo);
    }
  }, [companyLogo]);
  
  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    handleFile(file);
  };
  
  // Handle file drop
  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };
  
  // Process the selected file
  const handleFile = (file: File | undefined) => {
    if (!file) return;
    
    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml'];
    if (!validTypes.includes(file.type)) {
      setFileError('Dozwolone formaty plików: JPG, PNG, GIF, SVG');
      return;
    }
    
    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      setFileError('Maksymalny rozmiar pliku to 2MB');
      return;
    }
    
    // Clear any previous errors
    setFileError(null);
    
    // Create a preview URL
    const objectUrl = URL.createObjectURL(file);
    setPreviewUrl(objectUrl);
    
    // Store the file in the form
    setValue('company.logo', file);
  };
  
  // Remove the selected file
  const handleRemoveFile = () => {
    setValue('company.logo', null);
    setPreviewUrl(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };
  
  // Handle drag events
  const handleDrag = (e: React.DragEvent<HTMLDivElement>, active: boolean) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(active);
  };

  return (
    <div className="space-y-6" id={id}>
      <h2 className="text-xl font-bold text-purple-900">
        Informacje o firmie
      </h2>

      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Nazwa firmy
          <span className="text-red-600 ml-1">*</span>
        </label>
        <input
          type="text"
          {...register('company.name')}
          className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          placeholder="np. TechCorp Solutions"
        />
        {errors.company?.name && (
          <p className="mt-1 text-sm text-red-600">{errors.company.name.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Opis firmy
          <span className="text-red-600 ml-1">*</span>
        </label>
        <textarea
          {...register('company.description')}
          rows={4}
          className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
          placeholder="Krótki opis działalności firmy..."
        />
        {errors.company?.description && (
          <p className="mt-1 text-sm text-red-600">{errors.company.description.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Wielkość firmy
          <span className="text-red-600 ml-1">*</span>
        </label>
        <select
          {...register('company.size')}
          className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
        >
          <option value="">Wybierz wielkość</option>
          {companySizes.map((size) => (
            <option key={size.id} value={size.code}>
              {size.name}
            </option>
          ))}
        </select>
        {errors.company?.size && (
          <p className="mt-1 text-sm text-red-600">{errors.company.size.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-purple-900 mb-2">
          Logo firmy
          <span className="text-red-600 ml-1">*</span>          
        </label>
        
        {/* File upload area */}
        <div 
          className={`mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-xl ${
            dragActive 
              ? 'border-purple-500 bg-purple-50' 
              : 'border-purple-200 hover:border-purple-400'
          } transition-colors`}
          onDragEnter={(e) => handleDrag(e, true)}
          onDragLeave={(e) => handleDrag(e, false)}
          onDragOver={(e) => handleDrag(e, true)}
          onDrop={handleDrop}
        >
          {previewUrl ? (
            <div className="space-y-4 w-full flex flex-col items-center">
              <div className="relative w-40 h-40">
                <img 
                  src={previewUrl} 
                  alt="Logo podgląd" 
                  className="w-full h-full object-contain"
                />
                <button
                  type="button"
                  onClick={handleRemoveFile}
                  className="absolute -top-2 -right-2 bg-red-100 text-red-600 rounded-full p-1 hover:bg-red-200"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <p className="text-sm text-purple-600">
                {companyLogo?.name}
              </p>
            </div>
          ) : (
            <div className="space-y-1 text-center">
              <div className="flex flex-col items-center">
                <Image className="mx-auto h-12 w-12 text-purple-400" />
                <div className="flex text-sm text-purple-600 mt-2">
                  <label
                    htmlFor="company-logo-upload"
                    className="relative cursor-pointer bg-white rounded-md font-medium text-purple-600 hover:text-purple-500 focus-within:outline-none"
                  >
                    <span>Przeciągnij i upuść plik lub</span>
                    <span className="ml-1 text-purple-500 hover:text-purple-700"> przeglądaj</span>
                    <input
                      id="company-logo-upload"
                      name="company-logo-upload"
                      type="file"
                      className="sr-only"
                      accept="image/*"
                      onChange={handleFileChange}
                      ref={fileInputRef}
                    />
                  </label>
                </div>
                <p className="text-xs text-purple-500 mt-1">
                  PNG, JPG, GIF do 2MB
                </p>
              </div>
            </div>
          )}
        </div>
        
        {/* Register the logo field for validation */}
        {/* This hidden input is used for validation purposes */}
        <input
          type="hidden"
          {...register('company.logo')}
        />
        
        {/* Error messages */}
        {(errors.company?.logo || fileError) && (
          <p className="mt-2 text-sm text-red-600">
            {errors.company?.logo?.message || fileError}
          </p>
        )}
        
        {/* Validation message */}
        {!errors.company?.logo && !fileError && (
          <p className="mt-2 text-sm text-purple-600">
            {previewUrl ? 
              "Logo zostało dodane poprawnie" : 
              "Dodaj logo firmy (wymagane)"}
          </p>
        )}
      </div>
    </div>
  );
}