import React from 'react';
import { UseFormRegister, FieldErrors, UseFormWatch } from 'react-hook-form';
import { locations } from '../../data/jobPostingData';

type LocationProps = {
  id?: string;
  register: UseFormRegister<any>;
  errors: FieldErrors;
  watch: UseFormWatch<any>;
  citySearchQuery: string;
  setCitySearchQuery: (value: string) => void;
  showSuggestions: boolean;
  setShowSuggestions: (value: boolean) => void;
  citySuggestions: Array<{ city: string; count: number }>;
  setValue: (field: string, value: any) => void;
};

export default function Location({
  id,
  register,
  errors,
  watch,
  citySearchQuery,
  setCitySearchQuery,
  showSuggestions,
  setShowSuggestions,
  citySuggestions,
  setValue
}: LocationProps) {
  return (
    <div className="space-y-6" id={id}>
      <h2 className="text-xl font-bold text-purple-900">
        Lokalizacja
      </h2>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-purple-900 mb-2">
            Kraj
            <span className="text-red-600 ml-1">*</span>
            {errors.location?.country && (
              <span className="text-sm text-red-600 ml-2">
                {errors.location.country.message}
              </span>
            )}
          </label>
          <select
            {...register('location.country')}
            className={`w-full px-4 py-3 rounded-xl border ${
              errors.location?.country 
                ? 'border-red-300 focus:ring-red-500 focus:border-red-500' 
                : 'border-purple-200 focus:ring-purple-500 focus:border-purple-500'
            }`}
          >
            <option value="">Wybierz kraj</option>
            {locations.countries.map((country) => (
              <option key={country.value} value={country.value}>
                {country.label}
              </option>
            ))}
          </select>
          {errors.location?.country && (
            <p className="mt-1 text-sm text-red-600">{errors.location.country.message}</p>
          )}
        </div>

        {watch('location.country') === 'pl' && (
          <div>
            <label className="block text-sm font-medium text-purple-900 mb-2">
              Województwo
              <span className="text-red-600 ml-1">*</span>
              {errors.location?.voivodeship && (
                <span className="text-sm text-red-600 ml-2">
                  {errors.location.voivodeship.message}
                </span>
              )}
            </label>
            <select
              {...register('location.voivodeship')}
              className={`w-full px-4 py-3 rounded-xl border ${
                errors.location?.voivodeship 
                  ? 'border-red-300 focus:ring-red-500 focus:border-red-500' 
                  : 'border-purple-200 focus:ring-purple-500 focus:border-purple-500'
              }`}
            >
              <option value="">Wybierz województwo</option>
              {locations.voivodeships.map((voivodeship) => (
                <option key={voivodeship.value} value={voivodeship.value}>
                  {voivodeship.label}
                </option>
              ))}
            </select>
          </div>
        )}

        <div>
          <div className="relative">
            <label className="block text-sm font-medium text-purple-900 mb-2">
              Miasto
              <span className="text-red-600 ml-1">*</span>
              {errors.location?.city && (
                <span className="text-sm text-red-600 ml-2">
                  {errors.location.city.message}
                </span>
              )}
            </label>
            <input
              type="text"
              value={citySearchQuery}
              onChange={(e) => {
                setCitySearchQuery(e.target.value);
                setValue('location.city', e.target.value);
                // Ensure the hidden input is updated as well
                register('location.city').onChange({ target: { value: e.target.value } });
              }}
              onFocus={() => setShowSuggestions(true)}
              onBlur={() => {
                // Delay hiding suggestions to allow clicking them
                setTimeout(() => setShowSuggestions(false), 200);
              }}
              className={`w-full px-4 py-3 rounded-xl border ${
                errors.location?.city 
                  ? 'border-red-300 focus:ring-red-500 focus:border-red-500' 
                  : 'border-purple-200 focus:ring-purple-500 focus:border-purple-500'
              }`}
              placeholder="Wpisz nazwę miasta"
            />
            {showSuggestions && citySuggestions.length > 0 && (
              <div className="absolute z-10 w-full mt-1 bg-white rounded-xl shadow-lg border border-purple-100">
                {citySuggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    type="button"
                    className="w-full px-4 py-2 text-left hover:bg-purple-50 first:rounded-t-xl last:rounded-b-xl"
                    onClick={() => {
                      setValue('location.city', suggestion.city);
                      setCitySearchQuery(suggestion.city);
                      // Ensure the hidden input is updated as well
                      register('location.city').onChange({ target: { value: suggestion.city } });
                      setShowSuggestions(false);
                    }}
                  >
                    <span className="text-purple-900">{suggestion.city}</span>
                    <span className="text-sm text-purple-500 ml-2">
                      ({suggestion.count} {suggestion.count === 1 ? 'oferta' : 'ofert'})
                    </span>
                  </button>
                ))}
              </div>
            )}
            <input
              type="hidden"
              {...register('location.city')}
            />
          </div>
        </div>
      </div>
    </div>
  );
}