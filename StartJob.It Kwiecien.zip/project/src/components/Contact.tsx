import React, { useState, useEffect } from 'react';
import { Mail, Phone, MapPin, Clock, Users, MessageSquare, FileText, Building2, ArrowRight, Loader2, CheckCircle2, AlertCircle } from 'lucide-react';
import { Helmet } from 'react-helmet-async';
import { sendEmail } from '../lib/email';
import { supabase } from '../lib/supabase';

type Settings = {
  contact_phone: string;
  contact_email: string;
  contact_address: {
    street: string;
    city: string;
    postal_code: string;
    country: string;
  };
};

const contactReasons = [
  {
    icon: <Users className="w-6 h-6" />,
    title: 'Szukasz pracy?',
    description: 'Doradzimy, jak znaleźć najlepszą ofertę dopasowaną do Twoich umiejętności i doświadczenia.'
  },
  {
    icon: <Building2 className="w-6 h-6" />,
    title: 'Rekrutujesz?',
    description: 'Pomożemy Ci znaleźć idealnego specjalistę IT, który sprosta Twoim wymaganiom.'
  },
  {
    icon: <MessageSquare className="w-6 h-6" />,
    title: 'Indywidualne podejście',
    description: 'Dostosowujemy nasze rozwiązania do Twoich specyficznych potrzeb.'
  },
  {
    icon: <ArrowRight className="w-6 h-6" />,
    title: 'Szybka odpowiedź',
    description: 'Odpowiadamy na Twoje pytania w ciągu 24 godzin.'
  }
];

const departments = [
  {
    icon: <MessageSquare className="w-6 h-6" />,
    title: 'Wsparcie techniczne',
    description: 'Masz pytania dotyczące publikacji ogłoszeń lub chcesz dowiedzieć się więcej o naszych usługach?',
    email: 'kontakt@startjob.it',
    phone: '(+48) 501 42 00 42'
  },
  {
    icon: <FileText className="w-6 h-6" />,
    title: 'Faktury i płatności',
    description: 'Masz pytania dotyczące rozliczeń, faktur lub płatności? Skontaktuj się z naszym działem finansowym!',
    email: 'kontakt@startjob.it',
    phone: '(+48) 501 42 00 42'
  }
];

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [settings, setSettings] = useState<Settings>({
    contact_phone: '',
    contact_email: '',
    contact_address: {
      street: '',
      city: '',
      postal_code: '',
      country: ''
    }
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('site_settings')
        .select('key, value')
        .in('key', [
          'contact_phone',
          'contact_email',
          'contact_address'
        ]);

      if (error) throw error;

      const settingsMap = data.reduce((acc, { key, value }) => {
        acc[key] = value;
        return acc;
      }, {} as Settings);

      setSettings(settingsMap);
    } catch (err) {
      console.error('Error fetching settings:', err);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus('idle');
    setErrorMessage('');

    try {
      // Send notification to admin
      const adminTemplate = {
        subject: `Nowa wiadomość: ${formData.subject}`,
        message: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #4a3471;">Nowa wiadomość z formularza kontaktowego</h2>
            
            <div style="background: #f5f3fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
              <p><strong>Od:</strong> ${formData.name}</p>
              <p><strong>Email:</strong> ${formData.email}</p>
              <p><strong>Temat:</strong> ${formData.subject}</p>
            </div>
            
            <p><strong>Treść wiadomości:</strong></p>
            <div style="background: #f5f3fa; padding: 20px; border-radius: 8px;">
              ${formData.message.replace(/\n/g, '<br>')}
            </div>
            
            <p style="color: #666; font-size: 14px; margin-top: 20px;">
              Wiadomość wysłana przez formularz kontaktowy na StartJob.IT
            </p>
          </div>
        `
      };

      // Send confirmation to user
      const userTemplate = {
        subject: 'Potwierdzenie wysłania wiadomości - StartJob.IT',
        message: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #4a3471;">Dziękujemy za kontakt!</h2>
            
            <p>Witaj ${formData.name},</p>
            
            <p>Dziękujemy za wysłanie wiadomości przez formularz kontaktowy StartJob.IT.</p>
            
            <p>Potwierdzamy otrzymanie Twojej wiadomości o temacie: <strong>${formData.subject}</strong></p>
            
            <p>Odpowiemy na Twoją wiadomość najszybciej jak to możliwe.</p>
            
            <p style="margin-top: 30px; color: #666;">
              Pozdrawiamy,<br>
              Zespół StartJob.IT
            </p>
          </div>
        `
      };

      // Send both emails
      const adminEmailSent = await sendEmail('kontakt@startjob.it', adminTemplate);
      const userEmailSent = await sendEmail(formData.email, userTemplate);

      if (!adminEmailSent || !userEmailSent) {
        throw new Error('Nie udało się wysłać wiadomości. Spróbuj ponownie później.');
      }

      setSubmitStatus('success');
      setFormData({
        name: '',
        email: '',
        subject: '',
        message: ''
      });
    } catch (error) {
      console.error('Error sending contact form:', error);
      setSubmitStatus('error');
      setErrorMessage(error.message || 'Wystąpił błąd podczas wysyłania wiadomości.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Schema.org structured data for contact page */}
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'ContactPage',
            'name': 'Kontakt StartJob.IT',
            'description': 'Skontaktuj się z nami. StartJob.IT - Twój partner w rekrutacji IT.',
            'mainEntity': {
              '@type': 'Organization',
              'name': 'StartJob.IT',
              'telephone': settings.contact_phone,
              'email': settings.contact_email,
              'address': {
                '@type': 'PostalAddress',
                'streetAddress': settings.contact_address.street,
                'addressLocality': settings.contact_address.city,
                'postalCode': settings.contact_address.postal_code,
                'addressCountry': settings.contact_address.country
              },
              'openingHoursSpecification': {
                '@type': 'OpeningHoursSpecification',
                'dayOfWeek': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
                'opens': '08:00',
                'closes': '16:00'
              }
            }
          })}
        </script>
      </Helmet>

      {/* Hero Section */}
      <div className="bg-gradient-hero text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="bg-yellow-400 bg-opacity-20 rounded-full p-4">
                <MessageSquare className="w-12 h-12 text-yellow-400" />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Kontakt
            </h1>
            <p className="text-xl text-purple-200">
              Zawsze otwarci na kontakt – Twój sukces w IT zaczyna się tutaj!
            </p>
          </div>
        </div>
      </div>

      {/* Contact Card */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 relative z-10">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="flex items-center space-x-4">
              <div className="bg-purple-100 rounded-full p-3">
                <MapPin className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h3 className="font-medium text-purple-900">Adres</h3>
                <p className="text-purple-600">{settings.contact_address.street}</p>
                <p className="text-purple-600">{settings.contact_address.postal_code} {settings.contact_address.city}</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="bg-purple-100 rounded-full p-3">
                <Mail className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h3 className="font-medium text-purple-900">Email</h3>
                <a href={`mailto:${settings.contact_email}`} className="text-purple-600 hover:text-purple-700">
                  {settings.contact_email}
                </a>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="bg-purple-100 rounded-full p-3">
                <Phone className="w-6 h-6 text-purple-600" />
              </div>
              <div>
                <h3 className="font-medium text-purple-900">Telefon</h3>
                <a href={`tel:${settings.contact_phone}`} className="text-purple-600 hover:text-purple-700">
                  {settings.contact_phone}
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid lg:grid-cols-3 gap-12">
          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h2 className="text-2xl font-bold text-purple-900 mb-6">Wyślij wiadomość</h2>
              <form onSubmit={handleSubmit} className="space-y-6">
                {submitStatus === 'success' && (
                  <div className="p-4 bg-green-50 rounded-xl flex items-center text-green-700">
                    <CheckCircle2 className="w-5 h-5 mr-2" />
                    <span>Dziękujemy za wysłanie wiadomości! Odpowiemy najszybciej jak to możliwe.</span>
                  </div>
                )}
                {submitStatus === 'error' && (
                  <div className="p-4 bg-red-50 rounded-xl flex items-center text-red-700">
                    <AlertCircle className="w-5 h-5 mr-2" />
                    <span>{errorMessage}</span>
                  </div>
                )}
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Imię i nazwisko
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder="Jan Kowalski"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder="jan@example.com"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-purple-900 mb-2">
                    Temat
                  </label>
                  <input
                    type="text"
                    name="subject"
                    value={formData.subject}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="W czym możemy pomóc?"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-purple-900 mb-2">
                    Wiadomość
                  </label>
                  <textarea
                    rows={6}
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="Opisz szczegóły swojego zapytania..."
                  />
                </div>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full bg-purple-600 text-white rounded-xl py-3 font-medium hover:bg-purple-700 transition-colors"
                >
                  {isSubmitting ? (
                    <div className="flex items-center justify-center">
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Wysyłanie...
                    </div>
                  ) : (
                    'Wyślij wiadomość'
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Office Hours & Map */}
          <div>
            <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
              <div className="flex items-center space-x-4 mb-6">
                <div className="bg-purple-100 rounded-full p-3">
                  <Clock className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="text-xl font-bold text-purple-900">Godziny pracy</h3>
              </div>
              <p className="text-purple-600">Poniedziałek - Piątek: 8:00-16:00</p>
            </div>

            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h3 className="text-xl font-bold text-purple-900 mb-6">Lokalizacja</h3>
              <div className="aspect-w-16 aspect-h-9 rounded-xl overflow-hidden">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d611.6472946818494!2d21.01765462859463!3d52.17816242061747!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x471932db29d3dfdd%3A0xc5c07a411f72f98a!2s%C5%9Awieradowska%2047%2C%2000-662%20Warszawa!5e0!3m2!1spl!2spl!4v1742836603715!5m2!1spl!2spl"
                  width="100%"
                  height="300"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  className="rounded-xl"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Why Contact Us */}
      <div className="bg-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-purple-900 mb-4">
              Dlaczego warto do nas dołączyć?
            </h2>
            <p className="text-lg text-purple-600">
              Jesteśmy tu, aby pomóc Ci osiągnąć sukces w branży IT
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {contactReasons.map((reason, index) => (
              <div key={index} className="bg-white p-6 rounded-2xl shadow-lg transform hover:scale-105 transition-transform duration-300">
                <div className="bg-purple-100 rounded-full p-4 inline-block mb-4">
                  {reason.icon}
                </div>
                <h3 className="text-xl font-bold text-purple-900 mb-3">{reason.title}</h3>
                <p className="text-purple-600">{reason.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Departments */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid md:grid-cols-2 gap-8">
          {departments.map((dept, index) => (
            <div key={index} className="bg-white rounded-2xl shadow-lg p-8">
              <div className="flex items-center space-x-4 mb-6">
                <div className="bg-purple-100 rounded-full p-3">
                  {dept.icon}
                </div>
                <h3 className="text-xl font-bold text-purple-900">{dept.title}</h3>
              </div>
              <p className="text-purple-600 mb-6">{dept.description}</p>
              <div className="space-y-4">
                <a
                  href={`mailto:${settings.contact_email}`}
                  className="flex items-center text-purple-600 hover:text-purple-700"
                >
                  <Mail className="w-5 h-5 mr-2" />
                  {settings.contact_email}
                </a>
                <a
                  href={`tel:${settings.contact_phone}`}
                  className="flex items-center text-purple-600 hover:text-purple-700"
                >
                  <Phone className="w-5 h-5 mr-2" />
                  {settings.contact_phone}
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-gradient-hero text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-8">Zwiększ skuteczność swojej rekrutacji!</h2>
            <p className="text-xl text-purple-200 mb-12">
              Skontaktuj się z nami, aby dobrać najlepszą strategię promocji Twoich ofert pracy!
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 sm:gap-8">
              <a
                href={`mailto:${settings.contact_email}`}
                className="flex items-center justify-center bg-white bg-opacity-10 rounded-xl px-6 py-4 hover:bg-opacity-20 transition-colors w-full sm:w-auto"
              >
                <Mail className="w-6 h-6 mr-3" />
                <span>{settings.contact_email}</span>
              </a>
              <a
                href={`tel:${settings.contact_phone}`}
                className="flex items-center justify-center bg-white bg-opacity-10 rounded-xl px-6 py-4 hover:bg-opacity-20 transition-colors w-full sm:w-auto"
              >
                <Phone className="w-6 h-6 mr-3" />
                <span>{settings.contact_phone}</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}