import React, { useEffect, useState } from 'react';
import { useNavigate, Outlet, Link, useLocation, Navigate } from 'react-router-dom';
import { 
  LogOut, Menu, X, Loader2, LayoutDashboard, 
  Briefcase, BookOpen, CreditCard, Mail, BarChart, 
  Settings, Globe, Users
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { hasAdminAccess, getRoleBasedMenuItems, getRoleLandingPage, getUserRole } from '../lib/auth';

export default function AdminLayout() {
  const [loading, setLoading] = useState(true);
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [menuItems, setMenuItems] = useState<any[]>([]);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const checkAuth = async () => {
      try {
        const authorized = await hasAdminAccess();
        setIsAuthorized(authorized);
        
        if (authorized) {
          const role = await getUserRole();
          setIsAdmin(true);
          setMenuItems(getRoleBasedMenuItems(role));
          
          // Redirect to role-specific page if on generic admin page
          if (location.pathname === '/admin') {
            const landingPage = await getRoleLandingPage();
            if (landingPage !== '/admin') {
              navigate(landingPage);
            }
          }
        }
      } catch (error) {
        console.error('Error checking authorization:', error);
        setIsAuthorized(false);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
  }, [location.pathname, navigate]);

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      navigate('/admin/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Sprawdzanie uprawnień...</p>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return <Navigate to="/admin/login" state={{ from: location.pathname }} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-4 right-4 z-50">
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 rounded-lg bg-white shadow-lg"
        >
          {isMobileMenuOpen ? (
            <X className="w-6 h-6 text-purple-900" />
          ) : (
            <Menu className="w-6 h-6 text-purple-900" />
          )}
        </button>
      </div>

      {/* Sidebar */}
      <aside
        className={`
          fixed top-0 left-0 h-full w-64 bg-white shadow-lg transform transition-transform duration-300 z-40
          ${isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
        `}
      >
        <div className="p-6">
          <div className="flex items-center mb-8">
            <Briefcase className="w-8 h-8 text-purple-600" />
            <div className="ml-3">
              <span className="text-xl font-bold text-purple-900">Panel Admina</span>
              <span className="block text-xs text-purple-500 mt-1">Administrator</span>
            </div>
          </div>

          <nav className="space-y-1">
            {menuItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`
                  flex items-center px-4 py-3 rounded-lg transition-colors
                  ${location.pathname === item.path
                    ? 'bg-purple-50 text-purple-900'
                    : 'text-purple-600 hover:bg-purple-50 hover:text-purple-900'
                  }
                `}
              >
                {item.icon}
                <span className="ml-3">{item.label}</span>
              </Link>
            ))}
          </nav>
        </div>

        <div className="absolute bottom-0 left-0 right-0 p-6">
          <button
            onClick={handleSignOut}
            className="flex items-center w-full px-4 py-3 text-purple-600 hover:bg-purple-50 hover:text-purple-900 rounded-lg transition-colors"
          >
            <LogOut className="w-5 h-5" />
            <span className="ml-3">Wyloguj się</span>
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main className={`
        transition-all duration-300
        ${isMobileMenuOpen ? 'lg:ml-64' : 'lg:ml-64'}
      `}>
        <div className="p-8">
          <Outlet />
        </div>
      </main>

      {/* Mobile menu overlay */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </div>
  );
}
