import React from 'react';
import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { Facebook, Linkedin, Instagram, MessageSquare, Star, Briefcase, Code, Building2, Mail, Phone, Target, Video, Globe, Users, Search } from 'lucide-react';
import { supabase } from '../lib/supabase';

type Settings = {
  social_media: {
    facebook: string;
    linkedin: string;
    instagram: string;
  };
};

const socialStats = [
  { value: '50,000+', label: 'Specjalistów IT w społeczności' },
  { value: '1,000+', label: 'Aktywnych ofert pracy' },
  { value: '24/7', label: 'Wsparcie społeczności' }
];

const socialPlatforms = [
  {
    icon: <Facebook className="w-8 h-8" />,
    name: 'Facebook',
    title: 'Grupa dla Specjalistów IT',
    description: 'Specjaliści IT – Oferty Pracy, Polska i Zagranica',
    benefits: [
      'Codziennie aktualizowane oferty pracy',
      'Wartościowe kontakty zawodowe',
      'Wsparcie i inspiracje od ekspertów',
      'Dyskusje o warunkach zatrudnienia',
      'Sesje Q&A z ekspertami HR'
    ],
    ctaText: 'Dołącz do grupy na Facebooku',
    bgColor: 'bg-blue-600',
    image: 'https://i.ibb.co/jvHmhydC/1.png',
    imageAlt: 'Grupa programistów podczas spotkania zespołu'
  },
  {
    icon: <Linkedin className="w-8 h-8" />,
    name: 'LinkedIn',
    title: 'Profesjonalna Sieć dla IT',
    description: 'Strona StartJob.IT na LinkedIn',
    benefits: [
      'Najświeższe oferty pracy IT',
      'Trendy w branży i rozwój kariery',
      'Budowanie sieci kontaktów',
      'Dostęp do najlepszych talentów',
      'Ekskluzywne porady ekspertów'
    ],
    ctaText: 'Dołącz do strony na LinkedIn',
    bgColor: 'bg-blue-700',
    image: 'https://i.ibb.co/wh6VMHMW/2.png',
    imageAlt: 'Profesjonaliści podczas konferencji technologicznej'
  },
  {
    icon: <Instagram className="w-8 h-8" />,
    name: 'Instagram',
    title: 'Życie i Kariera w IT',
    description: 'Kulisy branży IT i inspirujące historie',
    benefits: [
      'Kulisy pracy w IT',
      'Historie sukcesu specjalistów',
      'Porady work-life balance',
      'Ekskluzywne oferty pracy',
      'Relacje z wydarzeń branżowych'
    ],
    ctaText: 'Obserwuj nas na Instagramie',
    bgColor: 'bg-pink-600',
    image: 'https://images.unsplash.com/photo-1515378791036-0648a3ef77b2?auto=format&fit=crop&w=800&q=80',
    imageAlt: 'Programista pracujący w nowoczesnym biurze'
  }
];

const features = [
  {
    icon: <Users className="w-6 h-6" />,
    title: 'Społeczność IT',
    description: 'Dołącz do tysięcy specjalistów IT i buduj swoją sieć kontaktów zawodowych.'
  },
  {
    icon: <MessageSquare className="w-6 h-6" />,
    title: 'Aktywne Dyskusje',
    description: 'Uczestnictwo w merytorycznych dyskusjach i wymiana doświadczeń.'
  },
  {
    icon: <Star className="w-6 h-6" />,
    title: 'Ekskluzywne Oferty',
    description: 'Dostęp do najlepszych ofert pracy, często przed ich oficjalną publikacją.'
  },
  {
    icon: <Code className="w-6 h-6" />,
    title: 'Rozwój Zawodowy',
    description: 'Porady ekspertów, webinary i materiały edukacyjne dla programistów.'
  }
];

export default function SocialMedia() {
  const [settings, setSettings] = useState<Settings>({
    social_media: {
      facebook: '',
      linkedin: '',
      instagram: ''
    }
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('site_settings')
        .select('key, value')
        .eq('key', 'social_media');

      if (error) throw error;

      if (data && data[0]) {
        setSettings({ social_media: data[0].value });
      }
    } catch (err) {
      console.error('Error fetching settings:', err);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Schema.org structured data for social media page */}
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebPage',
            'name': 'Social Media StartJob.IT',
            'description': 'Dołącz do społeczności specjalistów IT i bądź na bieżąco z najlepszymi ofertami pracy oraz trendami w branży!',
            'mainEntity': {
              '@type': 'ItemList',
              'itemListElement': [
                {
                  '@type': 'ListItem',
                  'position': 1,
                  'item': {
                    '@type': 'SocialMediaPosting',
                    'headline': 'Facebook - Grupa dla Specjalistów IT',
                    'url': settings.social_media?.facebook || 'https://facebook.com/startjob.it'
                  }
                },
                {
                  '@type': 'ListItem',
                  'position': 2,
                  'item': {
                    '@type': 'SocialMediaPosting',
                    'headline': 'LinkedIn - Profesjonalna Sieć dla IT',
                    'url': settings.social_media?.linkedin || 'https://linkedin.com/company/startjob-it'
                  }
                },
                {
                  '@type': 'ListItem',
                  'position': 3,
                  'item': {
                    '@type': 'SocialMediaPosting',
                    'headline': 'Instagram - Życie i Kariera w IT',
                    'url': settings.social_media?.instagram || 'https://instagram.com/startjob.it'
                  }
                }
              ]
            }
          })}
        </script>
      </Helmet>

      {/* Hero Section */}
      <div className="bg-gradient-hero text-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <div className="flex justify-center mb-6">
              <div className="bg-yellow-400 bg-opacity-20 rounded-full p-4">
                <Users className="w-12 h-12 text-yellow-400" />
              </div>
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Social Media StartJob.IT
            </h1>
            <p className="text-xl text-purple-200">
              Dołącz do społeczności specjalistów IT i bądź na bieżąco z najlepszymi ofertami pracy
              oraz trendami w branży!
            </p>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-12 relative z-10">
        <div className="bg-white rounded-2xl shadow-xl p-8">
          <div className="grid md:grid-cols-3 gap-8">
            {socialStats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-3xl font-bold text-purple-900 mb-2">{stat.value}</div>
                <div className="text-purple-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Features Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-purple-900 mb-4">
            Dlaczego warto do nas dołączyć?
          </h2>
          <p className="text-lg text-purple-600">
            Rozwijaj swoją karierę w IT wraz z naszą społecznością
          </p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="bg-white p-6 rounded-2xl shadow-lg transform hover:scale-105 transition-transform duration-300">
              <div className="bg-purple-100 rounded-full p-4 inline-block mb-4">
                {feature.icon}
              </div>
              <h3 className="text-xl font-bold text-purple-900 mb-3">{feature.title}</h3>
              <p className="text-purple-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Social Platforms */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="space-y-12">
          {socialPlatforms.map((platform, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl shadow-lg overflow-hidden transform hover:scale-102 transition-transform duration-300"
            >
              <div className="grid md:grid-cols-2">
                <div className="p-8">
                  <div className={`${platform.bgColor} w-16 h-16 rounded-2xl flex items-center justify-center text-white mb-6`}>
                    {platform.icon}
                  </div>
                  <h3 className="text-2xl font-bold text-purple-900 mb-2">
                    {platform.title}
                  </h3>
                  <p className="text-purple-600 text-lg mb-6">
                    {platform.description}
                  </p>
                  <ul className="space-y-3 mb-8">
                    {platform.benefits.map((benefit, benefitIndex) => (
                      <li key={benefitIndex} className="flex items-center">
                        <Star className="w-5 h-5 text-yellow-400 mr-3" />
                        <span className="text-purple-700">{benefit}</span>
                      </li>
                    ))}
                  </ul>
                  <button
                    type="submit"
                    className="inline-flex items-center px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors font-medium"
                    onClick={() => window.open(settings.social_media[platform.name.toLowerCase()], '_blank')}
                  >
                    {platform.ctaText}
                    <Target className="w-5 h-5 ml-2 inline-flex" />
                  </button>
                </div>
                <div className="bg-gradient-to-br from-purple-100 to-purple-50 p-8 flex items-center justify-center">
                  <div className="relative w-full h-full min-h-[300px] rounded-xl overflow-hidden group">
                    <img
                      src={platform.image}
                      alt={platform.imageAlt}
                      className="w-full h-full object-cover rounded-xl transform group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-purple-900/30 to-transparent group-hover:from-purple-900/40 transition-all duration-300"></div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Call to Action */}
      <div className="bg-gradient-hero text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-bold mb-8">
              Dołącz do społeczności StartJob.IT!
            </h2>
            <p className="text-xl text-purple-200 mb-12 max-w-2xl mx-auto">
              Nie przegap żadnej okazji na rozwój swojej kariery w IT. 
              Śledź nas w mediach społecznościowych i bądź częścią dynamicznej społeczności!
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 sm:gap-6">
              <button
                className="flex items-center justify-center bg-white bg-opacity-10 rounded-xl px-6 py-4 hover:bg-opacity-20 transition-colors transform hover:scale-105 duration-300 w-full sm:w-auto"
                onClick={() => window.open(settings.social_media.facebook, '_blank')}
              >
                <Facebook className="w-6 h-6 mr-3" />
                <span>Facebook</span>
              </button>
              <button
                className="flex items-center justify-center bg-white bg-opacity-10 rounded-xl px-6 py-4 hover:bg-opacity-20 transition-colors transform hover:scale-105 duration-300 w-full sm:w-auto"
                onClick={() => window.open(settings.social_media.linkedin, '_blank')}
              >
                <Linkedin className="w-6 h-6 mr-3" />
                <span>LinkedIn</span>
              </button>
              <button
                className="flex items-center justify-center bg-white bg-opacity-10 rounded-xl px-6 py-4 hover:bg-opacity-20 transition-colors transform hover:scale-105 duration-300 w-full sm:w-auto"
                onClick={() => window.open(settings.social_media.instagram, '_blank')}
              >
                <Instagram className="w-6 h-6 mr-3" />
                <span>Instagram</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}