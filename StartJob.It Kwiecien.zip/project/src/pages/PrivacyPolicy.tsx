import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { ArrowLeft, Shield, Lock, Eye, UserCheck, Database, Server, Mail } from 'lucide-react';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      {/* Schema.org structured data for privacy policy page */}
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebPage',
            'name': 'Polityka Prywatności StartJob.IT',
            'description': 'Polityka prywatności serwisu StartJob.IT. Informacje o przetwarzaniu danych osobowych.',
            'mainEntity': {
              '@type': 'WebPageElement',
              'headline': 'Polityka Prywatności',
              'text': 'Dbamy o Twoją prywatność i transparentność przetwarzania danych osobowych'
            },
            'publisher': {
              '@type': 'Organization',
              'name': 'StartJob.IT',
              'url': 'https://startjob.it'
            }
          })}
        </script>
      </Helmet>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back button */}
        <Link
          to="/"
          className="inline-flex items-center text-purple-600 hover:text-purple-900 mb-8"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Powrót do strony głównej
        </Link>

        {/* Header */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <div className="flex items-center justify-center mb-6">
            <div className="bg-purple-100 rounded-full p-4">
              <Shield className="w-8 h-8 text-purple-600" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-purple-900 text-center mb-4">
            Polityka Prywatności
          </h1>
          <p className="text-purple-600 text-center mb-2">
            Dbamy o Twoją prywatność i transparentność przetwarzania danych osobowych
          </p>
        </div>

        {/* Content */}
        <div className="bg-white rounded-2xl shadow-lg p-8 space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-purple-900 mb-4">
              Administrator danych
            </h2>
            <p className="text-purple-700 mb-4">
              Administratorem Pani/Pana danych osobowych jest W3 B2B SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ z siedzibą przy ul. Świeradowska 47, 02-662 Warszawa, Polska, wpisana do Krajowego Rejestru Sądowego pod numerem KRS: 0001115407, posiadająca NIP: 1133139476 oraz REGON: 529115601.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-purple-900 mb-4">
              Cele przetwarzania danych
            </h2>
            <div className="space-y-4">
              <div className="flex items-start">
                <div>
                  <h3 className="font-semibold text-purple-900 mb-2">A. Świadczenie usług</h3>
                  <p className="text-purple-700">
                    W związku z usługami świadczonymi za pośrednictwem strony internetowej www.StartJob.IT, w tym publikacją płatnych ogłoszeń o pracę dla branży IT oraz możliwością odpowiadania na ogłoszenia i aplikowania swoim CV do pracodawcy przez kandydatów do pracy, w celu zawarcia lub wykonania umowy (art. 6 ust. 1 lit. b Rozporządzenia), Państwa dane będą przechowywane do czasu wykonania umowy.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <div>
                  <h3 className="font-semibold text-purple-900 mb-2">B. Marketing i promocja</h3>
                  <p className="text-purple-700">
                    W celach marketingowych i promocji produktów oferowanych przez W3 B2B Sp. z o.o. z siedzibą w Warszawie będących naszym prawnie uzasadnionym interesem (art. 6 ust. 1 lit. f Rozporządzenia). Państwa dane będą przetwarzane do czasu wyrażenia sprzeciwu.
                  </p>
                </div>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-purple-900 mb-4">
              Pliki Cookies
            </h2>
            <div className="space-y-4">
              <div className="flex items-start">
                <div>
                  <p className="text-purple-700">
                    Cookies to pliki tekstowe tworzone automatycznie przez przeglądarki internetowe w momencie odwiedzania lub korzystania ze stron internetowych. Są one wysyłane przez stronę internetową i zapisywane na urządzeniu użytkownika.
                  </p>
                  <ul className="list-disc list-inside text-purple-700 mt-2 space-y-2">
                    <li>Niezbędne/Techniczne – Konieczne dla prawidłowego funkcjonowania strony</li>
                    <li>Funkcjonalne – Zapamiętują i dostosowują platformę do Twoich wyborów</li>
                    <li>Analityczne – Pozwalają na sprawdzenie liczby wizyt i źródeł ruchu</li>
                    <li>Marketingowe – Dopasowują wyświetlane treści reklamowe</li>
                    <li>Pliki cookies portali społecznościowych – Instalowane przez partnerów</li>
                  </ul>
                </div>
              </div>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-purple-900 mb-4">
              Twoje prawa
            </h2>
            <div className="space-y-4">
              <p className="text-purple-700">
                Przysługują Ci następujące prawa:
              </p>
              <ul className="list-disc list-inside text-purple-700 mt-2 space-y-2">
                <li>Prawo dostępu do przetwarzanych danych osobowych</li>
                <li>Sprostowania danych</li>
                <li>Usunięcia danych ("prawo do bycia zapomnianym")</li>
                <li>Ograniczenia przetwarzania</li>
                <li>Przenoszenia danych</li>
                <li>Prawo do cofnięcia zgody na przetwarzanie</li>
                <li>Prawo do sprzeciwu</li>
                <li>Prawo do wniesienia skargi do organu nadzorczego</li>
              </ul>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-purple-900 mb-4">
              Kontakt w sprawie ochrony danych
            </h2>
            <div className="space-y-4">
              <p className="text-purple-700">
                Jeśli potrzebujecie Państwo dodatkowych informacji związanych z ochroną danych osobowych lub chcecie skorzystać z przysługujących praw, prosimy o kontakt na adres e-mail: kontakt@startjob.it
              </p>
              <p className="text-purple-700 mt-4">
                W przypadku naruszenia przepisów o ochronie danych osobowych, masz prawo do zgłoszenia skargi do Prezesa Urzędu Ochrony Danych Osobowych pod adresem <a href="https://uodo.gov.pl/" className="text-purple-600 hover:text-purple-800 underline">https://uodo.gov.pl/</a>
              </p>
            </div>
          </section>
        </div>
      </div>
    </div>
  )
};
