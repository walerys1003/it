import React, { useState, useEffect } from 'react';
import { 
  Loader2, AlertCircle, Save, CheckCircle2
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import ContactSettings from '../../components/admin/settings/ContactSettings';
import SocialMediaSettings from '../../components/admin/settings/SocialMediaSettings';
import PricingSettings from '../../components/admin/settings/PricingSettings';
import JobOptionsSettings from '../../components/admin/settings/JobOptionsSettings';

type Settings = {
  [key: string]: any;
};

type PromotionService = {
  id: string;
  name: string;
  price: number;
};

type JobOption = {
  id: string;
  name: string;
  code: string;
  icon?: string;
  range_from?: number;
  range_to?: number;
  native_name?: string;
};

export default function Settings() {
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [settings, setSettings] = useState<Settings>({
    technologies: [] as JobOption[],
    contact_phone: '',
    contact_email: '',
    contact_address: {
      street: '',
      city: '',
      postal_code: '',
      country: ''
    },
    social_media: {
      facebook: '',
      linkedin: '',
      instagram: ''
    },
    currency: 'PLN',
    job_posting_price_standard: 599,
    job_posting_price_premium: 899,
    promotion_services: [] as PromotionService[],
    job_categories: [] as JobOption[],
    working_modes: [] as JobOption[],
    experience_levels: [] as JobOption[],
    contract_types: [] as JobOption[],
    benefits: [] as JobOption[],
    languages: [] as JobOption[],
  });

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('site_settings')
        .select('*');

      if (error) throw error;

      const settingsMap = data.reduce((acc, setting) => {
        acc[setting.key] = setting.value;
        return acc;
      }, {} as Settings);

      // Fetch job options
      const [
        { data: categories },
        { data: workingModes },
        { data: experienceLevels },
        { data: contractTypes },
        { data: benefits },
        { data: languages },
        { data: technologies }
      ] = await Promise.all([
        supabase.from('job_categories').select('*').order('name'),
        supabase.from('working_modes').select('*').order('name'),
        supabase.from('experience_levels').select('*').order('name'),
        supabase.from('contract_types').select('*').order('name'),
        supabase.from('benefits').select('*').order('name'),
        supabase.from('languages').select('*').order('name'),
        supabase.from('technologies').select('*').order('category', { ascending: true }).order('name', { ascending: true })
      ]);

      setSettings({
        ...settingsMap,
        job_categories: categories || [],
        working_modes: workingModes || [],
        experience_levels: experienceLevels || [],
        contract_types: contractTypes || [],
        benefits: benefits || [],
        languages: languages || [],
        technologies: technologies || []
      });
    } catch (err) {
      console.error('Error fetching settings:', err);
      setError('Wystąpił błąd podczas ładowania ustawień.');
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    setError(null);
    setSuccess(false);

    try {
      // Get existing records to identify deleted ones
      const [
        { data: existingCategories },
        { data: existingModes },
        { data: existingLevels },
        { data: existingTypes },
        { data: existingBenefits },
        { data: existingLanguages },
        { data: existingSizes },
        { data: existingTechnologies }
      ] = await Promise.all([
        supabase.from('job_categories').select('id'),
        supabase.from('working_modes').select('id'),
        supabase.from('experience_levels').select('id'),
        supabase.from('contract_types').select('id'),
        supabase.from('benefits').select('id'),
        supabase.from('languages').select('id'),
        supabase.from('company_sizes').select('id'),
        supabase.from('technologies').select('id')
      ]);

      // Delete removed records
      const currentCategoryIds = settings.job_categories.map(c => c.id);
      const deletedCategoryIds = existingCategories?.filter(c => !currentCategoryIds.includes(c.id)).map(c => c.id) || [];
      
      const currentModeIds = settings.working_modes.map(m => m.id);
      const deletedModeIds = existingModes?.filter(m => !currentModeIds.includes(m.id)).map(m => m.id) || [];
      
      const currentLevelIds = settings.experience_levels.map(l => l.id);
      const deletedLevelIds = existingLevels?.filter(l => !currentLevelIds.includes(l.id)).map(l => l.id) || [];
      
      const currentTypeIds = settings.contract_types.map(t => t.id);
      const deletedTypeIds = existingTypes?.filter(t => !currentTypeIds.includes(t.id)).map(t => t.id) || [];
      
      const currentBenefitIds = settings.benefits.map(b => b.id);
      const deletedBenefitIds = existingBenefits?.filter(b => !currentBenefitIds.includes(b.id)).map(b => b.id) || [];
      
      const currentLanguageIds = settings.languages.map(l => l.id);
      const deletedLanguageIds = existingLanguages?.filter(l => !currentLanguageIds.includes(l.id)).map(l => l.id) || [];
      
      const currentTechIds = settings.technologies.map(t => t.id);
      const deletedTechIds = existingTechnologies?.filter(t => !currentTechIds.includes(t.id)).map(t => t.id) || [];

      // Delete records in parallel
      await Promise.all([
        deletedCategoryIds.length > 0 && supabase.from('job_categories').delete().in('id', deletedCategoryIds),
        deletedModeIds.length > 0 && supabase.from('working_modes').delete().in('id', deletedModeIds),
        deletedLevelIds.length > 0 && supabase.from('experience_levels').delete().in('id', deletedLevelIds),
        deletedTypeIds.length > 0 && supabase.from('contract_types').delete().in('id', deletedTypeIds),
        deletedBenefitIds.length > 0 && supabase.from('benefits').delete().in('id', deletedBenefitIds),
        deletedLanguageIds.length > 0 && supabase.from('languages').delete().in('id', deletedLanguageIds),
        deletedTechIds.length > 0 && supabase.from('technologies').delete().in('id', deletedTechIds)
      ]);

      // Update site settings
      const siteSettingsKeys = [
        'contact_phone',
        'contact_email',
        'contact_address',
        'social_media',
        'currency',
        'job_posting_price_standard',
        'job_posting_price_premium',
        'promotion_services'
      ];

      for (const key of siteSettingsKeys) {
        if (settings[key] !== undefined) {
          const { error } = await supabase
            .from('site_settings')
            .update({ value: settings[key] })
            .eq('key', key);

          if (error) throw error;
        }
      }

      // Update job options
      const tables = {
        job_categories: settings.job_categories,
        working_modes: settings.working_modes,
        experience_levels: settings.experience_levels,
        contract_types: settings.contract_types,
        benefits: settings.benefits,
        languages: settings.languages,
        technologies: settings.technologies
      };

      for (const [table, data] of Object.entries(tables)) {
        const { error } = await supabase
          .from(table)
          .upsert(data, {
            onConflict: 'id',
            ignoreDuplicates: false
          });

        if (error) throw error;
      }

      // Log the update
      await supabase
        .from('admin_audit_log')
        .insert([{
          action: 'update_settings',
          entity_type: 'site_settings',
          details: {
            updated_at: new Date().toISOString()
          }
        }]);

      setSuccess(true);
      setTimeout(() => setSuccess(false), 3000);
    } catch (err) {
      console.error('Error saving settings:', err);
      setError('Wystąpił błąd podczas zapisywania ustawień.');
    } finally {
      setSaving(false);
    }
  };

  const handleInputChange = (key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleNestedChange = (key: string, nestedKey: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: {
        ...prev[key],
        [nestedKey]: value
      }
    }));
  };

  const handlePromotionServiceChange = (index: number, field: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      promotion_services: prev.promotion_services.map((service, i) => 
        i === index ? { ...service, [field]: value } : service
      )
    }));
  };

  const handleDelete = (table: string, id: string, name: string) => {
    if (window.confirm(`Czy na pewno chcesz usunąć "${name}"?`)) {
      setSettings(prev => ({
        ...prev,
        [table]: prev[table].filter((item: JobOption) => item.id !== id)
      }));
    }
  };

  const handleAdd = (table: string) => {
    const newItem = {
      id: crypto.randomUUID(),
      name: '',
      code: '',
      category: table === 'technologies' ? 'Inne popularne technologie i narzędzia' : '',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    setSettings(prev => ({
      ...prev,
      [table]: [newItem, ...prev[table]]
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie ustawień...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="sticky top-0 z-50 bg-gray-50 py-4 mb-8 border-b border-purple-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
        <h1 className="text-2xl font-bold text-purple-900">
          Ustawienia
        </h1>
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50"
        >
          {saving ? (
            <>
              <Loader2 className="w-5 h-5 mr-2 animate-spin" />
              Zapisywanie...
            </>
          ) : (
            <>
              <Save className="w-5 h-5 mr-2" />
              Zapisz zmiany
            </>
          )}
        </button>
        </div>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 rounded-xl">
          <div className="flex items-center">
            <AlertCircle className="w-5 h-5 text-red-400 mr-2" />
            <p className="text-red-700">{error}</p>
          </div>
        </div>
      )}

      {success && (
        <div className="mb-6 p-4 bg-green-50 rounded-xl">
          <div className="flex items-center">
            <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
            <p className="text-green-700">Ustawienia zostały zapisane</p>
          </div>
        </div>
      )}

      <div className="space-y-8">
        <ContactSettings 
          settings={settings} 
          onInputChange={handleInputChange}
          onNestedChange={handleNestedChange}
        />
        
        <SocialMediaSettings 
          settings={settings}
          onNestedChange={handleNestedChange}
        />
        
        <PricingSettings 
          settings={settings}
          onInputChange={handleInputChange}
          onPromotionServiceChange={handlePromotionServiceChange}
        />
        
        <JobOptionsSettings 
          settings={settings}
          onSettingsChange={(key, value) => setSettings(prev => ({ ...prev, [key]: value }))}
          onAdd={handleAdd}
          onDelete={handleDelete}
        />
      </div>
    </div>
  );
}