import React, { useEffect, useState } from 'react';
import { 
  Briefcase, Users, BookOpen, TrendingUp, Loader2, AlertCircle, 
  PlusCircle, FileEdit, ArrowRight, Calendar, Mail, Phone, 
  ExternalLink, Clock, CheckCircle, XCircle, Eye, Activity, 
  Edit, Trash2, Plus, FileText, Settings, CreditCard, Newspaper
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Link } from 'react-router-dom';
import { getUserRole } from '../../lib/auth';

type DashboardStats = {
  totalJobs: number;
  activeJobs: number;
  totalApplications: number;
  totalUsers: number;
  totalBlogPosts: number;
  totalNewsletterSubscribers: number;
};

type Application = {
  id: string;
  job_id: string;
  candidate_name: string;
  candidate_email: string;
  candidate_phone: string;
  status: string;
  created_at: string;
  job: {
    title: string;
    company_name: string;
  } | null;
};

type ActivityLog = {
  id: string;
  admin_id: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  details: any;
  created_at: string;
  admin_email?: string;
};

export default function Dashboard() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [loadingActivity, setLoadingActivity] = useState(true);
  const [applications, setApplications] = useState<Application[]>([]);
  const [loadingApplications, setLoadingApplications] = useState(true);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [stats, setStats] = useState<DashboardStats>({
    totalJobs: 0,
    activeJobs: 0,
    totalApplications: 0,
    totalUsers: 0,
    totalBlogPosts: 0,
    totalNewsletterSubscribers: 0
  });

  useEffect(() => {
    const checkUserRole = async () => {
      const role = await getUserRole();
      setUserRole(role);
    };
    
    checkUserRole();
    const fetchStats = async () => {
      try {
        // Fetch jobs stats
        const { count: totalJobs, error: jobsError } = await supabase
          .from('jobs')
          .select('*', { count: 'exact', head: true })
          .throwOnError();

        if (jobsError) throw jobsError;

        const { count: activeJobs } = await supabase
          .from('jobs')
          .select('*', { count: 'exact', head: true })
          .eq('is_active', true)
          .gt('valid_until', new Date().toISOString());

        // Fetch applications count
        const { count: totalApplications } = await supabase
          .from('applications')
          .select('*', { count: 'exact', head: true });

        // Fetch blog posts count
        const { count: totalBlogPosts } = await supabase
          .from('blog_posts')
          .select('*', { count: 'exact', head: true });

        // Fetch newsletter subscribers count
        const { count: totalNewsletterSubscribers } = await supabase
          .from('newsletter_subscribers')
          .select('*', { count: 'exact', head: true });

        setStats({
          totalJobs: totalJobs || 0,
          activeJobs: activeJobs || 0,
          totalApplications: totalApplications || 0,
          totalUsers: 0, // Will be implemented with auth stats
          totalBlogPosts: totalBlogPosts || 0,
          totalNewsletterSubscribers: totalNewsletterSubscribers || 0
        });
      } catch (err) {
        console.error('Error fetching dashboard stats:', err);
        setError('Wystąpił błąd podczas ładowania statystyk.');
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  useEffect(() => {
    const fetchRecentActivity = async () => {
      try {
        setLoadingActivity(true);
        
        // First, get the activity logs
        const { data: logs, error: logsError } = await supabase
          .from('admin_audit_log')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(10);

        if (logsError) throw logsError;

        // Then, for each log with an admin_id, get the email from admin_user_emails view
        const logsWithEmails = await Promise.all((logs || []).map(async (log) => {
          if (log.admin_id) {
            const { data: adminData } = await supabase
              .from('admin_user_emails')
              .select('email')
              .eq('id', log.admin_id)
              .single();

            return {
              ...log,
              admin_email: adminData?.email
            };
          }
          return log;
        }));

        setActivityLogs(logsWithEmails || []);
      } catch (err) {
        console.error('Error fetching activity logs:', err);
      } finally {
        setLoadingActivity(false);
      }
    };

    fetchRecentActivity();
  }, []);

  useEffect(() => {
    const fetchRecentApplications = async () => {
      try {
        setLoadingApplications(true);
        
        const { data, error } = await supabase
          .from('applications')
          .select(`
            *,
            job:job_id (
              title,
              company_name
            )
          `)
          .order('created_at', { ascending: false })
          .limit(5);

        if (error) throw error;
        setApplications(data || []);
      } catch (err) {
        console.error('Error fetching recent applications:', err);
      } finally {
        setLoadingApplications(false);
      }
    };

    fetchRecentApplications();
  }, []);

  // Helper function to format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pl-PL', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Helper function to get status badge
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'new':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <Clock className="w-3 h-3 mr-1" />
            Nowa
          </span>
        );
      case 'reviewed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <Eye className="w-3 h-3 mr-1" />
            Przejrzana
          </span>
        );
      case 'contacted':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <CheckCircle className="w-3 h-3 mr-1" />
            Skontaktowano
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <XCircle className="w-3 h-3 mr-1" />
            Odrzucona
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            {status}
          </span>
        );
    }
  };

  // Helper function to get activity icon
  const getActivityIcon = (action: string, entityType: string) => {
    if (action.includes('create')) {
      return <Plus className="w-4 h-4 text-green-500" />;
    } else if (action.includes('update')) {
      return <Edit className="w-4 h-4 text-blue-500" />;
    } else if (action.includes('delete')) {
      return <Trash2 className="w-4 h-4 text-red-500" />;
    } else if (entityType === 'jobs') {
      return <Briefcase className="w-4 h-4 text-purple-500" />;
    } else if (entityType === 'blog_posts') {
      return <FileText className="w-4 h-4 text-purple-500" />;
    } else if (entityType === 'site_settings') {
      return <Settings className="w-4 h-4 text-purple-500" />;
    } else if (entityType === 'payments') {
      return <CreditCard className="w-4 h-4 text-purple-500" />;
    } else {
      return <Activity className="w-4 h-4 text-purple-500" />;
    }
  };

  // Helper function to format activity description
  const getActivityDescription = (log: ActivityLog) => {
    const { action, entity_type, details } = log;
    
    // Format entity type for display
    const formatEntityType = (type: string) => {
      const entityTypeMap = {
        'jobs': 'ogłoszenie',
        'blog_posts': 'artykuł',
        'admin_users': 'użytkownika',
        'site_settings': 'ustawienia',
        'payments': 'płatność',
        'applications': 'aplikację',
        'newsletter_subscribers': 'subskrybenta'
      };
      
      return entityTypeMap[type] || type;
    };
    
    // Format action for display
    if (action.includes('create')) {
      return `Dodano ${formatEntityType(entity_type)}`;
    } else if (action.includes('update')) {
      return `Zaktualizowano ${formatEntityType(entity_type)}`;
    } else if (action.includes('delete')) {
      return `Usunięto ${formatEntityType(entity_type)}`;
    } else if (action.includes('job_expiration')) {
      return `Powiadomienie o wygaśnięciu ogłoszenia`;
    } else {
      return `${action} dla ${formatEntityType(entity_type)}`;
    }
  };

  // Helper function to get activity details
  const getActivityDetails = (log: ActivityLog) => {
    const { details, entity_type } = log;
    
    if (!details) return null;
    
    if (entity_type === 'jobs') {
      return details.title || details.company || 'Ogłoszenie o pracę';
    } else if (entity_type === 'blog_posts') {
      return details.title || 'Artykuł na blogu';
    } else if (entity_type === 'admin_users') {
      return details.email || details.name || 'Użytkownik';
    } else if (entity_type === 'payments') {
      return `${details.amount || ''} ${details.currency || 'PLN'}`;
    } else {
      return null;
    }
  };

  // Get quick actions based on user role
  const getQuickActions = () => {
    if (userRole === 'admin') {
      return [
        {
          title: 'Dodaj ogłoszenie',
          description: 'Utwórz nowe ogłoszenie o pracę',
          icon: <Briefcase className="w-6 h-6 text-purple-600" />,
          link: '/admin/jobs/add',
          color: 'bg-purple-100'
        },
        {
          title: 'Napisz artykuł',
          description: 'Dodaj nowy wpis na blogu',
          icon: <FileEdit className="w-6 h-6 text-purple-600" />,
          link: '/admin/blog/add',
          color: 'bg-purple-100'
        }
      ];
    } else if (userRole === 'editor') {
      return [
        {
          title: 'Napisz artykuł',
          description: 'Dodaj nowy wpis na blogu',
          icon: <FileEdit className="w-6 h-6 text-purple-600" />,
          link: '/admin/blog/add',
          color: 'bg-purple-100'
        },
        {
          title: 'Zarządzaj blogiem',
          description: 'Przeglądaj i edytuj istniejące artykuły',
          icon: <Newspaper className="w-6 h-6 text-purple-600" />,
          link: '/admin/blog',
          color: 'bg-purple-100'
        }
      ];
    } else if (userRole === 'moderator') {
      return [
        {
          title: 'Dodaj ogłoszenie',
          description: 'Utwórz nowe ogłoszenie o pracę',
          icon: <Briefcase className="w-6 h-6 text-purple-600" />,
          link: '/admin/jobs/add',
          color: 'bg-purple-100'
        },
        {
          title: 'Zarządzaj płatnościami',
          description: 'Przeglądaj i zarządzaj płatnościami',
          icon: <CreditCard className="w-6 h-6 text-purple-600" />,
          link: '/admin/payments',
          color: 'bg-purple-100'
        }
      ];
    }
    
    return [];
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie statystyk...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Wystąpił błąd
          </h2>
          <p className="text-purple-600">{error}</p>
        </div>
      </div>
    );
  }

  const quickActions = [
    {
      title: 'Dodaj ogłoszenie',
      description: 'Utwórz nowe ogłoszenie o pracę',
      icon: <Briefcase className="w-6 h-6 text-purple-600" />,
      link: '/admin/jobs/add',
      color: 'bg-purple-100'
    },
    {
      title: 'Napisz artykuł',
      description: 'Dodaj nowy wpis na blogu',
      icon: <FileEdit className="w-6 h-6 text-purple-600" />,
      link: '/admin/blog/add',
      color: 'bg-purple-100'
    }
  ];

  return (
    <div>
      <div className="flex items-center mb-8">
        <h1 className="text-2xl font-bold text-purple-900">
          {userRole === 'admin' ? 'Panel administracyjny' : 
           userRole === 'editor' ? 'Panel redaktora' : 
           userRole === 'moderator' ? 'Panel moderatora' : 
           'Panel użytkownika'}
        </h1>
        {userRole && (
          <span className="ml-3 px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm">
            {userRole === 'admin' ? 'Administrator' : 
             userRole === 'editor' ? 'Redaktor' : 
             userRole === 'moderator' ? 'Moderator' : ''}
          </span>
        )}
      </div>

      {/* Quick Actions */}
      {getQuickActions().length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-bold text-purple-900 mb-6">
            Szybkie akcje
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
            {getQuickActions().map((action, index) => (
              <Link 
                key={index}
                to={action.link}
                className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow transform hover:scale-102 duration-300"
              >
                <div className="flex items-start">
                  <div className={`${action.color} p-3 rounded-xl mr-4`}>
                    {action.icon}
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-purple-900 mb-2">
                      {action.title}
                    </h3>
                    <p className="text-sm text-purple-600 mb-4">
                      {action.description}
                    </p>
                    <div className="flex items-center text-purple-700 font-medium text-sm">
                      Przejdź
                      <ArrowRight className="w-4 h-4 ml-1" />
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Stats Grid */}
      {userRole === 'admin' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Jobs Stats */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-purple-900">
                Ogłoszenia
              </h3>
              <Briefcase className="w-6 h-6 text-purple-600" />
            </div>
            <div className="space-y-4">
              <div>
                <div className="text-3xl font-bold text-green-600">
                  {stats.activeJobs}
                </div>
                <div className="text-sm text-purple-600">
                  Aktywne ogłoszenia
                </div>
              </div>
              <div>
                <div className="text-xl font-semibold text-purple-900">
                  {stats.totalJobs}
                </div>
                <div className="text-sm text-purple-600">
                  Wszystkie ogłoszenia
                </div>
              </div>
            </div>
          </div>

          {/* Applications Stats */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-purple-900">
                Aplikacje
              </h3>
              <Users className="w-6 h-6 text-purple-600" />
            </div>
            <div className="space-y-4">
              <div>
                <div className="text-3xl font-bold text-purple-900">
                  {stats.totalApplications}
                </div>
                <div className="text-sm text-purple-600">
                  Wszystkie aplikacje
                </div>
              </div>
            </div>
          </div>

          {/* Blog Stats */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-purple-900">
                Blog
              </h3>
              <BookOpen className="w-6 h-6 text-purple-600" />
            </div>
            <div className="space-y-4">
              <div>
                <div className="text-3xl font-bold text-purple-900">
                  {stats.totalBlogPosts}
                </div>
                <div className="text-sm text-purple-600">
                  Artykuły na blogu
                </div>
              </div>
            </div>
          </div>

          {/* Newsletter Stats */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-purple-900">
                Newsletter
              </h3>
              <TrendingUp className="w-6 h-6 text-purple-600" />
            </div>
            <div className="space-y-4">
              <div>
                <div className="text-3xl font-bold text-purple-900">
                  {stats.totalNewsletterSubscribers}
                </div>
                <div className="text-sm text-purple-600">
                  Subskrybentów newslettera
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Moderator Stats */}
      {userRole === 'moderator' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {/* Jobs Stats */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-purple-900">
                Ogłoszenia
              </h3>
              <Briefcase className="w-6 h-6 text-purple-600" />
            </div>
            <div className="space-y-4">
              <div>
                <div className="text-3xl font-bold text-green-600">
                  {stats.activeJobs}
                </div>
                <div className="text-sm text-purple-600">
                  Aktywne ogłoszenia
                </div>
              </div>
              <div>
                <div className="text-xl font-semibold text-purple-900">
                  {stats.totalJobs}
                </div>
                <div className="text-sm text-purple-600">
                  Wszystkie ogłoszenia
                </div>
              </div>
            </div>
          </div>

          {/* Applications Stats */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-purple-900">
                Aplikacje
              </h3>
              <Users className="w-6 h-6 text-purple-600" />
            </div>
            <div className="space-y-4">
              <div>
                <div className="text-3xl font-bold text-purple-900">
                  {stats.totalApplications}
                </div>
                <div className="text-sm text-purple-600">
                  Wszystkie aplikacje
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {/* Editor Stats */}
      {userRole === 'editor' && (
        <div className="grid grid-cols-1 md:grid-cols-1 gap-6 mb-8">
          {/* Blog Stats */}
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-purple-900">
                Blog
              </h3>
              <BookOpen className="w-6 h-6 text-purple-600" />
            </div>
            <div className="space-y-4">
              <div>
                <div className="text-3xl font-bold text-purple-900">
                  {stats.totalBlogPosts}
                </div>
                <div className="text-sm text-purple-600">
                  Artykuły na blogu
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activity */}
        {(userRole === 'admin') && (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-purple-900 mb-6">
              Ostatnia aktywność w systemie
            </h2>
            {loadingActivity ? (
              <div className="flex justify-center py-8">
                <Loader2 className="w-8 h-8 text-purple-600 animate-spin" />
              </div>
            ) : activityLogs.length > 0 ? (
              <div className="space-y-4">
                {activityLogs.map((log) => (
                  <div key={log.id} className="border-l-4 border-purple-200 pl-4 py-2">
                    <div className="flex items-start">
                      <div className="bg-purple-100 p-2 rounded-full mr-3">
                        {getActivityIcon(log.action, log.entity_type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-purple-900">
                          {getActivityDescription(log)}
                        </p>
                        {getActivityDetails(log) && (
                          <p className="text-xs text-purple-600 truncate">
                            {getActivityDetails(log)}
                          </p>
                        )}
                        <div className="flex items-center mt-1 text-xs text-purple-500">
                          <span className="mr-2">{formatDate(log.created_at)}</span>
                          <span className="flex items-center">
                            <Users className="w-3 h-3 mr-1" />
                            {log.admin_email || 'System'}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                
                <div className="text-center pt-4">
                  <Link 
                    to="/admin/activity" 
                    className="inline-flex items-center text-purple-600 hover:text-purple-800 font-medium"
                  >
                    Zobacz pełną historię aktywności
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Link>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 bg-purple-50 rounded-xl">
                <Activity className="w-12 h-12 text-purple-300 mx-auto mb-3" />
                <p className="text-purple-600 mb-2">Brak aktywności</p>
                <p className="text-sm text-purple-500">
                  Historia aktywności pojawi się tutaj, gdy użytkownicy zaczną korzystać z systemu.
                </p>
              </div>
            )}
          </div>
        )}
        
        {/* Recent Applications */}
        {(userRole === 'admin' || userRole === 'moderator') && (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-purple-900 mb-6">
              Ostatnie aplikacje ({stats.totalApplications})
            </h2>
            {loadingApplications ? (
              <div className="flex justify-center py-8">
                <Loader2 className="w-8 h-8 text-purple-600 animate-spin" />
              </div>
            ) : applications.length > 0 ? (
              <div className="space-y-4">
                {applications.map((application) => (
                  <div key={application.id} className="border border-purple-100 rounded-xl p-4 hover:bg-purple-50 transition-colors">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="font-medium text-purple-900">{application.candidate_name}</h3>
                        <p className="text-sm text-purple-600">
                          <Link to={`/admin/jobs/${application.job_id}`} className="hover:text-purple-800">
                            {application.job?.title || 'Usunięte ogłoszenie'} - {application.job?.company_name || 'N/A'}
                          </Link>
                        </p>
                      </div>
                      <div>
                        {getStatusBadge(application.status)}
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-2 mt-3">
                      <div className="flex items-center text-sm text-purple-600">
                        <Mail className="w-4 h-4 mr-1.5 text-purple-400" />
                        <a href={`mailto:${application.candidate_email}`} className="hover:text-purple-800">
                          {application.candidate_email}
                        </a>
                      </div>
                      {application.candidate_phone && (
                        <div className="flex items-center text-sm text-purple-600">
                          <Phone className="w-4 h-4 mr-1.5 text-purple-400" />
                          <a href={`tel:${application.candidate_phone}`} className="hover:text-purple-800">
                            {application.candidate_phone}
                          </a>
                        </div>
                      )}
                    </div>
                    <div className="flex justify-between items-center mt-3 pt-2 border-t border-purple-100">
                      <div className="flex items-center text-xs text-purple-500">
                        <Calendar className="w-3.5 h-3.5 mr-1" />
                        {formatDate(application.created_at)}
                      </div>
                      <Link 
                        to={`/admin/applications/${application.id}`} 
                        className="text-xs text-purple-600 hover:text-purple-800 flex items-center"
                      >
                        Szczegóły
                        <ExternalLink className="w-3.5 h-3.5 ml-1" />
                      </Link>
                    </div>
                  </div>
                ))}
                
                <div className="text-center pt-4">
                  <Link 
                    to="/admin/applications" 
                    className="inline-flex items-center text-purple-600 hover:text-purple-800 font-medium"
                  >
                    Zobacz wszystkie aplikacje
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Link>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 bg-purple-50 rounded-xl">
                <Users className="w-12 h-12 text-purple-300 mx-auto mb-3" />
                <p className="text-purple-600 mb-2">Brak aplikacji</p>
                <p className="text-sm text-purple-500">
                  Aplikacje pojawią się tutaj, gdy kandydaci zaczną odpowiadać na ogłoszenia.
                </p>
              </div>
            )}
          </div>
        )}
        
        {/* Blog Stats for Editor */}
        {userRole === 'editor' && (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-purple-900 mb-6">
              Statystyki bloga
            </h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="bg-purple-100 p-3 rounded-full mr-4">
                    <FileText className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-purple-900">Artykuły</h3>
                    <p className="text-2xl font-bold text-purple-900">{stats.totalBlogPosts}</p>
                  </div>
                </div>
                <Link 
                  to="/admin/blog" 
                  className="text-purple-600 hover:text-purple-800"
                >
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </div>
              
              <div className="text-center pt-4">
                <Link 
                  to="/admin/blog/add" 
                  className="inline-flex items-center justify-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Dodaj nowy artykuł
                </Link>
              </div>
            </div>
          </div>
        )}
        
        {/* Jobs Stats for Moderator */}
        {userRole === 'moderator' && (
          <div className="bg-white rounded-xl shadow-lg p-6">
            <h2 className="text-xl font-bold text-purple-900 mb-6">
              Statystyki ogłoszeń
            </h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <div className="bg-purple-100 p-3 rounded-full mr-4">
                    <Briefcase className="w-6 h-6 text-purple-600" />
                  </div>
                  <div>
                    <h3 className="font-medium text-purple-900">Aktywne ogłoszenia</h3>
                    <p className="text-2xl font-bold text-green-600">{stats.activeJobs}</p>
                  </div>
                </div>
                <Link 
                  to="/admin/jobs" 
                  className="text-purple-600 hover:text-purple-800"
                >
                  <ArrowRight className="w-5 h-5" />
                </Link>
              </div>
              
              <div className="text-center pt-4">
                <Link 
                  to="/admin/jobs/add" 
                  className="inline-flex items-center justify-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Dodaj nowe ogłoszenie
                </Link>
              </div>
            </div>
          </div>
        )}
        </div>
    </div>
  );
}