import React, { useState, useEffect } from 'react';
import { 
  Loader2, AlertCircle, BarChart, TrendingUp, Eye,
  MousePointer, Send, Calendar, ArrowUpDown, CreditCard
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import PaymentAnalytics from '../../components/admin/analytics/PaymentAnalytics';

type EventStats = {
  views: number;
  clicks: number;
  applications: number;
};

type DailyStats = {
  date: string;
  views: number;
  clicks: number;
  applications: number;
};

type TopJob = {
  id: string;
  title: string;
  company_name: string;
  views: number;
  applications: number;
  conversion_rate: number;
};

export default function Analytics() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'jobs' | 'payments'>('jobs');
  const [totalStats, setTotalStats] = useState<EventStats>({
    views: 0,
    clicks: 0,
    applications: 0
  });
  const [dailyStats, setDailyStats] = useState<DailyStats[]>([]);
  const [topJobs, setTopJobs] = useState<TopJob[]>([]);
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d'>('30d');

  useEffect(() => {
    fetchAnalytics();
  }, [dateRange]);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);

      // Calculate date range
      const endDate = new Date();
      const startDate = new Date();
      switch (dateRange) {
        case '7d':
          startDate.setDate(startDate.getDate() - 7);
          break;
        case '30d':
          startDate.setDate(startDate.getDate() - 30);
          break;
        case '90d':
          startDate.setDate(startDate.getDate() - 90);
          break;
      }

      // Fetch total stats
      const { data: events, error: eventsError } = await supabase
        .from('job_events')
        .select('event_type')
        .gte('event_time', startDate.toISOString())
        .lte('event_time', endDate.toISOString());

      if (eventsError) throw eventsError;

      const stats = events.reduce((acc, event) => {
        acc[`${event.event_type}s`]++;
        return acc;
      }, { views: 0, clicks: 0, applications: 0 });

      setTotalStats(stats);

      // Fetch daily stats
      const { data: dailyEvents, error: dailyError } = await supabase
        .from('job_events')
        .select(`
          event_type,
          event_time
        `)
        .gte('event_time', startDate.toISOString())
        .lte('event_time', endDate.toISOString())
        .order('event_time', { ascending: true });

      if (dailyError) throw dailyError;

      // Process daily stats
      const dailyMap = new Map<string, DailyStats>();
      
      dailyEvents.forEach(event => {
        const date = new Date(event.event_time).toISOString().split('T')[0];
        const existing = dailyMap.get(date) || {
          date,
          views: 0,
          clicks: 0,
          applications: 0
        };
        existing[`${event.event_type}s`]++;
        dailyMap.set(date, existing);
      });

      setDailyStats(Array.from(dailyMap.values()));

      // Fetch top performing jobs
      const { data: jobStats, error: jobsError } = await supabase
        .from('jobs')
        .select(`
          id,
          title,
          company_name,
          job_events (
            event_type
          )
        `)
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(10);

      if (jobsError) throw jobsError;

      const processedJobs = jobStats.map(job => {
        const views = job.job_events.filter(e => e.event_type === 'view').length;
        const applications = job.job_events.filter(e => e.event_type === 'application').length;
        return {
          id: job.id,
          title: job.title,
          company_name: job.company_name,
          views,
          applications,
          conversion_rate: views > 0 ? ((applications / views) * 100).toFixed(1) : 0
        };
      }).sort((a, b) => b.views - a.views);

      setTopJobs(processedJobs);
    } catch (err) {
      console.error('Error fetching analytics:', err);
      setError('Wystąpił błąd podczas ładowania statystyk.');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie statystyk...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Wystąpił błąd
          </h2>
          <p className="text-purple-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-purple-900">
          Analityka
        </h1>
        <div className="flex space-x-4">
          <button
            onClick={() => setActiveTab('jobs')}
            className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'jobs'
                ? 'bg-purple-600 text-white'
                : 'bg-white text-purple-600 hover:bg-purple-50'
            }`}
          >
            <BarChart className="w-5 h-5 mr-2" />
            Ogłoszenia
          </button>
          <button
            onClick={() => setActiveTab('payments')}
            className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
              activeTab === 'payments'
                ? 'bg-purple-600 text-white'
                : 'bg-white text-purple-600 hover:bg-purple-50'
            }`}
          >
            <CreditCard className="w-5 h-5 mr-2" />
            Płatności
          </button>
        </div>
        <select
          value={dateRange}
          onChange={(e) => setDateRange(e.target.value as '7d' | '30d' | '90d')}
          className="px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
        >
          <option value="7d">Ostatnie 7 dni</option>
          <option value="30d">Ostatnie 30 dni</option>
          <option value="90d">Ostatnie 90 dni</option>
        </select>
      </div>

      {activeTab === 'payments' ? (
        <PaymentAnalytics />
      ) : (
        <>
      {/* Stats Overview */}
      <div className="grid grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-purple-900">
              Wyświetlenia
            </h3>
            <Eye className="w-6 h-6 text-purple-600" />
          </div>
          <div className="text-3xl font-bold text-purple-900">
            {totalStats.views}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-purple-900">
              Kliknięcia
            </h3>
            <MousePointer className="w-6 h-6 text-purple-600" />
          </div>
          <div className="text-3xl font-bold text-purple-900">
            {totalStats.clicks}
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-purple-900">
              Aplikacje
            </h3>
            <Send className="w-6 h-6 text-purple-600" />
          </div>
          <div className="text-3xl font-bold text-purple-900">
            {totalStats.applications}
          </div>
        </div>
      </div>

      {/* Daily Stats */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
        <h2 className="text-xl font-bold text-purple-900 mb-6">
          Statystyki dzienne
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-purple-50">
                <th className="px-6 py-3 text-left text-sm font-medium text-purple-900">
                  <div className="flex items-center">
                    <Calendar className="w-4 h-4 mr-2" />
                    Data
                  </div>
                </th>
                <th className="px-6 py-3 text-left text-sm font-medium text-purple-900">
                  <div className="flex items-center">
                    <Eye className="w-4 h-4 mr-2" />
                    Wyświetlenia
                  </div>
                </th>
                <th className="px-6 py-3 text-left text-sm font-medium text-purple-900">
                  <div className="flex items-center">
                    <MousePointer className="w-4 h-4 mr-2" />
                    Kliknięcia
                  </div>
                </th>
                <th className="px-6 py-3 text-left text-sm font-medium text-purple-900">
                  <div className="flex items-center">
                    <Send className="w-4 h-4 mr-2" />
                    Aplikacje
                  </div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-100">
              {dailyStats.map((day) => (
                <tr key={day.date} className="hover:bg-purple-50">
                  <td className="px-6 py-4 text-purple-900">
                    {new Date(day.date).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 text-purple-900">
                    {day.views}
                  </td>
                  <td className="px-6 py-4 text-purple-900">
                    {day.clicks}
                  </td>
                  <td className="px-6 py-4 text-purple-900">
                    {day.applications}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Top Performing Jobs */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h2 className="text-xl font-bold text-purple-900 mb-6">
          Najlepiej performujące ogłoszenia
        </h2>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-purple-50">
                <th className="px-6 py-3 text-left text-sm font-medium text-purple-900">
                  <button className="flex items-center">
                    Stanowisko
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-3 text-left text-sm font-medium text-purple-900">
                  <button className="flex items-center">
                    Firma
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-3 text-left text-sm font-medium text-purple-900">
                  <button className="flex items-center">
                    Wyświetlenia
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-3 text-left text-sm font-medium text-purple-900">
                  <button className="flex items-center">
                    Aplikacje
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-3 text-left text-sm font-medium text-purple-900">
                  <button className="flex items-center">
                    Konwersja
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-100">
              {topJobs.map((job) => (
                <tr key={job.id} className="hover:bg-purple-50">
                  <td className="px-6 py-4">
                    <div className="text-purple-900">{job.title}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-purple-700">{job.company_name}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-purple-900">{job.views}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-purple-900">{job.applications}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="text-purple-900">{job.conversion_rate}%</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
        </>
      )}
    </div>
  );
}