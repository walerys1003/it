import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { jobPostingSchema } from '../../schemas/jobPostingSchema';
import { Plus, X, Star, Code, Check, Building2, Mail, Phone, Loader2, AlertCircle, Info, Crown, Briefcase, ArrowLeft, ToggleLeft as Toggle, Image, Upload } from 'lucide-react';
import {
  jobCategories,
  technologies,
  workModes,
  experienceLevels,
  contractTypes,
  benefits,
  languages,
  locations
} from '../../data/jobPostingData';
import { supabase } from '../../lib/supabase';
import { uploadCompanyLogo } from '../../lib/fileStorage';
import { useRef } from 'react';

export default function EditJob() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { register, control, handleSubmit, watch, formState: { errors }, setValue } = useForm({
    resolver: zodResolver(jobPostingSchema),
    mode: 'onSubmit'
  });

  const {
    fields: responsibilitiesFields,
    append: appendResponsibility,
    remove: removeResponsibility
  } = useFieldArray({
    control,
    name: "responsibilities"
  });

  const {
    fields: requirementsFields,
    append: appendRequirement,
    remove: removeRequirement
  } = useFieldArray({
    control,
    name: "requirements"
  });

  const {
    fields: niceToHaveFields,
    append: appendNiceToHave,
    remove: removeNiceToHave
  } = useFieldArray({
    control,
    name: "niceToHave"
  });

  const {
    fields: languagesFields,
    append: appendLanguage,
    remove: removeLanguage
  } = useFieldArray({
    control,
    name: "languages"
  });

  useEffect(() => {
    const fetchJob = async () => {
      try {
        const { data: job, error: fetchError } = await supabase
          .from('jobs')
          .select('*')
          .eq('id', id)
          .single();

        if (fetchError) throw fetchError;

        // Transform job data to match form structure
        setValue('title', job.title);
        setValue('category', job.category);
        setValue('description', job.description);
        setValue('responsibilities', job.responsibilities);
        setValue('requirements', job.requirements);
        setValue('niceToHave', job.nice_to_have || []);
        setValue('technologies', job.technologies);
        setValue('workMode', job.work_mode);
        setValue('experienceLevel', job.experience_level);
        setValue('contractType', job.contract_type);
        setValue('salaryFrom', job.salary_from);
        setValue('salaryTo', job.salary_to);
        setValue('currency', job.currency);
        setValue('benefits', job.benefits || []);
        setValue('location', {
          country: job.location_country,
          voivodeship: job.location_voivodeship,
          city: job.location_city
        });
        setValue('languages', job.languages || []);
        setValue('company', {
          name: job.company_name,
          description: job.company_description,
          size: job.company_size,
          logo: job.company_logo
        });
        
        // Set logo preview if available
        if (job.company_logo) {
          setLogoPreview(job.company_logo);
        }
        
        setValue('contact', {
          name: job.contact_name,
          position: job.contact_position,
          email: job.contact_email,
          phone: job.contact_phone
        });
        setValue('packageType', job.is_premium ? 'premium' : 'standard');
        setValue('isActive', job.is_active);

      } catch (err) {
        console.error('Error fetching job:', err);
        setError('Wystąpił błąd podczas ładowania ogłoszenia.');
      } finally {
        setLoading(false);
      }
    };

    if (id) {
      fetchJob();
    }
  }, [id, setValue]);

  const onSubmit = async (data) => {
    setIsSubmitting(true);
    setError(null);
    
    let logoUrl = data.company.logo;
    
    try {
      // Handle logo file upload if present
      if (logoFile) {
        try {
          // Generate a unique ID for the file
          const fileId = crypto.randomUUID();
          logoUrl = await uploadCompanyLogo(logoFile, fileId);
        } catch (uploadError) {
          console.error('Error uploading logo:', uploadError);
          throw new Error('Failed to upload company logo. Please try again.');
        }
      }
      
      // Update job data
      const { error: updateError } = await supabase
        .from('jobs')
        .update({
          title: data.title,
          category: data.category,
          description: data.description,
          responsibilities: data.responsibilities,
          requirements: data.requirements,
          nice_to_have: data.niceToHave,
          technologies: data.technologies,
          work_mode: data.workMode,
          experience_level: data.experienceLevel,
          contract_type: data.contractType,
          salary_from: data.salaryFrom,
          salary_to: data.salaryTo,
          currency: data.currency,
          benefits: data.benefits,
          location_country: data.location.country,
          location_voivodeship: data.location.voivodeship,
          location_city: data.location.city,
          languages: data.languages,
          company_name: data.company.name,
          company_description: data.company.description,
          company_size: data.company.size,
          company_logo: logoUrl,
          contact_name: data.contact.name,
          contact_position: data.contact.position,
          contact_email: data.contact.email,
          contact_phone: data.contact.phone,
          is_premium: data.packageType === 'premium',
          is_active: data.isActive
        })
        .eq('id', id);

      if (updateError) throw updateError;

      // Log the update in admin audit log
      await supabase
        .from('admin_audit_log')
        .insert([{
          action: 'update_job',
          entity_type: 'jobs',
          entity_id: id,
          details: {
            updated_at: new Date().toISOString(),
            changes: data
          }
        }]);

      navigate('/admin/jobs');
    } catch (err) {
      console.error('Error updating job:', err);
      setError('Wystąpił błąd podczas aktualizacji ogłoszenia.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    handleFile(file);
  };
  
  // Process the selected file
  const handleFile = (file: File | undefined) => {
    if (!file) return;
    
    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml'];
    if (!validTypes.includes(file.type)) {
      setFileError('Dozwolone formaty plików: JPG, PNG, GIF, SVG');
      return;
    }
    
    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      setFileError('Maksymalny rozmiar pliku to 2MB');
      return;
    }
    
    // Clear any previous errors
    setFileError(null);
    
    // Create a preview URL
    const objectUrl = URL.createObjectURL(file);
    setLogoPreview(objectUrl);
    setLogoFile(file);
    
    // Store the file in the form
    setValue('company.logo', file);
  };
  
  // Remove the selected file
  const handleRemoveFile = () => {
    setValue('company.logo', '');
    setLogoPreview(null);
    setLogoFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie ogłoszenia...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Wystąpił błąd
          </h2>
          <p className="text-purple-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <button
              onClick={() => navigate('/admin/jobs')}
              className="mr-4 text-purple-600 hover:text-purple-800"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <h1 className="text-2xl font-bold text-purple-900">
              Edytuj ogłoszenie
            </h1>
          </div>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 rounded-xl">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-red-400 mr-2" />
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Job Status */}
          <div className="bg-purple-50 p-6 rounded-xl space-y-4">
            <h2 className="text-lg font-bold text-purple-900">
              Status ogłoszenia
            </h2>
            <div className="flex items-center space-x-4">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  {...register('isActive')}
                  className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                />
                <span className="text-purple-900">Aktywne</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="radio"
                  {...register('packageType')}
                  value="standard"
                  className="text-purple-600 focus:ring-purple-500"
                />
                <span className="text-purple-900">Standard</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="radio"
                  {...register('packageType')}
                  value="premium"
                  className="text-purple-600 focus:ring-purple-500"
                />
                <span className="text-purple-900">Premium</span>
              </label>
            </div>
          </div>

          {/* Basic Information */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Podstawowe informacje
            </h2>
            
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Stanowisko
              </label>
              <input
                type="text"
                {...register("title")}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. Senior React Developer (min. 10 znaków)"
              />
              {errors.title && (
                <p className="mt-1 text-sm text-red-600">{errors.title.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Kategoria
              </label>
              <select
                {...register("category")}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              >
                <option value="">Wybierz kategorię</option>
                {Object.entries(jobCategories).map(([category, subcategories]) => (
                  <optgroup key={category} label={category}>
                    {subcategories.map((subcat) => (
                      <option key={subcat} value={subcat}>{subcat}</option>
                    ))}
                  </optgroup>
                ))}
              </select>
              {errors.category && (
                <p className="mt-1 text-sm text-red-600">{errors.category.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Opis stanowiska
              </label>
              <textarea
                {...register("description")}
                rows={6}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="Opisz szczegółowo stanowisko, zakres obowiązków i wymagania... (min. 100 znaków)"
              />
              {errors.description && (
                <p className="mt-1 text-sm text-red-600">{errors.description.message}</p>
              )}
            </div>
          </div>

          {/* Requirements and Responsibilities */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Wymagania i obowiązki
            </h2>

            {/* Responsibilities */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Zakres obowiązków
              </label>
              <div className="space-y-3">
                {responsibilitiesFields.map((field, index) => (
                  <div key={field.id} className="flex gap-2">
                    <input
                      {...register(`responsibilities.${index}`)}
                      className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder="np. Rozwój aplikacji w React.js"
                    />
                    <button
                      type="button"
                      onClick={() => removeResponsibility(index)}
                      className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => appendResponsibility('')}
                  className="flex items-center text-purple-600 hover:text-purple-700"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Dodaj obowiązek
                </button>
              </div>
            </div>

            {/* Requirements */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Wymagania
              </label>
              <div className="space-y-3">
                {requirementsFields.map((field, index) => (
                  <div key={field.id} className="flex gap-2">
                    <input
                      {...register(`requirements.${index}`)}
                      className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder="np. Min. 3 lata doświadczenia w React.js"
                    />
                    <button
                      type="button"
                      onClick={() => removeRequirement(index)}
                      className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => appendRequirement('')}
                  className="flex items-center text-purple-600 hover:text-purple-700"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Dodaj wymaganie
                </button>
              </div>
            </div>

            {/* Nice to Have */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Mile widziane
              </label>
              <div className="space-y-3">
                {niceToHaveFields.map((field, index) => (
                  <div key={field.id} className="flex gap-2">
                    <input
                      {...register(`niceToHave.${index}`)}
                      className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder="np. Znajomość TypeScript"
                    />
                    <button
                      type="button"
                      onClick={() => removeNiceToHave(index)}
                      className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => appendNiceToHave('')}
                  className="flex items-center text-purple-600 hover:text-purple-700"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Dodaj mile widziane
                </button>
              </div>
            </div>
          </div>

          {/* Technologies */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Technologie
            </h2>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Wymagane technologie
              </label>
              <div className="space-y-5">
                {Object.entries(technologies).map(([category, techs]) => (
                  <div key={category} className="space-y-2">
                    <h3 className="text-sm font-medium text-purple-700">{category}</h3>
                    <div className="flex flex-wrap gap-2">
                      {techs.map((tech) => (
                        <label
                          key={tech}
                          className="inline-flex items-center px-4 py-2 rounded-xl border border-purple-200 hover:bg-purple-50 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            {...register('technologies')}
                            value={tech}
                            className="mr-2 rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                          />
                          {tech}
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              {errors.technologies && (
                <p className="mt-1 text-sm text-red-600">{errors.technologies.message}</p>
              )}
            </div>
          </div>

          {/* Languages */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Wymagane języki
            </h2>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Wymagane języki
              </label>
              <div className="space-y-3">
                {languagesFields.map((field, index) => (
                  <div key={field.id} className="flex gap-4">
                    <select
                      {...register(`languages.${index}.language`)}
                      className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value="">Wybierz język</option>
                      {languages.map((lang) => (
                        <option key={lang.value} value={lang.value}>
                          {lang.label}
                        </option>
                      ))}
                    </select>
                    <select
                      {...register(`languages.${index}.level`)}
                      className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value="">Poziom</option>
                      <option value="A1">A1 - Początkujący</option>
                      <option value="A2">A2 - Podstawowy</option>
                      <option value="B1">B1 - Średniozaawansowany</option>
                      <option value="B2">B2 - Wyższy średniozaawansowany</option>
                      <option value="C1">C1 - Zaawansowany</option>
                      <option value="C2">C2 - Biegły</option>
                      <option value="native">Ojczysty</option>
                    </select>
                    <button
                      type="button"
                      onClick={() => removeLanguage(index)}
                      className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => appendLanguage({ language: '', level: '' })}
                  className="flex items-center text-purple-600 hover:text-purple-700"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Dodaj język
                </button>
              </div>
              {errors.languages && (
                <p className="mt-1 text-sm text-red-600">{errors.languages.message}</p>
              )}
            </div>
          </div>

          {/* Employment Details */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Warunki zatrudnienia
            </h2>

            {/* Work Mode */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Tryb pracy
              </label>
              <div className="grid grid-cols-3 gap-4">
                {workModes.map((mode) => (
                  <label
                    key={mode.value}
                    className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
                  >
                    <input
                      type="radio"
                      {...register('workMode')}
                      value={mode.value}
                      className="mr-3 text-purple-600 focus:ring-purple-500"
                    />
                    {mode.label}
                  </label>
                ))}
              </div>
              {errors.workMode && (
                <p className="mt-1 text-sm text-red-600">{errors.workMode.message}</p>
              )}
            </div>

            {/* Experience Level */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Poziom doświadczenia
              </label>
              <div className="grid grid-cols-2 gap-4">
                {experienceLevels.map((level) => (
                  <label
                    key={level.value}
                    className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
                  >
                    <input
                      type="radio"
                      {...register('experienceLevel')}
                      value={level.value}
                      className="mr-3 text-purple-600 focus:ring-purple-500"
                    />
                    {level.label}
                  </label>
                ))}
              </div>
              {errors.experienceLevel && (
                <p className="mt-1 text-sm text-red-600">{errors.experienceLevel.message}</p>
              )}
            </div>

            {/* Contract Type */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Typ umowy
              </label>
              <div className="grid grid-cols-2 gap-4">
                {contractTypes.map((type) => (
                  <label
                    key={type.value}
                    className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
                  >
                    <input
                      type="radio"
                      {...register('contractType')}
                      value={type.value}
                      className="mr-3 text-purple-600 focus:ring-purple-500"
                    />
                    {type.label}
                  </label>
                ))}
              </div>
              {errors.contractType && (
                <p className="mt-1 text-sm text-red-600">{errors.contractType.message}</p>
              )}
            </div>

            {/* Salary Range */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Wynagrodzenie (PLN netto/msc)
              </label>
              <div className="flex gap-4 items-center">
                <input
                  type="number"
                  {...register('salaryFrom', { valueAsNumber: true })}
                  className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Od"
                />
                <span className="text-purple-600">-</span>
                <input
                  type="number"
                  {...register('salaryTo', { valueAsNumber: true })}
                  className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Do"
                />
              </div>
              {(errors.salaryFrom || errors.salaryTo) && (
                <p className="mt-1 text-sm text-red-600">
                  {errors.salaryFrom?.message || errors.salaryTo?.message}
                </p>
              )}
            </div>

            {/* Benefits */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Benefity
              </label>
              <div className="grid grid-cols-2 gap-4">
                {benefits.map((benefit) => (
                  <label
                    key={benefit.value}
                    className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      {...register('benefits')}
                      value={benefit.value}
                      className="mr-3 rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                    />
                    {benefit.label}
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Location */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Lokalizacja
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Kraj
                </label>
                <select
                  {...register('location.country')}
                  className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                  <option value="">Wybierz kraj</option>
                  {locations.countries.map((country) => (
                    <option key={country.value} value={country.value}>
                      {country.label}
                    </option>
                  ))}
                </select>
                {errors.location?.country && (
                  <p className="mt-1 text-sm text-red-600">{errors.location.country.message}</p>
                )}
              </div>

              {watch('location.country') === 'pl' && (
                <div>
                  <label className="block text-sm font-medium text-purple-900 mb-2">
                    Województwo
                  </label>
                  <select
                    {...register('location.voivodeship')}
                    className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  >
                    <option value="">Wybierz województwo</option>
                    {locations.voivodeships.map((voivodeship) => (
                      <option key={voivodeship.value} value={voivodeship.value}>
                        {voivodeship.label}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Miasto
                </label>
                <input
                  type="text"
                  {...register('location.city')}
                  className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Wpisz nazwę miasta"
                />
                {errors.location?.city && (
                  <p className="mt-1 text-sm text-red-600">{errors.location.city.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Company Information */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Informacje o firmie
            </h2>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Nazwa firmy
              </label>
              <input
                type="text"
                {...register('company.name')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. TechCorp Solutions"
              />
              {errors.company?.name && (
                <p className="mt-1 text-sm text-red-600">{errors.company.name.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Opis firmy
              </label>
              <textarea
                {...register('company.description')}
                rows={4}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="Krótki opis działalności firmy..."
              />
              {errors.company?.description && (
                <p className="mt-1 text-sm text-red-600">{errors.company.description.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Wielkość firmy
              </label>
              <select
                {...register('company.size')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              >
                <option value="">Wybierz wielkość</option>
                <option value="1-10">1-10 pracowników</option>
                <option value="11-50">11-50 pracowników</option>
                <option value="51-200">51-200 pracowników</option>
                <option value="201-500">201-500 pracowników</option>
                <option value="501-1000">501-1000 pracowników</option>
                <option value="1000+">1000+ pracowników</option>
              </select>
              {errors.company?.size && (
                <p className="mt-1 text-sm text-red-600">{errors.company.size.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Logo firmy (JPG, PNG, GIF, SVG)
              </label>
              <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-xl border-purple-200 hover:border-purple-400 transition-colors">
                {logoPreview ? (
                  <div className="space-y-4 w-full flex flex-col items-center">
                    <div className="relative w-40 h-40">
                      <img 
                        src={logoPreview} 
                        alt="Logo podgląd" 
                        className="w-full h-full object-contain"
                      />
                      <button
                        type="button"
                        onClick={handleRemoveFile}
                        className="absolute -top-2 -right-2 bg-red-100 text-red-600 rounded-full p-1 hover:bg-red-200"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                    <p className="text-sm text-purple-600">
                      {logoFile?.name || "Obecne logo"}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-1 text-center">
                    <div className="flex flex-col items-center">
                      <Image className="mx-auto h-12 w-12 text-purple-400" />
                      <div className="flex text-sm text-purple-600 mt-2">
                        <label
                          htmlFor="company-logo-upload"
                          className="relative cursor-pointer bg-white rounded-md font-medium text-purple-600 hover:text-purple-500 focus-within:outline-none"
                        >
                          <span>Przeciągnij i upuść plik lub</span>
                          <span className="ml-1 text-purple-500 hover:text-purple-700"> przeglądaj</span>
                          <input
                            id="company-logo-upload"
                            name="company-logo-upload"
                            type="file"
                            className="sr-only"
                            accept="image/*"
                            onChange={handleFileChange}
                            ref={fileInputRef}
                          />
                        </label>
                      </div>
                      <p className="text-xs text-purple-500 mt-1">
                        PNG, JPG, GIF do 2MB
                      </p>
                    </div>
                  </div>
                )}
              </div>
              
              {/* Register the logo field for validation */}
              <input
                type="hidden"
                {...register('company.logo')}
              />
              
              {/* Error messages */}
              {(errors.company?.logo || fileError) && (
                <p className="mt-2 text-sm text-red-600">
                  {errors.company?.logo?.message || fileError}
                </p>
              )}
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Dane kontaktowe
            </h2>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Imię i nazwisko osoby kontaktowej
              </label>
              <input
                type="text"
                {...register('contact.name')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. Jan Kowalski"
              />
              {errors.contact?.name && (
                <p className="mt-1 text-sm text-red-600">{errors.contact.name.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Stanowisko
              </label>
              <input
                type="text"
                {...register('contact.position')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. HR Manager"
              />
              {errors.contact?.position && (
                <p className="mt-1 text-sm text-red-600">{errors.contact.position.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Email
              </label>
              <input
                type="email"
                {...register('contact.email')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. jan.kowalski@firma.pl"
              />
              {errors.contact?.email && (
                <p className="mt-1 text-sm text-red-600">{errors.contact.email.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Telefon
              </label>
              <input
                type="tel"
                {...register('contact.phone')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. +48 500 600 700"
              />
              {errors.contact?.phone && (
                <p className="mt-1 text-sm text-red-600">{errors.contact.phone.message}</p>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-between pt-8 border-t border-purple-100">
            <button
              onClick={() => navigate('/admin/jobs')}
              type="button"
              className="px-6 py-3 bg-purple-100 text-purple-700 rounded-xl hover:bg-purple-200 transition-colors"
            >
              Anuluj
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors"
            >
              {isSubmitting ? 'Zapisywanie...' : 'Zapisz zmiany'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}