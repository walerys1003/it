import React, { useState, useEffect } from 'react';
import { 
  Loader2, AlertCircle, Search, Save, Globe, 
  FileText, Code, Tag, Facebook, Twitter, 
  CheckCircle2, ChevronDown, ChevronRight, Edit
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

type SEOPage = {
  id: string;
  path: string;
  title: string;
  description: string;
  keywords: string;
  og_title: string;
  og_description: string;
  og_image: string;
  og_type: string;
  schema_type: string;
  schema_data: any;
  created_at: string;
  updated_at: string;
};

type ExpandedPages = {
  [key: string]: boolean;
};

export default function SEO() {
  const [pages, setPages] = useState<SEOPage[]>([]);
  const [filteredPages, setFilteredPages] = useState<SEOPage[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);
  const [expandedPages, setExpandedPages] = useState<ExpandedPages>({});
  const [editingPage, setEditingPage] = useState<SEOPage | null>(null);

  // Default pages in the system
  const defaultPages = [
    { path: '/', name: 'Strona główna' },
    { path: '/cennik', name: 'Cennik' },
    { path: '/uslugi-promocji', name: 'Usługi promocji' },
    { path: '/social-media', name: 'Social Media' },
    { path: '/kontakt', name: 'Kontakt' },
    { path: '/blog', name: 'Blog' },
    { path: '/dodaj-ogloszenie', name: 'Dodaj ogłoszenie' },
    { path: '/polityka-prywatnosci', name: 'Polityka prywatności' },
    { path: '/regulamin', name: 'Regulamin' }
  ];

  useEffect(() => {
    fetchSEOPages();
  }, []);

  const fetchSEOPages = async () => {
    try {
      setLoading(true);
      
      // Fetch existing SEO pages from database
      const { data, error } = await supabase
        .from('seo_pages')
        .select('*')
        .order('path');

      if (error) throw error;

      // If we have data, use it
      if (data && data.length > 0) {
        setPages(data);
        setFilteredPages(data);
      } else {
        // Otherwise, create default entries for all default pages
        const defaultEntries = defaultPages.map(page => ({
          id: crypto.randomUUID(),
          path: page.path,
          title: `${page.name} | StartJob.IT`,
          description: `StartJob.IT - ${page.name}`,
          keywords: 'praca, IT, oferty pracy, programista, developer',
          og_title: `${page.name} | StartJob.IT`,
          og_description: `StartJob.IT - ${page.name}`,
          og_image: '',
          og_type: 'website',
          schema_type: 'WebPage',
          schema_data: {},
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }));

        setPages(defaultEntries);
        setFilteredPages(defaultEntries);
      }
    } catch (err) {
      console.error('Error fetching SEO pages:', err);
      setError('Wystąpił błąd podczas ładowania stron SEO.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    const timeout = setTimeout(() => {
      const filtered = pages.filter(page => {
        const searchLower = searchQuery.toLowerCase();
        return (
          page.path.toLowerCase().includes(searchLower) ||
          page.title.toLowerCase().includes(searchLower) ||
          page.description.toLowerCase().includes(searchLower)
        );
      });
      setFilteredPages(filtered);
    }, 300);

    setSearchTimeout(timeout);

    return () => {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    };
  }, [pages, searchQuery]);

  const togglePageExpand = (pageId: string) => {
    setExpandedPages(prev => ({
      ...prev,
      [pageId]: !prev[pageId]
    }));
  };

  const handleEditPage = (page: SEOPage) => {
    setEditingPage({...page});
  };

  const handleSavePage = async (page: SEOPage) => {
    try {
      setSaving(page.id);
      setError(null);
      setSuccess(null);

      // Check if the page already exists in the database
      const { data: existingPage, error: checkError } = await supabase
        .from('seo_pages')
        .select('id')
        .eq('path', page.path)
        .maybeSingle();

      if (checkError) throw checkError;

      let result;
      
      if (existingPage) {
        // Update existing page
        const { data, error } = await supabase
          .from('seo_pages')
          .update({
            title: page.title,
            description: page.description,
            keywords: page.keywords,
            og_title: page.og_title,
            og_description: page.og_description,
            og_image: page.og_image,
            og_type: page.og_type,
            schema_type: page.schema_type,
            schema_data: page.schema_data,
            updated_at: new Date().toISOString()
          })
          .eq('id', page.id)
          .select()
          .single();

        if (error) throw error;
        result = data;
      } else {
        // Insert new page
        const { data, error } = await supabase
          .from('seo_pages')
          .insert([{
            path: page.path,
            title: page.title,
            description: page.description,
            keywords: page.keywords,
            og_title: page.og_title,
            og_description: page.og_description,
            og_image: page.og_image,
            og_type: page.og_type,
            schema_type: page.schema_type,
            schema_data: page.schema_data
          }])
          .select()
          .single();

        if (error) throw error;
        result = data;
      }

      // Update pages state
      setPages(prevPages => 
        prevPages.map(p => p.id === page.id ? result : p)
      );
      
      // Log the action
      await supabase
        .from('admin_audit_log')
        .insert([{
          action: existingPage ? 'update_seo_page' : 'create_seo_page',
          entity_type: 'seo_pages',
          entity_id: result.id,
          details: {
            path: page.path,
            updated_at: new Date().toISOString()
          }
        }]);

      setSuccess(`Ustawienia SEO dla strony "${page.path}" zostały zapisane.`);
      setEditingPage(null);
      
      // Clear success message after 3 seconds
      setTimeout(() => {
        setSuccess(null);
      }, 3000);
    } catch (err) {
      console.error('Error saving SEO page:', err);
      setError(`Wystąpił błąd podczas zapisywania ustawień SEO: ${err.message}`);
    } finally {
      setSaving(null);
    }
  };

  const handleCancelEdit = () => {
    setEditingPage(null);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie ustawień SEO...</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-purple-900">
          Zarządzanie SEO
        </h1>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 rounded-xl">
          <div className="flex items-center">
            <AlertCircle className="w-5 h-5 text-red-400 mr-2" />
            <p className="text-red-700">{error}</p>
          </div>
        </div>
      )}

      {success && (
        <div className="mb-6 p-4 bg-green-50 rounded-xl">
          <div className="flex items-center">
            <CheckCircle2 className="w-5 h-5 text-green-500 mr-2" />
            <p className="text-green-700">{success}</p>
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
        <div className="grid md:grid-cols-2 gap-4">
          {/* Search */}
          <div className="relative">
            <input
              type="text"
              placeholder="Szukaj strony..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-purple-400" />
          </div>

          {/* Results Count */}
          <div className="flex items-center justify-end text-sm text-purple-600">
            Znaleziono: {filteredPages.length} stron
          </div>
        </div>
      </div>

      {/* SEO Pages List */}
      <div className="space-y-4">
        {filteredPages.map((page) => (
          <div key={page.id} className="bg-white rounded-xl shadow-lg overflow-hidden">
            <div 
              className={`p-6 flex items-center justify-between cursor-pointer ${expandedPages[page.id] ? 'border-b border-purple-100' : ''}`}
              onClick={() => togglePageExpand(page.id)}
            >
              <div className="flex items-center">
                {expandedPages[page.id] ? (
                  <ChevronDown className="w-5 h-5 text-purple-500 mr-3" />
                ) : (
                  <ChevronRight className="w-5 h-5 text-purple-500 mr-3" />
                )}
                <div>
                  <div className="flex items-center">
                    <Globe className="w-5 h-5 text-purple-400 mr-2" />
                    <h2 className="text-lg font-semibold text-purple-900">{page.path}</h2>
                  </div>
                  <p className="text-sm text-purple-600 mt-1">{page.title}</p>
                </div>
              </div>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  handleEditPage(page);
                }}
                className="px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors"
              >
                <Edit className="w-4 h-4 mr-2 inline-block" />
                Edytuj
              </button>
            </div>
            
            {expandedPages[page.id] && (
              <div className="p-6 space-y-6">
                {/* Meta Tags */}
                <div>
                  <h3 className="text-md font-semibold text-purple-900 mb-3 flex items-center">
                    <Tag className="w-5 h-5 mr-2 text-purple-500" />
                    Meta Tagi
                  </h3>
                  <div className="space-y-3 pl-7">
                    <div>
                      <p className="text-sm font-medium text-purple-700">Tytuł</p>
                      <p className="text-sm text-purple-900 bg-purple-50 p-2 rounded">{page.title}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-purple-700">Opis</p>
                      <p className="text-sm text-purple-900 bg-purple-50 p-2 rounded">{page.description}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-purple-700">Słowa kluczowe</p>
                      <p className="text-sm text-purple-900 bg-purple-50 p-2 rounded">{page.keywords}</p>
                    </div>
                  </div>
                </div>
                
                {/* OpenGraph Tags */}
                <div>
                  <h3 className="text-md font-semibold text-purple-900 mb-3 flex items-center">
                    <Facebook className="w-5 h-5 mr-2 text-purple-500" />
                    OpenGraph Tagi
                  </h3>
                  <div className="space-y-3 pl-7">
                    <div>
                      <p className="text-sm font-medium text-purple-700">OG:Title</p>
                      <p className="text-sm text-purple-900 bg-purple-50 p-2 rounded">{page.og_title}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-purple-700">OG:Description</p>
                      <p className="text-sm text-purple-900 bg-purple-50 p-2 rounded">{page.og_description}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-purple-700">OG:Image</p>
                      <p className="text-sm text-purple-900 bg-purple-50 p-2 rounded">{page.og_image || 'Nie ustawiono'}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-purple-700">OG:Type</p>
                      <p className="text-sm text-purple-900 bg-purple-50 p-2 rounded">{page.og_type}</p>
                    </div>
                  </div>
                </div>
                
                {/* Schema.org */}
                <div>
                  <h3 className="text-md font-semibold text-purple-900 mb-3 flex items-center">
                    <Code className="w-5 h-5 mr-2 text-purple-500" />
                    Schema.org
                  </h3>
                  <div className="space-y-3 pl-7">
                    <div>
                      <p className="text-sm font-medium text-purple-700">Typ</p>
                      <p className="text-sm text-purple-900 bg-purple-50 p-2 rounded">{page.schema_type}</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-purple-700">Dane</p>
                      <pre className="text-sm text-purple-900 bg-purple-50 p-2 rounded overflow-x-auto">
                        {JSON.stringify(page.schema_data || {}, null, 2)}
                      </pre>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Edit Modal */}
      {editingPage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 max-w-3xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-xl font-bold text-purple-900 mb-6 flex items-center">
              <Globe className="w-6 h-6 mr-2 text-purple-600" />
              Edycja SEO: {editingPage.path}
            </h2>
            
            <div className="space-y-6">
              {/* Meta Tags */}
              <div className="border-b border-purple-100 pb-6">
                <h3 className="text-md font-semibold text-purple-900 mb-4 flex items-center">
                  <Tag className="w-5 h-5 mr-2 text-purple-500" />
                  Meta Tagi
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Tytuł
                    </label>
                    <input
                      type="text"
                      value={editingPage.title}
                      onChange={(e) => setEditingPage({...editingPage, title: e.target.value})}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                    <p className="text-xs text-purple-600 mt-1">
                      Zalecana długość: 50-60 znaków. Obecna długość: {editingPage.title.length}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Opis
                    </label>
                    <textarea
                      value={editingPage.description}
                      onChange={(e) => setEditingPage({...editingPage, description: e.target.value})}
                      rows={3}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                    <p className="text-xs text-purple-600 mt-1">
                      Zalecana długość: 150-160 znaków. Obecna długość: {editingPage.description.length}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Słowa kluczowe
                    </label>
                    <input
                      type="text"
                      value={editingPage.keywords}
                      onChange={(e) => setEditingPage({...editingPage, keywords: e.target.value})}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                    <p className="text-xs text-purple-600 mt-1">
                      Oddziel słowa kluczowe przecinkami. Np.: praca, IT, programista
                    </p>
                  </div>
                </div>
              </div>
              
              {/* OpenGraph Tags */}
              <div className="border-b border-purple-100 pb-6">
                <h3 className="text-md font-semibold text-purple-900 mb-4 flex items-center">
                  <Facebook className="w-5 h-5 mr-2 text-purple-500" />
                  OpenGraph Tagi
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      OG:Title
                    </label>
                    <input
                      type="text"
                      value={editingPage.og_title}
                      onChange={(e) => setEditingPage({...editingPage, og_title: e.target.value})}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      OG:Description
                    </label>
                    <textarea
                      value={editingPage.og_description}
                      onChange={(e) => setEditingPage({...editingPage, og_description: e.target.value})}
                      rows={3}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      OG:Image
                    </label>
                    <input
                      type="text"
                      value={editingPage.og_image}
                      onChange={(e) => setEditingPage({...editingPage, og_image: e.target.value})}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder="https://example.com/image.jpg"
                    />
                    <p className="text-xs text-purple-600 mt-1">
                      Zalecany rozmiar: 1200x630 pikseli
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      OG:Type
                    </label>
                    <select
                      value={editingPage.og_type}
                      onChange={(e) => setEditingPage({...editingPage, og_type: e.target.value})}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value="website">website</option>
                      <option value="article">article</option>
                      <option value="profile">profile</option>
                      <option value="book">book</option>
                    </select>
                  </div>
                </div>
              </div>
              
              {/* Schema.org */}
              <div>
                <h3 className="text-md font-semibold text-purple-900 mb-4 flex items-center">
                  <Code className="w-5 h-5 mr-2 text-purple-500" />
                  Schema.org
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Typ
                    </label>
                    <select
                      value={editingPage.schema_type}
                      onChange={(e) => setEditingPage({...editingPage, schema_type: e.target.value})}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value="WebPage">WebPage</option>
                      <option value="Article">Article</option>
                      <option value="Blog">Blog</option>
                      <option value="BlogPosting">BlogPosting</option>
                      <option value="Organization">Organization</option>
                      <option value="LocalBusiness">LocalBusiness</option>
                      <option value="Service">Service</option>
                      <option value="JobPosting">JobPosting</option>
                      <option value="ContactPage">ContactPage</option>
                      <option value="Product">Product</option>
                      <option value="Person">Person</option>
                      <option value="Event">Event</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Dane JSON
                    </label>
                    <textarea
                      value={JSON.stringify(editingPage.schema_data || {}, null, 2)}
                      onChange={(e) => {
                        try {
                          const jsonData = JSON.parse(e.target.value);
                          setEditingPage({...editingPage, schema_data: jsonData});
                        } catch (err) {
                          // Allow invalid JSON during editing, but don't update the state
                          console.log('Invalid JSON, not updating state');
                        }
                      }}
                      rows={8}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 font-mono"
                    />
                    <p className="text-xs text-purple-600 mt-1">
                      Wprowadź dane w formacie JSON zgodnie ze standardem schema.org
                    </p>
                    <div className="mt-4 p-4 bg-purple-50 rounded-lg">
                      <h4 className="text-sm font-medium text-purple-900 mb-2">Przykładowe dane dla {editingPage.schema_type}</h4>
                      <div className="text-xs text-purple-700">
                        {editingPage.schema_type === 'Organization' && (
                          <pre className="whitespace-pre-wrap">
{`{
  "name": "StartJob.IT",
  "url": "https://startjob.it",
  "logo": "https://startjob.it/logo.png",
  "description": "StartJob.IT to platforma łącząca specjalistów IT z najlepszymi pracodawcami.",
  "sameAs": [
    "https://facebook.com/startjob.it",
    "https://linkedin.com/company/startjob-it"
  ],
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "ul. Świeradowska 47",
    "addressLocality": "Warszawa",
    "postalCode": "02-662",
    "addressCountry": "PL"
  }
}`}
                          </pre>
                        )}
                        {editingPage.schema_type === 'WebPage' && (
                          <pre className="whitespace-pre-wrap">
{`{
  "name": "Nazwa strony",
  "description": "Opis strony",
  "isPartOf": {
    "@type": "WebSite",
    "name": "StartJob.IT",
    "url": "https://startjob.it"
  }
}`}
                          </pre>
                        )}
                        {editingPage.schema_type === 'Article' || editingPage.schema_type === 'BlogPosting' && (
                          <pre className="whitespace-pre-wrap">
{`{
  "headline": "Tytuł artykułu",
  "description": "Opis artykułu",
  "image": "https://example.com/image.jpg",
  "datePublished": "2025-01-01T12:00:00Z",
  "author": {
    "@type": "Person",
    "name": "Imię Nazwisko"
  }
}`}
                          </pre>
                        )}
                        {editingPage.schema_type === 'ContactPage' && (
                          <pre className="whitespace-pre-wrap">
{`{
  "name": "Kontakt StartJob.IT",
  "description": "Skontaktuj się z nami",
  "contactPoint": {
    "@type": "ContactPoint",
    "telephone": "(+48) 501 42 00 42",
    "email": "kontakt@startjob.it"
  }
}`}
                          </pre>
                        )}
                        {editingPage.schema_type === 'JobPosting' && (
                          <pre className="whitespace-pre-wrap">
{`{
  "title": "Tytuł stanowiska",
  "description": "Opis stanowiska",
  "datePosted": "2025-01-01T12:00:00Z",
  "validThrough": "2025-03-01T12:00:00Z",
  "employmentType": "FULL_TIME",
  "hiringOrganization": {
    "@type": "Organization",
    "name": "Nazwa firmy"
  },
  "jobLocation": {
    "@type": "Place",
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Warszawa",
      "addressCountry": "PL"
    }
  }
}`}
                          </pre>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="flex justify-end space-x-4 mt-8">
              <button
                onClick={handleCancelEdit}
                className="px-4 py-2 border border-purple-200 text-purple-700 rounded-lg hover:bg-purple-50 transition-colors"
              >
                Anuluj
              </button>
              <button
                onClick={() => handleSavePage(editingPage)}
                disabled={saving === editingPage.id}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center"
              >
                {saving === editingPage.id ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Zapisywanie...
                  </>
                ) : (
                  <>
                    <Save className="w-5 h-5 mr-2" />
                    Zapisz zmiany
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}