import React, { useState, useEffect } from 'react';
import { 
  Loader2, AlertCircle, Trash2, Search, Download,
  ArrowUpDown, Calendar, Mail
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

type Subscriber = {
  id: string;
  email: string;
  created_at: string;
};

export default function Newsletter() {
  const [subscribers, setSubscribers] = useState<Subscriber[]>([]);
  const [filteredSubscribers, setFilteredSubscribers] = useState<Subscriber[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);

  useEffect(() => {
    fetchSubscribers();
  }, []);

  const fetchSubscribers = async () => {
    try {
      const { data, error } = await supabase
        .from('newsletter_subscribers')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSubscribers(data);
      setFilteredSubscribers(data);
    } catch (err) {
      console.error('Error fetching subscribers:', err);
      setError('Wystąpił błąd podczas ładowania subskrybentów.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    const timeout = setTimeout(() => {
      const filtered = subscribers.filter(subscriber => 
        subscriber.email.toLowerCase().includes(searchQuery.toLowerCase())
      );
      setFilteredSubscribers(filtered);
    }, 300);

    setSearchTimeout(timeout);

    return () => {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    };
  }, [subscribers, searchQuery]);

  const handleDelete = async (subscriberId: string) => {
    if (!window.confirm('Czy na pewno chcesz usunąć tego subskrybenta?')) {
      return;
    }

    try {
      setProcessingId(subscriberId);
      const { error } = await supabase
        .from('newsletter_subscribers')
        .delete()
        .eq('id', subscriberId);

      if (error) throw error;

      // Log the deletion
      await supabase
        .from('admin_audit_log')
        .insert([{
          action: 'delete_newsletter_subscriber',
          entity_type: 'newsletter_subscribers',
          entity_id: subscriberId,
          details: {
            deleted_at: new Date().toISOString()
          }
        }]);

      setSubscribers(prev => prev.filter(sub => sub.id !== subscriberId));
      setFilteredSubscribers(prev => prev.filter(sub => sub.id !== subscriberId));
    } catch (err) {
      console.error('Error deleting subscriber:', err);
      alert('Wystąpił błąd podczas usuwania subskrybenta.');
    } finally {
      setProcessingId(null);
    }
  };

  const handleExportCSV = () => {
    // Create CSV content with UTF-8 BOM for Excel compatibility
    const BOM = '\uFEFF';
    const headers = ['Email', 'Data dodania'];
    
    // Format rows with proper CSV escaping
    const rows = filteredSubscribers.map(subscriber => {
      const email = subscriber.email;
      const date = new Date(subscriber.created_at).toLocaleDateString();
      return [email, date];
    });
    
    // Use semicolons as separators for better Excel compatibility
    const csvContent = BOM + 
      headers.join(';') + '\n' + 
      rows.map(row => row.join(';')).join('\n');

    // Create and download the file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `newsletter-subscribers-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie subskrybentów...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Wystąpił błąd
          </h2>
          <p className="text-purple-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-purple-900">
          Newsletter
        </h1>
        <button
          onClick={handleExportCSV}
          className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
        >
          <Download className="w-5 h-5 mr-2" />
          Eksportuj do CSV
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
        <div className="grid md:grid-cols-2 gap-4">
          {/* Search */}
          <div className="relative">
            <input
              type="text"
              placeholder="Szukaj po adresie email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-purple-400" />
          </div>

          {/* Results Count */}
          <div className="flex items-center justify-end text-sm text-purple-600">
            Znaleziono: {filteredSubscribers.length} subskrybentów
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto" style={{ maxHeight: 'calc(100vh - 300px)' }}>
          <table className="w-full">
            <thead>
              <tr className="bg-purple-50">
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                  >
                    Email
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                  >
                    Data dodania
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-center">
                  <span className="text-sm font-medium text-purple-900">
                    Akcje
                  </span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-100">
              {filteredSubscribers.map((subscriber) => (
                <tr key={subscriber.id} className="hover:bg-purple-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <Mail className="w-5 h-5 text-purple-400 mr-2" />
                      <span className="text-purple-900">{subscriber.email}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <Calendar className="w-5 h-5 text-purple-400 mr-2" />
                      <span className="text-purple-700">
                        {new Date(subscriber.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex justify-center">
                      <button
                        onClick={() => handleDelete(subscriber.id)}
                        disabled={processingId === subscriber.id}
                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg"
                        title="Usuń"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="sticky bottom-0 w-full h-2 bg-gradient-to-t from-white to-transparent"></div>
        </div>
      </div>
    </div>
  );
}