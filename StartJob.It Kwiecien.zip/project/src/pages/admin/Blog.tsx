import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Loader2, AlertCircle, Plus, Pencil, Trash2, Search,
  ArrowUpDown, Calendar, User, BookOpen, CheckCircle2, Star, Tag,
  XCircle, X, ChevronRight, ChevronDown, FolderPlus, Folder
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

type BlogPost = {
  id: string;
  title: string;
  author_name: string;
  published_at: string;
  created_at: string;
  is_published: boolean;
  is_featured: boolean;
  category: {
    id: string;
    name: string;
  };
};

type Category = {
  id: string;
  name: string;
  parent_id?: string | null;
  code?: string;
};

type BlogTag = {
  id: string;
  name: string;
};

export default function AdminBlog() {
  const navigate = useNavigate();
  const [posts, setPosts] = useState<BlogPost[]>([]);
  const [filteredPosts, setFilteredPosts] = useState<BlogPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [showFeatured, setShowFeatured] = useState<boolean>(false);
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<BlogTag[]>([]);
  const [newCategoryName, setNewCategoryName] = useState<string>('');
  const [expandedCategories, setExpandedCategories] = useState<{[key: string]: boolean}>({});
  const [selectedTag, setSelectedTag] = useState<string>('');
  const [showCategoryManagement, setShowCategoryManagement] = useState<boolean>(false);
  const [showTagManagement, setShowTagManagement] = useState<boolean>(false);
  const [newSubcategoryName, setNewSubcategoryName] = useState<{[key: string]: string}>({});

  useEffect(() => {
    fetchPosts();
    fetchCategories();
    fetchTags();
  }, []);

  const fetchCategories = async () => {
    try {
      const { data: categoriesData, error } = await supabase
        .from('blog_taxonomies')
        .select('id, name, code')
        .eq('type', 'category')
        .order('name');

      if (error) throw error;
      setCategories(categoriesData || []);
    } catch (err) {
      console.error('Error fetching categories:', err);
    }
  };

  const fetchTags = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_taxonomies')
        .select('id, name')
        .eq('type', 'tag')
        .order('name');

      if (error) throw error;
      setTags(data || []);
    } catch (err) {
      console.error('Error fetching tags:', err);
    }
  };

  const fetchPosts = async () => {
    try {
      // Get all blog posts with their categories and tags
      const { data: posts, error } = await supabase
        .from('blog_posts')
        .select(`
          id,
          title,
          author_name,
          published_at,
          created_at,
          is_published,
          is_featured,
          category:category_id (
            id,
            name
          ),
          blog_post_tags (
            tag_id,
            tag:tag_id (
              id,
              name
            )
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      setPosts(posts || []);
      setFilteredPosts(posts || []);
    } catch (err) {
      console.error('Error fetching posts:', err);
      setError('Wystąpił błąd podczas ładowania wpisów.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    const timeout = setTimeout(() => {
      const filtered = posts.filter(post => {
        const searchLower = searchQuery.toLowerCase();
        const matchesSearch = (
          post.title.toLowerCase().includes(searchLower) ||
          post.blog_post_tags?.some(tag => tag.tag.name.toLowerCase().includes(searchLower)) ||
          post.author_name.toLowerCase().includes(searchLower) ||
          post.category?.name.toLowerCase().includes(searchLower)
        );
        
        const matchesTag = !selectedTag || post.blog_post_tags?.some(
          postTag => postTag.tag_id === selectedTag
        );
        
        const matchesCategory = !selectedCategory || post.category_id === selectedCategory;
        
        const matchesStatus = !selectedStatus || (
          (selectedStatus === 'published' && post.is_published) ||
          (selectedStatus === 'draft' && !post.is_published)
        );
        
        const matchesFeatured = !showFeatured || post.is_featured;

        return matchesSearch && matchesCategory && matchesTag && matchesStatus && matchesFeatured;
      });

      setFilteredPosts(filtered);
    }, 300);

    setSearchTimeout(timeout);

    return () => {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    };
  }, [posts, searchQuery, selectedCategory, selectedTag, selectedStatus, showFeatured]);

  const handleDelete = async (postId: string) => {
    if (!window.confirm('Czy na pewno chcesz usunąć ten wpis?')) {
      return;
    }

    try {
      setProcessingId(postId);
      const { error } = await supabase
        .from('blog_posts')
        .delete()
        .eq('id', postId);

      if (error) throw error;

      await supabase
        .from('admin_audit_log')
        .insert([{
          action: 'delete_blog_post',
          entity_type: 'blog_posts',
          entity_id: postId,
          details: {
            deleted_at: new Date().toISOString()
          }
        }]);

      setPosts(prevPosts => prevPosts.filter(post => post.id !== postId));
      setFilteredPosts(prevPosts => prevPosts.filter(post => post.id !== postId));
    } catch (err) {
      console.error('Error deleting post:', err);
      alert('Wystąpił błąd podczas usuwania wpisu.');
    } finally {
      setProcessingId(null);
    }
  };

  const handleAddCategory = async () => {
    if (!newCategoryName.trim()) {
      alert('Nazwa kategorii nie może być pusta.');
      return;
    }
    
    try {
      const { data, error } = await supabase
        .from('blog_taxonomies')
        .insert([{ 
          name: newCategoryName, 
          type: 'category',
          code: newCategoryName.toLowerCase().replace(/\s+/g, '-')
        }])
        .select()
        .single();

      if (error) throw error;
      
      setCategories([...categories, data]);
      setNewCategoryName('');
      
      await supabase
        .from('admin_audit_log')
        .insert([{
          action: 'create_blog_category',
          entity_type: 'blog_taxonomies',
          entity_id: data.id,
          details: {
            name: newCategoryName,
            type: 'category'
          }
        }]);
    } catch (err) {
      console.error('Error creating category:', err);
      alert('Wystąpił błąd podczas tworzenia kategorii.');
    }
  };

  const handleAddSubcategory = async (parentId: string) => {
    const subcategoryName = newSubcategoryName[parentId];
    if (!subcategoryName || !subcategoryName.trim()) {
      alert('Nazwa podkategorii nie może być pusta.');
      return;
    }
    
    alert('Funkcja dodawania podkategorii będzie dostępna po aktualizacji bazy danych.');
    
    setNewSubcategoryName(prev => ({
      ...prev,
      [parentId]: ''
    }));
  };

  const handleDeleteCategory = async (categoryId: string) => {
    try {
      const { count, error: countError } = await supabase
        .from('blog_posts')
        .select('*', { count: 'exact', head: true })
        .eq('category_id', categoryId);
        
      if (countError) throw countError;
      
      if (count && count > 0) {
        alert(`Nie można usunąć kategorii, ponieważ jest używana w ${count} postach.`);
        return;
      }
      
      if (window.confirm('Czy na pewno chcesz usunąć tę kategorię?')) {
        const { error } = await supabase
          .from('blog_taxonomies')
          .delete()
          .eq('id', categoryId);
          
        if (error) throw error;
        
        setCategories(categories.filter(cat => cat.id !== categoryId));
        
        await supabase
          .from('admin_audit_log')
          .insert([{
            action: 'delete_blog_category',
            entity_type: 'blog_taxonomies',
            entity_id: categoryId,
            details: {
              deleted_at: new Date().toISOString()
            }
          }]);
      }
    } catch (err) {
      console.error('Error deleting category:', err);
      alert('Wystąpił błąd podczas usuwania kategorii.');
    }
  };

  const handleUpdateCategory = async (category: Category, newName: string) => {
    if (!newName.trim()) {
      alert('Nazwa kategorii nie może być pusta.');
      return;
    }
    
    try {
      const { error } = await supabase
        .from('blog_taxonomies')
        .update({ 
          name: newName,
          code: category.code || newName.toLowerCase().replace(/\s+/g, '-')
        })
        .eq('id', category.id);

      if (error) throw error;
      
      setCategories(prev => prev.map(cat => 
        cat.id === category.id 
          ? { ...cat, name: newName } 
          : cat
      ));
      
      await supabase
        .from('admin_audit_log')
        .insert([{
          action: 'update_blog_category',
          entity_type: 'blog_taxonomies',
          entity_id: category.id,
          details: {
            old_name: category.name,
            new_name: newName,
            updated_at: new Date().toISOString()
          }
        }]);
    } catch (err) {
      console.error('Error updating category:', err);
      alert('Wystąpił błąd podczas aktualizacji kategorii.');
    }
  };

  const toggleCategory = (categoryId: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [categoryId]: !prev[categoryId]
    }));
  };

  const mainCategories = [...categories].sort((a, b) => a.name.localeCompare(b.name));
  
  const getSubcategories = (parentId: string) => {
    return [];
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie wpisów...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Wystąpił błąd
          </h2>
          <p className="text-purple-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-purple-900">
          Blog
        </h1>
        <button
          onClick={() => navigate('/admin/blog/add')}
          className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
        >
          <Plus className="w-5 h-5 mr-2" />
          Dodaj wpis
        </button>
      </div>

      <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
        <div className="grid md:grid-cols-5 gap-4">
          <div className="relative">
            <input
              type="text"
              placeholder="Szukaj..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-purple-400" />
          </div>

          <div>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            >
              <option value="">Wszystkie kategorie</option>
              {categories.map(category => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
          
          <div>
            <select
              value={selectedTag}
              onChange={(e) => setSelectedTag(e.target.value)}
              className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            >
              <option value="">Wszystkie tagi</option>
              {tags.map(tag => (
                <option key={tag.id} value={tag.id}>{tag.name}</option>
              ))}
            </select>
          </div>

          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            >
              <option value="">Wszystkie statusy</option>
              <option value="published">Opublikowane</option>
              <option value="draft">Szkice</option>
            </select>
          </div>

          <div>
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={showFeatured}
                onChange={(e) => setShowFeatured(e.target.checked)}
                className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
              />
              <span className="text-sm text-purple-900">Tylko wyróżnione</span>
            </label>
          </div>

          <div className="flex items-center justify-end text-sm text-purple-600">
            Znaleziono: {filteredPosts.length} wpisów
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto" style={{ maxHeight: 'calc(100vh - 300px)' }}>
          <table className="w-full">
            <thead>
              <tr className="bg-purple-50">
                <th className="px-6 py-4 text-left">
                  <button className="flex items-center text-sm font-medium text-purple-900">
                    Tytuł
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button className="flex items-center text-sm font-medium text-purple-900">
                    Autor
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="text-sm font-medium text-purple-900">
                    Kategoria
                  </span>
                </th>
                <th className="px-6 py-4 text-left">
                  <button className="flex items-center text-sm font-medium text-purple-900">
                    Data publikacji
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="text-sm font-medium text-purple-900">
                    Status
                  </span>
                </th>
                <th className="px-6 py-4 text-center">
                  <span className="text-sm font-medium text-purple-900">
                    Akcje
                  </span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-100">
              {filteredPosts.map((post) => (
                <tr key={post.id} className="hover:bg-purple-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-900">{post.title}</span>
                      {post.is_featured && (
                        <div className="w-5 h-5 flex items-center justify-center pl-1">
                          <Star className="w-4 h-4 text-yellow-500" />
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-700">{post.author_name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-700">{post.category?.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-700">
                        {post.published_at ? new Date(post.published_at).toLocaleDateString() : '-'}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {post.is_published ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        <CheckCircle2 className="w-4 h-4 mr-1" />
                        Opublikowany
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                        <XCircle className="w-4 h-4 mr-1" />
                        Szkic
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex justify-center space-x-2">
                      <button
                        onClick={() => navigate(`/admin/blog/${post.id}/edit`)}
                        className="p-2 text-purple-600 hover:bg-purple-100 rounded-lg"
                        title="Edytuj"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(post.id)}
                        disabled={processingId === post.id}
                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg"
                        title="Usuń"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="sticky bottom-0 w-full h-2 bg-gradient-to-t from-white to-transparent"></div>
        </div>
      </div>

      <div className="mt-8 bg-white rounded-xl shadow-lg overflow-hidden">
        <button 
          onClick={() => setShowCategoryManagement(!showCategoryManagement)}
          className="w-full p-6 text-left flex items-center justify-between bg-white hover:bg-purple-50 transition-colors"
        >
          <h2 className="text-xl font-bold text-purple-900">Zarządzanie kategoriami</h2>
          <ChevronDown 
            className={`w-6 h-6 text-purple-600 transition-transform duration-300 ${showCategoryManagement ? 'transform rotate-180' : ''}`} 
          />
        </button>
        
        {showCategoryManagement && (
          <div className="p-6 border-t border-purple-100">
            <div className="mb-8">
              <h3 className="text-md font-medium text-purple-900 mb-3">Dodaj nową kategorię</h3>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  placeholder="Nazwa nowej kategorii"
                  className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
                <button
                  type="button"
                  onClick={handleAddCategory}
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center"
                >
                  <FolderPlus className="w-5 h-5 mr-2" />
                  Dodaj
                </button>
              </div>
            </div>
            
            <div className="mb-8">
              <h3 className="text-md font-medium text-purple-900 mb-3">Lista kategorii</h3>
              
              <div className="space-y-3">
                {mainCategories.map(category => (
                  <div key={category.id} className="border border-purple-100 rounded-xl overflow-hidden">
                    <div className="bg-purple-50 p-4 flex items-center justify-between">
                      <div className="flex items-center flex-1">
                        <button
                          onClick={() => toggleCategory(category.id)}
                          className="text-purple-600 hover:text-purple-800 p-1 rounded mr-2"
                        >
                          {expandedCategories[category.id] ? (
                            <ChevronDown className="w-5 h-5" />
                          ) : (
                            <ChevronRight className="w-5 h-5" />
                          )}
                        </button>
                        
                        <div className="flex items-center flex-1">
                          <Folder className="w-5 h-5 text-purple-600 mr-2" />
                          <input
                            type="text"
                            value={category.name}
                            onChange={(e) => handleUpdateCategory(category, e.target.value)}
                            className="flex-1 px-3 py-1 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                          />
                        </div>
                      </div>
                      
                      <button
                        onClick={() => handleDeleteCategory(category.id)}
                        className="p-1 text-red-600 hover:bg-red-50 rounded-lg ml-2"
                        title="Usuń kategorię"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                    
                    <div className={`pl-10 pr-4 py-3 space-y-3 border-t border-purple-100 ${
                      expandedCategories[category.id] ? 'block' : 'hidden'
                    }`}>
                      <div className="flex items-center gap-2 mb-3">
                        <input
                          type="text"
                          value={newSubcategoryName[category.id] || ''}
                          onChange={(e) => setNewSubcategoryName(prev => ({
                            ...prev,
                            [category.id]: e.target.value
                          }))}
                          placeholder="Nazwa nowej podkategorii"
                          className="flex-1 px-3 py-1 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                        />
                        <button
                          onClick={() => handleAddSubcategory(category.id)}
                          className="p-1 text-purple-600 hover:bg-purple-100 rounded-lg"
                          title="Dodaj podkategorię"
                        >
                          <Plus className="w-5 h-5" />
                        </button>
                      </div>
                      
                      {getSubcategories(category.id).map((subcategory) => (
                        <div
                          key={subcategory.id}
                          className="flex items-center"
                        >
                          <input
                            type="text"
                            value={subcategory.name}
                            onChange={(e) => handleUpdateCategory(subcategory, e.target.value)}
                            className="flex-1 px-3 py-1 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                          />
                          <button
                            onClick={() => handleDeleteCategory(subcategory.id)}
                            className="p-1 text-red-600 hover:bg-red-50 rounded-lg ml-2"
                            title="Usuń podkategorię"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
      
      <div className="mt-8 bg-white rounded-xl shadow-lg overflow-hidden">
        <button 
          onClick={() => setShowTagManagement(!showTagManagement)}
          className="w-full p-6 text-left flex items-center justify-between bg-white hover:bg-purple-50 transition-colors"
        >
          <h2 className="text-xl font-bold text-purple-900">Zarządzanie tagami</h2>
          <ChevronDown 
            className={`w-6 h-6 text-purple-600 transition-transform duration-300 ${showTagManagement ? 'transform rotate-180' : ''}`} 
          />
        </button>
        
        {showTagManagement && (
          <div className="p-6 border-t border-purple-100">
            <div className="mb-8">
              <h3 className="text-md font-medium text-purple-900 mb-3">Dodaj nowy tag</h3>
              <div className="flex gap-2">
                <input
                  type="text"
                  id="newTagGlobal"
                  placeholder="Nazwa nowego tagu"
                  className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
                <button
                  type="button"
                  onClick={async () => {
                    const newTagName = (document.getElementById('newTagGlobal') as HTMLInputElement).value;
                    if (newTagName.trim()) {
                      try {
                        const { data, error } = await supabase
                          .from('blog_taxonomies')
                          .insert([{ name: newTagName, type: 'tag' }])
                          .select()
                          .single();
                          
                        if (error) throw error;
                        
                        setTags([...tags, data]);
                        
                        (document.getElementById('newTagGlobal') as HTMLInputElement).value = '';
                        
                        await supabase
                          .from('admin_audit_log')
                          .insert([{
                            action: 'create_blog_tag',
                            entity_type: 'blog_taxonomies',
                            entity_id: data.id,
                            details: {
                              name: newTagName,
                              type: 'tag'
                            }
                          }]);
                
                          
                        alert('Tag został dodany pomyślnie.');
                      } catch (err) {
                        console.error('Error creating tag:', err);
                        alert('Wystąpił błąd podczas tworzenia tagu.');
                      }
                    }
                  }}
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                </button>
              </div>
            </div>
            
            <div>
              <h3 className="text-md font-medium text-purple-900 mb-3">Istniejące tagi</h3>
              <div className="flex flex-wrap gap-3 p-2">
                {[...tags].sort((a, b) => a.name.localeCompare(b.name)).map(tag => (
                  <div key={tag.id} className="flex items-center bg-purple-100 text-purple-700 px-3 py-1 rounded-full">
                    <Tag className="w-4 h-4 mr-1" />
                    <span>{tag.name}</span>
                    <button
                      onClick={async () => {
                        if (window.confirm(`Czy na pewno chcesz usunąć tag "${tag.name}"?`)) {
                          try {
                            const { count, error: countError } = await supabase
                              .from('blog_post_tags')
                              .select('*', { count: 'exact', head: true })
                              .eq('tag_id', tag.id);
                              
                            if (countError) throw countError;
                            
                            if (count && count > 0) {
                              alert(`Nie można usunąć tagu "${tag.name}", ponieważ jest używany w ${count} postach.`);
                              return;
                            }
                            
                            const { error } = await supabase
                              .from('blog_taxonomies')
                              .delete()
                              .eq('id', tag.id);
                              
                            if (error) throw error;
                            
                            setTags(tags.filter(t => t.id !== tag.id));
                            
                            await supabase
                              .from('admin_audit_log')
                              .insert([{
                                action: 'delete_blog_tag',
                                entity_type: 'blog_taxonomies',
                                entity_id: tag.id,
                                details: {
                                  name: tag.name,
                                  type: 'tag'
                                }
                              }]);
                              
                            alert('Tag został usunięty pomyślnie.');
                          } catch (err) {
                            console.error('Error deleting tag:', err);
                            alert('Wystąpił błąd podczas usuwania tagu.');
                          }
                        }
                      }}
                      className="ml-2 text-purple-500 hover:text-purple-700"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}