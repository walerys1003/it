import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Briefcase, Mail, Lock, Loader2, AlertCircle } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { hasAdminAccess, isAdmin } from '../../lib/auth';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [checkingAuth, setCheckingAuth] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    try {
      const { data: sessionData } = await supabase.auth.getSession();
      
      if (sessionData?.session?.user) {
        const authorized = await hasAdminAccess();
        if (authorized) {
          navigate('/admin');
        }
      }
    } catch (error) {
      console.error('Error checking auth:', error);
    } finally {
      setCheckingAuth(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      // First attempt to sign in
      const { data, error: signInError } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (signInError) {
        if (signInError.message.includes('Invalid login credentials')) {
          throw new Error('Nieprawidłowy email lub hasło. Upewnij się, że podane dane są poprawne.');
        } else if (signInError.message.includes('Email not confirmed')) {
          throw new Error('Email nie został potwierdzony. Sprawdź swoją skrzynkę email.');
        } else if (signInError.message.includes('not found')) {
          throw new Error('Nie znaleziono konta o podanym adresie email. Sprawdź poprawność adresu email.');
        } else {
          throw new Error(signInError.message);
        }
      }

      if (!data?.user) {
        throw new Error('Wystąpił błąd podczas logowania. Spróbuj ponownie.');
      }

      // Check if user has admin access
      const { data: userData, error: userError } = await supabase
        .from('users')
        .select('role')
        .eq('user_id', data.user.id)
        .single();

      if (userError || !userData || !['admin', 'editor', 'moderator'].includes(userData.role)) {
          await supabase.auth.signOut();
          throw new Error('Brak uprawnień administratora. To konto nie ma dostępu do panelu administracyjnego.');
      }

      // Redirect to admin dashboard
      navigate('/admin');

    } catch (error) {
      console.error('Login error:', error);
      setError(error.message || 'Wystąpił nieznany błąd podczas logowania.');
      // Ensure we're signed out if there was an error
      await supabase.auth.signOut();
    } finally {
      setLoading(false);
    }
  };

  if (checkingAuth) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Sprawdzanie uprawnień...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center">
          <div className="bg-purple-100 rounded-full p-3">
            <Briefcase className="w-12 h-12 text-purple-600" />
          </div>
        </div>
        <h2 className="mt-6 text-center text-3xl font-bold text-purple-900">
          Panel administracyjny
        </h2>
        <p className="mt-2 text-center text-sm text-purple-600">
          Zaloguj się, aby uzyskać dostęp
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-xl sm:rounded-2xl sm:px-10">
          {error && (
            <div className="mb-4 p-4 bg-red-50 rounded-xl">
              <div className="flex">
                <AlertCircle className="w-5 h-5 text-red-400" />
                <div className="ml-3">
                  <p className="text-sm text-red-700">{error}</p>
                </div>
              </div>
            </div>
          )}

          <form className="space-y-6" onSubmit={handleSubmit}>
            <div>
              <label 
                htmlFor="email" 
                className="block text-sm font-medium text-purple-900"
              >
                Email
              </label>
              <div className="mt-1 relative">
                <input
                  id="email"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="appearance-none block w-full px-4 py-3 pl-12 border border-purple-200 rounded-xl shadow-sm placeholder-purple-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="twoj@email.com"
                />
                <Mail className="absolute left-4 top-3.5 h-5 w-5 text-purple-400" />
              </div>
            </div>

            <div>
              <label
                htmlFor="password"
                className="block text-sm font-medium text-purple-900"
              >
                Hasło
              </label>
              <div className="mt-1 relative">
                <input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="appearance-none block w-full px-4 py-3 pl-12 border border-purple-200 rounded-xl shadow-sm placeholder-purple-400 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="••••••••"
                />
                <Lock className="absolute left-4 top-3.5 h-5 w-5 text-purple-400" />
              </div>
            </div>

            <div>
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center items-center py-3 px-4 border border-transparent rounded-xl shadow-sm text-sm font-medium text-white bg-purple-600 hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <Loader2 className="animate-spin -ml-1 mr-2 h-5 w-5" />
                    Logowanie...
                  </>
                ) : (
                  'Zaloguj się'
                )}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
