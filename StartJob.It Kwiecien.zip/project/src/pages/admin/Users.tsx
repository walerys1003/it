import React, { useState, useEffect } from 'react';
import { 
  Loader2, AlertCircle, Search, ArrowUpDown, 
  UserCircle, Mail, Shield, Plus, Pencil, Trash2,
  ShieldOff, X, Lock, RefreshCw, CheckCircle2
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useNavigate } from 'react-router-dom';
import { isAdmin, getUserRole } from '../../lib/auth';

type User = {
  id: string;
  email: string;
  role: string;
  created_at: string;
  user_metadata: any;
};

export default function Users() {
  const [users, setUsers] = useState<User[]>([]);
  const [filteredUsers, setFilteredUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);
  const [showAddUserModal, setShowAddUserModal] = useState(false);
  const [newUser, setNewUser] = useState({
    email: '',
    password: '',
    name: '',
    role: 'moderator'
  });
  const [addingUser, setAddingUser] = useState(false);
  const [addUserError, setAddUserError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    checkAuthorization();
  }, []);

  const checkAuthorization = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();

      if (!session) {
        setIsAuthorized(false);
        setError('Nie jesteś zalogowany. Zaloguj się, aby kontynuować.');
        navigate('/admin/login');
        return;
      }

      // Check if user has admin role using the helper function
      const userIsAdmin = await isAdmin();

      if (!userIsAdmin) {
        setIsAuthorized(false);
        setError('Nie masz uprawnień do przeglądania tej strony.');
        return;
      }

      setIsAuthorized(true);
      await fetchUsers();
    } catch (err) {
      console.error('Error checking authorization:', err);
      setIsAuthorized(false);
      setError('Wystąpił błąd podczas weryfikacji uprawnień.');
    }
  };

  const fetchUsers = async () => {
    try {
      setLoading(true);

      // Get users from our users table
      const { data, error } = await supabase
        .from('users')
        .select('*');

      if (error) throw error;

      // Get auth user details
      const { data: authUsers, error: authError } = await supabase
        .rpc('get_all_auth_users');

      if (authError) throw authError;

      // Map users with auth data
      const transformedUsers = (data || []).map(user => {
        const authUser = authUsers?.find(au => au.id === user.user_id);
        return {
          id: user.user_id,
          email: authUser?.email || 'Unknown',
          role: user.role,
          created_at: authUser?.created_at || user.created_at,
          user_metadata: authUser?.raw_user_meta_data || {}
        };
      });

      setUsers(transformedUsers || []);
      setFilteredUsers(transformedUsers || []);
    } catch (err: any) {
      console.error('Error fetching users:', err);
      setError(err.message || 'Wystąpił błąd podczas ładowania użytkowników.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    const timeout = setTimeout(() => {
      const filtered = users.filter(user => {
        const matchesSearch = searchQuery === '' ||
          user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
          user.role.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (user.user_metadata?.name || '').toLowerCase().includes(searchQuery.toLowerCase());

        return matchesSearch;
      });

      setFilteredUsers(filtered || []);
    }, 300);

    setSearchTimeout(timeout);

    return () => {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    };
  }, [users, searchQuery]);

  const handleDelete = async (userId: string) => {
    if (!confirm('Czy na pewno chcesz usunąć tego użytkownika?')) return;
  
    try {
      setProcessingId(userId);
  
      // 1) Wywołanie RPC i debug
      const { data, error } = await supabase
        .rpc('delete_user_by_id', { p_user_id: userId });
      console.log('[delete_user_by_id]', { data, error });
  
      // 2) Rzucaj konkretny Error, nie cały obiekt
      if (error) throw new Error(error.message);
  
      // 3) Sprawdź zwrotkę
      if (data !== true) {
        throw new Error('Procedura zwróciła false – nie udało się usunąć użytkownika');
      }
  
      // 4) Aktualizacja stanu
      setUsers(prev => prev.filter(u => u.id !== userId));
      setFilteredUsers(prev => prev.filter(u => u.id !== userId));
      alert('Użytkownik został usunięty pomyślnie');
    } catch (err) {
      console.error('Error deleting user:', err);
      const msg = err instanceof Error
        ? err.message
        : (err as any).message || JSON.stringify(err);
      alert('Wystąpił błąd podczas usuwania użytkownika: ' + msg);
    } finally {
      setProcessingId(null);
    }
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddingUser(true);
    setAddUserError(null);
    
    try {
      // Validate inputs
      if (!newUser.email || !newUser.password || !newUser.name) {
        throw new Error('Wszystkie pola są wymagane');
      }
      
      if (newUser.password.length < 6) {
        throw new Error('Hasło musi mieć co najmniej 6 znaków');
      }
      
      // Create user in auth.users
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: newUser.email,
        password: newUser.password,
        options: {
          data: {
            name: newUser.name
          }
        }
      });
      
      if (authError) throw authError;
      
      if (!authData.user) {
        throw new Error('Nie udało się utworzyć użytkownika');
      }
      
      // Add user to users table with role
      const { error: roleError } = await supabase
        .from('users')
        .insert([{
          user_id: authData.user.id,
          role: newUser.role
        }]);
        
      if (roleError) throw roleError;
      
      // Reset form and close modal
      setNewUser({
        email: '',
        password: '',
        name: '',
        role: 'moderator'
      });
      setShowAddUserModal(false);
      
      // Refresh user list
      await fetchUsers();
      
      alert('Użytkownik został dodany pomyślnie');
    } catch (err) {
      console.error('Error adding user:', err);
      setAddUserError(err.message || 'Wystąpił błąd podczas dodawania użytkownika');
    } finally {
      setAddingUser(false);
    }
  };

  const getRoleBadge = (role: string) => {
    switch (role) {
      case 'admin':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800">
            <Shield className="w-3 h-3 mr-1" />
            Administrator
          </span>
        );
      case 'moderator':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <Shield className="w-3 h-3 mr-1" />
            Moderator
          </span>
        );
      case 'editor':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <Pencil className="w-3 h-3 mr-1" />
            Redaktor
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
            <UserCircle className="w-3 h-3 mr-1" />
            {role || 'Użytkownik'}
          </span>
        );
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie...</p>
        </div>
      </div>
    );
  }

  if (!isAuthorized) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <ShieldOff className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Brak dostępu
          </h2>
          <p className="text-purple-600">
            Nie masz uprawnień do przeglądania tej strony.
          </p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Wystąpił błąd
          </h2>
          <p className="text-purple-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-purple-900">
          Użytkownicy systemu
        </h1>
        <button
          onClick={() => setShowAddUserModal(true)}
          className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
        >
          <Plus className="w-5 h-5 mr-2" />
          Dodaj użytkownika
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
        <div className="grid md:grid-cols-2 gap-4">
          {/* Search */}
          <div className="relative">
            <input
              type="text"
              placeholder="Szukaj użytkownika..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-purple-400" />
          </div>

          {/* Results Count */}
          <div className="flex items-center justify-end text-sm text-purple-600">
            Znaleziono: {filteredUsers.length} użytkowników
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto" style={{ maxHeight: 'calc(100vh - 300px)' }}>
          <table className="w-full">
            <thead>
              <tr className="bg-purple-50">
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                  >
                    Nazwa użytkownika
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                    onClick={() => {
                      const sorted = [...filteredUsers].sort((a, b) => 
                        a.email.localeCompare(b.email)
                      );
                      setFilteredUsers(sorted);
                    }}
                  >
                    Email
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                    onClick={() => {
                      const sorted = [...filteredUsers].sort((a, b) => 
                        a.created_at.localeCompare(b.created_at)
                      );
                      setFilteredUsers(sorted);
                    }}
                  >
                    Data utworzenia
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-center">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                    onClick={() => {
                      const sorted = [...filteredUsers].sort((a, b) => 
                        a.role.localeCompare(b.role)
                      );
                      setFilteredUsers(sorted);
                    }}
                  >
                    Rola
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-center">
                  <span className="text-sm font-medium text-purple-900">
                    Akcje
                  </span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-100">
              {filteredUsers.map((user) => (
                <tr key={user.id} className="hover:bg-purple-50">
                  <td className="px-6 py-4">
                    <div className="flex items-start">
                      <UserCircle className="w-5 h-5 text-purple-400 mr-2 mt-0.5" />
                      <div>
                        <span className="text-purple-900">{user.user_metadata?.name || user.email.split('@')[0] || 'Użytkownik'}</span>
                        {user.id && (
                          <span className="block text-xs text-purple-500">{user.id.substring(0, 8)}...</span>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <Mail className="w-5 h-5 text-purple-400 mr-2" />
                      <span className="text-purple-700">{user.email}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-purple-700">
                      {new Date(user.created_at).toLocaleDateString()}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center justify-center">
                      {getRoleBadge(user.role)}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex justify-center space-x-2">
                      <button
                        onClick={() => alert('Funkcja edycji użytkowników będzie dostępna wkrótce')}
                        className="p-2 text-purple-600 hover:bg-purple-100 rounded-lg"
                        title="Edytuj"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(user.id)}
                        disabled={processingId === user.id || user.role === 'admin'}
                        className={`p-2 ${processingId === user.id ? 'cursor-wait ' : ''}${
                          user.role === 'admin' 
                            ? 'text-gray-400 cursor-not-allowed' 
                            : 'text-red-600 hover:bg-red-100'
                        } rounded-lg`}
                        title={user.role === 'admin' ? 'Nie można usunąć administratora' : 'Usuń'}
                      >
                        {processingId === user.id ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Trash2 className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="sticky bottom-0 w-full h-2 bg-gradient-to-t from-white to-transparent"></div>
        </div>
      </div>
      
      {/* Add User Modal */}
      {showAddUserModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-bold text-purple-900">Dodaj użytkownika</h2>
              <button
                onClick={() => setShowAddUserModal(false)}
                className="p-2 text-purple-600 hover:bg-purple-100 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            {addUserError && (
              <div className="mb-4 p-4 bg-red-50 rounded-xl">
                <div className="flex items-center">
                  <AlertCircle className="w-5 h-5 text-red-400 mr-2" />
                  <p className="text-sm text-red-700">{addUserError}</p>
                </div>
              </div>
            )}
            
            <form onSubmit={handleAddUser} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Email
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3 h-5 w-5 text-purple-400" />
                  <input
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                    className="w-full pl-10 px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="email@example.com"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Hasło
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3 h-5 w-5 text-purple-400" />
                  <input
                    type="password"
                    value={newUser.password}
                    onChange={(e) => setNewUser({...newUser, password: e.target.value})}
                    className="w-full pl-10 px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="Minimum 6 znaków"
                    required
                    minLength={6}
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Imię i nazwisko
                </label>
                <div className="relative">
                  <UserCircle className="absolute left-3 top-3 h-5 w-5 text-purple-400" />
                  <input
                    type="text"
                    value={newUser.name}
                    onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                    className="w-full pl-10 px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="Jan Kowalski"
                    required
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Rola
                </label>
                <select
                  value={newUser.role}
                  onChange={(e) => setNewUser({...newUser, role: e.target.value})}
                  className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  required
                >
                  <option value="admin">Administrator</option>
                  <option value="moderator">Moderator</option>
                  <option value="editor">Redaktor</option>
                </select>
              </div>
              
              <div className="flex justify-end space-x-4 pt-4">
                <button
                  type="button"
                  onClick={() => setShowAddUserModal(false)}
                  className="px-4 py-2 border border-purple-200 text-purple-700 rounded-lg hover:bg-purple-50 transition-colors"
                >
                  Anuluj
                </button>
                <button
                  type="submit"
                  disabled={addingUser}
                  className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors flex items-center"
                >
                  {addingUser ? (
                    <>
                      <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                      Dodawanie...
                    </>
                  ) : (
                    <>
                      <Plus className="w-5 h-5 mr-2" />
                      Dodaj użytkownika
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}