import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { jobPostingSchema } from '../../schemas/jobPostingSchema';
import { Plus, X, Star, Code, Check, Building2, Mail, Phone, Loader2, AlertCircle, Info, Crown, Briefcase, Image, Upload } from 'lucide-react';
import {
  jobCategories,
  technologies,
  workModes,
  experienceLevels,
  contractTypes,
  benefits,
  languages,
  locations
} from '../../data/jobPostingData';
import { supabase } from '../../lib/supabase';
import { uploadCompanyLogo } from '../../lib/fileStorage';

export default function AddJob() {
  const navigate = useNavigate();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState<string | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { register, control, handleSubmit, watch, formState: { errors }, setValue } = useForm({
    resolver: zodResolver(jobPostingSchema),
    defaultValues: {
      title: '',
      category: '',
      description: '',
      responsibilities: [''],
      requirements: [''],
      niceToHave: [''],
      technologies: [],
      workMode: undefined,
      experienceLevel: undefined,
      contractType: undefined,
      salaryFrom: undefined,
      salaryTo: undefined,
      currency: 'PLN',
      benefits: [],
      location: {
        country: '',
        voivodeship: '',
        city: ''
      },
      languages: [{ language: '', level: '' }],
      company: {
        name: '',
        description: '',
        size: '',
        logo: ''
      },
      contact: {
        name: '',
        position: '',
        email: '',
        phone: ''
      },
      packageType: 'standard'
    }
  });

  const {
    fields: responsibilitiesFields,
    append: appendResponsibility,
    remove: removeResponsibility
  } = useFieldArray({
    control,
    name: "responsibilities"
  });

  const {
    fields: requirementsFields,
    append: appendRequirement,
    remove: removeRequirement
  } = useFieldArray({
    control,
    name: "requirements"
  });

  const {
    fields: niceToHaveFields,
    append: appendNiceToHave,
    remove: removeNiceToHave
  } = useFieldArray({
    control,
    name: "niceToHave"
  });

  const {
    fields: languagesFields,
    append: appendLanguage,
    remove: removeLanguage
  } = useFieldArray({
    control,
    name: "languages"
  });

  const onSubmit = async (data) => {
    setIsSubmitting(true);
    setError(null);

    let logoUrl = data.company.logo;
    
    try {
      // Handle logo file upload if present
      if (logoFile) {
        try {
          // Generate a unique ID for the file
          const fileId = crypto.randomUUID();
          logoUrl = await uploadCompanyLogo(logoFile, fileId);
        } catch (uploadError) {
          console.error('Error uploading logo:', uploadError);
          throw new Error('Failed to upload company logo. Please try again.');
        }
      }
      
      // Calculate valid_until date (60 or 90 days from now)
      const validUntil = new Date();
      validUntil.setDate(validUntil.getDate() + (data.packageType === 'premium' ? 90 : 60));

      // Transform languages array to match database format
      const transformedLanguages = data.languages.map(lang => ({
        language: lang.language,
        level: lang.level
      }));

      // Prepare job data
      const jobData = {
        title: data.title,
        category: data.category,
        description: data.description,
        responsibilities: data.responsibilities,
        requirements: data.requirements,
        nice_to_have: data.niceToHave,
        technologies: data.technologies,
        work_mode: data.workMode,
        experience_level: data.experienceLevel,
        contract_type: data.contractType,
        salary_from: data.salaryFrom,
        salary_to: data.salaryTo,
        currency: data.currency,
        benefits: data.benefits || [],
        location_country: data.location.country,
        location_voivodeship: data.location.voivodeship,
        location_city: data.location.city,
        languages: transformedLanguages,
        company_name: data.company.name,
        company_description: data.company.description,
        company_size: data.company.size,
        company_logo: logoUrl,
        contact_name: data.contact.name,
        contact_position: data.contact.position,
        contact_email: data.contact.email,
        contact_phone: data.contact.phone,
        valid_until: validUntil.toISOString(),
        is_premium: data.packageType === 'premium',
        is_featured: data.packageType === 'premium',
        is_active: true,
        views_count: 0,
        applications_count: 0
      };

      // Insert job into database
      const { data: job, error: jobError } = await supabase
        .from('jobs')
        .insert([jobData])
        .select()
        .single();

      if (jobError) throw jobError;

      // Log the action in admin audit log
      await supabase
        .from('admin_audit_log')
        .insert([{
          action: 'create_job',
          entity_type: 'jobs',
          entity_id: job.id,
          details: {
            title: job.title,
            company: job.company_name,
            package_type: data.packageType
          }
        }])
        .throwOnError();

      // Navigate to jobs list
      navigate('/admin/jobs');
    } catch (error) {
      console.error('Error creating job:', error);
      setError('Wystąpił błąd podczas dodawania ogłoszenia.');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    handleFile(file);
  };
  
  // Process the selected file
  const handleFile = (file: File | undefined) => {
    if (!file) return;
    
    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/svg+xml'];
    if (!validTypes.includes(file.type)) {
      setFileError('Dozwolone formaty plików: JPG, PNG, GIF, SVG');
      return;
    }
    
    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      setFileError('Maksymalny rozmiar pliku to 2MB');
      return;
    }
    
    // Clear any previous errors
    setFileError(null);
    
    // Create a preview URL
    const objectUrl = URL.createObjectURL(file);
    setLogoPreview(objectUrl);
    setLogoFile(file);
    
    // Store the file in the form
    setValue('company.logo', file);
  };
  
  // Remove the selected file
  const handleRemoveFile = () => {
    setValue('company.logo', '');
    setLogoPreview(null);
    setLogoFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-purple-900">
            Dodaj nowe ogłoszenie
          </h1>
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-50 rounded-xl">
            <div className="flex items-center">
              <AlertCircle className="w-5 h-5 text-red-400 mr-2" />
              <p className="text-red-700">{error}</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
          {/* Error Messages */}
          <div className="mt-6">
            {Object.keys(errors).length > 0 && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-4">
                <div className="flex items-center mb-2">
                  <Info className="w-5 h-5 text-red-500 mr-2" />
                  <h4 className="font-medium text-red-700">
                    Formularz zawiera błędy
                  </h4>
                </div>
                <ul className="space-y-1 text-sm text-red-600">
                  {errors.contact?.name && (
                    <li>• Imię i nazwisko: {errors.contact.name.message}</li>
                  )}
                  {errors.contact?.position && (
                    <li>• Stanowisko: {errors.contact.position.message}</li>
                  )}
                  {errors.contact?.email && (
                    <li>• Email: {errors.contact.email.message}</li>
                  )}
                  {errors.contact?.phone && (
                    <li>• Telefon: {errors.contact.phone.message}</li>
                  )}
                  {errors.packageType && (
                    <li>• {errors.packageType.message}</li>
                  )}
                  {Object.keys(errors).filter(key => !key.startsWith('contact')).map((key) => (
                    <li key={key}>• {errors[key].message}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Basic Information */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Podstawowe informacje
            </h2>
            
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Stanowisko
                {errors.title && (
                  <span className="text-sm text-red-600 ml-2">
                    {errors.title.message}
                  </span>
                )}
              </label>
              <input
                type="text"
                {...register("title")}
                className={`w-full px-4 py-3 rounded-xl border ${
                  errors.title 
                    ? 'border-red-300 focus:ring-red-500 focus:border-red-500' 
                    : 'border-purple-200 focus:ring-purple-500 focus:border-purple-500'
                }`}
                placeholder="np. Senior React Developer (min. 10 znaków)"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Kategoria
                {errors.category && (
                  <span className="text-sm text-red-600 ml-2">
                    {errors.category.message}
                  </span>
                )}
              </label>
              <select
                {...register("category")}
                className={`w-full px-4 py-3 rounded-xl border ${
                  errors.category 
                    ? 'border-red-300 focus:ring-red-500 focus:border-red-500' 
                    : 'border-purple-200 focus:ring-purple-500 focus:border-purple-500'
                }`}
              >
                <option value="">Wybierz kategorię</option>
                {Object.entries(jobCategories).map(([category, subcategories]) => (
                  <optgroup key={category} label={category}>
                    {subcategories.map((subcat) => (
                      <option key={subcat} value={subcat}>{subcat}</option>
                    ))}
                  </optgroup>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Opis stanowiska
                {errors.description && (
                  <span className="text-sm text-red-600 ml-2">
                    {errors.description.message}
                  </span>
                )}
              </label>
              <textarea
                {...register("description")}
                rows={6}
                className={`w-full px-4 py-3 rounded-xl border ${
                  errors.description 
                    ? 'border-red-300 focus:ring-red-500 focus:border-red-500' 
                    : 'border-purple-200 focus:ring-purple-500 focus:border-purple-500'
                }`}
                placeholder="Opisz szczegółowo stanowisko, zakres obowiązków i wymagania... (min. 100 znaków)"
              />
            </div>
          </div>

          {/* Requirements and Responsibilities */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Wymagania i obowiązki
            </h2>

            {/* Responsibilities */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Zakres obowiązków
                {errors.responsibilities && (
                  <span className="text-sm text-red-600 ml-2">
                    {errors.responsibilities.message}
                  </span>
                )}
              </label>
              <div className="space-y-3">
                {responsibilitiesFields.map((field, index) => (
                  <div key={field.id} className="flex gap-2">
                    <input
                      {...register(`responsibilities.${index}`)}
                      className={`flex-1 px-4 py-3 rounded-xl border ${
                        errors.responsibilities 
                          ? 'border-red-300 focus:ring-red-500 focus:border-red-500' 
                          : 'border-purple-200 focus:ring-purple-500 focus:border-purple-500'
                      }`}
                      placeholder="np. Rozwój aplikacji w React.js"
                    />
                    <button
                      type="button"
                      onClick={() => removeResponsibility(index)}
                      className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => appendResponsibility('')}
                  className="flex items-center text-purple-600 hover:text-purple-700"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Dodaj obowiązek
                </button>
              </div>
            </div>

            {/* Requirements */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Wymagania
                {errors.requirements && (
                  <span className="text-sm text-red-600 ml-2">
                    {errors.requirements.message}
                  </span>
                )}
              </label>
              <div className="space-y-3">
                {requirementsFields.map((field, index) => (
                  <div key={field.id} className="flex gap-2">
                    <input
                      {...register(`requirements.${index}`)}
                      className={`flex-1 px-4 py-3 rounded-xl border ${
                        errors.requirements 
                          ? 'border-red-300 focus:ring-red-500 focus:border-red-500' 
                          : 'border-purple-200 focus:ring-purple-500 focus:border-purple-500'
                      }`}
                      placeholder="np. Min. 3 lata doświadczenia w React.js"
                    />
                    <button
                      type="button"
                      onClick={() => removeRequirement(index)}
                      className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => appendRequirement('')}
                  className="flex items-center text-purple-600 hover:text-purple-700"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Dodaj wymaganie
                </button>
              </div>
            </div>

            {/* Nice to Have */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Mile widziane
              </label>
              <div className="space-y-3">
                {niceToHaveFields.map((field, index) => (
                  <div key={field.id} className="flex gap-2">
                    <input
                      {...register(`niceToHave.${index}`)}
                      className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder="np. Znajomość TypeScript"
                    />
                    <button
                      type="button"
                      onClick={() => removeNiceToHave(index)}
                      className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => appendNiceToHave('')}
                  className="flex items-center text-purple-600 hover:text-purple-700"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Dodaj mile widziane
                </button>
              </div>
            </div>
          </div>

          {/* Technologies */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Technologie
            </h2>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Wymagane technologie
              </label>
              <div className="space-y-5">
                {Object.entries(technologies).map(([category, techs]) => (
                  <div key={category} className="space-y-2">
                    <h3 className="text-sm font-medium text-purple-700">{category}</h3>
                    <div className="flex flex-wrap gap-2">
                      {techs.map((tech) => (
                        <label
                          key={tech}
                          className="inline-flex items-center px-4 py-2 rounded-xl border border-purple-200 hover:bg-purple-50 cursor-pointer"
                        >
                          <input
                            type="checkbox"
                            {...register('technologies')}
                            value={tech}
                            className="mr-2 rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                          />
                          {tech}
                        </label>
                      ))}
                    </div>
                  </div>
                ))}
                {errors.technologies && (
                  <p className="mt-1 text-sm text-red-600">{errors.technologies.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Languages */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Wymagane języki
            </h2>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Wymagane języki
                {errors.languages && (
                  <span className="text-sm text-red-600 ml-2">
                    {errors.languages.message}
                  </span>
                )}
              </label>
              <div className="space-y-3">
                {languagesFields.map((field, index) => (
                  <div key={field.id} className="flex gap-4">
                    <select
                      {...register(`languages.${index}.language`)}
                      className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value="">Wybierz język</option>
                      {languages.map((lang) => (
                        <option key={lang.value} value={lang.value}>
                          {lang.label}
                        </option>
                      ))}
                    </select>
                    <select
                      {...register(`languages.${index}.level`)}
                      className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value="">Poziom</option>
                      <option value="A1">A1 - Początkujący</option>
                      <option value="A2">A2 - Podstawowy</option>
                      <option value="B1">B1 - Średniozaawansowany</option>
                      <option value="B2">B2 - Wyższy średniozaawansowany</option>
                      <option value="C1">C1 - Zaawansowany</option>
                      <option value="C2">C2 - Biegły</option>
                      <option value="native">Ojczysty</option>
                    </select>
                    <button
                      type="button"
                      onClick={() => removeLanguage(index)}
                      className="p-3 text-red-500 hover:bg-red-50 rounded-xl"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => appendLanguage({ language: '', level: '' })}
                  className="flex items-center text-purple-600 hover:text-purple-700"
                >
                  <Plus className="w-5 h-5 mr-2" />
                  Dodaj język
                </button>
              </div>
              {errors.languages && (
                <p className="mt-1 text-sm text-red-600">{errors.languages.message}</p>
              )}
            </div>
          </div>

          {/* Employment Details */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Warunki zatrudnienia
            </h2>

            {/* Work Mode */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Tryb pracy
              </label>
              <div className="grid grid-cols-3 gap-4">
                {workModes.map((mode) => (
                  <label
                    key={mode.value}
                    className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
                  >
                    <input
                      type="radio"
                      {...register('workMode')}
                      value={mode.value}
                      className="mr-3 text-purple-600 focus:ring-purple-500"
                    />
                    {mode.label}
                  </label>
                ))}
              </div>
              {errors.workMode && (
                <p className="mt-1 text-sm text-red-600">{errors.workMode.message}</p>
              )}
            </div>

            {/* Experience Level */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Poziom doświadczenia
              </label>
              <div className="grid grid-cols-2 gap-4">
                {experienceLevels.map((level) => (
                  <label
                    key={level.value}
                    className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
                  >
                    <input
                      type="radio"
                      {...register('experienceLevel')}
                      value={level.value}
                      className="mr-3 text-purple-600 focus:ring-purple-500"
                    />
                    {level.label}
                  </label>
                ))}
              </div>
              {errors.experienceLevel && (
                <p className="mt-1 text-sm text-red-600">{errors.experienceLevel.message}</p>
              )}
            </div>

            {/* Contract Type */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Typ umowy
              </label>
              <div className="grid grid-cols-2 gap-4">
                {contractTypes.map((type) => (
                  <label
                    key={type.value}
                    className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
                  >
                    <input
                      type="radio"
                      {...register('contractType')}
                      value={type.value}
                      className="mr-3 text-purple-600 focus:ring-purple-500"
                    />
                    {type.label}
                  </label>
                ))}
              </div>
              {errors.contractType && (
                <p className="mt-1 text-sm text-red-600">{errors.contractType.message}</p>
              )}
            </div>

            {/* Salary Range */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Wynagrodzenie (PLN netto/msc)
              </label>
              <div className="flex gap-4 items-center">
                <input
                  type="number"
                  {...register('salaryFrom', { valueAsNumber: true })}
                  className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Od"
                />
                <span className="text-purple-600">-</span>
                <input
                  type="number"
                  {...register('salaryTo', { valueAsNumber: true })}
                  className="flex-1 px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Do"
                />
              </div>
              {(errors.salaryFrom || errors.salaryTo) && (
                <p className="mt-1 text-sm text-red-600">
                  {errors.salaryFrom?.message || errors.salaryTo?.message}
                </p>
              )}
            </div>

            {/* Benefits */}
            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Benefity
              </label>
              <div className="grid grid-cols-2 gap-4">
                {benefits.map((benefit) => (
                  <label
                    key={benefit.value}
                    className="flex items-center p-4 border border-purple-200 rounded-xl hover:bg-purple-50 cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      {...register('benefits')}
                      value={benefit.value}
                      className="mr-3 rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                    />
                    {benefit.label}
                  </label>
                ))}
              </div>
            </div>
          </div>

          {/* Location */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Lokalizacja
            </h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Kraj
                </label>
                <select
                  {...register('location.country')}
                  className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                  <option value="">Wybierz kraj</option>
                  {locations.countries.map((country) => (
                    <option key={country.value} value={country.value}>
                      {country.label}
                    </option>
                  ))}
                </select>
                {errors.location?.country && (
                  <p className="mt-1 text-sm text-red-600">{errors.location.country.message}</p>
                )}
              </div>

              {watch('location.country') === 'pl' && (
                <div>
                  <label className="block text-sm font-medium text-purple-900 mb-2">
                    Województwo
                  </label>
                  <select
                    {...register('location.voivodeship')}
                    className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  >
                    <option value="">Wybierz województwo</option>
                    {locations.voivodeships.map((voivodeship) => (
                      <option key={voivodeship.value} value={voivodeship.value}>
                        {voivodeship.label}
                      </option>
                    ))}
                  </select>
                  {errors.location?.voivodeship && (
                    <p className="mt-1 text-sm text-red-600">{errors.location.voivodeship.message}</p>
                  )}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Miasto
                </label>
                <input
                  type="text"
                  {...register('location.city')}
                  className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Wpisz nazwę miasta"
                />
                {errors.location?.city && (
                  <p className="mt-1 text-sm text-red-600">{errors.location.city.message}</p>
                )}
              </div>
            </div>
          </div>

          {/* Company Information */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Informacje o firmie
            </h2>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Nazwa firmy
              </label>
              <input
                type="text"
                {...register('company.name')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. TechCorp Solutions"
              />
              {errors.company?.name && (
                <p className="mt-1 text-sm text-red-600">{errors.company.name.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Opis firmy
              </label>
              <textarea
                {...register('company.description')}
                rows={4}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="Krótki opis działalności firmy..."
              />
              {errors.company?.description && (
                <p className="mt-1 text-sm text-red-600">{errors.company.description.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Wielkość firmy
              </label>
              <select
                {...register('company.size')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              >
                <option value="">Wybierz wielkość</option>
                <option value="1-10">1-10 pracowników</option>
                <option value="11-50">11-50 pracowników</option>
                <option value="51-200">51-200 pracowników</option>
                <option value="201-500">201-500 pracowników</option>
                <option value="501-1000">501-1000 pracowników</option>
                <option value="1000+">1000+ pracowników</option>
              </select>
              {errors.company?.size && (
                <p className="mt-1 text-sm text-red-600">{errors.company.size.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Logo firmy (JPG, PNG, GIF, SVG)
              </label>
              <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-dashed rounded-xl border-purple-200 hover:border-purple-400 transition-colors">
                {logoPreview ? (
                  <div className="space-y-4 w-full flex flex-col items-center">
                    <div className="relative w-40 h-40">
                      <img 
                        src={logoPreview} 
                        alt="Logo podgląd" 
                        className="w-full h-full object-contain"
                      />
                      <button
                        type="button"
                        onClick={handleRemoveFile}
                        className="absolute -top-2 -right-2 bg-red-100 text-red-600 rounded-full p-1 hover:bg-red-200"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                    <p className="text-sm text-purple-600">
                      {logoFile?.name}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-1 text-center">
                    <div className="flex flex-col items-center">
                      <Image className="mx-auto h-12 w-12 text-purple-400" />
                      <div className="flex text-sm text-purple-600 mt-2">
                        <label
                          htmlFor="company-logo-upload"
                          className="relative cursor-pointer bg-white rounded-md font-medium text-purple-600 hover:text-purple-500 focus-within:outline-none"
                        >
                          <span>Przeciągnij i upuść plik lub</span>
                          <span className="ml-1 text-purple-500 hover:text-purple-700"> przeglądaj</span>
                          <input
                            id="company-logo-upload"
                            name="company-logo-upload"
                            type="file"
                            className="sr-only"
                            accept="image/*"
                            onChange={handleFileChange}
                            ref={fileInputRef}
                          />
                        </label>
                      </div>
                      <p className="text-xs text-purple-500 mt-1">
                        PNG, JPG, GIF do 2MB
                      </p>
                    </div>
                  </div>
                )}
              </div>
              
              {/* Register the logo field for validation */}
              <input
                type="hidden"
                {...register('company.logo')}
              />
              
              {/* Error messages */}
              {(errors.company?.logo || fileError) && (
                <p className="mt-2 text-sm text-red-600">
                  {errors.company?.logo?.message || fileError}
                </p>
              )}
            </div>
          </div>

          {/* Contact Information */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Dane kontaktowe
            </h2>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Imię i nazwisko osoby kontaktowej
              </label>
              <input
                type="text"
                {...register('contact.name')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. Jan Kowalski"
              />
              {errors.contact?.name && (
                <p className="mt-1 text-sm text-red-600">{errors.contact.name.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Stanowisko
              </label>
              <input
                type="text"
                {...register('contact.position')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. HR Manager"
              
              
              />
              {errors.contact?.position && (
                <p className="mt-1 text-sm text-red-600">{errors.contact.position.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Email
              </label>
              <input
                type="email"
                {...register('contact.email')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. jan.kowalski@firma.pl"
              />
              {errors.contact?.email && (
                <p className="mt-1 text-sm text-red-600">{errors.contact.email.message}</p>
              )}
            </div>

            <div>
              <label className="block text-sm font-medium text-purple-900 mb-2">
                Telefon
              </label>
              <input
                type="tel"
                {...register('contact.phone')}
                className="w-full px-4 py-3 rounded-xl border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                placeholder="np. +48 500 600 700"
              />
              {errors.contact?.phone && (
                <p className="mt-1 text-sm text-red-600">{errors.contact.phone.message}</p>
              )}
            </div>
          </div>

          {/* Package Type */}
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-purple-900">
              Typ ogłoszenia
            </h2>

            <div className="grid grid-cols-2 gap-4">
              <label className="relative flex flex-col p-6 bg-white rounded-xl border-2 border-purple-200 cursor-pointer hover:border-purple-300">
                <input
                  type="radio"
                  {...register('packageType')}
                  value="standard"
                  className="absolute right-4 top-4"
                />
                <div className="flex items-center mb-4">
                  <Briefcase className="w-6 h-6 text-purple-600 mr-2" />
                  <span className="font-medium text-purple-900">Standard</span>
                </div>
                <div className="text-2xl font-bold text-purple-900 mb-2">
                  599 zł
                  <span className="text-sm font-normal text-purple-600 ml-1">z VAT</span>
                </div>
                <ul className="space-y-2 text-sm text-purple-600">
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-500 mr-2" />
                    <span>60 dni widoczności</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-green-500 mr-2" />
                    <span>Podstawowa promocja</span>
                  </li>
                </ul>
              </label>

              <label className="relative flex flex-col p-6 bg-gradient-to-br from-purple-500 to-purple-700 rounded-xl border-2 border-purple-400 cursor-pointer hover:border-purple-300 text-white">
                <input
                  type="radio"
                  {...register('packageType')}
                  value="premium"
                  className="absolute right-4 top-4"
                />
                <div className="flex items-center mb-4">
                  <Crown className="w-6 h-6 text-yellow-400 mr-2" />
                  <span className="font-medium">Premium</span>
                </div>
                <div className="text-2xl font-bold mb-2">
                  899 zł
                  <span className="text-sm font-normal text-purple-200 ml-1">z VAT</span>
                </div>
                <ul className="space-y-2 text-sm text-purple-200">
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-yellow-400 mr-2" />
                    <span>90 dni widoczności</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-yellow-400 mr-2" />
                    <span>Wyróżnienie na liście</span>
                  </li>
                  <li className="flex items-center">
                    <Check className="w-4 h-4 text-yellow-400 mr-2" />
                    <span>Promocja w social media</span>
                  </li>
                </ul>
              </label>
            </div>
            {errors.packageType && (
              <p className="mt-2 text-sm text-red-600">{errors.packageType.message}</p>
            )}
          </div>

          {/* Detailed Error Display */}
          <div className="space-y-4 mb-6">
            {/* Form Validation Errors */}
            {Object.keys(errors).length > 0 && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-6">
                <div className="flex items-center mb-4">
                  <AlertCircle className="w-6 h-6 text-red-500 mr-3" />
                  <h3 className="text-lg font-medium text-red-800">
                    Błędy walidacji formularza
                  </h3>
                </div>
                <div className="space-y-4">
                  {/* Basic Information Errors */}
                  {(errors.title || errors.category || errors.description) && (
                    <div className="pl-4 border-l-2 border-red-300">
                      <h4 className="font-medium text-red-700 mb-2">Podstawowe informacje:</h4>
                      <ul className="space-y-1 text-sm text-red-600">
                        {errors.title && <li>• {errors.title.message}</li>}
                        {errors.category && <li>• {errors.category.message}</li>}
                        {errors.description && <li>• {errors.description.message}</li>}
                      </ul>
                    </div>
                  )}
                  
                  {/* Requirements Errors */}
                  {(errors.responsibilities || errors.requirements) && (
                    <div className="pl-4 border-l-2 border-red-300">
                      <h4 className="font-medium text-red-700 mb-2">Wymagania i obowiązki:</h4>
                      <ul className="space-y-1 text-sm text-red-600">
                        {errors.responsibilities && <li>• {errors.responsibilities.message}</li>}
                        {errors.requirements && <li>• {errors.requirements.message}</li>}
                      </ul>
                    </div>
                  )}
                  
                  {/* Technologies Errors */}
                  {errors.technologies && (
                    <div className="pl-4 border-l-2 border-red-300">
                      <h4 className="font-medium text-red-700 mb-2">Technologie:</h4>
                      <ul className="space-y-1 text-sm text-red-600">
                        <li>• {errors.technologies.message}</li>
                      </ul>
                    </div>
                  )}
                  
                  {/* Employment Details Errors */}
                  {(errors.workMode || errors.experienceLevel || errors.contractType || errors.salaryFrom || errors.salaryTo) && (
                    <div className="pl-4 border-l-2 border-red-300">
                      <h4 className="font-medium text-red-700 mb-2">Warunki zatrudnienia:</h4>
                      <ul className="space-y-1 text-sm text-red-600">
                        {errors.workMode && <li>• {errors.workMode.message}</li>}
                        {errors.experienceLevel && <li>• {errors.experienceLevel.message}</li>}
                        {errors.contractType && <li>• {errors.contractType.message}</li>}
                        {errors.salaryFrom && <li>• {errors.salaryFrom.message}</li>}
                        {errors.salaryTo && <li>• {errors.salaryTo.message}</li>}
                      </ul>
                    </div>
                  )}
                  
                  {/* Location Errors */}
                  {errors.location && (
                    <div className="pl-4 border-l-2 border-red-300">
                      <h4 className="font-medium text-red-700 mb-2">Lokalizacja:</h4>
                      <ul className="space-y-1 text-sm text-red-600">
                        {errors.location.country && <li>• {errors.location.country.message}</li>}
                        {errors.location.voivodeship && <li>• {errors.location.voivodeship.message}</li>}
                        {errors.location.city && <li>• {errors.location.city.message}</li>}
                      </ul>
                    </div>
                  )}
                  
                  {/* Company Information Errors */}
                  {errors.company && (
                    <div className="pl-4 border-l-2 border-red-300">
                      <h4 className="font-medium text-red-700 mb-2">Informacje o firmie:</h4>
                      <ul className="space-y-1 text-sm text-red-600">
                        {errors.company.name && <li>• {errors.company.name.message}</li>}
                        {errors.company.description && <li>• {errors.company.description.message}</li>}
                        {errors.company.size && <li>• {errors.company.size.message}</li>}
                        {errors.company.logo && <li>• {errors.company.logo.message}</li>}
                      </ul>
                    </div>
                  )}
                  
                  {/* Contact Information Errors */}
                  {errors.contact && (
                    <div className="pl-4 border-l-2 border-red-300">
                      <h4 className="font-medium text-red-700 mb-2">Dane kontaktowe:</h4>
                      <ul className="space-y-1 text-sm text-red-600">
                        {errors.contact.name && <li>• {errors.contact.name.message}</li>}
                        {errors.contact.position && <li>• {errors.contact.position.message}</li>}
                        {errors.contact.email && <li>• {errors.contact.email.message}</li>}
                        {errors.contact.phone && <li>• {errors.contact.phone.message}</li>}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {/* Database/API Errors */}
            {error && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-6">
                <div className="flex items-center mb-4">
                  <AlertCircle className="w-6 h-6 text-red-500 mr-3" />
                  <h3 className="text-lg font-medium text-red-800">
                    Błąd podczas zapisywania
                  </h3>
                </div>
                <p className="text-red-600">{error}</p>
              </div>
            )}
          </div>

          <button
            type="button"
            onClick={handleSubmit(onSubmit)}
            disabled={isSubmitting}
            className="w-full bg-purple-600 text-white rounded-xl py-3 font-medium hover:bg-purple-700 transition-colors flex items-center justify-center"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                Dodawanie...
              </>
            ) : (
              'Dodaj ogłoszenie'
            )}
          </button>
        </form>
      </div>
    </div>
  );
}