import React, { useState, useEffect } from 'react';
import { 
  Loader2, AlertCircle, Search, ArrowUpDown,
  Calendar, DollarSign, CreditCard, Building2, MapPin, Phone, Mail,
  CheckCircle2, XCircle, AlertTriangle, RefreshCcw, ChevronDown, ChevronRight,
  FileText, Briefcase
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

type Payment = {
  id: string;
  amount: number;
  currency: string;
  status: 'pending' | 'completed' | 'failed' | 'refunded';
  package_type: string;
  payment_method: string;
  invoice_data: {
    company_name: string;
    email: string;
    phone?: string;
    address: string;
    city: string;
    postal_code: string;
    country: string;
    vat_id: string;
  };
  created_at: string;
  paid_at: string | null;
  job: {
    id: string;
    title: string;
  };
};

const statusColors = {
  pending: { bg: 'bg-yellow-100', text: 'text-yellow-800', icon: AlertTriangle },
  completed: { bg: 'bg-green-100', text: 'text-green-800', icon: CheckCircle2 },
  failed: { bg: 'bg-red-100', text: 'text-red-800', icon: XCircle },
  refunded: { bg: 'bg-purple-100', text: 'text-purple-800', icon: RefreshCcw }
};

const formatCurrency = (amount: number, currency: string) => {
  return new Intl.NumberFormat('pl-PL', {
    style: 'currency',
    currency: currency
  }).format(amount);
};

type ExpandedPayments = {
  [key: string]: boolean;
};

export default function Payments() {
  const [payments, setPayments] = useState<Payment[]>([]);
  const [filteredPayments, setFilteredPayments] = useState<Payment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);
  const [totalAmount, setTotalAmount] = useState(0);
  const [expandedPayments, setExpandedPayments] = useState<ExpandedPayments>({});

  useEffect(() => {
    fetchPayments();
  }, []);

  const fetchPayments = async () => {
    try {
      const { data, error } = await supabase
        .from('payments')
        .select(`
          *,
          job:job_id (
            id,
            title
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setPayments(data);
      setFilteredPayments(data);

      // Calculate total amount for completed payments
      const total = data
        .filter(payment => payment.status === 'completed')
        .reduce((sum, payment) => sum + payment.amount, 0);
      setTotalAmount(total);
    } catch (err) {
      console.error('Error fetching payments:', err);
      setError('Wystąpił błąd podczas ładowania płatności.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    const timeout = setTimeout(() => {
      const filtered = payments.filter(payment => {
        const searchLower = searchQuery.toLowerCase();
        const matchesSearch = (
          payment.job?.title.toLowerCase().includes(searchLower) ||
          payment.invoice_data.company_name.toLowerCase().includes(searchLower) ||
          payment.invoice_data.email.toLowerCase().includes(searchLower)
        );
        
        const matchesStatus = !selectedStatus || payment.status === selectedStatus;

        return matchesSearch && matchesStatus;
      });
      setFilteredPayments(filtered);
    }, 300);

    setSearchTimeout(timeout);

    return () => {
      if (searchTimeout) {
        clearTimeout(searchTimeout);
      }
    };
  }, [payments, searchQuery, selectedStatus]);

  const togglePaymentExpand = (paymentId: string) => {
    setExpandedPayments(prev => ({
      ...prev,
      [paymentId]: !prev[paymentId]
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie płatności...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Wystąpił błąd
          </h2>
          <p className="text-purple-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-purple-900">
          Płatności
        </h1>
        <div className="text-lg font-semibold text-green-600">
          Suma płatności: {formatCurrency(totalAmount, 'PLN')}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
        <div className="grid md:grid-cols-3 gap-4">
          {/* Search */}
          <div className="relative">
            <input
              type="text"
              placeholder="Szukaj po tytule ogłoszenia lub danych płatnika..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-purple-400" />
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            >
              <option value="">Wszystkie statusy</option>
              <option value="pending">Oczekujące</option>
              <option value="completed">Zakończone</option>
              <option value="failed">Nieudane</option>
              <option value="refunded">Zwrócone</option>
            </select>
          </div>

          {/* Results Count */}
          <div className="flex items-center justify-end text-sm text-purple-600">
            Znaleziono: {filteredPayments.length} płatności
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto" style={{ maxHeight: 'calc(100vh - 250px)' }}>
          <table className="w-full">
            <thead>
              <tr className="bg-purple-50">
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                  >
                    Ogłoszenie
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                  >
                    Kwota
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                  >
                    Status
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                  >
                    Data płatności
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-100">
              {filteredPayments.map((payment) => {
                const StatusIcon = statusColors[payment.status].icon;
                return (
                  <React.Fragment key={payment.id}>
                    <tr 
                      className={`hover:bg-purple-50 cursor-pointer ${expandedPayments[payment.id] ? 'bg-purple-50' : ''}`}
                      onClick={() => togglePaymentExpand(payment.id)}
                    >
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          {expandedPayments[payment.id] ? (
                            <ChevronDown className="w-5 h-5 text-purple-500 mr-2" />
                          ) : (
                            <ChevronRight className="w-5 h-5 text-purple-500 mr-2" />
                          )}
                          <span className="text-purple-900">{payment.job?.title}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <span className="text-green-600 font-medium">
                            {formatCurrency(payment.amount, payment.currency)}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${statusColors[payment.status].bg} ${statusColors[payment.status].text}`}>
                            <StatusIcon className="w-4 h-4 mr-1" />
                            {payment.status === 'pending' && 'Oczekująca'}
                            {payment.status === 'completed' && 'Zakończona'}
                            {payment.status === 'failed' && 'Nieudana'}
                            {payment.status === 'refunded' && 'Zwrócona'}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center">
                          <Calendar className="w-5 h-5 text-purple-400 mr-2" />
                          <span className="text-purple-700">
                            {payment.paid_at ? new Date(payment.paid_at).toLocaleDateString() : '-'}
                          </span>
                        </div>
                      </td>
                    </tr>
                    {expandedPayments[payment.id] && (
                      <tr className="bg-purple-50">
                        <td colSpan={5} className="px-6 py-4">
                          <div className="grid grid-cols-2 gap-6">
                            {/* Payment Details */}
                            <div className="space-y-3">
                              <h3 className="font-medium text-purple-900">Szczegóły płatności</h3>
                              <div className="space-y-2">
                                <div className="flex items-center">
                                  <CreditCard className="w-4 h-4 mr-2 text-purple-500" />
                                  <span className="text-sm text-purple-700 mr-2">ID transakcji:</span>
                                  <span className="text-sm font-mono text-purple-900">#{payment.id}</span>
                                </div>
                                <div className="flex items-center">
                                  <Calendar className="w-4 h-4 mr-2 text-purple-500" />
                                  <span className="text-sm text-purple-700 mr-2">Data utworzenia:</span>
                                  <span className="text-sm text-purple-900">{new Date(payment.created_at).toLocaleString()}</span>
                                </div>
                                {payment.paid_at && (
                                  <div className="flex items-center">
                                    <Calendar className="w-4 h-4 mr-2 text-purple-500" />
                                    <span className="text-sm text-purple-700 mr-2">Data płatności:</span>
                                    <span className="text-sm text-purple-900">{new Date(payment.paid_at).toLocaleString()}</span>
                                  </div>
                                )}
                                <div className="flex items-center">
                                  <DollarSign className="w-4 h-4 mr-2 text-purple-500" />
                                  <span className="text-sm text-purple-700 mr-2">Kwota:</span>
                                  <span className="text-sm font-medium text-green-600">{formatCurrency(payment.amount, payment.currency)}</span>
                                </div>
                                <div className="flex items-center">
                                  <Briefcase className="w-4 h-4 mr-2 text-purple-500" />
                                  <span className="text-sm text-purple-700 mr-2">Pakiet:</span>
                                  <span className="text-sm text-purple-900">{payment.package_type === 'premium' ? 'Premium' : 'Standard'}</span>
                                </div>
                              </div>
                            </div>
                            
                            {/* Payer Details */}
                            <div className="space-y-3">
                              <h3 className="font-medium text-purple-900">Dane płatnika</h3>
                              <div className="space-y-2">
                                <div className="flex items-center">
                                  <Building2 className="w-4 h-4 mr-2 text-purple-500" />
                                  <span className="text-sm text-purple-700 mr-2">Firma:</span>
                                  <span className="text-sm text-purple-900">{payment.invoice_data.company_name}</span>
                                </div>
                                <div className="flex items-center">
                                  <Mail className="w-4 h-4 mr-2 text-purple-500" />
                                  <span className="text-sm text-purple-700 mr-2">Email:</span>
                                  <span className="text-sm text-purple-900">{payment.invoice_data.email}</span>
                                </div>
                                {payment.invoice_data.phone && (
                                  <div className="flex items-center">
                                    <Phone className="w-4 h-4 mr-2 text-purple-500" />
                                    <span className="text-sm text-purple-700 mr-2">Telefon:</span>
                                    <span className="text-sm text-purple-900">{payment.invoice_data.phone}</span>
                                  </div>
                                )}
                                <div className="flex items-center">
                                  <MapPin className="w-4 h-4 mr-2 text-purple-500" />
                                  <span className="text-sm text-purple-700 mr-2">Adres:</span>
                                  <span className="text-sm text-purple-900">
                                    {payment.invoice_data.address}, {payment.invoice_data.postal_code} {payment.invoice_data.city}, {payment.invoice_data.country}
                                  </span>
                                </div>
                                <div className="flex items-center">
                                  <FileText className="w-4 h-4 mr-2 text-purple-500" />
                                  <span className="text-sm text-purple-700 mr-2">NIP:</span>
                                  <span className="text-sm text-purple-900">{payment.invoice_data.vat_id}</span>
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
          <div className="sticky bottom-0 w-full h-2 bg-gradient-to-t from-white to-transparent"></div>
        </div>
      </div>
    </div>
  );
}