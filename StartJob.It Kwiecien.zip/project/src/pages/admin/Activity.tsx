import React, { useState, useEffect } from 'react';
import { 
  Loader2, AlertCircle, Search, ArrowUpDown, Calendar, 
  Users, Filter, X, Download, Activity as ActivityIcon,
  Plus, Edit, Trash2, FileText, Settings, CreditCard, Briefcase, ChevronDown,
  ArrowLeft
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Link } from 'react-router-dom';
import { useRef, useCallback } from 'react';

type ActivityLog = {
  id: string;
  admin_id: string | null;
  action: string;
  entity_type: string;
  entity_id: string | null;
  details: any;
  created_at: string;
  admin_email?: string;
};

export default function Activity() {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<ActivityLog[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAction, setSelectedAction] = useState<string>('');
  const [selectedEntityType, setSelectedEntityType] = useState<string>('');
  const [selectedAdmin, setSelectedAdmin] = useState<string>('');
  const [dateFrom, setDateFrom] = useState<string>('');
  const [dateTo, setDateTo] = useState<string>('');
  const [showFilters, setShowFilters] = useState(false);
  const [admins, setAdmins] = useState<{id: string, email: string}[]>([]);
  const [actions, setActions] = useState<string[]>([]);
  const [entityTypes, setEntityTypes] = useState<string[]>([]);
  const [displayedLogs, setDisplayedLogs] = useState<ActivityLog[]>([]);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const logsPerPage = 25;
  const observer = useRef<IntersectionObserver | null>(null);
  const lastLogElementRef = useCallback((node: HTMLTableRowElement | null) => {
    if (loadingMore) return;
    if (observer.current) observer.current.disconnect();
    observer.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && hasMore) {
        loadMoreLogs();
      }
    });
    if (node) observer.current.observe(node);
  }, [loadingMore, hasMore]);

  useEffect(() => {
    fetchActivityLogs();
    fetchFilterOptions();
  }, []);

  const fetchActivityLogs = async () => {
    try {
      setLoading(true);
      
      // Get all activity logs
      const { data: logs, error: logsError } = await supabase
        .from('admin_audit_log')
        .select('*')
        .order('created_at', { ascending: false });

      if (logsError) throw logsError;

      // Get admin emails
      const { data: adminEmails } = await supabase
        .from('admin_user_emails')
        .select('id, email');

      // Map admin emails to logs
      const logsWithEmails = (logs || []).map(log => {
        const admin = adminEmails?.find(a => a.id === log.admin_id);
        return {
          ...log,
          admin_email: admin?.email || 'System'
        };
      });

      setActivityLogs(logsWithEmails);
      setFilteredLogs(logsWithEmails);
      setDisplayedLogs(logsWithEmails.slice(0, logsPerPage));
      setHasMore(logsWithEmails.length > logsPerPage);
    } catch (err) {
      console.error('Error fetching activity logs:', err);
      setError('Wystąpił błąd podczas ładowania historii aktywności.');
    } finally {
      setLoading(false);
    }
  };

  const fetchFilterOptions = async () => {
    try {
      // Get unique admins
      const { data: adminData } = await supabase
        .from('admin_user_emails')
        .select('id, email');
      
      setAdmins(adminData || []);

      // Get unique actions and entity types from logs
      const { data: logs } = await supabase
        .from('admin_audit_log')
        .select('action, entity_type');
      
      if (logs) {
        const uniqueActions = [...new Set(logs.map(log => log.action))];
        const uniqueEntityTypes = [...new Set(logs.map(log => log.entity_type))];
        
        setActions(uniqueActions.sort());
        setEntityTypes(uniqueEntityTypes.sort());
      }
    } catch (err) {
      console.error('Error fetching filter options:', err);
    }
  };

  useEffect(() => {
    applyFilters();
  }, [searchQuery, selectedAction, selectedEntityType, selectedAdmin, dateFrom, dateTo, activityLogs]);

  const applyFilters = () => {
    let filtered = [...activityLogs];

    // Apply search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(log => 
        log.action.toLowerCase().includes(query) ||
        log.entity_type.toLowerCase().includes(query) ||
        log.admin_email?.toLowerCase().includes(query) ||
        JSON.stringify(log.details).toLowerCase().includes(query)
      );
    }

    // Apply action filter
    if (selectedAction) {
      filtered = filtered.filter(log => log.action === selectedAction);
    }

    // Apply entity type filter
    if (selectedEntityType) {
      filtered = filtered.filter(log => log.entity_type === selectedEntityType);
    }

    // Apply admin filter
    if (selectedAdmin) {
      filtered = filtered.filter(log => log.admin_id === selectedAdmin);
    }

    // Apply date from filter
    if (dateFrom) {
      const fromDate = new Date(dateFrom);
      filtered = filtered.filter(log => new Date(log.created_at) >= fromDate);
    }

    // Apply date to filter
    if (dateTo) {
      const toDate = new Date(dateTo);
      toDate.setHours(23, 59, 59, 999); // End of the day
      filtered = filtered.filter(log => new Date(log.created_at) <= toDate);
    }

    setFilteredLogs(filtered);
    setDisplayedLogs(filtered.slice(0, logsPerPage));
    setHasMore(filtered.length > logsPerPage);
  };

  const loadMoreLogs = () => {
    if (!hasMore || loadingMore) return;
    
    setLoadingMore(true);
    
    // Simulate a delay to show loading indicator
    setTimeout(() => {
      const currentSize = displayedLogs.length;
      const newLogs = filteredLogs.slice(currentSize, currentSize + logsPerPage);
      
      setDisplayedLogs(prev => [...prev, ...newLogs]);
      setHasMore(currentSize + newLogs.length < filteredLogs.length);
      setLoadingMore(false);
    }, 500);
  };

  const clearFilters = () => {
    setSearchQuery('');
    setSelectedAction('');
    setSelectedEntityType('');
    setSelectedAdmin('');
    setDateFrom('');
    setDateTo('');
  };

  const handleExportCSV = () => {
    // Create CSV content with UTF-8 BOM for proper encoding
    const BOM = '\uFEFF';
    const headers = ['Data', 'Akcja', 'Typ encji', 'ID encji', 'Administrator', 'Szczegóły'];
    
    // Prepare data rows with proper CSV escaping
    const rows = filteredLogs.map(log => [
      new Date(log.created_at).toLocaleString('pl-PL'),
      getActivityDescription(log),
      log.entity_type,
      log.entity_id || '',
      log.admin_email || 'System',
      JSON.stringify(log.details || {})
    ]);
    
    // Convert array to CSV with proper escaping
    const escapeCSV = (data: any) => {
      if (data === null || data === undefined) {
        return '';
      }
      
      const str = String(data);
      
      // If the string contains quotes, commas, or newlines, wrap in quotes and escape quotes
      if (str.includes('"') || str.includes(',') || str.includes('\n') || str.includes('\r')) {
        return `"${str.replace(/"/g, '""')}"`;
      }
      
      return str;
    };
    
    // Use semicolons as separators instead of commas for better Excel compatibility
    const csvContent = BOM +
      headers.map(escapeCSV).join(';') + 
      '\n' + 
      rows.map(row => row.map(escapeCSV).join(';')).join('\n');

    // Create blob with UTF-8 encoding
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `activity-logs-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  // Helper function to format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pl-PL', { 
      day: '2-digit', 
      month: '2-digit', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  // Helper function to get activity icon
  const getActivityIcon = (action: string, entityType: string) => {
    if (action.includes('create')) {
      return <Plus className="w-4 h-4 text-green-500" />;
    } else if (action.includes('update')) {
      return <Edit className="w-4 h-4 text-blue-500" />;
    } else if (action.includes('delete')) {
      return <Trash2 className="w-4 h-4 text-red-500" />;
    } else if (entityType === 'jobs') {
      return <Briefcase className="w-4 h-4 text-purple-500" />;
    } else if (entityType === 'blog_posts') {
      return <FileText className="w-4 h-4 text-purple-500" />;
    } else if (entityType === 'site_settings') {
      return <Settings className="w-4 h-4 text-purple-500" />;
    } else if (entityType === 'payments') {
      return <CreditCard className="w-4 h-4 text-purple-500" />;
    } else {
      return <ActivityIcon className="w-4 h-4 text-purple-500" />;
    }
  };

  // Helper function to format activity description
  const getActivityDescription = (log: ActivityLog) => {
    const { action, entity_type, details } = log;
    
    // Format entity type for display
    const formatEntityType = (type: string) => {
      const entityTypeMap = {
        'jobs': 'ogłoszenie',
        'blog_posts': 'artykuł',
        'admin_users': 'użytkownika',
        'site_settings': 'ustawienia',
        'payments': 'płatność',
        'applications': 'aplikację',
        'newsletter_subscribers': 'subskrybenta',
        'technologies': 'technologię',
        'job_categories': 'kategorię',
        'working_modes': 'tryb pracy',
        'experience_levels': 'poziom doświadczenia',
        'contract_types': 'typ umowy',
        'benefits': 'benefit',
        'languages': 'język'
      };
      
      return entityTypeMap[type] || type;
    };
    
    // Format action for display
    if (action.includes('create')) {
      return `Dodano ${formatEntityType(entity_type)}`;
    } else if (action.includes('update')) {
      return `Zaktualizowano ${formatEntityType(entity_type)}`;
    } else if (action.includes('delete')) {
      return `Usunięto ${formatEntityType(entity_type)}`;
    } else if (action.includes('job_expiration')) {
      return `Powiadomienie o wygaśnięciu ogłoszenia`;
    } else {
      return `${action} dla ${formatEntityType(entity_type)}`;
    }
  };

  // Get current logs for pagination
  const getCurrentLogs = () => {
    const indexOfLastLog = currentPage * logsPerPage;
    const indexOfFirstLog = indexOfLastLog - logsPerPage;
    return filteredLogs.slice(indexOfFirstLog, indexOfLastLog);
  };

  // Change page
  const paginate = (pageNumber: number) => setCurrentPage(pageNumber);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie historii aktywności...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Wystąpił błąd
          </h2>
          <p className="text-purple-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center mb-8">
        <Link to="/admin" className="mr-4 text-purple-600 hover:text-purple-800">
          <ArrowLeft className="w-6 h-6" />
        </Link>
        <h1 className="text-2xl font-bold text-purple-900">
          Historia aktywności
        </h1>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
        <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
          <div className="relative flex-1 min-w-[300px]">
            <input
              type="text"
              placeholder="Szukaj w historii aktywności..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-purple-400" />
          </div>
          
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center px-4 py-2 bg-purple-100 text-purple-700 rounded-lg hover:bg-purple-200 transition-colors"
            >
              <Filter className="w-5 h-5 mr-2" />
              {showFilters ? 'Ukryj filtry' : 'Pokaż filtry'}
            </button>
            
            <button
              onClick={handleExportCSV}
              className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              <Download className="w-5 h-5 mr-2" />
              Eksportuj CSV
            </button>
          </div>
        </div>
        
        {showFilters && (
          <div className="mt-4 p-4 bg-purple-50 rounded-xl">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-medium text-purple-900">Filtry zaawansowane</h3>
              <button
                onClick={clearFilters}
                className="text-sm text-purple-600 hover:text-purple-800 flex items-center"
              >
                <X className="w-4 h-4 mr-1" />
                Wyczyść filtry
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Akcja
                </label>
                <select
                  value={selectedAction}
                  onChange={(e) => setSelectedAction(e.target.value)}
                  className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                  <option value="">Wszystkie akcje</option>
                  {actions.map(action => (
                    <option key={action} value={action}>{action}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Typ encji
                </label>
                <select
                  value={selectedEntityType}
                  onChange={(e) => setSelectedEntityType(e.target.value)}
                  className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                  <option value="">Wszystkie typy</option>
                  {entityTypes.map(type => (
                    <option key={type} value={type}>{type}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Administrator
                </label>
                <select
                  value={selectedAdmin}
                  onChange={(e) => setSelectedAdmin(e.target.value)}
                  className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                  <option value="">Wszyscy administratorzy</option>
                  {admins.map(admin => (
                    <option key={admin.id} value={admin.id}>{admin.email}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Data od
                </label>
                <input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Data do
                </label>
                <input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                />
              </div>
            </div>
          </div>
        )}
        
        <div className="mt-4 text-sm text-purple-600">
          Znaleziono: {filteredLogs.length} {filteredLogs.length === 1 ? 'wpis' : 'wpisów'}
        </div>
      </div>

      {/* Activity Logs Table */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto" style={{ maxHeight: 'calc(100vh - 300px)' }}>
          <table className="w-full">
            <thead>
              <tr className="bg-purple-50">
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                    onClick={() => {
                      const sorted = [...filteredLogs].sort((a, b) => 
                        new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
                      );
                      setFilteredLogs(sorted);
                    }}
                  >
                    Data
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                    onClick={() => {
                      const sorted = [...filteredLogs].sort((a, b) => 
                        a.action.localeCompare(b.action)
                      );
                      setFilteredLogs(sorted);
                    }}
                  >
                    Akcja
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                    onClick={() => {
                      const sorted = [...filteredLogs].sort((a, b) => 
                        a.entity_type.localeCompare(b.entity_type)
                      );
                      setFilteredLogs(sorted);
                    }}
                  >
                    Typ encji
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="text-sm font-medium text-purple-900">
                    ID encji
                  </span>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    className="flex items-center text-sm font-medium text-purple-900"
                    onClick={() => {
                      const sorted = [...filteredLogs].sort((a, b) => 
                        (a.admin_email || '').localeCompare(b.admin_email || '')
                      );
                      setFilteredLogs(sorted);
                    }}
                  >
                    Administrator
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="text-sm font-medium text-purple-900">
                    Szczegóły
                  </span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-100">
              {displayedLogs.map((log, index) => (
                <tr 
                  key={log.id} 
                  className="hover:bg-purple-50"
                  ref={index === displayedLogs.length - 1 ? lastLogElementRef : null}
                >
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-900">{formatDate(log.created_at)}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <div className="bg-purple-100 p-1.5 rounded-full mr-2">
                        {getActivityIcon(log.action, log.entity_type)}
                      </div>
                      <span className="text-purple-900">{getActivityDescription(log)}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-purple-700">{log.entity_type}</span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="text-purple-700 font-mono text-sm">
                      {log.entity_id ? log.entity_id.substring(0, 8) + '...' : '-'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <Users className="w-4 h-4 text-purple-400 mr-2" />
                      <span className="text-purple-700">{log.admin_email || 'System'}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="max-w-xs truncate text-purple-700">
                      {log.details ? (
                        <div className="group relative">
                          <span className="truncate block">
                            {JSON.stringify(log.details).substring(0, 50)}
                            {JSON.stringify(log.details).length > 50 ? '...' : ''}
                          </span>
                          <div className="hidden group-hover:block absolute left-0 top-full z-10 bg-white p-4 rounded-lg shadow-lg border border-purple-100 whitespace-pre-wrap max-w-lg">
                            {JSON.stringify(log.details, null, 2)}
                          </div>
                        </div>
                      ) : (
                        '-'
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="sticky bottom-0 w-full h-2 bg-gradient-to-t from-white to-transparent"></div>
        </div>
        
        {/* Loading indicator */}
        {loadingMore && (
          <div className="flex justify-center py-6">
            <div className="flex items-center space-x-2 text-purple-600">
              <Loader2 className="w-5 h-5 animate-spin" />
              <span>Ładowanie więcej...</span>
            </div>
          </div>
        )}
        
        {/* End of results indicator */}
        {!hasMore && displayedLogs.length > 0 && (
          <div className="flex justify-center py-6 text-purple-600 text-sm">
            <span>Koniec wyników</span>
          </div>
        )}
      </div>

      {/* Custom scrollbar styles */}
      <style jsx>{`
        /* Webkit (Chrome, Safari, Edge) */
        .overflow-x-auto::-webkit-scrollbar {
          height: 8px;
          display: block;
        }
        
        .overflow-x-auto::-webkit-scrollbar-track {
          background: #f1f1f1;
          border-radius: 4px;
        }
        
        .overflow-x-auto::-webkit-scrollbar-thumb {
          background: #d6d0eb;
          border-radius: 4px;
        }
        
        .overflow-x-auto::-webkit-scrollbar-thumb:hover {
          background: #9283cb;
        }
        
        /* Firefox */
        .overflow-x-auto {
          scrollbar-width: thin;
          scrollbar-color: #d6d0eb #f1f1f1;
        }
      `}</style>
    </div>
  );
}