import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import RichTextEditor from '../../components/RichTextEditor';
import { 
  Loader2, AlertCircle, ArrowLeft, Calendar, Plus, X, Tag,
  BookOpen, Save, CheckCircle2, XCircle, Facebook, Code, Globe
} from 'lucide-react';
import { supabase } from '../../lib/supabase';

type Category = {
  id: string;
  name: string;
};

type Tag = {
  id: string;
  name: string;
};

type BlogPost = {
  id: string;
  title: string;
  subtitle: string;
  content: string;
  excerpt: string;
  thumbnail_url: string;
  author_name: string;
  author_role: string;
  author_avatar_url: string;
  category_id: string;
  published_at: string | null;
  is_published: boolean;
  is_featured: boolean,
  seo_title: string | null;
  seo_description: string | null;
  seo_keywords: string | null;
  og_title: string | null;
  og_description: string | null;
  og_image: string | null;
  schema_type: string | null;
  schema_data: any;
};

export default function AdminEditBlogPost() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [tags, setTags] = useState<Tag[]>([]);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [activeTab, setActiveTab] = useState<'content' | 'seo'>('content');
  const [post, setPost] = useState<BlogPost>({
    id: '',
    title: '',
    subtitle: '',
    content: '',
    excerpt: '',
    thumbnail_url: '',
    author_name: '',
    author_role: '',
    author_avatar_url: '',
    category_id: '',
    published_at: null,
    is_published: false,
    is_featured: false,
    seo_title: null,
    seo_description: null,
    seo_keywords: null,
    og_title: null,
    og_description: null,
    og_image: null,
    schema_type: 'BlogPosting',
    schema_data: {}
  });
  const [seoData, setSeoData] = useState({
    meta_title: '',
    meta_description: '',
    meta_keywords: '',
    og_title: '',
    og_description: '',
    og_image: '',
    schema_type: 'BlogPosting',
    schema_data: ''
  });

  useEffect(() => {
    fetchPost();
    fetchCategories();
    fetchTags();
  }, [id]);

  // Update SEO form when post data changes
  useEffect(() => {
    setSeoData({
      meta_title: post.seo_title || post.title ? `${post.title} | Blog StartJob.IT` : '',
      meta_description: post.seo_description || post.excerpt || post.subtitle || '',
      meta_keywords: post.seo_keywords || '',
      og_title: post.og_title || post.title ? `${post.title} | Blog StartJob.IT` : '',
      og_description: post.og_description || post.excerpt || post.subtitle || '',
      og_image: post.og_image || post.thumbnail_url || '',
      schema_type: post.schema_type || 'BlogPosting',
      schema_data: post.schema_data ? JSON.stringify(post.schema_data, null, 2) : JSON.stringify({
        '@type': 'BlogPosting',
        'headline': post.title || '',
        'description': post.excerpt || post.subtitle || '',
        'image': post.thumbnail_url || '',
        'author': {
          '@type': 'Person',
          'name': post.author_name || ''
        }
      }, null, 2)
    });
  }, [post]);

  const fetchPost = async () => {
    try {
      const { data: post, error: postError } = await supabase
        .from('blog_posts')
        .select('*')
        .eq('id', id)
        .single();

      if (postError) throw postError;

      // Fetch post tags
      const { data: postTags, error: tagsError } = await supabase
        .from('blog_post_tags')
        .select('tag_id')
        .eq('post_id', id);

      if (tagsError) throw tagsError;

      setPost(post);
      setSelectedTags(postTags.map(pt => pt.tag_id));
    } catch (err) {
      console.error('Error fetching post:', err);
      setError('Wystąpił błąd podczas ładowania wpisu.');
    } finally {
      setLoading(false);
    }
  };

  const fetchCategories = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_taxonomies')
        .select('*')
        .eq('type', 'category')
        .order('name');

      if (error) throw error;
      setCategories(data);
    } catch (err) {
      console.error('Error fetching categories:', err);
    }
  };

  const fetchTags = async () => {
    try {
      const { data, error } = await supabase
        .from('blog_taxonomies')
        .select('*')
        .eq('type', 'tag')
        .order('name');

      if (error) throw error;
      setTags(data);
    } catch (err) {
      console.error('Error fetching tags:', err);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);

    try {
      // Parse schema data
      let parsedSchemaData = {};
      try {
        parsedSchemaData = JSON.parse(seoData.schema_data);
      } catch (err) {
        console.error('Error parsing schema data:', err);
        throw new Error('Nieprawidłowy format danych Schema.org. Sprawdź składnię JSON.');
      }

      // Update post
      const { error: updateError } = await supabase
        .from('blog_posts')
        .update({
          title: post.title,
          subtitle: post.subtitle,
          content: post.content,
          excerpt: post.excerpt,
          thumbnail_url: post.thumbnail_url,
          author_name: post.author_name,
          author_role: post.author_role,
          author_avatar_url: post.author_avatar_url,
          category_id: post.category_id,
          is_published: post.is_published,
          is_featured: post.is_featured,
          published_at: post.is_published ? (post.published_at || new Date().toISOString()) : null,
          seo_title: seoData.meta_title || null,
          seo_description: seoData.meta_description || null,
          seo_keywords: seoData.meta_keywords || null,
          og_title: seoData.og_title || null,
          og_description: seoData.og_description || null,
          og_image: seoData.og_image || null,
          schema_type: seoData.schema_type || 'BlogPosting',
          schema_data: parsedSchemaData
        })
        .eq('id', id);

      if (updateError) throw updateError;

      // Update tags
      await supabase
        .from('blog_post_tags')
        .delete()
        .eq('post_id', id);

      if (selectedTags.length > 0) {
        await supabase
          .from('blog_post_tags')
          .insert(
            selectedTags.map(tagId => ({
              post_id: id,
              tag_id: tagId
            }))
          );
      }

      // Log the update
      await supabase
        .from('admin_audit_log')
        .insert([{
          action: 'update_blog_post',
          entity_type: 'blog_posts',
          entity_id: id,
          details: {
            updated_at: new Date().toISOString(),
            is_published: post.is_published
          }
        }]);

      navigate('/admin/blog');
    } catch (err) {
      console.error('Error updating post:', err);
      setError('Wystąpił błąd podczas zapisywania wpisu.');
    } finally {
      setSaving(false);
    }
  };

  const handleSeoInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setSeoData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie wpisu...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Wystąpił błąd
          </h2>
          <p className="text-purple-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center">
          <button
            onClick={() => navigate('/admin/blog')}
            className="mr-4 text-purple-600 hover:text-purple-800"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <h1 className="text-2xl font-bold text-purple-900">
            Edytuj wpis
          </h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="bg-white rounded-xl shadow-lg p-6">
          {/* Status Bar */}
          <div className="flex items-center justify-between mb-6 pb-6 border-b border-purple-100">
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <Calendar className="w-5 h-5 text-purple-400 mr-2" />
                <span className="text-purple-600">
                  Utworzono: {new Date(post.created_at).toLocaleDateString()}
                </span>
              </div>
              {post.published_at && (
                <div className="flex items-center">
                  <Calendar className="w-5 h-5 text-purple-400 mr-2" />
                  <span className="text-purple-600">
                    Opublikowano: {new Date(post.published_at).toLocaleDateString()}
                  </span>
                </div>
              )}
            </div>
            <div className="flex items-center space-x-4">
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={post.is_featured}
                  onChange={(e) => setPost({ ...post, is_featured: e.target.checked })}
                  className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                />
                <span className="text-purple-900">Wyróżniony</span>
              </label>
              <label className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  checked={!post.is_published}
                  onChange={(e) => setPost({ ...post, is_published: !e.target.checked })}
                  className="rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                />
                <span className="text-purple-900">Szkic</span>
              </label>
              <button
                type="submit"
                disabled={saving}
                className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50"
              >
                {saving ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Zapisywanie...
                  </>
                ) : (
                  <>
                    <Save className="w-5 h-5 mr-2" />
                    Zapisz zmiany
                  </>
                )}
              </button>
            </div>
          </div>
          {/* Tabs */}
          <div className="flex border-b border-purple-100 mb-6">
            <button
              type="button"
              className={`px-4 py-2 font-medium ${
                activeTab === 'content'
                  ? 'text-purple-600 border-b-2 border-purple-600'
                  : 'text-purple-400 hover:text-purple-600'
              }`}
              onClick={() => setActiveTab('content')}
            >
              Treść
            </button>
            <button
              type="button"
              className={`px-4 py-2 font-medium ${
                activeTab === 'seo'
                  ? 'text-purple-600 border-b-2 border-purple-600'
                  : 'text-purple-400 hover:text-purple-600'
              }`}
              onClick={() => setActiveTab('seo')}
            >
              SEO
            </button>
          </div>

          {activeTab === 'content' ? (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Tytuł
                </label>
                <input
                  type="text"
                  value={post.title}
                  onChange={(e) => setPost({ ...post, title: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Wpisz tytuł wpisu..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Podtytuł
                </label>
                <input
                  type="text"
                  value={post.subtitle}
                  onChange={(e) => setPost({ ...post, subtitle: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Wpisz podtytuł wpisu..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Treść
                </label>
                <RichTextEditor
                  value={post.content}
                  onChange={(value) => setPost({ ...post, content: value })}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Fragment
                </label>
                <textarea
                  value={post.excerpt}
                  onChange={(e) => setPost({ ...post, excerpt: e.target.value })}
                  rows={3}
                  className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="Wpisz fragment wpisu..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  URL miniatury
                </label>
                <input
                  type="url"
                  value={post.thumbnail_url}
                  onChange={(e) => setPost({ ...post, thumbnail_url: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="https://example.com/image.jpg"
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-purple-900 mb-2">
                    Autor
                  </label>
                  <input
                    type="text"
                    value={post.author_name}
                    onChange={(e) => setPost({ ...post, author_name: e.target.value })}
                    className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="Imię i nazwisko autora"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-purple-900 mb-2">
                    Stanowisko autora
                  </label>
                  <input
                    type="text"
                    value={post.author_role}
                    onChange={(e) => setPost({ ...post, author_role: e.target.value })}
                    className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    placeholder="np. Senior Developer"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  URL avatara autora
                </label>
                <input
                  type="url"
                  value={post.author_avatar_url}
                  onChange={(e) => setPost({ ...post, author_avatar_url: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                  placeholder="https://example.com/avatar.jpg"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Kategoria
                </label>
                <select
                  value={post.category_id}
                  onChange={(e) => setPost({ ...post, category_id: e.target.value })}
                  className="w-full px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                >
                  <option value="">Wybierz kategorię</option>
                  {categories.map(category => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-purple-900 mb-2">
                  Tagi
                  <span className="text-xs text-purple-500 ml-2">(opcjonalnie)</span>
                </label>
                <div className="flex flex-wrap gap-2 mb-4">
                  {tags.map(tag => (
                    <label
                      key={tag.id}
                      className="inline-flex items-center px-4 py-2 rounded-xl border border-purple-200 hover:bg-purple-50 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selectedTags.includes(tag.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedTags([...selectedTags, tag.id]);
                          } else {
                            setSelectedTags(selectedTags.filter(id => id !== tag.id));
                          }
                        }}
                        className="mr-2 rounded border-purple-300 text-purple-600 focus:ring-purple-500"
                      />
                      {tag.name}
                    </label>
                  ))}
                </div>
                
                {/* Add New Tag */}
                <div className="mt-4 border-t border-purple-100 pt-4">
                  <h4 className="text-sm font-medium text-purple-900 mb-2">Dodaj nowy tag</h4>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      id="newTag"
                      name="newTag"
                      placeholder="Nazwa nowego tagu"
                      className="flex-1 px-4 py-2 rounded-lg border border-purple-200 focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        const newTagName = (document.getElementById('newTag') as HTMLInputElement).value;
                        if (newTagName.trim()) {
                          try {
                            const { data, error } = await supabase
                              .from('blog_taxonomies')
                              .insert([{ name: newTagName, type: 'tag' }])
                              .select()
                              .single();
                              
                            if (error) throw error;
                            
                            // Add to tags list and select it
                            setTags([...tags, data]);
                            setSelectedTags([...selectedTags, data.id]);
                            
                            // Clear input
                            (document.getElementById('newTag') as HTMLInputElement).value = '';
                            
                            // Log the action
                            await supabase
                              .from('admin_audit_log')
                              .insert([{
                                action: 'create_blog_tag',
                                entity_type: 'blog_taxonomies',
                                entity_id: data.id,
                                details: {
                                  name: newTagName,
                                  type: 'tag'
                                }
                              }]);
                          } catch (err) {
                            console.error('Error creating tag:', err);
                            alert('Wystąpił błąd podczas tworzenia tagu.');
                          }
                        }
                      }}
                      className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                    >
                      <Plus className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* SEO Settings */
            <div className="space-y-6">
              {/* Meta Tags */}
              <div className="border-b border-purple-100 pb-6">
                <h3 className="text-md font-semibold text-purple-900 mb-4 flex items-center">
                  <Tag className="w-5 h-5 mr-2 text-purple-500" />
                  Meta Tagi
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Tytuł (meta title)
                    </label>
                    <input
                      type="text"
                      name="meta_title"
                      value={seoData.meta_title}
                      onChange={handleSeoInputChange}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder={`${post.title} | Blog StartJob.IT`}
                    />
                    <p className="text-xs text-purple-600 mt-1">
                      Zalecana długość: 50-60 znaków. Obecna długość: {seoData.meta_title.length}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Opis (meta description)
                    </label>
                    <textarea
                      name="meta_description"
                      value={seoData.meta_description}
                      onChange={handleSeoInputChange}
                      rows={3}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder={post.excerpt || post.subtitle || ''}
                    />
                    <p className="text-xs text-purple-600 mt-1">
                      Zalecana długość: 150-160 znaków. Obecna długość: {seoData.meta_description.length}
                    </p>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Słowa kluczowe (meta keywords)
                    </label>
                    <input
                      type="text"
                      name="meta_keywords"
                      value={seoData.meta_keywords}
                      onChange={handleSeoInputChange}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder="blog, IT, programowanie, kariera"
                    />
                    <p className="text-xs text-purple-600 mt-1">
                      Oddziel słowa kluczowe przecinkami. Np.: blog, IT, programowanie
                    </p>
                  </div>
                </div>
              </div>
              
              {/* OpenGraph Tags */}
              <div className="border-b border-purple-100 pb-6">
                <h3 className="text-md font-semibold text-purple-900 mb-4 flex items-center">
                  <Facebook className="w-5 h-5 mr-2 text-purple-500" />
                  OpenGraph Tagi
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      OG:Title
                    </label>
                    <input
                      type="text"
                      name="og_title"
                      value={seoData.og_title}
                      onChange={handleSeoInputChange}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder={`${post.title} | Blog StartJob.IT`}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      OG:Description
                    </label>
                    <textarea
                      name="og_description"
                      value={seoData.og_description}
                      onChange={handleSeoInputChange}
                      rows={3}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder={post.excerpt || post.subtitle || ''}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      OG:Image
                    </label>
                    <input
                      type="text"
                      name="og_image"
                      value={seoData.og_image}
                      onChange={handleSeoInputChange}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                      placeholder={post.thumbnail_url || "https://example.com/image.jpg"}
                    />
                    <p className="text-xs text-purple-600 mt-1">
                      Zalecany rozmiar: 1200x630 pikseli
                    </p>
                  </div>
                </div>
              </div>
              
              {/* Schema.org */}
              <div>
                <h3 className="text-md font-semibold text-purple-900 mb-4 flex items-center">
                  <Code className="w-5 h-5 mr-2 text-purple-500" />
                  Schema.org
                </h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Typ
                    </label>
                    <select
                      name="schema_type"
                      value={seoData.schema_type}
                      onChange={handleSeoInputChange}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
                    >
                      <option value="BlogPosting">BlogPosting</option>
                      <option value="Article">Article</option>
                      <option value="NewsArticle">NewsArticle</option>
                      <option value="TechArticle">TechArticle</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-purple-900 mb-2">
                      Dane JSON
                    </label>
                    <textarea
                      name="schema_data"
                      value={seoData.schema_data}
                      onChange={handleSeoInputChange}
                      rows={8}
                      className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500 font-mono"
                    />
                    <p className="text-xs text-purple-600 mt-1">
                      Wprowadź dane w formacie JSON zgodnie ze standardem schema.org
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </form>
    </div>
  );
}