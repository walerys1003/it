import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Loader2, AlertCircle, Plus, Pencil, Trash2, Clock, Search,
  ArrowUpDown, Building2, MapPin, Briefcase, Calendar,
  Crown, CheckCircle2, XCircle, DollarSign, Timer
} from 'lucide-react';
import { contractTypes } from '../../data/jobPostingData';
import { supabase } from '../../lib/supabase';

type Notification = {
  type: 'success' | 'error';
  message: string;
};

const getContractTypeLabel = (type: string) => {
  const contractType = contractTypes.find(t => t.value === type);
  return contractType ? contractType.label : type;
};

type Job = {
  id: string;
  title: string;
  company_name: string;
  location_city: string;
  contract_type: string;
  created_at: string;
  valid_until: string;
  is_premium: boolean;
  is_active: boolean;
  salary_from: number;
  salary_to: number;
  currency: string;
};

type SortField = 'created_at' | 'valid_until' | 'title' | 'company_name';
type SortOrder = 'asc' | 'desc';

export default function Jobs() {
  const navigate = useNavigate();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sortField, setSortField] = useState<SortField>('created_at');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedContractType, setSelectedContractType] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [filteredJobs, setFilteredJobs] = useState<Job[]>([]);
  const [searchTimeout, setSearchTimeout] = useState<NodeJS.Timeout | null>(null);
  const [notification, setNotification] = useState<Notification | null>(null);

  const [processingId, setProcessingId] = useState<string | null>(null);

  useEffect(() => {
    fetchJobs();
  }, [sortField, sortOrder]);

  const fetchJobs = async () => {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('*')
        .order(sortField, { ascending: sortOrder === 'asc' });

      if (error) throw error;
      setJobs(data);
      setFilteredJobs(data);
    } catch (err) {
      console.error('Error fetching jobs:', err);
      setError('Wystąpił błąd podczas ładowania ogłoszeń.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (searchTimeout) {
      clearTimeout(searchTimeout);
    }

    const timeout = setTimeout(() => {
      const filtered = jobs.filter(job => {
        const matchesSearch = searchQuery === '' || 
          job.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          job.company_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          job.location_city.toLowerCase().includes(searchQuery.toLowerCase());

        const matchesContractType = selectedContractType === '' || 
          job.contract_type === selectedContractType;

        const matchesStatus = selectedStatus === '' || 
          (selectedStatus === 'active' && job.is_active) ||
          (selectedStatus === 'inactive' && !job.is_active);

        return matchesSearch && matchesContractType && matchesStatus;
      });

      setFilteredJobs(filtered);
    }, 300);

    setSearchTimeout(timeout);

    return () => {
      clearTimeout(timeout);
    };
  }, [jobs, searchQuery, selectedContractType, selectedStatus]);

  const handleSort = (field: SortField) => {
    if (field === sortField) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const handleExtendValidity = async (jobId: string, days: number) => {
    try {
      setProcessingId(jobId);
      
      // Get current job data
      const { data: job, error: fetchError } = await supabase
        .from('jobs')
        .select('valid_until')
        .eq('id', jobId)
        .single();

      if (fetchError) throw fetchError;

      // Calculate new validity date
      const currentDate = new Date();
      const validUntil = new Date(job.valid_until);
      const newValidUntil = validUntil > currentDate
        ? new Date(validUntil.setDate(validUntil.getDate() + days)) // Extend from current valid_until
        : new Date(currentDate.setDate(currentDate.getDate() + days)); // Start from today

      const { error } = await supabase
        .from('jobs')
        .update({ valid_until: newValidUntil.toISOString() })
        .eq('id', jobId);

      if (error) throw error;

      // Log the extension in admin audit log
      await supabase
        .from('admin_audit_log')
        .insert([{
          action: 'extend_job_validity',
          entity_type: 'jobs',
          entity_id: jobId,
          details: {
            days_extended: days,
            new_valid_until: newValidUntil.toISOString()
          }
        }]);
      
      await fetchJobs();
      
      // Show success notification
      setNotification({
        type: 'success',
        message: `Termin ważności ogłoszenia został przedłużony o ${days} dni`
      });
      
      // Clear notification after 3 seconds
      setTimeout(() => {
        setNotification(null);
      }, 3000);

    } catch (err) {
      console.error('Error extending job validity:', err);
      setNotification({
        type: 'error',
        message: 'Wystąpił błąd podczas przedłużania ważności ogłoszenia'
      });
    } finally {
      setProcessingId(null);
    }
  };

  const handleDelete = async (jobId: string) => {
    if (!window.confirm('Czy na pewno chcesz usunąć to ogłoszenie?')) {
      return;
    }

    try {
      setProcessingId(jobId);
      const { data, error } = await supabase
        .from('jobs')
        .delete()
        .eq('id', jobId);

      if (error) throw error;
      
      // Log the deletion in admin audit log
      await supabase
        .from('admin_audit_log')
        .insert([{
          action: 'delete_job',
          entity_type: 'jobs',
          entity_id: jobId,
          details: {
            deleted_at: new Date().toISOString()
          }
        }]);

      // Remove the deleted job from state
      setJobs(prevJobs => prevJobs.filter(job => job.id !== jobId));
      setFilteredJobs(prevJobs => prevJobs.filter(job => job.id !== jobId));
      
      // Show success notification
      setNotification({
        type: 'success',
        message: 'Ogłoszenie zostało pomyślnie usunięte'
      });
      
      // Clear notification after 3 seconds
      setTimeout(() => {
        setNotification(null);
      }, 3000);
    } catch (err) {
      console.error('Error deleting job:', err);
      setNotification({
        type: 'error',
        message: 'Wystąpił błąd podczas usuwania ogłoszenia'
      });
    } finally {
      setProcessingId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <Loader2 className="w-12 h-12 text-purple-600 animate-spin mx-auto mb-4" />
          <p className="text-purple-600">Ładowanie ogłoszeń...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-purple-900 mb-2">
            Wystąpił błąd
          </h2>
          <p className="text-purple-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-purple-900">
          Ogłoszenia o pracę
        </h1>
        <button
          onClick={() => navigate('/admin/jobs/add')}
          className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
        >
          <Plus className="w-5 h-5 mr-2" />
          Dodaj ogłoszenie
        </button>
      </div>

      {/* Notification */}
      {notification && (
        <div className={`mb-6 p-4 rounded-xl flex items-center ${
          notification.type === 'success' 
            ? 'bg-green-50 text-green-700' 
            : 'bg-red-50 text-red-700'
        }`}>
          {notification.type === 'success' ? (
            <CheckCircle2 className="w-5 h-5 mr-2" />
          ) : (
            <AlertCircle className="w-5 h-5 mr-2" />
          )}
          <p>{notification.message}</p>
        </div>
      )}

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
        <div className="grid md:grid-cols-4 gap-4">
          {/* Search */}
          <div className="relative">
            <input
              type="text"
              placeholder="Szukaj..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            />
            <Search className="absolute left-3 top-2.5 h-5 w-5 text-purple-400" />
          </div>

          {/* Contract Type Filter */}
          <div>
            <select
              value={selectedContractType}
              onChange={(e) => setSelectedContractType(e.target.value)}
              className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            >
              <option value="">Wszystkie umowy</option>
              {contractTypes.map(type => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-4 py-2 border border-purple-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
            >
              <option value="">Wszystkie statusy</option>
              <option value="active">Aktywne</option>
              <option value="inactive">Nieaktywne</option>
            </select>
          </div>

          {/* Results Count */}
          <div className="flex items-center justify-end text-sm text-purple-600">
            Znaleziono: {filteredJobs.length} ogłoszeń
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="overflow-x-auto" style={{ maxHeight: 'calc(100vh - 250px)' }}>
          <table className="w-full">
            <thead>
              <tr className="bg-purple-50">
                <th className="px-6 py-4 text-left">
                  <button
                    onClick={() => handleSort('title')}
                    className="flex items-center text-sm font-medium text-purple-900"
                  >
                    Tytuł
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    onClick={() => handleSort('company_name')}
                    className="flex items-center text-sm font-medium text-purple-900"
                  >
                    Firma
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="text-sm font-medium text-purple-900">
                    Lokalizacja
                  </span>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="text-sm font-medium text-purple-900">
                    Umowa
                  </span>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    onClick={() => handleSort('created_at')}
                    className="flex items-center text-sm font-medium text-purple-900"
                  >
                    Data utworzenia
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <button
                    onClick={() => handleSort('valid_until')}
                    className="flex items-center text-sm font-medium text-purple-900"
                  >
                    Ważne do
                    <ArrowUpDown className="w-4 h-4 ml-1" />
                  </button>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="text-sm font-medium text-purple-900">
                    Status
                  </span>
                </th>
                <th className="px-6 py-4 text-left">
                  <span className="text-sm font-medium text-purple-900">
                    Wynagrodzenie
                  </span>
                </th>
                <th className="px-6 py-4 text-center">
                  <span className="text-sm font-medium text-purple-900">
                    Akcje
                  </span>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-purple-100">
              {filteredJobs.map((job) => (
                <tr key={job.id} className="hover:bg-purple-50">
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-900">{job.title}</span>
                      {job.is_premium && (
                        <div className="w-5 h-5 flex items-center justify-center pl-1">
                          <Crown className="w-4 h-4 text-yellow-500" />
                        </div>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-700">{job.company_name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-700">{job.location_city}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-700">{getContractTypeLabel(job.contract_type)}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-700">
                        {new Date(job.created_at).toLocaleDateString()}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-700">
                        {new Date(job.valid_until).toLocaleDateString()}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {job.is_active ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        Aktywne
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                        Nieaktywne
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <span className="text-purple-700">
                        {job.salary_from} - {job.salary_to} {job.currency}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex justify-center space-x-2">
                      <button
                        onClick={() => navigate(`/admin/jobs/${job.id}/edit`)}
                        className="p-2 text-purple-600 hover:bg-purple-100 rounded-lg"
                        title="Edytuj"
                      >
                        <Pencil className="w-4 h-4" />
                      </button>
                      <div className="relative group">
                        <button
                          className="p-2 text-purple-600 hover:bg-purple-100 rounded-lg"
                          title="Przedłuż ważność"
                        >
                          <Timer className="w-4 h-4" />
                        </button>
                        <div className="absolute right-0 mt w-48 bg-white rounded-lg shadow-lg py-2 hidden group-hover:block z-10">
                          <button
                            onClick={() => handleExtendValidity(job.id, 60)}
                            disabled={processingId === job.id}
                            className="w-full px-4 py-2 text-left text-sm text-purple-700 hover:bg-purple-50"
                          >
                            Przedłuż o 60 dni
                          </button>
                          <button
                            onClick={() => handleExtendValidity(job.id, 90)}
                            disabled={processingId === job.id}
                            className="w-full px-4 py-2 text-left text-sm text-purple-700 hover:bg-purple-50"
                          >
                            Przedłuż o 90 dni
                          </button>
                        </div>
                      </div>
                      <button
                        onClick={() => handleDelete(job.id)}
                        disabled={processingId === job.id}
                        className="p-2 text-red-600 hover:bg-red-100 rounded-lg"
                        title="Usuń"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="sticky bottom-0 w-full h-2 bg-gradient-to-t from-white to-transparent"></div>
        </div>
      </div>
    </div>
  );
}