import React from 'react';
import { Link } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { ArrowLeft, FileText, CheckSquare, AlertTriangle, CreditCard, Clock, Shield } from 'lucide-react';

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-gray-50 py-12">
      {/* Schema.org structured data for terms of service page */}
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebPage',
            'name': 'Regulamin Serwisu StartJob.IT',
            'description': 'Regulamin korzystania z serwisu StartJob.IT. Warunki świadczenia usług.',
            'mainEntity': {
              '@type': 'WebPageElement',
              'headline': 'Regulamin Serwisu',
              'text': 'Regulamin określający zasady korzystania z serwisu StartJob.IT'
            },
            'publisher': {
              '@type': 'Organization',
              'name': 'StartJob.IT',
              'url': 'https://startjob.it'
            }
          })}
        </script>
      </Helmet>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back button */}
        <Link
          to="/"
          className="inline-flex items-center text-purple-600 hover:text-purple-900 mb-8"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Powrót do strony głównej
        </Link>

        {/* Header */}
        <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
          <div className="flex items-center justify-center mb-6">
            <div className="bg-purple-100 rounded-full p-4">
              <FileText className="w-8 h-8 text-purple-600" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-purple-900 text-center mb-4">
            Regulamin Serwisu StartJob.IT
          </h1>
          <p className="text-purple-600 text-center">
            Obowiązuje od: 01.01.2025
          </p>
        </div>

        {/* Content */}
        <div className="bg-white rounded-2xl shadow-lg p-8 space-y-8">
          <section>
            <h2 className="text-2xl font-bold text-purple-900 mb-4">
              §1. Definicje
            </h2>
            <div className="space-y-4">
              <p className="text-purple-700">
                1. Administrator W3 B2B SPÓŁKA Z OGRANICZONĄ ODPOWIEDZIALNOŚCIĄ z siedzibą przy ul. Świeradowska 47, 02-662 Warszawa, Polska, wpisana do Krajowego Rejestru Sądowego pod numerem KRS: 0001115407, posiadająca NIP: 1133139476 oraz REGON: 529115601.
              </p>
              <p className="text-purple-700">
                2. Konsument Osoba fizyczna zawierająca z Administratorem umowę niezwiązaną bezpośrednio z jej działalnością gospodarczą lub zawodową lub osoba fizyczna zawierająca z Administratorem umowę bezpośrednio związaną z jej działalnością gospodarczą, gdy z treści tej umowy wynika, że nie posiada ona dla tej osoby charakteru zawodowego.
              </p>
              <p className="text-purple-700">
                3. Reklamobiorca Osoba fizyczna korzystająca z Serwisu Internetowego w celu przeglądania opublikowanych ofert pracy i ewentualnego aplikowania do trwających procesów rekrutacyjnych za pośrednictwem Serwisu.
              </p>
              <p className="text-purple-700">
                4. Reklamodawca Niebędąca konsumentem osoba fizyczna, osoba prawna lub jednostka organizacyjna nieposiadająca osobowości prawnej, będąca wpisaną do Rejestru Podmiotów Wykonujących Działalność Leczniczą.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-purple-900 mb-4">
              §2. Postanowienia wstępne
            </h2>
            <div className="space-y-4">              
              <p className="text-purple-700">
                1. Administrator za pośrednictwem Serwisu świadczy na rzecz Użytkownika usługę drogą elektroniczną polegającą na umożliwieniu Użytkownikowi zawarcia z Administratorem umowy o dostarczenie treści cyfrowych.
              </p>           
              <p className="text-purple-700">
                2. Usługi świadczone są na rzecz Użytkownika nieodpłatnie, z wyłączeniem umów o dostarczenie treści cyfrowych w postaci ekspozycji ogłoszenia internetowego zawieranych za pośrednictwem Serwisu, które są odpłatne zgodnie z opublikowanym w Serwisie cennikiem.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-purple-900 mb-4">
              §3. Prawa własności intelektualnej
            </h2>
            <div className="space-y-4">
              <p className="text-purple-700">
                1. Administrator poucza niniejszym Użytkownika, że treści ogłoszeń dostępne w Serwisie oraz treści cyfrowe udostępnione za pośrednictwem Serwisu mogą stanowić utwory w rozumieniu ustawy z dnia 4 lutego 1994 r. o prawie autorskim i prawach pokrewnych.
              </p>
              <p className="text-purple-700">
                2. Dalsze rozpowszechnianie treści objętych prawami autorskimi bez zgody Administratora stanowi naruszenie praw autorskich i może skutkować odpowiedzialnością cywilną.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-purple-900 mb-4">
              §4. Umowa Reklamowa
            </h2>
            <div className="space-y-4">
              <p className="text-purple-700">
                1. Zawarcie Umowy Reklamowej wymaga:
              </p>
              <ul className="list-disc list-inside text-purple-700 ml-2 mb-2">
                <li>Przejście do formularza dodania ogłoszenia</li>
                <li>Wypełnienia formularza dodania ogłoszenia</li>
                <li>Zaakceptowania Regulaminu</li>
                <li>Kliknięcia w przycisk "Dodaj ogłoszenie"</li>
              </ul>
              <p className="text-purple-700">
                2. Po skutecznym dokonaniu płatności, ogłoszenie zostanie opublikowane automatycznie.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-purple-900 mb-4">
              §5. Odpowiedzialność za wady
            </h2>
            <div className="space-y-4">
              <p className="text-purple-700">
                1. Administrator ma obowiązek dostarczyć Reklamodawcy ogłoszenie internetowe wolne od wad.
              </p>
              <p className="text-purple-700">
                2. Wszelkie reklamacje związane z funkcjonowaniem Serwisu można zgłaszać za pośrednictwem poczty elektronicznej na adres kontakt@startjob.it.
              </p>
            </div>
          </section>

          <section>
            <h2 className="text-2xl font-bold text-purple-900 mb-4">
              §6. Postanowienia końcowe
            </h2>
            <div className="space-y-4">
              <p className="text-purple-700">
                1. Administrator zastrzega sobie prawo do wprowadzania oraz odwoływania ofert, promocji oraz do zmiany cen w Serwisie bez uszczerbku dla praw nabytych przez Użytkownika.
              </p>
              <p className="text-purple-700">
                1. Wszelkie spory związane z umowami zawieranymi za pośrednictwem Serwisu będą rozpatrywane przez polski sąd powszechny właściwy ze względu na miejsce siedziby Administratora.
              </p>
            </div>
          </section>
          
        </div>
      </div>
    </div>
  );
}