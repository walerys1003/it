import React, { useState, useEffect } from 'react';
import JobList from '../components/JobList';
import SearchFilters, { JobFilters } from '../components/SearchFilters';
import { Briefcase, Building2, Code, Users, SlidersHorizontal, X } from 'lucide-react';
import { Link, useLocation, useSearchParams } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';

export default function Home() {
  const [filters, setFilters] = useState<JobFilters | undefined>();
  const [isFiltersOpen, setIsFiltersOpen] = useState(false);
  const location = useLocation();
  const [searchParams, setSearchParams] = useSearchParams();

  useEffect(() => {
    // Restore filters from URL params
    const urlFilters: Partial<JobFilters> = {
      search: searchParams.get('search') || '',
      location: {
        country: searchParams.get('country') || '',
        voivodeship: searchParams.get('voivodeship') || '',
        city: searchParams.get('city') || ''
      },
      categories: searchParams.getAll('category'),
      workModes: searchParams.getAll('workMode'),
      experienceLevels: searchParams.getAll('experienceLevel'),
      contractTypes: searchParams.getAll('contractType'),
      technologies: searchParams.getAll('technology'),
      salaryRange: {
        from: searchParams.get('salaryFrom') ? Number(searchParams.get('salaryFrom')) : null,
        to: searchParams.get('salaryTo') ? Number(searchParams.get('salaryTo')) : null
      },
      benefits: searchParams.getAll('benefit'),
      onlySalaryVisible: searchParams.get('onlySalaryVisible') === 'true'
    };

    // Only set filters if we have any params
    if (Object.values(urlFilters).some(value => 
      value && (Array.isArray(value) ? value.length > 0 : true)
    )) {
      setFilters(urlFilters as JobFilters);
    }
  }, [searchParams]);

  const handleFiltersChange = (newFilters: JobFilters) => {
    // Update URL params
    const params = new URLSearchParams();
    
    if (newFilters.search) params.set('search', newFilters.search);
    if (newFilters.location.country) params.set('country', newFilters.location.country);
    if (newFilters.location.voivodeship) params.set('voivodeship', newFilters.location.voivodeship);
    if (newFilters.location.city) params.set('city', newFilters.location.city);
    
    newFilters.categories.forEach(cat => params.append('category', cat));
    newFilters.workModes.forEach(mode => params.append('workMode', mode));
    newFilters.experienceLevels.forEach(level => params.append('experienceLevel', level));
    newFilters.contractTypes.forEach(type => params.append('contractType', type));
    newFilters.technologies.forEach(tech => params.append('technology', tech));
    newFilters.benefits.forEach(benefit => params.append('benefit', benefit));
    
    if (newFilters.salaryRange.from) params.set('salaryFrom', String(newFilters.salaryRange.from));
    if (newFilters.salaryRange.to) params.set('salaryTo', String(newFilters.salaryRange.to));
    if (newFilters.onlySalaryVisible) params.set('onlySalaryVisible', 'true');
    
    setSearchParams(params);
    setFilters(newFilters);
  };

  return (
    <>
      {/* Schema.org structured data for homepage */}
      <Helmet>
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'WebSite',
            'url': 'https://startjob.it',
            'name': 'StartJob.IT',
            'description': 'StartJob.IT to platforma łącząca specjalistów IT z najlepszymi pracodawcami. Znajdź swoją wymarzoną pracę w branży IT.',
            'potentialAction': {
              '@type': 'SearchAction',
              'target': 'https://startjob.it/?search={search_term_string}',
              'query-input': 'required name=search_term_string'
            }
          })}
        </script>
        <script type="application/ld+json">
          {JSON.stringify({
            '@context': 'https://schema.org',
            '@type': 'Organization',
            'name': 'StartJob.IT',
            'url': 'https://startjob.it',
            'logo': 'https://startjob.it/logo.png',
            'description': 'StartJob.IT to platforma łącząca specjalistów IT z najlepszymi pracodawcami. Znajdź swoją wymarzoną pracę w branży IT.',
            'sameAs': [
              'https://facebook.com/startjob.it',
              'https://linkedin.com/company/startjob-it',
              'https://instagram.com/startjob.it'
            ],
            'contactPoint': {
              '@type': 'ContactPoint',
              'telephone': '(+48) 501 42 00 42',
              'contactType': 'customer service',
              'email': 'kontakt@startjob.it'
            }
          })}
        </script>
      </Helmet>

      {/* CTA Section */}
      <section className="bg-white py-16 border-b border-purple-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-purple-900 mb-6">
                Znajdź swoją wymarzoną pracę w IT
              </h2>
              <p className="text-lg text-purple-700 mb-8">
                StartJob.IT to platforma stworzona z myślą o branży IT – łączymy najlepszych 
                specjalistów z wiodącymi pracodawcami. Codziennie nowe oferty pracy dla programistów, 
                testerów, administratorów i innych ekspertów IT.
              </p>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="bg-purple-100 rounded-full p-2 mr-4">
                    <Code className="w-6 h-6 text-purple-600" />
                  </div>
                  <span className="text-purple-900">Ponad 600 aktualnych ofert pracy</span>
                </div>
                <div className="flex items-center">
                  <div className="bg-purple-100 rounded-full p-2 mr-4">
                    <Building2 className="w-6 h-6 text-purple-600" />
                  </div>
                  <span className="text-purple-900">Współpraca z najlepszymi firmami IT</span>
                </div>
                <div className="flex items-center">
                  <div className="bg-purple-100 rounded-full p-2 mr-4">
                    <Users className="w-6 h-6 text-purple-600" />
                  </div>
                  <span className="text-purple-900">Społeczność 10 000+ specjalistów IT</span>
                </div>
              </div>
              <div className="mt-8">
                <Link
                  to="/dodaj-ogloszenie"
                  className="inline-flex bg-yellow-400 text-purple-900 px-6 py-3 rounded-full hover:bg-yellow-300 transition-colors items-center font-medium"
                >
                  Dodaj ogłoszenie
                  <Briefcase className="w-5 h-5 ml-2" />
                </Link>
              </div>
            </div>
            <div className="relative">
              <div className="bg-gradient-to-br from-purple-100 to-purple-50 rounded-3xl p-8">
                <div className="relative w-full h-full min-h-[400px] rounded-2xl overflow-hidden">
                  <img
                    src="https://i.ibb.co/84cB1bbW/3.png"
                    alt="Team of professionals working together"
                    className="w-full h-full object-cover rounded-2xl"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-purple-900/30 to-transparent"></div>
                </div>
              </div>
              {/* Decorative elements */}
              <div className="absolute -top-6 -right-6 w-24 h-24 bg-yellow-400 rounded-full opacity-20"></div>
              <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-purple-600 rounded-full opacity-20"></div>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Filters */}
          <div className="lg:col-span-3">
            {/* Mobile/Tablet Filter Button */}
            <button
              onClick={() => setIsFiltersOpen(true)}
              className="lg:hidden w-full mb-6 flex items-center justify-center px-4 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 transition-colors"
            >
              <SlidersHorizontal className="w-5 h-5 mr-2" />
              Pokaż filtry
            </button>

            {/* Filters Sidebar/Modal */}
            <div className={`
              fixed inset-0 z-50 lg:relative lg:z-auto lg:block
              ${isFiltersOpen ? 'block' : 'hidden'}
            `}>
              {/* Overlay */}
              <div 
                className="fixed inset-0 bg-black bg-opacity-50 lg:hidden"
                onClick={() => setIsFiltersOpen(false)}
              />
              
              {/* Filters Content */}
              <div className={`
                fixed right-0 top-0 h-full w-[90%] max-w-md bg-gray-50 p-6 overflow-y-auto
                transform transition-transform duration-300 ease-in-out
                lg:transform-none lg:relative lg:w-full lg:p-0 lg:block lg:bg-transparent
                ${isFiltersOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
              `}>
                <div className="flex justify-between items-center mb-6 lg:hidden">
                  <h2 className="text-xl font-bold text-purple-900">Filtry</h2>
                  <button
                    onClick={() => setIsFiltersOpen(false)}
                    className="p-2 text-purple-600 hover:bg-purple-100 rounded-lg"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>
                <SearchFilters onFiltersChange={handleFiltersChange} initialFilters={filters} />
              </div>
            </div>
          </div>
          {/* Job Listings */}
          <div className="lg:col-span-9">
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-2xl font-bold text-purple-900">Najnowsze oferty pracy IT</h2>
              <div className="hidden sm:flex items-center space-x-2">
                <span className="text-purple-700">Sortuj według:</span>
                <select className="border border-purple-200 rounded-xl px-4 py-2 text-purple-900 focus:ring-purple-500 focus:border-purple-500">
                  <option>Najnowsze</option>
                  <option>Wynagrodzenie: malejąco</option>
                  <option>Wynagrodzenie: rosnąco</option>
                </select>
              </div>
            </div>

            <JobList filters={filters} />
          </div>
        </div>
      </main>
    </>
  );
}