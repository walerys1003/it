import { z } from 'zod';

// Basic Information Schema
const basicInfoSchema = z.object({
  title: z.string()
    .min(1, 'Pole stanowisko jest wymagane')
    .min(10, 'Nazwa stanowiska musi mieć co najmniej 10 znaków')
    .max(100, 'Nazwa stanowiska nie może przekraczać 100 znaków'),
  category: z.string()
    .min(1, 'Wybierz kategorię stanowiska'),
  description: z.string()
    .min(1, 'Pole opis stanowiska jest wymagane')
    .min(100, 'Opis stanowiska musi mieć co najmniej 100 znaków')
    .max(5000, 'Opis stanowiska nie może przekraczać 5000 znaków'),
});

// Full Job Posting Schema
export const jobPostingSchema = z.object({
  // Basic Information
  ...basicInfoSchema.shape,
  
  // Lists
  responsibilities: z.array(
    z.string().min(5, 'Każdy obowiązek musi mieć co najmniej 5 znaków')
  ).min(1, 'Dodaj co najmniej jeden zakres obowiązków'),
  requirements: z.array(
    z.string().min(5, 'Każde wymaganie musi mieć co najmniej 5 znaków')
  ).min(1, 'Dodaj co najmniej jedno wymaganie'),
  niceToHave: z.array(z.string()).optional().default([]),
  technologies: z.array(z.string())
    .min(1, 'Wybierz co najmniej jedną technologię'),

  // Employment Details
  workMode: z.string()
    .min(1, 'Wybierz tryb pracy'),
  experienceLevel: z.enum(['junior', 'mid', 'senior', 'lead'], {
    errorMap: () => ({ message: 'Wybierz poziom doświadczenia' })
  }),
  contractType: z.enum(['employment', 'b2b', 'mandate', 'work'], {
    errorMap: () => ({ message: 'Wybierz typ umowy' })
  }),
  
  // Salary
  salaryFrom: z.number({
    required_error: 'Podaj minimalną kwotę wynagrodzenia',
    invalid_type_error: 'Wynagrodzenie musi być liczbą'
  }).min(1, 'Wynagrodzenie musi być większe od 0'),
  salaryTo: z.number({
    required_error: 'Podaj maksymalną kwotę wynagrodzenia',
    invalid_type_error: 'Wynagrodzenie musi być liczbą'
  }).min(1, 'Wynagrodzenie musi być większe od 0'),
  currency: z.string().default('PLN'),
  benefits: z.array(z.string()),
  
  // Location
  location: z.object({
    country: z.string().min(1, 'Wybierz kraj'),
    voivodeship: z.string().optional(),
    city: z.string().min(1, 'Wpisz nazwę miasta')
  }).refine((data) => {
    // If country is Poland, voivodeship is required
    if (data.country === 'pl') {
      return !!data.voivodeship;
    }
    return true;
  }, {
    message: "Wybierz województwo",
    path: ["voivodeship"]
  }),
  
  // Languages
  languages: z.array(z.object({
    language: z.string().min(1, 'Wybierz język'),
    level: z.string().min(1, 'Wybierz poziom znajomości języka')
  })).min(1, 'Dodaj co najmniej jeden język'),
  
  // Company Information
  company: z.object({
    name: z.string()
      .min(1, 'Nazwa firmy jest wymagana')
      .min(2, 'Nazwa firmy musi mieć co najmniej 2 znaki'),
    description: z.string()
      .min(1, 'Opis firmy jest wymagany')
      .min(50, 'Opis firmy musi mieć co najmniej 50 znaków')
      .max(1000, 'Opis firmy nie może przekraczać 1000 znaków'),
    size: z.string()
      .min(1, 'Wielkość firmy jest wymagana'),
    logo: z.any()
      .refine(val => {
        // Check if val is a File object or a non-empty string/URL
        if (val instanceof File) {
          return true;
        }
        
        if (typeof val === 'string' && val.trim() !== '') {
          return true;
        }
        
        if (val && typeof val === 'object' && val.name) {
          // This handles the case where we have a file object representation
          return true;
        }
        
        return false;
      }, {
        message: 'Logo firmy jest wymagane'
      })
  }),
  
  // Contact Information
  contact: z.object({
    name: z.string().min(3, 'Imię i nazwisko musi mieć co najmniej 3 znaki'),
    position: z.string().min(2, 'Stanowisko musi mieć co najmniej 2 znaki'),
    email: z.string().email('Podaj prawidłowy adres email'),
    phone: z.string()
      .regex(/^\+?[\d\s-]{9,}$/, 'Podaj prawidłowy numer telefonu')
      .optional()
  }),
  
  // Package Type
  packageType: z.enum(['standard', 'premium'], {
    required_error: 'Wybierz rodzaj ogłoszenia',
    invalid_type_error: 'Wybierz rodzaj ogłoszenia'
  })
});

// Export the basic info schema for first step validation
export const firstStepSchema = basicInfoSchema;