import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import Layout from './components/Layout';
import AdminLayout from './components/AdminLayout';
import AdminLogin from './pages/admin/Login';
import Dashboard from './pages/admin/Dashboard';
import Activity from './pages/admin/Activity';
import Analytics from './pages/admin/Analytics';
import Users from './pages/admin/Users';
import AdminAddJob from './pages/admin/AddJob';
import EditJob from './pages/admin/EditJob';
import Jobs from './pages/admin/Jobs';
import AdminBlog from './pages/admin/Blog';
import AddBlogPost from './pages/admin/AddBlogPost';
import AdminEditBlogPost from './pages/admin/EditBlogPost';
import SEO from './pages/admin/SEO';
import PrivacyPolicy from './pages/PrivacyPolicy';
import TermsOfService from './pages/TermsOfService';
import Payments from './pages/admin/Payments';
import Newsletter from './pages/admin/Newsletter';
import Settings from './pages/admin/Settings';
import Home from './pages/Home';
import Pricing from './components/Pricing';
import BlogPost from './components/BlogPost';
import BlogCategory from './components/BlogCategory';
import PromotionServices from './components/PromotionServices';
import SocialMedia from './components/SocialMedia';
import Contact from './components/Contact';
import Blog from './components/Blog';
import AddJobPosting from './components/AddJobPosting';
import JobPostingSummary from './components/JobPostingSummary';
import JobPostingPage from './components/JobPostingPage';
import Payment from './components/Payment';

// ScrollToTop component to reset scroll position on navigation
function ScrollToTop() {
  const { pathname } = useLocation();
  
  React.useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  
  return null;
}

export default function App() {
  return (
    <React.Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-purple-600 animate-spin" />
      </div>
    }>
      <ErrorBoundary>
        <Router>
          <ScrollToTop />
          <Routes>
            {/* Admin Routes */}
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="activity" element={<Activity />} />
              <Route path="jobs" element={<Jobs />} />
              <Route path="analytics" element={<Analytics />} />
              <Route path="users" element={<Users />} />
              <Route path="jobs/add" element={<AdminAddJob />} />
              <Route path="jobs/:id/edit" element={<EditJob />} />
              <Route path="blog" element={<AdminBlog />} />
              <Route path="blog/add" element={<AddBlogPost />} />
              <Route path="blog/:id/edit" element={<AdminEditBlogPost />} />
              <Route path="seo" element={<SEO />} />
              <Route path="payments" element={<Payments />} />
              <Route path="newsletter" element={<Newsletter />} />
              <Route path="settings" element={<Settings />} />
            </Route>
            
            {/* Public Routes */}
            <Route path="/" element={<Layout />}>
              <Route index element={<Home />} />
              <Route path="cennik" element={<Pricing />} />
              <Route path="uslugi-promocji" element={<PromotionServices />} />
              <Route path="social-media" element={<SocialMedia />} />
              <Route path="kontakt" element={<Contact />} />
              <Route path="blog" element={<Blog />} />
              <Route path="blog/:id" element={<BlogPost />} />
              <Route path="blog/category/:categoryId" element={<BlogCategory />} />
              <Route path="dodaj-ogloszenie" element={<AddJobPosting />} />
              <Route path="polityka-prywatnosci" element={<PrivacyPolicy />} />
              <Route path="regulamin" element={<TermsOfService />} />
              <Route path="dodaj-ogloszenie/podsumowanie" element={<JobPostingSummary />} />
              <Route path="oferta/:id" element={<JobPostingPage />} />
              <Route path="platnosc" element={<Payment />} />
            </Route>
          </Routes>
        </Router>
      </ErrorBoundary>
    </React.Suspense>
  );
}

// Error boundary component to catch and display errors
class ErrorBoundary extends React.Component {
  state = { hasError: false, error: null };

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    console.error("App error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl shadow-lg p-8 max-w-lg w-full">
            <h2 className="text-2xl font-bold text-purple-900 mb-4">Wystąpił błąd</h2>
            <div className="bg-red-50 p-4 rounded-lg mb-4 overflow-auto max-h-[300px]">
              <p className="text-red-700 font-mono text-sm whitespace-pre-wrap">
                {this.state.error?.toString()}
              </p>
            </div>
            <p className="text-purple-700 mb-6">
              Spróbuj odświeżyć stronę lub skontaktuj się z administratorem.
            </p>
            <div className="flex justify-between">
              <button
                onClick={() => window.location.href = '/'}
                className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
              >
                Strona główna
              </button>
              <button
                onClick={() => window.location.reload()}
                className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                Odśwież stronę
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}