import React from 'react';
import { 
  LayoutDashboard,
  Briefcase,
  BarChart,
  BookOpen,
  CreditCard,
  Mail,
  Settings, 
  Globe,
  Users
} from 'lucide-react';
import { supabase } from './supabase';

export async function isAdmin(): Promise<boolean> {
  try {
    // Get current session
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session?.user) {
      return false;
    }
    
    // Query the users table to check if user has admin role
    const { data, error } = await supabase
      .from('users')
      .select('role')
      .eq('user_id', session.user.id)
      .single();
      
    if (error || !data) {
      console.error('Error checking admin status:', error);
      return false;
    }
    
    return data.role === 'admin';
  } catch (error) {
    console.error('Error checking admin status:', error);
    return false;
  }
}

// Get user role from auth metadata
export async function getUserRole(): Promise<string | null> {
  try {
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session?.user) {
      return null;
    }

    // Check if user is admin
    if (await isAdmin()) {
      return 'admin';
    }
    
    // For other roles, query the users table
    try {
      const { data, error } = await supabase
        .from('users')
        .select('role')
        .eq('user_id', session.user.id)
        .single();
        
      if (error || !data) {
        console.error('Error getting user role:', error);
        return null;
      }

      return data.role;
    } catch (err) {
      console.error('Error querying users table:', err);
      return null;
    }
  } catch (error) {
    console.error('Error getting user role:', error);
    return null;
  }
}

// Check if user has any admin access (any role)
export async function hasAdminAccess(): Promise<boolean> {
  try {
    // Get current session
    const { data: { session } } = await supabase.auth.getSession();
    
    if (!session?.user) {
      return false;
    }
    
    // Query the users table to check if user has any admin role
    const { data, error } = await supabase
      .from('users')
      .select('role')
      .eq('user_id', session.user.id)
      .single();
      
    if (error || !data) {
      console.error('Error checking admin access:', error);
      return false;
    }
    
    // Check if role is admin, editor, or moderator
    return ['admin', 'editor', 'moderator'].includes(data.role);
  } catch (error) {
    console.error('Error checking admin access:', error);
    return false;
  }
}

// Get the landing page for the user's role
export async function getRoleLandingPage(): Promise<string> {
  const role = await getUserRole();
  
  switch (role) {
    case 'admin':
      return '/admin';
    case 'editor':
      return '/admin/blog';
    case 'moderator':
      return '/admin/jobs';
    default:
      return '/admin';
  }
}

export async function requireAdmin() {
  const isUserAdmin = await isAdmin();
  
  if (!isUserAdmin) {
    throw new Error('Unauthorized: Admin access required');
  }
}

export async function requireAdminAccess() {
  const hasAccess = await hasAdminAccess();
  
  if (!hasAccess) {
    throw new Error('Unauthorized: Admin access required');
  }
}

// Get menu items based on user role
export function getRoleBasedMenuItems(role: string) {
  // Define menu items based on role
  if (role === 'admin') {
    return [
      {
        icon: React.createElement(LayoutDashboard, { className: "w-5 h-5" }),
        label: 'Dashboard',
        path: '/admin'
      },
      {
        icon: React.createElement(Briefcase, { className: "w-5 h-5" }),
        label: 'Ogłoszenia',
        path: '/admin/jobs'
      },
      {
        icon: React.createElement(BarChart, { className: "w-5 h-5" }),
        label: 'Analityka',
        path: '/admin/analytics'
      },
      {
        icon: React.createElement(BookOpen, { className: "w-5 h-5" }),
        label: 'Blog',
        path: '/admin/blog'
      },
      {
        icon: React.createElement(CreditCard, { className: "w-5 h-5" }),
        label: 'Płatności',
        path: '/admin/payments'
      },
      {
        icon: React.createElement(Mail, { className: "w-5 h-5" }),
        label: 'Newsletter',
        path: '/admin/newsletter' 
      },
      {
        icon: React.createElement(Users, { className: "w-5 h-5" }),
        label: 'Użytkownicy',
        path: '/admin/users'
      },
      {
        icon: React.createElement(Settings, { className: "w-5 h-5" }),
        label: 'Ustawienia',
        path: '/admin/settings'
      },
      {
        icon: React.createElement(Globe, { className: "w-5 h-5" }),
        label: 'SEO',
        path: '/admin/seo'
      }
    ];
  } else if (role === 'editor') {
    return [
      {
        icon: React.createElement(BookOpen, { className: "w-5 h-5" }),
        label: 'Blog',
        path: '/admin/blog'
      }
    ];
  } else if (role === 'moderator') {
    return [
      {
        icon: React.createElement(Briefcase, { className: "w-5 h-5" }),
        label: 'Ogłoszenia',
        path: '/admin/jobs'
      },
      {
        icon: React.createElement(CreditCard, { className: "w-5 h-5" }),
        label: 'Płatności',
        path: '/admin/payments'
      }
    ];
  }
  
  // Default menu items
  return [
    {
      icon: React.createElement(LayoutDashboard, { className: "w-5 h-5" }),
      label: 'Dashboard',
      path: '/admin'
    }
  ];
}
