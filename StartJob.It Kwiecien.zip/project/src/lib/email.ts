import { supabase } from './supabase';

type EmailTemplate = {
  subject: string;
  message: string;
};

type JobApplicationEmailData = {
  candidateName: string;
  jobTitle: string;
  companyName: string;
  message: string;
};

type RecruiterNotificationEmailData = {
  candidateName: string;
  jobTitle: string;
  candidateEmail: string;
  candidatePhone?: string;
  message: string;
};

export const emailTemplates = {
  // Template for candidate confirmation
  jobApplication: (data: JobApplicationEmailData): EmailTemplate => ({
    subject: `Potwierdzenie aplikacji - ${data.jobTitle}`,
    message: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #4a3471;">Dziękujemy za Twoją aplikację!</h2>
        
        <p>Cześć ${data.candidateName},</p>
        
        <p>Dziękujemy za aplikację na stanowisko <strong>${data.jobTitle}</strong> w firmie ${data.companyName}.</p>
        
        <p>Twoja wiadomość:</p>
        <blockquote style="border-left: 4px solid #6a4ea5; margin: 0; padding: 10px 20px; color: #666;">
          ${data.message}
        </blockquote>
        
        <p>Co dalej?</p>
        <ul>
          <li>Twoja aplikacja została przekazana do rekrutera</li>
          <li>Rekruter skontaktuje się z Tobą w ciągu kilku dni roboczych</li>
          <li>W międzyczasie możesz przeglądać inne oferty na <a href="https://startjob.it" style="color: #6a4ea5;">StartJob.IT</a></li>
        </ul>
        
        <p style="margin-top: 30px; color: #666; font-size: 14px;">
          Pozdrawiamy,<br>
          Zespół StartJob.IT
        </p>
      </div>
    `
  }),

  // Template for recruiter notification
  recruiterNotification: (data: RecruiterNotificationEmailData): EmailTemplate => ({
    subject: `Nowa aplikacja - ${data.jobTitle}`,
    message: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #4a3471;">Nowa aplikacja na stanowisko ${data.jobTitle}</h2>
        
        <p>Otrzymałeś nową aplikację od kandydata:</p>
        
        <div style="background: #f5f3fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
          <p><strong>Imię i nazwisko:</strong> ${data.candidateName}</p>
          <p><strong>Email:</strong> ${data.candidateEmail}</p>
          ${data.candidatePhone ? `<p><strong>Telefon:</strong> ${data.candidatePhone}</p>` : ''}
        </div>
        
        <p><strong>Wiadomość od kandydata:</strong></p>
        <blockquote style="border-left: 4px solid #6a4ea5; margin: 0; padding: 10px 20px; color: #666;">
          ${data.message}
        </blockquote>
        
        <p style="margin-top: 30px; color: #666; font-size: 14px;">
          Wiadomość wygenerowana automatycznie przez system StartJob.IT
        </p>
      </div>
    `
  })
};

export const sendEmail = async (
  to: string,
  template: EmailTemplate,
  attachment?: File
): Promise<boolean> => {
  try {
    const formData = new FormData();
    const apiKey = "4cd6c3fb-d2ec-4426-b955-51e7e3faa4b6";
    formData.append('mail_to', to);
    formData.append('subject', template.subject);
    formData.append('message', template.message);
    formData.append('api_key', apiKey);
    
    if (attachment) {
      formData.append('attachment', attachment);
    }

    const response = await fetch('https://mail-api.startjob.it/email.php', {
      method: 'POST',
      // headers: {
      //   "Authorization": `Bearer ${apiKey}`
      // },
      body: formData
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result = await response.json();
    return result.status === 'success';
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
};