import { supabase } from './supabase';

/**
 * Uploads a company logo file to Supabase storage
 * @param file The logo file to upload
 * @param paymentId The payment ID to associate with the file
 * @returns The public URL of the uploaded file
 */
export async function uploadCompanyLogo(file: File, paymentId: string): Promise<string> {
  try {
    // Generate a unique file name
    const fileExt = file.name.split('.').pop();
    const fileName = `${paymentId}_${Date.now()}.${fileExt}`;
    const filePath = `company_logos/${fileName}`;
    
    // Upload the file to Supabase storage
    const { data, error } = await supabase.storage
      .from('job_assets')
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false
      });
    
    if (error) throw error;
    
    // Get the public URL
    const { data: urlData } = supabase.storage
      .from('job_assets')
      .getPublicUrl(filePath);
    
    return urlData.publicUrl;
  } catch (error) {
    console.error('Error uploading logo:', error);
    throw error;
  }
}

/**
 * Deletes a company logo file from Supabase storage
 * @param url The public URL of the file to delete
 */
export async function deleteCompanyLogo(url: string): Promise<void> {
  try {
    // Extract the file path from the URL
    const urlObj = new URL(url);
    const pathParts = urlObj.pathname.split('/');
    const bucketName = pathParts[1]; // e.g., 'job_assets'
    const filePath = pathParts.slice(2).join('/'); // e.g., 'company_logos/file.jpg'
    
    // Delete the file
    const { error } = await supabase.storage
      .from(bucketName)
      .remove([filePath]);
    
    if (error) throw error;
  } catch (error) {
    console.error('Error deleting logo:', error);
    throw error;
  }
}