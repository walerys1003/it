export const settings = {
  sandbox: false // Set to false in production
};

export const sampleData = {
  title: 'Senior React Developer',
  category: 'Frontend',
  description: 'Poszukujemy doświadczonego React Developera do pracy przy innowacyjnych projektach e-commerce. Oferujemy pracę w dynamicznym zespole, możliwość rozwoju i atrakcyjne wynagrodzenie.',
  responsibilities: [
    'Rozwój i utrzymanie aplikacji w React.js',
    'Projektowanie i implementacja nowych funkcjonalności',
    'Code review i mentoring młodszych programistów'
  ],
  requirements: [
    'Min. 5 lat doświadczenia w React.js',
    'Bardzo dobra znajomość TypeScript',
    'Doświadczenie w Node.js i Express'
  ],
  niceToHave: [
    'Doświadczenie w React Native',
    'Znajomość GraphQL',
    'Contributions do open source'
  ],
  technologies: ['React', 'TypeScript', 'Node.js', 'AWS', 'Docker'],
  workMode: 'hybrid',
  experienceLevel: 'senior',
  contractType: 'b2b',
  salaryFrom: 18000,
  salaryTo: 25000,
  currency: 'PLN',
  benefits: ['flexible-hours', 'medical', 'sports-card', 'training-budget'],
  location: {
    country: 'pl',
    voivodeship: 'mazowieckie',
    city: 'Warszawa'
  },
  languages: [
    { language: 'pl', level: 'B2' },
    { language: 'en', level: 'C1' }
  ],
  company: {
    name: 'TechCorp Solutions',
    description: 'TechCorp Solutions to wiodący software house specjalizujący się w tworzeniu innowacyjnych rozwiązań dla klientów z całego świata.',
    size: '200+ pracowników',
    logo: 'https://images.unsplash.com/photo-1549924231-f129b911e442?w=64&h=64&fit=crop&crop=faces'
  },
  contact: {
    name: 'Anna Kowalska',
    position: 'Senior Tech Recruiter',
    email: 'rekrutacja@techcorp.pl',
    phone: '+48 500 600 700'
  },
  packageType: 'premium'
};