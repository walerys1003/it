export const jobs = [
  {
    id: 1,
    title: 'Senior React Developer',
    company: 'TechCorp Solutions',
    logo: 'https://images.unsplash.com/photo-1549924231-f129b911e442?w=64&h=64&fit=crop&crop=faces',
    location: 'Remote / Warsaw',
    type: 'B2B',
    salary: '18 000 - 25 000 PLN',
    posted: '2h ago',
    postedDate: '2024-03-07',
    featured: true,
    isPremium: true,
    workMode: 'hybrid',
    validUntil: '2024-05-15',
    description: 'Dołącz do naszego zespołu jako Senior React Developer i twórz innowacyjne rozwiązania dla naszych klientów. Oferujemy pracę przy ciekawych projektach z wykorzystaniem najnowszych technologii.',
    responsibilities: [
      'Rozwój i utrzymanie aplikacji w React.js',
      'Projektowanie i implementacja nowych funkcjonalności',
      'Code review i mentoring młodszych programistów',
      'Współpraca z zespołem UX/UI przy projektowaniu interfejsów',
      'Optymalizacja wydajności aplikacji'
    ],
    requirements: [
      'Min. 5 lat doświadczenia w React.js',
      'Bardzo dobra znajomość TypeScript',
      'Doświadczenie w Node.js i Express',
      'Znajomość AWS i architektury cloud',
      'Umiejętność pracy w metodologii Agile'
    ],
    niceToHave: [
      'Doświadczenie w React Native',
      'Znajomość GraphQL',
      'Contributions do open source',
      'Certyfikaty AWS'
    ],
    benefits: [
      'Prywatna opieka medyczna',
      'Karta Multisport',
      'Budżet szkoleniowy 8000 PLN/rok',
      'Elastyczne godziny pracy',
      'Możliwość pracy zdalnej'
    ],
    technologies: ['React', 'TypeScript', 'Node.js', 'AWS', 'Docker'],
    languages: [
      { name: 'Polski', level: 'B2' },
      { name: 'Angielski', level: 'C1' }
    ],
    companyInfo: {
      name: 'TechCorp Solutions',
      size: '200+ pracowników',
      industry: 'Software House',
      description: 'TechCorp Solutions to wiodący software house specjalizujący się w tworzeniu innowacyjnych rozwiązań dla klientów z całego świata. Od 10 lat dostarczamy najwyższej jakości oprogramowanie dla sektora fintech, e-commerce i telekomunikacji.'
    },
    contact: {
      name: 'Anna Kowalska',
      position: 'Senior IT Recruiter',
      email: 'rekrutacja@techcorp.pl',
      phone: '+48 500 600 700'
    }
  },
  {
    id: 2,
    title: 'DevOps Engineer',
    company: 'Cloud Systems',
    logo: 'https://images.unsplash.com/photo-1552664730-d307ca884978?w=64&h=64&fit=crop&crop=faces',
    location: 'Hybrid / Kraków',
    type: 'Permanent',
    salary: '16 000 - 22 000 PLN',
    posted: '5h ago',
    postedDate: '2024-03-07',
    featured: false,
    isPremium: false,
    workMode: 'office',
    validUntil: '2024-05-01',
    description: 'Poszukujemy DevOps Engineer do zespołu Cloud Infrastructure. Oferujemy możliwość pracy z najnowszymi technologiami chmurowymi i rozwój w międzynarodowym środowisku.',
    responsibilities: [
      'Zarządzanie infrastrukturą chmurową AWS',
      'Automatyzacja procesów CI/CD',
      'Monitoring i optymalizacja wydajności systemów',
      'Wdrażanie rozwiązań containerowych',
      'Zapewnienie bezpieczeństwa infrastruktury'
    ],
    requirements: [
      'Min. 3 lata doświadczenia w DevOps',
      'Praktyczna znajomość AWS',
      'Doświadczenie z Kubernetes i Docker',
      'Znajomość Terraform i Ansible',
      'Umiejętność pisania skryptów (Python/Bash)'
    ],
    niceToHave: [
      'Certyfikaty AWS',
      'Doświadczenie z Azure lub GCP',
      'Znajomość ELK Stack',
      'Doświadczenie z Prometheus i Grafana'
    ],
    benefits: [
      'Elastyczne godziny pracy',
      'Prywatna opieka medyczna',
      'Akcje pracownicze',
      'Budżet szkoleniowy',
      'Dofinansowanie certyfikacji'
    ],
    technologies: ['Kubernetes', 'Docker', 'AWS', 'Terraform', 'Ansible'],
    languages: [
      { name: 'Polski', level: 'Ojczysty' },
      { name: 'Angielski', level: 'B2' }
    ],
    companyInfo: {
      name: 'Cloud Systems',
      size: '50-100 pracowników',
      industry: 'Cloud Computing',
      description: 'Cloud Systems to dynamicznie rozwijająca się firma specjalizująca się w rozwiązaniach chmurowych dla biznesu. Pomagamy firmom w transformacji cyfrowej i migracji do chmury.'
    },
    contact: {
      name: 'Piotr Nowak',
      position: 'Technical Recruiter',
      email: 'careers@cloudsystems.pl',
      phone: '+48 500 100 200'
    }
  }
];

export const similarJobs = [
  {
    id: 3,
    title: 'Frontend Developer',
    company: 'Digital Agency',
    location: 'Warszawa',
    type: 'B2B',
    salary: '15 000 - 20 000 PLN'
  },
  {
    id: 4,
    title: 'Full Stack Developer',
    company: 'Startup Inc',
    location: 'Remote',
    type: 'Permanent',
    salary: '17 000 - 23 000 PLN'
  },
  {
    id: 5,
    title: 'React Native Developer',
    company: 'Mobile Apps Co',
    location: 'Kraków',
    type: 'B2B',
    salary: '16 000 - 21 000 PLN'
  }
];