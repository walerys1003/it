export const jobCategories = {
  'Inżynieria Oprogramowania': [
    'Backend',
    'Frontend',
    'Fullstack',
    'Mobile',
    'Embedded',
    'Game dev'
  ],
  'Inżynieria danych i sztuczna inteligencja': [
    'AI (Artificial Intelligence)',
    'Data',
    'Business Intelligence'
  ],
  'Inżynieria Systemów i Operacje': [
    'DevOps',
    'Security',
    'Sys. Administrator',
    'IT Support'
  ],
  'Zarządzanie Projektami i Analiza Biznesowa': [
    'Project Manager',
    'Agile',
    'Product Management',
    'Business Analysis'
  ],
  'Architektura systemów': ['Architecture'],
  'Projektowanie UX/UI': ['Design'],
  'Kategorie inżynierskie': [
    'Automatyka',
    'Telekomunikacja',
    'Elektronika',
    'Robotyka',
    'Inżynieria elektryczna',
    'Mechanika'
  ],
  'Specjalistyczne i inne': [
    'ERP (Enterprise Resource Planning)',
    'Testing',
    'Inne IT'
  ]
};

export const technologies = {
  'Języki programowania i technologie front-end': [
    'JavaScript',
    'TypeScript',
    'HTML',
    'CSS',
    'React.js',
    'Angular',
    'Vue.js',
    'Sass',
    'Bootstrap'
  ],
  'Języki programowania i technologie back-end': [
    'Python',
    'Java',
    'C# (.NET)',
    'C++',
    'C',
    'PHP',
    'Ruby',
    'Node.js',
    'Express.js',
    'Go (Golang)',
    'Scala',
    'Elixir',
    'Rust',
    'Perl',
    'Shell/Bash'
  ],
  'Programowanie mobilne': [
    'Swift',
    'Kotlin',
    'React Native',
    'Flutter',
    'Objective-C',
    'Dart'
  ],
  'Technologie chmurowe i DevOps': [
    'AWS',
    'Microsoft Azure',
    'Google Cloud Platform',
    'Docker',
    'Kubernetes',
    'Terraform',
    'Ansible',
    'Jenkins',
    'Prometheus',
    'Grafana'
  ],
  'Bazy danych i zarządzanie danymi': [
    'MySQL',
    'PostgreSQL',
    'MongoDB',
    'Redis',
    'Elasticsearch',
    'SQLite',
    'Firebase',
    'Oracle'
  ],
  'API i technologie komunikacyjne': [
    'REST API',
    'GraphQL',
    'gRPC',
    'SOAP'
  ],
  'Uczenie maszynowe i sztuczna inteligencja': [
    'TensorFlow',
    'PyTorch',
    'Scikit-Learn',
    'OpenAI API',
    'Apache Spark',
    'Hadoop'
  ],
  'Bezpieczeństwo IT': [
    'SSL/TLS',
    'OAuth',
    'JWT',
    'SIEM'
  ],
  'Narzędzia do analizy danych': [
    'Power BI',
    'Tableau',
    'Jupyter Notebook',
    'Apache Kafka'
  ],
  'Inne popularne technologie i narzędzia': [
    '.NET Core',
    'Spring Boot',
    'Laravel',
    'WordPress',
    'Selenium',
    'Solidity',
    'Unity',
    'Blender'
  ],
  'Zarządzanie projektami i współpraca': [
    'Git & GitHub',
    'Jira',
    'Confluence',
    'Slack',
    'Trello'
  ],
  'Technologie przyszłości': [
    'Blockchain',
    'IoT',
    'AR/VR',
    '5G'
  ]
};

export const workModes = [
  { value: 'office', label: 'Stacjonarna' },
  { value: 'hybrid', label: 'Hybrydowa' },
  { value: 'remote', label: 'Zdalna' }
];

export const experienceLevels = [
  { value: 'junior', label: 'Junior' },
  { value: 'mid', label: 'Mid' },
  { value: 'senior', label: 'Senior' },
  { value: 'lead', label: 'Expert/Lead' }
];

export const contractTypes = [
  { value: 'employment', label: 'Umowa o pracę' },
  { value: 'b2b', label: 'Kontrakt B2B' },
  { value: 'mandate', label: 'Umowa zlecenie' },
  { value: 'work', label: 'Umowa o dzieło' }
];

export const benefits = [
  { value: 'flexible-hours', label: 'Elastyczne godziny pracy' },
  { value: '4-day-week', label: '4-dniowy tydzień pracy' },
  { value: 'training-budget', label: 'Budżet na szkolenia' },
  { value: 'medical', label: 'Prywatna opieka medyczna' },
  { value: 'sports-card', label: 'Pakiet sportowy' },
  { value: 'stock-options', label: 'Opcje na akcje' },
  { value: 'equipment', label: 'Sprzęt firmowy' },
  { value: 'abroad', label: 'Możliwość pracy za granicą' }
];

export const languages = [
  { value: 'pl', label: 'Polski' },
  { value: 'en', label: 'Angielski' },
  { value: 'de', label: 'Niemiecki' },
  { value: 'other', label: 'Inne' }
];

export const locations = {
  countries: [
    { value: 'pl', label: 'Polska' },
    { value: 'remote', label: 'Zdalnie' },
    { value: 'abroad', label: 'Zagranica' }
  ],
  voivodeships: [
    { value: 'dolnoslaskie', label: 'Dolnośląskie' },
    { value: 'kujawsko-pomorskie', label: 'Kujawsko-pomorskie' },
    { value: 'lubelskie', label: 'Lubelskie' },
    { value: 'lubuskie', label: 'Lubuskie' },
    { value: 'lodzkie', label: 'Łódzkie' },
    { value: 'malopolskie', label: 'Małopolskie' },
    { value: 'mazowieckie', label: 'Mazowieckie' },
    { value: 'opolskie', label: 'Opolskie' },
    { value: 'podkarpackie', label: 'Podkarpackie' },
    { value: 'podlaskie', label: 'Podlaskie' },
    { value: 'pomorskie', label: 'Pomorskie' },
    { value: 'slaskie', label: 'Śląskie' },
    { value: 'swietokrzyskie', label: 'Świętokrzyskie' },
    { value: 'warminsko-mazurskie', label: 'Warmińsko-mazurskie' },
    { value: 'wielkopolskie', label: 'Wielkopolskie' },
    { value: 'zachodniopomorskie', label: 'Zachodniopomorskie' }
  ]
};