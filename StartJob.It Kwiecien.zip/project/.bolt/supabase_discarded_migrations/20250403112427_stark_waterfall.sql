/*
  # Add company size ordering function

  1. New Functions
    - `company_size_order`: Function to order company sizes correctly
    - Returns the range_from value for proper ordering

  2. Security
    - Function is immutable for better performance
    - No special permissions needed
*/

-- Create a function to order company sizes correctly
CREATE OR REPLACE FUNCTION company_size_order(company_sizes)
RETURNS integer AS $$
BEGIN
  RETURN $1.range_from;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create an index using the custom ordering function
CREATE INDEX IF NOT EXISTS company_sizes_order_idx ON company_sizes(company_size_order(company_sizes));