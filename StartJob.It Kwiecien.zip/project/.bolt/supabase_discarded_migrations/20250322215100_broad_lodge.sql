/*
  # Add code column to job_categories

  1. Changes
    - Add code column to job_categories table
    - Make code column required and unique
    - Generate code from name for existing records
    - Add index for faster lookups

  2. Security
    - Maintain existing RLS policies
*/

-- Add code column to job_categories
ALTER TABLE job_categories 
ADD COLUMN code text;

-- Update existing records to generate code from name
UPDATE job_categories
SET code = LOWER(REGEXP_REPLACE(name, '\s+', '-', 'g'));

-- Make code column required and unique
ALTER TABLE job_categories 
ALTER COLUMN code SET NOT NULL,
ADD CONSTRAINT job_categories_code_key UNIQUE (code);

-- Add index for code lookups
CREATE INDEX IF NOT EXISTS job_categories_code_idx ON job_categories(code);

-- Add comment
COMMENT ON COLUMN job_categories.code IS 'URL-friendly version of the category name';