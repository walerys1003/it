/*
  # Fix admin user update and delete functionality

  1. Changes
    - Create functions for updating and deleting admin users
    - Fix issues with user ID handling
    - Ensure proper error handling and validation
    - Update functions to work with the new admin_users structure

  2. Security
    - Maintain existing security checks
    - Keep audit logging
*/

-- Create function to update admin user
CREATE OR REPLACE FUNCTION update_admin_user(
  p_admin_id uuid,
  p_name text,
  p_role text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_old_role text;
  v_email text;
  v_old_metadata jsonb;
  v_new_metadata jsonb;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Validate role
  IF p_role NOT IN ('admin', 'super_admin', 'redaktor', 'moderator') THEN
    RAISE EXCEPTION 'Invalid role specified';
  END IF;

  -- Start transaction
  BEGIN
    -- Get current user data for logging
    SELECT 
      au.user_id,
      u.email,
      u.raw_user_meta_data,
      au.role
    INTO 
      v_user_id,
      v_email,
      v_old_metadata,
      v_old_role
    FROM 
      admin_users au
    JOIN 
      auth.users u ON au.user_id = u.id
    WHERE 
      au.id = p_admin_id;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Admin user not found';
    END IF;

    -- Update user metadata
    v_new_metadata := v_old_metadata || jsonb_build_object('name', p_name);
    
    UPDATE auth.users
    SET 
      raw_user_meta_data = v_new_metadata,
      updated_at = now()
    WHERE id = v_user_id;

    -- Update admin role
    UPDATE admin_users
    SET 
      role = p_role,
      updated_at = now()
    WHERE id = p_admin_id;

    -- Log the action
    INSERT INTO admin_audit_log (
      admin_id,
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'update_admin_user',
      'admin_users',
      p_admin_id,
      jsonb_build_object(
        'email', v_email,
        'old_role', v_old_role,
        'new_role', p_role,
        'old_metadata', v_old_metadata,
        'new_metadata', v_new_metadata,
        'updated_at', now()
      )
    );

    RETURN true;
  EXCEPTION
    WHEN others THEN
      -- Log the error
      INSERT INTO admin_audit_log (
        admin_id,
        action,
        entity_type,
        entity_id,
        details
      ) VALUES (
        auth.uid(),
        'update_admin_user_error',
        'admin_users',
        p_admin_id,
        jsonb_build_object(
          'error', SQLERRM,
          'email', v_email,
          'old_role', v_old_role,
          'new_role', p_role
        )
      );
      
      RAISE;
  END;
END;
$$;

-- Create function to delete admin user
CREATE OR REPLACE FUNCTION delete_user_completely(
  p_admin_id uuid
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_email text;
  v_role text;
  v_name text;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Get user details for logging
  SELECT 
    au.user_id,
    u.email, 
    au.role,
    COALESCE(u.raw_user_meta_data->>'name', 'Unknown')
  INTO 
    v_user_id,
    v_email, 
    v_role,
    v_name
  FROM admin_users au
  JOIN auth.users u ON au.user_id = u.id
  WHERE au.id = p_admin_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Admin user not found';
  END IF;

  -- Prevent deleting super_admin
  IF v_role = 'super_admin' THEN
    RAISE EXCEPTION 'Super admin cannot be deleted';
  END IF;

  -- Log the deletion attempt
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'delete_user_attempt',
    'admin_users',
    p_admin_id,
    jsonb_build_object(
      'email', v_email,
      'role', v_role,
      'name', v_name,
      'user_id', v_user_id,
      'attempted_at', now()
    )
  );

  -- Delete from admin_users first
  DELETE FROM admin_users WHERE id = p_admin_id;
  
  -- Then delete from auth.users
  DELETE FROM auth.users WHERE id = v_user_id;

  -- Log successful deletion
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'delete_user_success',
    'admin_users',
    p_admin_id,
    jsonb_build_object(
      'email', v_email,
      'role', v_role,
      'name', v_name,
      'user_id', v_user_id,
      'deleted_at', now()
    )
  );

  RETURN true;
EXCEPTION
  WHEN others THEN
    -- Log the error
    INSERT INTO admin_audit_log (
      admin_id,
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'delete_user_error',
      'admin_users',
      p_admin_id,
      jsonb_build_object(
        'error', SQLERRM,
        'email', v_email,
        'role', v_role,
        'name', v_name,
        'user_id', v_user_id
      )
    );
    
    RAISE;
END;
$$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION update_admin_user(uuid, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION delete_user_completely(uuid) TO authenticated;

-- Add comments
COMMENT ON FUNCTION update_admin_user(uuid, text, text) IS 'Updates an admin user with proper error handling and logging';
COMMENT ON FUNCTION delete_user_completely(uuid) IS 'Completely deletes a user from both admin_users and auth.users tables';