/*
  # Create admin_emails view

  1. New Views
    - `admin_emails`: View that provides access to admin user emails
    - Simplifies access to admin user information
    - Fixes the "relation admin_emails does not exist" error

  2. Security
    - Maintains existing RLS policies
    - Provides secure access to admin user information
*/

-- Create admin_emails view
CREATE OR REPLACE VIEW admin_emails AS
SELECT 
  u.id,
  u.email,
  us.role
FROM 
  auth.users u
JOIN 
  users us ON u.id = us.user_id
WHERE 
  us.role = 'admin';

-- Grant necessary permissions
GRANT SELECT ON admin_emails TO authenticated;

-- Add comment
COMMENT ON VIEW admin_emails IS 'View that provides access to admin user emails';