/*
  # Restructure admin_users table

  1. Changes
    - Create new admin_users table with user_id reference to auth.users
    - Add role column with admin, super_admin, redaktor, moderator options
    - Create super_admin role for admin@startjob.pl
    - Update RLS policies for proper access control

  2. Security
    - Only admins and super_admins can manage users
    - Super_admin cannot be deleted from admin panel
    - Maintain audit logging
*/

-- First, create a temporary function to check if user is admin or super_admin
-- This will be used during the transition
CREATE OR REPLACE FUNCTION is_admin_temp()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- During migration, always return true to avoid permission issues
  RETURN true;
END;
$$;

-- Update existing policies to use the temporary function
DO $$
DECLARE
  policy_record RECORD;
BEGIN
  FOR policy_record IN
    SELECT 
      schemaname, 
      tablename, 
      policyname
    FROM 
      pg_policies 
    WHERE 
      policyname IN (
        'Jobs viewing policy',
        'Admins can delete jobs',
        'Admins can update jobs',
        'Blog posts viewing and editing policy',
        'Blog post tags viewing and editing policy',
        'Admins can manage settings',
        'Admins can manage job categories',
        'Admins can manage working modes',
        'Admins can manage experience levels',
        'Admins can manage contract types',
        'Admins can manage benefits',
        'Admins can manage languages',
        'Admins can manage company sizes',
        'Admins can manage technologies',
        'Admins can manage SEO pages'
      )
  LOOP
    EXECUTE format('ALTER POLICY %I ON %I.%I USING (is_admin_temp());', 
                  policy_record.policyname, 
                  policy_record.schemaname, 
                  policy_record.tablename);
    
    -- For policies that have WITH CHECK clause
    BEGIN
      EXECUTE format('ALTER POLICY %I ON %I.%I WITH CHECK (is_admin_temp());', 
                    policy_record.policyname, 
                    policy_record.schemaname, 
                    policy_record.tablename);
    EXCEPTION WHEN OTHERS THEN
      -- Some policies might not have WITH CHECK clause
      NULL;
    END;
  END LOOP;
END $$;

-- Now we can safely drop the existing functions and tables
DROP TRIGGER IF EXISTS validate_admin_user_operation ON admin_users;
DROP TRIGGER IF EXISTS log_admin_user_operation ON admin_users;
DROP FUNCTION IF EXISTS validate_admin_operation_v2() CASCADE;
DROP FUNCTION IF EXISTS is_admin() CASCADE;
DROP FUNCTION IF EXISTS has_admin_role() CASCADE;
DROP TABLE IF EXISTS admin_users CASCADE;

-- Create new admin_users table
CREATE TABLE admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('admin', 'super_admin', 'redaktor', 'moderator')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id)
);

-- Add trigger for updating updated_at
CREATE TRIGGER update_admin_users_updated_at
  BEFORE UPDATE ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create function to check if user is admin or super_admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  );
END;
$$;

-- Create function to validate admin operations
CREATE OR REPLACE FUNCTION validate_admin_operation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Check if user is authenticated
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Authentication required';
  END IF;

  -- Check if user is admin or super_admin
  IF NOT EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Prevent deletion of super_admin
  IF TG_OP = 'DELETE' AND OLD.role = 'super_admin' THEN
    RAISE EXCEPTION 'Super admin cannot be deleted';
  END IF;

  -- Prevent changing super_admin role
  IF TG_OP = 'UPDATE' AND OLD.role = 'super_admin' AND NEW.role != 'super_admin' THEN
    RAISE EXCEPTION 'Super admin role cannot be changed';
  END IF;

  -- Allow the operation to proceed
  RETURN NEW;
END;
$$;

-- Create trigger for admin operations validation
CREATE TRIGGER validate_admin_user_operation
  BEFORE INSERT OR UPDATE OR DELETE
  ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION validate_admin_operation();

-- Create function to log admin operations
-- Fixed: Using TG_ARGV instead of declared arguments
CREATE OR REPLACE FUNCTION log_admin_operation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    TG_ARGV[0],
    TG_TABLE_NAME,
    NEW.id,
    row_to_json(NEW)
  );
  RETURN NEW;
END;
$$;

-- Create trigger for logging admin operations
-- Fixed: Passing the operation as an argument to the trigger
CREATE TRIGGER log_admin_user_operation
  AFTER INSERT OR UPDATE
  ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION log_admin_operation('admin_user_modified');

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Admins can manage admin users"
  ON admin_users
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1
      FROM admin_users
      WHERE user_id = auth.uid()
      AND role IN ('admin', 'super_admin')
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1
      FROM admin_users
      WHERE user_id = auth.uid()
      AND role IN ('admin', 'super_admin')
    )
  );

-- Add policy to allow direct deletion from dashboard
CREATE POLICY "Allow direct admin_users deletion from dashboard"
  ON admin_users
  FOR DELETE
  TO public
  USING (is_supabase_dashboard());

-- Find admin@startjob.pl user or create if not exists
DO $$
DECLARE
  v_user_id uuid;
  v_admin_id uuid;
  v_email text := 'admin@startjob.pl';
  v_hashed_password text;
BEGIN
  -- Check if user exists
  SELECT id INTO v_user_id
  FROM auth.users
  WHERE email = v_email;

  -- If user doesn't exist, create it
  IF v_user_id IS NULL THEN
    -- Generate hashed password
    v_hashed_password := crypt('Startjob25!', gen_salt('bf'));
    
    -- Create user
    INSERT INTO auth.users (
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      aud,
      role
    ) VALUES (
      v_email,
      v_hashed_password,
      now(),
      '{"provider": "email", "providers": ["email"]}'::jsonb,
      '{"name": "Super Admin"}'::jsonb,
      now(),
      now(),
      'authenticated',
      'authenticated'
    )
    RETURNING id INTO v_user_id;
    
    RAISE NOTICE 'Created super admin user with ID %', v_user_id;
  ELSE
    RAISE NOTICE 'Found existing user with ID %', v_user_id;
  END IF;

  -- Add as super_admin
  INSERT INTO admin_users (
    user_id,
    role
  ) VALUES (
    v_user_id,
    'super_admin'
  )
  ON CONFLICT (user_id) DO UPDATE
  SET role = 'super_admin';
  
  RAISE NOTICE 'Set user % as super_admin', v_email;
  
  -- Log the action
  INSERT INTO admin_audit_log (
    action,
    entity_type,
    details
  ) VALUES (
    'create_super_admin',
    'admin_users',
    jsonb_build_object(
      'email', v_email,
      'created_at', now()
    )
  );
END $$;

-- Create view for admin user emails
CREATE OR REPLACE VIEW admin_user_emails AS
SELECT 
  au.id,
  au.user_id,
  au.role,
  u.email
FROM 
  admin_users au
JOIN 
  auth.users u ON au.user_id = u.id;

-- Grant necessary permissions
GRANT SELECT ON admin_user_emails TO authenticated;

-- Update all policies to use the new is_admin function
DO $$
DECLARE
  policy_record RECORD;
BEGIN
  FOR policy_record IN
    SELECT 
      schemaname, 
      tablename, 
      policyname
    FROM 
      pg_policies 
    WHERE 
      policyname IN (
        'Jobs viewing policy',
        'Admins can delete jobs',
        'Admins can update jobs',
        'Blog posts viewing and editing policy',
        'Blog post tags viewing and editing policy',
        'Admins can manage settings',
        'Admins can manage job categories',
        'Admins can manage working modes',
        'Admins can manage experience levels',
        'Admins can manage contract types',
        'Admins can manage benefits',
        'Admins can manage languages',
        'Admins can manage company sizes',
        'Admins can manage technologies',
        'Admins can manage SEO pages'
      )
  LOOP
    EXECUTE format('ALTER POLICY %I ON %I.%I USING (is_admin());', 
                  policy_record.policyname, 
                  policy_record.schemaname, 
                  policy_record.tablename);
    
    -- For policies that have WITH CHECK clause
    BEGIN
      EXECUTE format('ALTER POLICY %I ON %I.%I WITH CHECK (is_admin());', 
                    policy_record.policyname, 
                    policy_record.schemaname, 
                    policy_record.tablename);
    EXCEPTION WHEN OTHERS THEN
      -- Some policies might not have WITH CHECK clause
      NULL;
    END;
  END LOOP;
END $$;

-- Drop the temporary function
DROP FUNCTION IF EXISTS is_admin_temp();

-- Add comments
COMMENT ON TABLE admin_users IS 'Stores admin user roles and permissions';
COMMENT ON COLUMN admin_users.user_id IS 'Reference to auth.users table';
COMMENT ON COLUMN admin_users.role IS 'User role: super_admin, admin, redaktor, moderator';
COMMENT ON FUNCTION is_admin() IS 'Checks if the current user has admin or super_admin role';
COMMENT ON FUNCTION validate_admin_operation() IS 'Validates admin operations and prevents super_admin deletion';
COMMENT ON FUNCTION log_admin_operation() IS 'Logs admin operations for audit purposes';