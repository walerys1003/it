/*
  # Fix admin user creation functionality

  1. Changes
    - Create a new function for creating admin users
    - Fix the issue with user ID handling
    - Ensure proper error handling and validation
    - Update admin_user_view to work with the new admin_users structure

  2. Security
    - Maintain existing security checks
    - Keep audit logging
*/

-- Create function to create admin user
CREATE OR REPLACE FUNCTION create_admin_user(
  p_email TEXT,
  p_password TEXT,
  p_name TEXT,
  p_role TEXT
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_admin_id uuid;
  v_result jsonb;
  v_hashed_password text;
BEGIN
  -- Input validation
  IF p_email IS NULL OR p_email = '' THEN
    RAISE EXCEPTION 'Email cannot be empty';
  END IF;

  IF p_password IS NULL OR length(p_password) < 6 THEN
    RAISE EXCEPTION 'Password must be at least 6 characters long';
  END IF;

  IF p_role NOT IN ('admin', 'super_admin', 'redaktor', 'moderator') THEN
    RAISE EXCEPTION 'Invalid role specified';
  END IF;

  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Generate hashed password
  v_hashed_password := crypt(p_password, gen_salt('bf'));

  -- Create user in auth.users
  INSERT INTO auth.users (
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at,
    aud,
    role
  ) VALUES (
    p_email,
    v_hashed_password,
    now(),
    '{"provider": "email", "providers": ["email"]}'::jsonb,
    jsonb_build_object('name', p_name),
    now(),
    now(),
    'authenticated',
    'authenticated'
  )
  RETURNING id INTO v_user_id;

  -- Create admin user record
  INSERT INTO admin_users (
    user_id,
    role
  ) VALUES (
    v_user_id,
    p_role
  )
  RETURNING id INTO v_admin_id;

  -- Log the action
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'create_admin_user',
    'admin_users',
    v_admin_id,
    jsonb_build_object(
      'email', p_email,
      'role', p_role,
      'user_id', v_user_id,
      'created_at', now()
    )
  );

  -- Return success response
  v_result := jsonb_build_object(
    'success', true,
    'user', jsonb_build_object(
      'id', v_admin_id,
      'user_id', v_user_id,
      'email', p_email,
      'role', p_role
    )
  );

  RETURN v_result;

EXCEPTION WHEN OTHERS THEN
  -- Return error response
  RETURN jsonb_build_object(
    'success', false,
    'error', SQLERRM
  );
END;
$$;

-- Update admin_user_view to work with the new admin_users structure
DROP VIEW IF EXISTS admin_user_view;

CREATE OR REPLACE VIEW admin_user_view AS
SELECT 
  au.id,
  au.user_id,
  u.email,
  u.raw_user_meta_data as user_metadata,
  u.created_at,
  au.role as admin_role
FROM 
  admin_users au
JOIN 
  auth.users u ON au.user_id = u.id
WHERE EXISTS (
  SELECT 1 
  FROM admin_users 
  WHERE user_id = auth.uid()
  AND role IN ('admin', 'super_admin')
);

-- Grant necessary permissions
GRANT SELECT ON admin_user_view TO authenticated;
GRANT EXECUTE ON FUNCTION create_admin_user(TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- Add comments
COMMENT ON FUNCTION create_admin_user(TEXT, TEXT, TEXT, TEXT) IS 'Creates a new admin user with proper error handling and logging';
COMMENT ON VIEW admin_user_view IS 'Secure view for admin users to manage system users';