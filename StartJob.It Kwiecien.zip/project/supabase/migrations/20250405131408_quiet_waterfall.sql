/*
  # Add get_user_role function

  1. New Functions
    - `get_user_role`: Function to get a user's role from admin_users table
    - Returns the role as text or null if not found
    - Used for role-based access control

  2. Security
    - Function is security definer
    - Proper error handling
*/

-- Create function to get user role
CREATE OR REPLACE FUNCTION get_user_role(user_id uuid DEFAULT auth.uid())
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role text;
BEGIN
  -- Get user role from admin_users table
  SELECT role INTO v_role
  FROM admin_users
  WHERE id = user_id;
  
  RETURN v_role;
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Error getting user role: %', SQLERRM;
    RETURN NULL;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION get_user_role(uuid) TO authenticated;

-- Add comment
COMMENT ON FUNCTION get_user_role(uuid) IS 'Gets the role of a user from admin_users table';