/*
  # Fix company size order

  1. Changes
    - Update company_sizes table to ensure proper ordering
    - Add custom ordering for company sizes
    - Ensure "1000+" appears last in the list

  2. Notes
    - Uses range_from field for ordering
    - Maintains existing data
*/

-- Update range_from values to ensure proper ordering
UPDATE company_sizes
SET range_from = 
  CASE code
    WHEN '1-10' THEN 1
    WHEN '11-50' THEN 11
    WHEN '51-200' THEN 51
    WHEN '201-500' THEN 201
    WHEN '501-1000' THEN 501
    WHEN '1000+' THEN 1001
    ELSE range_from
  END;

-- Create a function to order company sizes correctly
CREATE OR REPLACE FUNCTION company_size_order(company_sizes)
RETURNS integer AS $$
BEGIN
  RETURN $1.range_from;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Create an index using the custom ordering function
CREATE INDEX IF NOT EXISTS company_sizes_order_idx ON company_sizes(company_size_order(company_sizes));