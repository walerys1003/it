/*
  # Remove user authentication dependency

  1. Changes
    - Drop all policies that depend on user_id
    - Drop foreign key constraints
    - Remove user_id columns
    - Create new public policies
    - Update handle_job_payment function

  2. Security
    - Enable RLS on all tables
    - Add public policies for job creation and viewing
*/

-- First drop all dependent policies
DROP POLICY IF EXISTS "Anyone can view active jobs" ON jobs;
DROP POLICY IF EXISTS "Authenticated users can create jobs" ON jobs;
DROP POLICY IF EXISTS "Users can update own jobs" ON jobs;
DROP POLICY IF EXISTS "Users can delete own jobs" ON jobs;
DROP POLICY IF EXISTS "Users can view their own payments" ON payments;
DROP POLICY IF EXISTS "Users can create payments" ON payments;
DROP POLICY IF EXISTS "Users can view their own payment logs" ON payment_logs;

-- Drop existing function that depends on auth
DROP FUNCTION IF EXISTS handle_job_payment(jsonb, jsonb);

-- Drop foreign key constraints
ALTER TABLE jobs DROP CONSTRAINT IF EXISTS jobs_user_id_fkey CASCADE;
ALTER TABLE payment_logs DROP CONSTRAINT IF EXISTS payment_logs_user_id_fkey CASCADE;

-- Remove user_id columns
ALTER TABLE jobs DROP COLUMN IF EXISTS user_id;
ALTER TABLE payment_logs DROP COLUMN IF EXISTS user_id;

-- Create new policies for jobs
CREATE POLICY "Anyone can view active jobs"
  ON jobs
  FOR SELECT
  USING (is_active = true AND valid_until > now());

CREATE POLICY "Anyone can create jobs"
  ON jobs
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create new policies for payments
CREATE POLICY "Public can view payments"
  ON payments
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can create payments"
  ON payments
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Create new policies for payment_logs
CREATE POLICY "Public can view payment logs"
  ON payment_logs
  FOR SELECT
  TO public
  USING (true);

-- Create improved function without user_id dependency
CREATE OR REPLACE FUNCTION handle_job_payment(
  job_data jsonb,
  payment_data jsonb
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_job_id uuid;
  new_payment_id uuid;
  log_id uuid;
BEGIN
  -- Create initial log entry
  INSERT INTO payment_logs (job_data, payment_data)
  VALUES (job_data, payment_data)
  RETURNING id INTO log_id;

  -- Input validation with detailed logging
  IF job_data IS NULL THEN
    UPDATE payment_logs 
    SET error_message = 'job_data cannot be null',
        success = false 
    WHERE id = log_id;
    RAISE EXCEPTION 'job_data cannot be null';
  END IF;

  IF payment_data IS NULL THEN
    UPDATE payment_logs 
    SET error_message = 'payment_data cannot be null',
        success = false 
    WHERE id = log_id;
    RAISE EXCEPTION 'payment_data cannot be null';
  END IF;

  -- Start transaction
  BEGIN
    -- Insert job
    INSERT INTO jobs (
      title,
      category,
      description,
      responsibilities,
      requirements,
      nice_to_have,
      technologies,
      work_mode,
      experience_level,
      contract_type,
      salary_from,
      salary_to,
      currency,
      benefits,
      location_country,
      location_voivodeship,
      location_city,
      languages,
      company_name,
      company_description,
      company_size,
      company_logo,
      contact_name,
      contact_position,
      contact_email,
      contact_phone,
      valid_until,
      is_active,
      is_featured,
      is_premium
    )
    VALUES (
      job_data->>'title',
      job_data->>'category',
      job_data->>'description',
      ARRAY(SELECT jsonb_array_elements_text(job_data->'responsibilities')),
      ARRAY(SELECT jsonb_array_elements_text(job_data->'requirements')),
      ARRAY(SELECT jsonb_array_elements_text(COALESCE(job_data->'niceToHave', '[]'::jsonb))),
      ARRAY(SELECT jsonb_array_elements_text(job_data->'technologies')),
      job_data->>'workMode',
      job_data->>'experienceLevel',
      job_data->>'contractType',
      (job_data->>'salaryFrom')::integer,
      (job_data->>'salaryTo')::integer,
      COALESCE(job_data->>'currency', 'PLN'),
      ARRAY(SELECT jsonb_array_elements_text(COALESCE(job_data->'benefits', '[]'::jsonb))),
      job_data->'location'->>'country',
      job_data->'location'->>'voivodeship',
      job_data->'location'->>'city',
      ARRAY(SELECT jsonb_array_elements(COALESCE(job_data->'languages', '[]'::jsonb))),
      job_data->'company'->>'name',
      job_data->'company'->>'description',
      job_data->'company'->>'size',
      job_data->'company'->>'logo',
      job_data->'contact'->>'name',
      job_data->'contact'->>'position',
      job_data->'contact'->>'email',
      job_data->'contact'->>'phone',
      CURRENT_TIMESTAMP + INTERVAL '90 days',
      false,
      job_data->>'packageType' = 'premium',
      job_data->>'packageType' = 'premium'
    )
    RETURNING id INTO new_job_id;

    -- Insert payment
    INSERT INTO payments (
      job_id,
      amount,
      currency,
      status,
      package_type,
      payment_method,
      invoice_data
    )
    VALUES (
      new_job_id,
      CASE 
        WHEN job_data->>'packageType' = 'premium' THEN 899.00
        ELSE 599.00
      END,
      'PLN',
      'pending',
      job_data->>'packageType',
      payment_data->>'paymentMethod',
      payment_data->'invoiceData'
    )
    RETURNING id INTO new_payment_id;

    -- Update log with success
    UPDATE payment_logs 
    SET success = true,
        created_job_id = new_job_id,
        created_payment_id = new_payment_id
    WHERE id = log_id;

    RETURN new_payment_id;
  EXCEPTION
    WHEN others THEN
      -- Log the error details
      UPDATE payment_logs 
      SET error_message = SQLERRM,
          error_detail = SQLSTATE,
          success = false
      WHERE id = log_id;
      
      RAISE;
  END;
END;
$$;

-- Grant execute permission to public
GRANT EXECUTE ON FUNCTION handle_job_payment(jsonb, jsonb) TO public;