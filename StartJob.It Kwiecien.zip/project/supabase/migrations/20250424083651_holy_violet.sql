/*
  # Fix admin authentication system

  1. Changes
    - Update is_admin function to check users table instead of hardcoded emails
    - Add function to check for specific admin roles
    - Update RLS policies to use the new functions

  2. Security
    - Maintain proper access control
    - Keep audit logging
*/

-- Create a function to check admin status from users table
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_role text;
BEGIN
  -- Get current user's role from users table
  SELECT role INTO user_role
  FROM users
  WHERE user_id = auth.uid();
  
  -- Check if role is admin
  RETURN user_role = 'admin';
EXCEPTION
  WHEN others THEN
    RETURN false;
END;
$$;

-- Create a function to check for any admin role (admin, editor, moderator)
CREATE OR REPLACE FUNCTION has_admin_access()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_role text;
BEGIN
  -- Get current user's role from users table
  SELECT role INTO user_role
  FROM users
  WHERE user_id = auth.uid();
  
  -- Check if role is any admin type
  RETURN user_role IN ('admin', 'editor', 'moderator');
EXCEPTION
  WHEN others THEN
    RETURN false;
END;
$$;

-- Update RLS policies to use the new functions
DO $$
DECLARE
  table_name text;
BEGIN
  -- List of tables that had admin-only policies
  FOR table_name IN (
    SELECT tablename FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename IN (
      'blog_posts', 'blog_taxonomies', 'blog_post_tags',
      'job_categories', 'working_modes', 'experience_levels',
      'contract_types', 'benefits', 'languages',
      'company_sizes', 'technologies', 'seo_pages',
      'site_settings'
    )
  )
  LOOP
    -- Drop existing admin policies
    EXECUTE 'DROP POLICY IF EXISTS "Admins can manage ' || table_name || '" ON ' || table_name;
    
    -- Create new admin policies
    EXECUTE '
      CREATE POLICY "Admins can manage ' || table_name || '"
      ON ' || table_name || '
      FOR ALL
      TO public
      USING (is_admin())
      WITH CHECK (is_admin())
    ';
  END LOOP;
END $$;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION is_admin() TO public;
GRANT EXECUTE ON FUNCTION has_admin_access() TO public;

-- Add comments
COMMENT ON FUNCTION is_admin() IS 'Checks if the current user has admin role in the users table';
COMMENT ON FUNCTION has_admin_access() IS 'Checks if the current user has any admin role (admin, editor, moderator) in the users table';