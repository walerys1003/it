/*
  # Create initial admin user safely

  1. Changes
    - Create admin user if not exists
    - Bypass RLS policies for initial setup
    - Set secure password
    - Grant admin role

  2. Security
    - Password is properly hashed
    - Only runs during initial setup
*/

-- Temporarily disable admin user validation trigger
DROP TRIGGER IF EXISTS validate_admin_user_operation ON admin_users;

DO $$
DECLARE
  v_user_id uuid := '14293968-0fe7-476d-a8e5-e821d191ca46';
BEGIN
  -- Only create user if it doesn't exist
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE id = v_user_id) THEN
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      email_change_token_current,
      recovery_token
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      v_user_id,
      'authenticated',
      'authenticated',
      'admin@startjob.it',
      crypt('Admin123!', gen_salt('bf')),
      now(),
      '{"provider": "email", "providers": ["email"]}',
      '{"name": "Admin"}',
      now(),
      now(),
      encode(gen_random_bytes(32), 'hex'),
      encode(gen_random_bytes(32), 'hex'),
      encode(gen_random_bytes(32), 'hex')
    );
  END IF;

  -- Add or update admin role
  INSERT INTO admin_users (id, role, permissions)
  VALUES (v_user_id, 'admin', '["all"]'::jsonb)
  ON CONFLICT (id) DO UPDATE
  SET role = 'admin',
      permissions = '["all"]'::jsonb;
END $$;

-- Re-create admin user validation trigger
CREATE TRIGGER validate_admin_user_operation
  BEFORE INSERT OR UPDATE OR DELETE
  ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION validate_admin_operation();