/*
  # Add users table

  1. New Tables
    - `users`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `role` (text)

  2. Security
    - Enable RLS on `users` table
    - Add policy for public read access
    - Add policy for admin write access

  3. Notes
    - Stores user roles and permissions
    - Replaces the previous admin_users table with a simpler structure
    - All users can view the table, only admins can modify it
*/

-- Create users table
CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create index for user_id
CREATE INDEX users_user_id_idx ON users(user_id);

-- Add trigger for updating updated_at
CREATE TRIGGER update_users_updated_at
  BEFORE UPDATE ON users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Anyone can view users"
  ON users
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admins can manage users"
  ON users
  FOR ALL
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());

-- Create function to get user role
CREATE OR REPLACE FUNCTION get_user_role(p_user_id uuid DEFAULT auth.uid())
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role text;
BEGIN
  -- Get user role from users table
  SELECT role INTO v_role
  FROM users
  WHERE user_id = p_user_id;
  
  -- If no role found, check if user is admin
  IF v_role IS NULL AND is_admin() THEN
    RETURN 'admin';
  END IF;
  
  RETURN v_role;
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Error getting user role: %', SQLERRM;
    RETURN NULL;
END;
$$;

-- Grant execute permission
GRANT EXECUTE ON FUNCTION get_user_role(uuid) TO public;

-- Add comment
COMMENT ON TABLE users IS 'Stores user roles and permissions';
COMMENT ON FUNCTION get_user_role(uuid) IS 'Gets the role of a user from users table';

-- Insert admin user if not exists
DO $$
DECLARE
  admin_id uuid;
BEGIN
  -- Get admin user ID
  SELECT id INTO admin_id
  FROM auth.users
  WHERE email = 'admin@startjob.it';
  
  -- Insert admin into users table if found
  IF admin_id IS NOT NULL THEN
    INSERT INTO users (user_id, role)
    VALUES (admin_id, 'admin')
    ON CONFLICT (id) DO NOTHING;
    
    RAISE NOTICE 'Added admin user to users table';
  END IF;
END $$;

-- Insert a log entry about this change
INSERT INTO admin_audit_log (
  action,
  entity_type,
  details
)
VALUES (
  'add_users_table',
  'system',
  jsonb_build_object(
    'description', 'Added users table with role-based access control',
    'timestamp', now()
  )
);