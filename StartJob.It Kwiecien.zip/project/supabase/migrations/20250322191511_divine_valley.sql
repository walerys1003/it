/*
  # Remove sort_order column and use alphabetical sorting

  1. Changes
    - Drop sort_order column from all job option tables
    - Update queries to sort by name
    - Keep existing data and functionality

  2. Security
    - Maintain existing RLS policies
    - Keep table comments
*/

-- Remove sort_order from job_categories
ALTER TABLE job_categories DROP COLUMN sort_order;

-- Remove sort_order from working_modes
ALTER TABLE working_modes DROP COLUMN sort_order;

-- Remove sort_order from experience_levels
ALTER TABLE experience_levels DROP COLUMN sort_order;

-- Remove sort_order from contract_types
ALTER TABLE contract_types DROP COLUMN sort_order;

-- Remove sort_order from benefits
ALTER TABLE benefits DROP COLUMN sort_order;

-- Remove sort_order from languages
ALTER TABLE languages DROP COLUMN sort_order;

-- Remove sort_order from company_sizes
ALTER TABLE company_sizes DROP COLUMN sort_order;

-- Create indexes for name columns to improve sorting performance
CREATE INDEX IF NOT EXISTS job_categories_name_idx ON job_categories(name);
CREATE INDEX IF NOT EXISTS working_modes_name_idx ON working_modes(name);
CREATE INDEX IF NOT EXISTS experience_levels_name_idx ON experience_levels(name);
CREATE INDEX IF NOT EXISTS contract_types_name_idx ON contract_types(name);
CREATE INDEX IF NOT EXISTS benefits_name_idx ON benefits(name);
CREATE INDEX IF NOT EXISTS languages_name_idx ON languages(name);
CREATE INDEX IF NOT EXISTS company_sizes_name_idx ON company_sizes(name);