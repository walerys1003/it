/*
  # Add payments table

  1. New Tables
    - `payments`
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key to jobs table)
      - `amount` (numeric, payment amount)
      - `currency` (text, payment currency)
      - `status` (text, payment status)
      - `package_type` (text, standard or premium)
      - `promotion_services` (jsonb, additional promotion services)
      - `payment_method` (text, payment method used)
      - `invoice_data` (jsonb, invoice details)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `paid_at` (timestamp)

  2. Security
    - Enable RLS on `payments` table
    - Add policy for public read access to own payments
    - Add policy for creating payments

  3. Constraints
    - Check constraints for status and package_type
    - Foreign key to jobs table
*/

-- Create payments table
CREATE TABLE IF NOT EXISTS payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES jobs(id) ON DELETE CASCADE,
  amount numeric(10,2) NOT NULL CHECK (amount > 0),
  currency text NOT NULL DEFAULT 'PLN',
  status text NOT NULL CHECK (status IN ('pending', 'completed', 'failed', 'refunded')),
  package_type text NOT NULL CHECK (package_type IN ('standard', 'premium')),
  promotion_services jsonb DEFAULT '[]'::jsonb,
  payment_method text NOT NULL CHECK (payment_method IN ('card', 'transfer', 'blik')),
  invoice_data jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  paid_at timestamptz
);

-- Create indexes
CREATE INDEX payments_job_id_idx ON payments(job_id);
CREATE INDEX payments_status_idx ON payments(status);
CREATE INDEX payments_created_at_idx ON payments(created_at);

-- Add trigger for updating updated_at
CREATE TRIGGER update_payments_updated_at
  BEFORE UPDATE ON payments
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Users can view their own payments"
  ON payments
  FOR SELECT
  TO authenticated
  USING (
    job_id IN (
      SELECT id FROM jobs WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "Users can create payments"
  ON payments
  FOR INSERT
  TO authenticated
  WITH CHECK (
    job_id IN (
      SELECT id FROM jobs WHERE user_id = auth.uid()
    )
  );

-- Add example payment types
COMMENT ON TABLE payments IS 'Stores payment information for job postings and promotion services';
COMMENT ON COLUMN payments.promotion_services IS 'Array of additional promotion services purchased with the job posting';
COMMENT ON COLUMN payments.invoice_data IS 'Invoice details including company name, address, tax ID, etc.';

-- Example promotion services structure:
COMMENT ON COLUMN payments.promotion_services IS E'Example structure:
[
  {
    "id": "social-pack",
    "name": "Social Media Pack",
    "price": 399.00
  },
  {
    "id": "featured",
    "name": "Featured Listing",
    "price": 299.00
  }
]';

-- Example invoice data structure:
COMMENT ON COLUMN payments.invoice_data IS E'Example structure:
{
  "company_name": "Example Corp",
  "address": "ul. Example 123",
  "city": "Warsaw",
  "postal_code": "00-000",
  "country": "Poland",
  "vat_id": "PL1234567890",
  "email": "invoices@example.com"
}';