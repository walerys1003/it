/*
  # Add blog tag management functions

  1. New Functions
    - `manage_blog_tag`: Function to create or update blog tags
    - `delete_blog_tag`: Function to safely delete blog tags
    - Both functions handle validation and error handling

  2. Security
    - Functions are security definer
    - Only admins can execute
    - Proper error handling and logging
*/

-- Create function to manage blog tags
CREATE OR REPLACE FUNCTION manage_blog_tag(
  p_id uuid,
  p_name text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tag_id uuid;
  v_now timestamptz;
BEGIN
  -- Input validation
  IF p_name IS NULL OR trim(p_name) = '' THEN
    RAISE EXCEPTION 'Tag name cannot be empty';
  END IF;

  -- Check if user has admin privileges
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Get current timestamp
  v_now := now();

  -- Insert or update tag
  IF p_id IS NULL THEN
    -- Check if tag with same name already exists
    SELECT id INTO v_tag_id
    FROM blog_taxonomies
    WHERE name = p_name AND type = 'tag';
    
    IF FOUND THEN
      RAISE EXCEPTION 'Tag with name "%" already exists', p_name;
    END IF;
    
    -- Create new tag
    INSERT INTO blog_taxonomies (
      name,
      type,
      created_at,
      updated_at
    )
    VALUES (
      p_name,
      'tag',
      v_now,
      v_now
    )
    RETURNING id INTO v_tag_id;

    -- Log the creation
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      'create_blog_tag',
      'blog_taxonomies',
      v_tag_id,
      jsonb_build_object(
        'name', p_name,
        'type', 'tag',
        'created_at', v_now
      )
    );
  ELSE
    -- Update existing tag
    UPDATE blog_taxonomies
    SET
      name = p_name,
      updated_at = v_now
    WHERE id = p_id AND type = 'tag'
    RETURNING id INTO v_tag_id;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'Tag with ID % not found', p_id;
    END IF;

    -- Log the update
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      'update_blog_tag',
      'blog_taxonomies',
      v_tag_id,
      jsonb_build_object(
        'name', p_name,
        'updated_at', v_now
      )
    );
  END IF;

  RETURN v_tag_id;
EXCEPTION
  WHEN others THEN
    -- Log error
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      details
    ) VALUES (
      'blog_tag_error',
      'blog_taxonomies',
      jsonb_build_object(
        'error', SQLERRM,
        'name', p_name
      )
    );
    RAISE;
END;
$$;

-- Create function to delete blog tags
CREATE OR REPLACE FUNCTION delete_blog_tag(p_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_tag_name text;
  v_has_posts boolean;
BEGIN
  -- Check if user has admin privileges
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Get tag name for logging
  SELECT name INTO v_tag_name
  FROM blog_taxonomies
  WHERE id = p_id AND type = 'tag';

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Tag not found';
  END IF;

  -- Check if tag is used in any posts
  SELECT EXISTS (
    SELECT 1 FROM blog_post_tags WHERE tag_id = p_id
  ) INTO v_has_posts;

  IF v_has_posts THEN
    RAISE EXCEPTION 'Cannot delete tag that is used by posts';
  END IF;

  -- Delete the tag
  DELETE FROM blog_taxonomies WHERE id = p_id AND type = 'tag';

  -- Log the deletion
  INSERT INTO admin_audit_log (
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    'delete_blog_tag',
    'blog_taxonomies',
    p_id,
    jsonb_build_object(
      'name', v_tag_name,
      'deleted_at', now()
    )
  );

  RETURN true;
EXCEPTION
  WHEN others THEN
    -- Log error
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      'blog_tag_delete_error',
      'blog_taxonomies',
      p_id,
      jsonb_build_object(
        'error', SQLERRM,
        'name', v_tag_name
      )
    );
    RETURN false;
END;
$$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION manage_blog_tag(uuid, text) TO public;
GRANT EXECUTE ON FUNCTION delete_blog_tag(uuid) TO public;

-- Add comments
COMMENT ON FUNCTION manage_blog_tag(uuid, text) IS 'Creates or updates a blog tag with proper validation and logging';
COMMENT ON FUNCTION delete_blog_tag(uuid) IS 'Safely deletes a blog tag if it is not used by any posts';