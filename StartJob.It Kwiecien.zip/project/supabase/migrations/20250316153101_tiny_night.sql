/*
  # Add admin functionality

  1. New Tables
    - `admin_users`
      - Links to auth.users
      - Stores admin role and permissions
    - `admin_audit_log`
      - Tracks admin actions
      - Provides accountability

  2. Security
    - Enable RLS
    - Add policies for admin access
    - Create helper functions

  3. Changes
    - Add admin-specific columns and functions
    - Set up audit logging
*/

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('admin', 'editor', 'moderator')),
  permissions jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create admin_audit_log table
CREATE TABLE IF NOT EXISTS admin_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid REFERENCES admin_users(id),
  action text NOT NULL,
  entity_type text NOT NULL,
  entity_id uuid,
  details jsonb,
  ip_address text,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_audit_log ENABLE ROW LEVEL SECURITY;

-- Create indexes
CREATE INDEX admin_audit_log_admin_id_idx ON admin_audit_log(admin_id);
CREATE INDEX admin_audit_log_created_at_idx ON admin_audit_log(created_at);
CREATE INDEX admin_audit_log_action_idx ON admin_audit_log(action);

-- Add trigger for updating updated_at
CREATE TRIGGER update_admin_users_updated_at
  BEFORE UPDATE ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Create function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid()
  );
END;
$$;

-- Create function to log admin actions
CREATE OR REPLACE FUNCTION log_admin_action(
  action text,
  entity_type text,
  entity_id uuid,
  details jsonb DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  log_id uuid;
BEGIN
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'User is not an admin';
  END IF;

  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details,
    ip_address,
    user_agent
  )
  VALUES (
    auth.uid(),
    action,
    entity_type,
    entity_id,
    details,
    current_setting('request.headers')::json->>'x-forwarded-for',
    current_setting('request.headers')::json->>'user-agent'
  )
  RETURNING id INTO log_id;

  RETURN log_id;
END;
$$;

-- Add RLS policies
CREATE POLICY "Only admins can view admin users"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (is_admin());

CREATE POLICY "Only admins can view audit log"
  ON admin_audit_log
  FOR SELECT
  TO authenticated
  USING (is_admin());

-- Insert test admin user (replace with your user ID)
INSERT INTO admin_users (id, role, permissions)
VALUES (
  '14293968-0fe7-476d-a8e5-e821d191ca46',
  'admin',
  '["all"]'::jsonb
) ON CONFLICT (id) DO NOTHING;