/*
  # Fix user deletion functionality

  1. Changes
    - Fix delete_user_completely function to properly delete from admin_users table
    - Ensure proper transaction handling
    - Add better error handling and logging
    - Fix order of operations to avoid foreign key constraint issues

  2. Security
    - Maintain security definer
    - Keep admin access check
    - Ensure proper audit logging
*/

-- Drop existing function if it exists
DROP FUNCTION IF EXISTS delete_user_completely(uuid);

-- Create improved function for complete user deletion
CREATE OR REPLACE FUNCTION delete_user_completely(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text;
  v_role text;
  v_name text;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Get user details for logging
  SELECT 
    u.email, 
    COALESCE(au.role, 'none'),
    COALESCE(u.raw_user_meta_data->>'name', 'Unknown')
  INTO 
    v_email, 
    v_role,
    v_name
  FROM auth.users u
  LEFT JOIN admin_users au ON au.id = u.id
  WHERE u.id = user_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- Log the deletion attempt
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'delete_user_attempt',
    'users',
    user_id,
    jsonb_build_object(
      'email', v_email,
      'role', v_role,
      'name', v_name,
      'attempted_at', now()
    )
  );

  -- Start transaction
  BEGIN
    -- First delete from admin_users to avoid foreign key issues
    DELETE FROM admin_users WHERE id = user_id;
    
    -- Then delete from auth.users
    DELETE FROM auth.users WHERE id = user_id;

    -- Log successful deletion
    INSERT INTO admin_audit_log (
      admin_id,
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'delete_user_success',
      'users',
      user_id,
      jsonb_build_object(
        'email', v_email,
        'role', v_role,
        'name', v_name,
        'deleted_at', now()
      )
    );

    RETURN true;
  EXCEPTION
    WHEN others THEN
      -- Log the error
      INSERT INTO admin_audit_log (
        admin_id,
        action,
        entity_type,
        entity_id,
        details
      ) VALUES (
        auth.uid(),
        'delete_user_error',
        'users',
        user_id,
        jsonb_build_object(
          'error', SQLERRM,
          'email', v_email,
          'role', v_role,
          'name', v_name
        )
      );
      
      RAISE EXCEPTION 'Error deleting user: %', SQLERRM;
  END;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION delete_user_completely(uuid) TO authenticated;

-- Add comment
COMMENT ON FUNCTION delete_user_completely(uuid) IS 'Completely deletes a user from both admin_users and auth.users tables with proper transaction handling';