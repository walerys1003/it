/*
  # Add Schema.org data for main pages

  1. Changes
    - Update existing SEO pages with proper schema.org data
    - Add structured data for homepage, pricing, blog, contact, etc.
    - Improve search engine visibility with rich results

  2. Data Added
    - Organization data for homepage
    - Service data for pricing page
    - Blog data for blog section
    - ContactPage data for contact page
    - LocalBusiness data for company information
*/

-- Update homepage with Organization schema
UPDATE seo_pages
SET schema_data = jsonb_build_object(
  'name', 'StartJob.IT',
  'url', 'https://startjob.it',
  'logo', 'https://startjob.it/logo.png',
  'description', 'StartJob.IT to platforma łącząca specjalistów IT z najlepszymi pracodawcami. Znajdź swoją wymarzoną pracę w branży IT.',
  'sameAs', jsonb_build_array(
    'https://facebook.com/startjob.it',
    'https://linkedin.com/company/startjob-it',
    'https://instagram.com/startjob.it'
  ),
  'address', jsonb_build_object(
    '@type', 'PostalAddress',
    'streetAddress', 'ul. Świeradowska 47',
    'addressLocality', 'Warszawa',
    'postalCode', '02-662',
    'addressCountry', 'PL'
  ),
  'contactPoint', jsonb_build_object(
    '@type', 'ContactPoint',
    'telephone', '(+48) 501 42 00 42',
    'contactType', 'customer service',
    'email', 'kontakt@startjob.it'
  )
),
schema_type = 'Organization'
WHERE path = '/';

-- Update pricing page with Service schema
UPDATE seo_pages
SET schema_data = jsonb_build_object(
  'name', 'Usługi publikacji ogłoszeń o pracę w IT',
  'provider', jsonb_build_object(
    '@type', 'Organization',
    'name', 'StartJob.IT',
    'url', 'https://startjob.it'
  ),
  'serviceType', 'Job Posting Service',
  'description', 'Publikacja ogłoszeń o pracę w branży IT, z opcjami pakietów Standard i Premium',
  'offers', jsonb_build_array(
    jsonb_build_object(
      '@type', 'Offer',
      'name', 'Pakiet Standard',
      'price', '599',
      'priceCurrency', 'PLN',
      'description', 'Ogłoszenie o pracę widoczne przez 60 dni'
    ),
    jsonb_build_object(
      '@type', 'Offer',
      'name', 'Pakiet Premium',
      'price', '899',
      'priceCurrency', 'PLN',
      'description', 'Ogłoszenie o pracę widoczne przez 90 dni z wyróżnieniem'
    )
  )
),
schema_type = 'Service'
WHERE path = '/cennik';

-- Update blog page with Blog schema
UPDATE seo_pages
SET schema_data = jsonb_build_object(
  'name', 'Blog StartJob.IT',
  'description', 'Blog StartJob.IT - Wiedza i Trendy dla Branży IT. Najnowsze artykuły, porady i informacje z branży IT.',
  'publisher', jsonb_build_object(
    '@type', 'Organization',
    'name', 'StartJob.IT',
    'logo', jsonb_build_object(
      '@type', 'ImageObject',
      'url', 'https://startjob.it/logo.png'
    )
  )
),
schema_type = 'Blog'
WHERE path = '/blog';

-- Update contact page with ContactPage schema
UPDATE seo_pages
SET schema_data = jsonb_build_object(
  'name', 'Kontakt StartJob.IT',
  'description', 'Skontaktuj się z nami. StartJob.IT - Twój partner w rekrutacji IT.',
  'contactPoint', jsonb_build_object(
    '@type', 'ContactPoint',
    'telephone', '(+48) 501 42 00 42',
    'contactType', 'customer service',
    'email', 'kontakt@startjob.it',
    'availableLanguage', jsonb_build_array('Polish', 'English')
  ),
  'address', jsonb_build_object(
    '@type', 'PostalAddress',
    'streetAddress', 'ul. Świeradowska 47',
    'addressLocality', 'Warszawa',
    'postalCode', '02-662',
    'addressCountry', 'PL'
  ),
  'openingHours', 'Mo-Fr 08:00-16:00'
),
schema_type = 'ContactPage'
WHERE path = '/kontakt';

-- Update promotion services page with Service schema
UPDATE seo_pages
SET schema_data = jsonb_build_object(
  'name', 'Usługi Promocji StartJob.IT',
  'description', 'Usługi promocji ogłoszeń o pracę w IT. Zwiększ widoczność swoich ofert pracy.',
  'provider', jsonb_build_object(
    '@type', 'Organization',
    'name', 'StartJob.IT',
    'url', 'https://startjob.it'
  ),
  'serviceType', 'Job Promotion Service',
  'offers', jsonb_build_array(
    jsonb_build_object(
      '@type', 'Offer',
      'name', 'Kampanie reklamowe',
      'description', 'Reklamy w social mediach, kampanie Google Ads i YouTube'
    ),
    jsonb_build_object(
      '@type', 'Offer',
      'name', 'Video ogłoszenie',
      'description', 'Produkcja i promocja 30-60 sekundowego wideo'
    ),
    jsonb_build_object(
      '@type', 'Offer',
      'name', 'Headhunting Premium',
      'description', 'Dedykowany headhunting i weryfikacja kandydatów'
    )
  )
),
schema_type = 'Service'
WHERE path = '/uslugi-promocji';

-- Update social media page with WebPage schema
UPDATE seo_pages
SET schema_data = jsonb_build_object(
  'name', 'Social Media StartJob.IT',
  'description', 'Dołącz do społeczności specjalistów IT i bądź na bieżąco z najlepszymi ofertami pracy oraz trendami w branży!',
  'mainEntity', jsonb_build_object(
    '@type', 'ItemList',
    'itemListElement', jsonb_build_array(
      jsonb_build_object(
        '@type', 'ListItem',
        'position', 1,
        'item', jsonb_build_object(
          '@type', 'SocialMediaPosting',
          'headline', 'Facebook - Grupa dla Specjalistów IT',
          'url', 'https://facebook.com/startjob.it'
        )
      ),
      jsonb_build_object(
        '@type', 'ListItem',
        'position', 2,
        'item', jsonb_build_object(
          '@type', 'SocialMediaPosting',
          'headline', 'LinkedIn - Profesjonalna Sieć dla IT',
          'url', 'https://linkedin.com/company/startjob-it'
        )
      ),
      jsonb_build_object(
        '@type', 'ListItem',
        'position', 3,
        'item', jsonb_build_object(
          '@type', 'SocialMediaPosting',
          'headline', 'Instagram - Życie i Kariera w IT',
          'url', 'https://instagram.com/startjob.it'
        )
      )
    )
  )
),
schema_type = 'WebPage'
WHERE path = '/social-media';

-- Update job posting page with JobPosting schema template
UPDATE seo_pages
SET schema_data = jsonb_build_object(
  'name', 'Dodaj ogłoszenie o pracę w IT',
  'description', 'Dodaj ogłoszenie o pracę w branży IT na StartJob.IT i znajdź najlepszych specjalistów.',
  'mainEntity', jsonb_build_object(
    '@type', 'Service',
    'serviceType', 'Job Posting Service',
    'provider', jsonb_build_object(
      '@type', 'Organization',
      'name', 'StartJob.IT',
      'url', 'https://startjob.it'
    ),
    'offers', jsonb_build_array(
      jsonb_build_object(
        '@type', 'Offer',
        'name', 'Pakiet Standard',
        'price', '599',
        'priceCurrency', 'PLN'
      ),
      jsonb_build_object(
        '@type', 'Offer',
        'name', 'Pakiet Premium',
        'price', '899',
        'priceCurrency', 'PLN'
      )
    )
  )
),
schema_type = 'WebPage'
WHERE path = '/dodaj-ogloszenie';

-- Update privacy policy page with WebPage schema
UPDATE seo_pages
SET schema_data = jsonb_build_object(
  'name', 'Polityka Prywatności StartJob.IT',
  'description', 'Polityka prywatności serwisu StartJob.IT. Informacje o przetwarzaniu danych osobowych.',
  'mainEntity', jsonb_build_object(
    '@type', 'WebPageElement',
    'headline', 'Polityka Prywatności',
    'text', 'Dbamy o Twoją prywatność i transparentność przetwarzania danych osobowych'
  )
),
schema_type = 'WebPage'
WHERE path = '/polityka-prywatnosci';

-- Update terms of service page with WebPage schema
UPDATE seo_pages
SET schema_data = jsonb_build_object(
  'name', 'Regulamin Serwisu StartJob.IT',
  'description', 'Regulamin korzystania z serwisu StartJob.IT. Warunki świadczenia usług.',
  'mainEntity', jsonb_build_object(
    '@type', 'WebPageElement',
    'headline', 'Regulamin Serwisu',
    'text', 'Regulamin określający zasady korzystania z serwisu StartJob.IT'
  )
),
schema_type = 'WebPage'
WHERE path = '/regulamin';

-- Add comment
COMMENT ON TABLE seo_pages IS 'Stores SEO metadata and schema.org structured data for each page in the site';