/*
  # Add delete_user_by_id RPC function

  1. New Functions
    - `delete_user_by_id`: Function to safely delete a user by ID
    - Handles both auth.users and users table deletion
    - Includes proper error handling and access control

  2. Security
    - Function is security definer
    - Only admins can delete users
    - Maintains audit logging
*/

-- Create function to delete a user by ID
CREATE OR REPLACE FUNCTION delete_user_by_id(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text;
  v_role text;
  v_name text;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM users 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Get user details for logging
  SELECT 
    u.email, 
    us.role,
    (u.raw_user_meta_data->>'name')::text
  INTO 
    v_email, 
    v_role,
    v_name
  FROM auth.users u
  LEFT JOIN users us ON us.user_id = u.id
  WHERE u.id = user_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- Prevent deleting your own account
  IF user_id = auth.uid() THEN
    RAISE EXCEPTION 'Cannot delete your own account';
  END IF;

  -- Log the deletion attempt
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'delete_user_attempt',
    'users',
    user_id,
    jsonb_build_object(
      'email', v_email,
      'role', v_role,
      'name', v_name,
      'attempted_at', now()
    )
  );

  -- Delete from users table first
  DELETE FROM users WHERE user_id = user_id;
  
  -- Delete from auth.users
  DELETE FROM auth.users WHERE id = user_id;

  -- Log successful deletion
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'delete_user_success',
    'users',
    user_id,
    jsonb_build_object(
      'email', v_email,
      'role', v_role,
      'name', v_name,
      'deleted_at', now()
    )
  );

  RETURN true;

EXCEPTION
  WHEN others THEN
    -- Log the error
    INSERT INTO admin_audit_log (
      admin_id,
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'delete_user_error',
      'users',
      user_id,
      jsonb_build_object(
        'error', SQLERRM,
        'email', v_email,
        'role', v_role,
        'name', v_name
      )
    );
    
    RAISE EXCEPTION 'Error deleting user: %', SQLERRM;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION delete_user_by_id(uuid) TO authenticated;

-- Add comment
COMMENT ON FUNCTION delete_user_by_id(uuid) IS 'Safely deletes a user from both auth.users and users tables with proper access control';