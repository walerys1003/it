/*
  # Create newsletter subscribers table

  1. New Tables
    - `newsletter_subscribers`
      - `id` (uuid, primary key)
      - `email` (text, unique, not null)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `newsletter_subscribers` table
    - Add policy for public insert access
    - Add policy for public read access

  3. Notes
    - Stores only email addresses for newsletter subscriptions
    - No user authentication required
    - Prevents duplicate email subscriptions
*/

-- Create newsletter_subscribers table
CREATE TABLE IF NOT EXISTS newsletter_subscribers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text NOT NULL UNIQUE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create index for email lookups
CREATE INDEX newsletter_subscribers_email_idx ON newsletter_subscribers(email);

-- Add trigger for updating updated_at
CREATE TRIGGER update_newsletter_subscribers_updated_at
  BEFORE UPDATE ON newsletter_subscribers
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE newsletter_subscribers ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Anyone can subscribe to newsletter"
  ON newsletter_subscribers
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Public can view newsletter subscribers"
  ON newsletter_subscribers
  FOR SELECT
  TO public
  USING (true);

-- Add table comment
COMMENT ON TABLE newsletter_subscribers IS 'Stores email addresses of newsletter subscribers';
COMMENT ON COLUMN newsletter_subscribers.email IS 'Email address of the subscriber (unique)';