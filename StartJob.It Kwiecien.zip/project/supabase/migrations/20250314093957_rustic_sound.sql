/*
  # Add remote and international job postings

  1. Data Insertion
    - Add 4 new job postings:
      - Senior Software Engineer at Google (USA)
      - Remote Frontend Developer at Spotify (Sweden)
      - Full Stack Developer at Remote-First Company (100% Remote)
      - Senior Cloud Architect at Amazon (Germany)

  2. Notes
    - All jobs are linked to the existing test user
    - Mix of remote and on-site positions
    - Competitive international salaries
    - Various locations and companies
*/

INSERT INTO jobs (
  title, category, description, responsibilities, requirements, nice_to_have,
  technologies, work_mode, experience_level, contract_type, salary_from, salary_to,
  currency, benefits, location_country, location_city, languages, company_name,
  company_description, company_size, company_logo, contact_name, contact_position,
  contact_email, contact_phone, valid_until, is_active, is_featured, is_premium,
  user_id
) VALUES
-- Senior Software Engineer at Google
(
  'Senior Software Engineer',
  'Backend',
  'Join Google''s engineering team and work on projects that impact billions of users worldwide. We''re looking for exceptional engineers to help build the next generation of cloud infrastructure.',
  ARRAY['Design and implement scalable backend services', 'Lead technical projects and mentor junior engineers', 'Collaborate with cross-functional teams', 'Drive architectural decisions', 'Contribute to system design and planning'],
  ARRAY['8+ years of software development experience', 'Strong expertise in distributed systems', 'Experience with large-scale applications', 'Deep knowledge of Java or C++', 'Track record of technical leadership'],
  ARRAY['Experience with Google Cloud Platform', 'Contributions to open source projects', 'Research publications', 'System design expertise'],
  ARRAY['Java', 'C++', 'Python', 'Kubernetes', 'Cloud Infrastructure'],
  'office',
  'senior',
  'employment',
  150000,
  250000,
  'USD',
  ARRAY['Competitive salary', 'Stock options (RSUs)', 'Comprehensive health insurance', '401(k) matching', 'Unlimited PTO', 'Learning and development budget'],
  'us',
  'Mountain View, CA',
  ARRAY['{"language": "Angielski", "level": "C1"}']::jsonb[],
  'Google',
  'Google''s mission is to organize the world''s information and make it universally accessible and useful.',
  '100,000+ employees',
  'https://images.unsplash.com/photo-1573804633927-bfcbcd909acd?w=64&h=64&fit=crop&crop=faces',
  'John Smith',
  'Technical Recruiter',
  'careers@google.com',
  '+1 650-253-0000',
  NOW() + INTERVAL '90 days',
  true,
  true,
  true,
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a'
),

-- Remote Frontend Developer at Spotify
(
  'Senior Frontend Developer',
  'Frontend',
  'Join Spotify''s web platform team and help shape the future of music streaming. Work remotely while collaborating with talented engineers from around the world.',
  ARRAY['Build and maintain Spotify''s web applications', 'Improve performance and user experience', 'Collaborate with designers and product managers', 'Write clean, maintainable code', 'Contribute to frontend architecture'],
  ARRAY['5+ years of frontend development', 'Expert knowledge of React and TypeScript', 'Experience with state management (Redux/MobX)', 'Understanding of web performance', 'Strong testing practices'],
  ARRAY['Experience with Web Audio API', 'Knowledge of WebAssembly', 'Contribution to design systems', 'Music industry experience'],
  ARRAY['React', 'TypeScript', 'Redux', 'Jest', 'Webpack'],
  'remote',
  'senior',
  'employment',
  65000,
  85000,
  'EUR',
  ARRAY['Remote-first culture', 'Flexible working hours', 'Home office setup', 'Spotify Premium Family plan', 'Learning budget', 'Annual team gatherings'],
  'se',
  'Stockholm',
  ARRAY['{"language": "Angielski", "level": "C1"}']::jsonb[],
  'Spotify',
  'Spotify is a digital music, podcast, and video service that gives you access to millions of songs and other content from creators all over the world.',
  '10,000+ employees',
  'https://images.unsplash.com/photo-1614680376593-902f74cf0d41?w=64&h=64&fit=crop&crop=faces',
  'Emma Andersson',
  'Senior Tech Recruiter',
  'tech-jobs@spotify.com',
  '+46 8 123 45 67',
  NOW() + INTERVAL '90 days',
  true,
  true,
  true,
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a'
),

-- Full Stack Developer at Remote-First Company
(
  'Full Stack Developer',
  'Fullstack',
  'Join our fully distributed team at RemoteFirst Tech and work on exciting projects from anywhere in the world. We''re building the future of remote work tools.',
  ARRAY['Develop full-stack web applications', 'Work with modern JavaScript frameworks', 'Design and implement APIs', 'Optimize application performance', 'Participate in code reviews'],
  ARRAY['4+ years of full-stack development', 'Strong JavaScript/TypeScript skills', 'Experience with Node.js and React', 'Database design and optimization', 'Git workflow expertise'],
  ARRAY['Experience with GraphQL', 'Knowledge of WebRTC', 'DevOps experience', 'Open source contributions'],
  ARRAY['React', 'Node.js', 'TypeScript', 'PostgreSQL', 'Redis'],
  'remote',
  'mid',
  'b2b',
  70000,
  100000,
  'USD',
  ARRAY['100% remote work', 'Flexible hours', 'Home office budget', 'Learning allowance', 'Co-working space stipend', 'Regular virtual team events'],
  'remote',
  'Anywhere',
  ARRAY['{"language": "Angielski", "level": "B2"}']::jsonb[],
  'RemoteFirst Tech',
  'RemoteFirst Tech is building the next generation of collaboration tools for distributed teams.',
  '50-100 employees',
  'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=64&h=64&fit=crop&crop=faces',
  'Sarah Johnson',
  'Head of Talent',
  'jobs@remotefirst.tech',
  '+1 888-555-0123',
  NOW() + INTERVAL '90 days',
  true,
  false,
  true,
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a'
),

-- Senior Cloud Architect at Amazon
(
  'Senior Cloud Architect',
  'DevOps',
  'Join Amazon Web Services in Berlin and help shape the future of cloud computing. Work with cutting-edge technologies and design solutions for global customers.',
  ARRAY['Design cloud architecture solutions', 'Lead technical discussions with customers', 'Drive adoption of AWS services', 'Mentor junior architects', 'Contribute to best practices'],
  ARRAY['8+ years in cloud architecture', 'Deep AWS knowledge', 'Experience with microservices', 'Strong system design skills', 'Technical leadership experience'],
  ARRAY['Multiple AWS certifications', 'Experience with multi-cloud', 'Public speaking experience', 'Technical publications'],
  ARRAY['AWS', 'Kubernetes', 'Terraform', 'Docker', 'Python'],
  'hybrid',
  'lead',
  'employment',
  85000,
  120000,
  'EUR',
  ARRAY['Competitive salary', 'RSU grants', 'Relocation assistance', 'Health insurance', 'Pension plan', 'Training budget'],
  'de',
  'Berlin',
  ARRAY['{"language": "Angielski", "level": "C1"}', '{"language": "Niemiecki", "level": "B1"}']::jsonb[],
  'Amazon Web Services',
  'Amazon Web Services (AWS) is the world''s most comprehensive and broadly adopted cloud platform.',
  '100,000+ employees',
  'https://images.unsplash.com/photo-1580741569354-f55f29d13489?w=64&h=64&fit=crop&crop=faces',
  'Michael Weber',
  'Technical Recruiter',
  'aws-jobs@amazon.de',
  '+49 30 1234567',
  NOW() + INTERVAL '90 days',
  true,
  true,
  true,
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a'
);