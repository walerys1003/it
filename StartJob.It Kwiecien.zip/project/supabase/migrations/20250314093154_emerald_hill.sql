/*
  # Create jobs table

  1. New Tables
    - `jobs`
      - Basic information (id, title, description, etc.)
      - Requirements and responsibilities
      - Employment details (salary, work mode, etc.)
      - Company information
      - Contact details
      - Timestamps and status fields

  2. Security
    - Enable RLS on `jobs` table
    - Add policies for:
      - Public read access for active jobs
      - Authenticated users can create jobs
      - Job owners can update their jobs
*/

-- Create jobs table
CREATE TABLE IF NOT EXISTS jobs (
  -- Basic Information
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  category text NOT NULL,
  description text NOT NULL,
  responsibilities text[] NOT NULL DEFAULT '{}',
  requirements text[] NOT NULL DEFAULT '{}',
  nice_to_have text[] DEFAULT '{}',
  technologies text[] NOT NULL DEFAULT '{}',

  -- Employment Details
  work_mode text NOT NULL CHECK (work_mode IN ('remote', 'hybrid', 'office')),
  experience_level text NOT NULL CHECK (experience_level IN ('junior', 'mid', 'senior', 'lead')),
  contract_type text NOT NULL CHECK (contract_type IN ('employment', 'b2b', 'mandate', 'work')),
  salary_from integer,
  salary_to integer,
  currency text NOT NULL DEFAULT 'PLN',
  benefits text[] DEFAULT '{}',

  -- Location
  location_country text NOT NULL,
  location_voivodeship text,
  location_city text,

  -- Languages
  languages jsonb[] DEFAULT '{}',

  -- Company Information
  company_name text NOT NULL,
  company_description text,
  company_size text,
  company_logo text,

  -- Contact Information
  contact_name text NOT NULL,
  contact_position text,
  contact_email text NOT NULL,
  contact_phone text,

  -- Posting Details
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  valid_until timestamptz NOT NULL,
  is_active boolean NOT NULL DEFAULT true,
  is_featured boolean NOT NULL DEFAULT false,
  is_premium boolean NOT NULL DEFAULT false,
  views_count integer NOT NULL DEFAULT 0,
  applications_count integer NOT NULL DEFAULT 0,
  
  -- Owner Information
  user_id uuid NOT NULL REFERENCES auth.users(id)
);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_jobs_updated_at
  BEFORE UPDATE ON jobs
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE jobs ENABLE ROW LEVEL SECURITY;

-- Policies
-- Allow anyone to view active jobs
CREATE POLICY "Anyone can view active jobs"
  ON jobs
  FOR SELECT
  USING (is_active = true AND valid_until > now());

-- Allow authenticated users to create jobs
CREATE POLICY "Authenticated users can create jobs"
  ON jobs
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Allow users to update their own jobs
CREATE POLICY "Users can update own jobs"
  ON jobs
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Allow users to delete their own jobs
CREATE POLICY "Users can delete own jobs"
  ON jobs
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create index for common queries
CREATE INDEX jobs_category_idx ON jobs(category);
CREATE INDEX jobs_technologies_idx ON jobs USING gin(technologies);
CREATE INDEX jobs_created_at_idx ON jobs(created_at);
CREATE INDEX jobs_valid_until_idx ON jobs(valid_until);
CREATE INDEX jobs_is_active_idx ON jobs(is_active);
CREATE INDEX jobs_is_featured_idx ON jobs(is_featured);
CREATE INDEX jobs_location_country_idx ON jobs(location_country);
CREATE INDEX jobs_experience_level_idx ON jobs(experience_level);
CREATE INDEX jobs_work_mode_idx ON jobs(work_mode);