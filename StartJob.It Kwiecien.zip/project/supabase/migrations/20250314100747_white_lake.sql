/*
  # Add countries table and update jobs table

  1. New Tables
    - `jobs_countries`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `code` (text, unique)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Changes
    - Add `location_country_id` column to `jobs` table
    - Migrate existing data from `location_country` to use foreign keys
    - Add foreign key constraint
    - Enable RLS on new table

  3. Security
    - Enable RLS on `jobs_countries` table
    - Add policy for public read access
*/

-- Create jobs_countries table
CREATE TABLE IF NOT EXISTS jobs_countries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  code text NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE jobs_countries ENABLE ROW LEVEL SECURITY;

-- Add RLS policy for public read access
CREATE POLICY "Anyone can view countries" 
  ON jobs_countries
  FOR SELECT 
  TO public 
  USING (true);

-- Insert initial countries
INSERT INTO jobs_countries (name, code) VALUES
  ('Polska', 'PL'),
  ('Niemcy', 'DE'),
  ('Wielka Brytania', 'GB'),
  ('Stany Zjednoczone', 'US'),
  ('Holandia', 'NL'),
  ('Szwecja', 'SE'),
  ('Norwegia', 'NO'),
  ('Dania', 'DK'),
  ('Francja', 'FR'),
  ('Hiszpania', 'ES'),
  ('Włochy', 'IT'),
  ('Czechy', 'CZ'),
  ('Słowacja', 'SK'),
  ('Węgry', 'HU'),
  ('Austria', 'AT'),
  ('Szwajcaria', 'CH'),
  ('Irlandia', 'IE'),
  ('Belgia', 'BE'),
  ('Finlandia', 'FI'),
  ('Portugalia', 'PT')
ON CONFLICT (code) DO NOTHING;

-- Add new column to jobs table
ALTER TABLE jobs ADD COLUMN location_country_id uuid REFERENCES jobs_countries(id);

-- Create index for the new foreign key
CREATE INDEX jobs_location_country_id_idx ON jobs(location_country_id);

-- Migrate existing data
DO $$
BEGIN
  -- Update existing jobs to use the new foreign key
  UPDATE jobs
  SET location_country_id = countries.id
  FROM jobs_countries countries
  WHERE jobs.location_country = countries.name;
END $$;

-- Add trigger for updating updated_at
CREATE TRIGGER update_jobs_countries_updated_at
  BEFORE UPDATE ON jobs_countries
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();