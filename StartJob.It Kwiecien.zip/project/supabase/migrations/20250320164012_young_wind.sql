/*
  # Add job expiration notifications

  1. New Functions
    - `check_job_expiration`: Function to check and send notifications for jobs expiring soon
    - Sends emails at 7 days, 3 days, and 1 day before expiration
    - Uses email templates for consistent messaging

  2. Security
    - Function runs with security definer
    - Proper error handling and logging
*/

-- Create function to check job expiration and send notifications
CREATE OR REPLACE FUNCTION check_job_expiration()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  job_record RECORD;
  days_until_expiry INTEGER;
  notification_template TEXT;
  notification_subject TEXT;
BEGIN
  -- Get all active jobs
  FOR job_record IN 
    SELECT 
      id,
      title,
      company_name,
      contact_email,
      valid_until,
      EXTRACT(DAY FROM valid_until - CURRENT_TIMESTAMP) as days_left
    FROM jobs 
    WHERE 
      is_active = true 
      AND valid_until > CURRENT_TIMESTAMP
      AND valid_until <= CURRENT_TIMESTAMP + INTERVAL '7 days'
  LOOP
    days_until_expiry := job_record.days_left::INTEGER;
    
    -- Only send notifications for 7, 3, and 1 days before expiry
    IF days_until_expiry IN (7, 3, 1) THEN
      -- Prepare notification content
      notification_subject := CASE 
        WHEN days_until_expiry = 7 THEN 'Twoje ogłoszenie wygaśnie za 7 dni'
        WHEN days_until_expiry = 3 THEN 'Twoje ogłoszenie wygaśnie za 3 dni'
        WHEN days_until_expiry = 1 THEN 'Twoje ogłoszenie wygaśnie jutro'
      END;

      notification_template := '
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #4a3471;">Przypomnienie o wygasającym ogłoszeniu</h2>
          
          <p>Witaj,</p>
          
          <p>Twoje ogłoszenie <strong>"' || job_record.title || '"</strong> w serwisie StartJob.IT wygaśnie za ' || days_until_expiry || ' dni.</p>
          
          <p>Szczegóły ogłoszenia:</p>
          <ul>
            <li>Firma: ' || job_record.company_name || '</li>
            <li>Data wygaśnięcia: ' || to_char(job_record.valid_until, 'YYYY-MM-DD') || '</li>
          </ul>
          
          <p>Aby przedłużyć ważność ogłoszenia, zaloguj się do panelu pracodawcy i wybierz opcję przedłużenia.</p>
          
          <p style="margin-top: 30px; color: #666; font-size: 14px;">
            Pozdrawiamy,<br>
            Zespół StartJob.IT
          </p>
        </div>
      ';

      -- Send email notification
      PERFORM net.http_post(
        url := 'https://mail-api.startjob.it/email.php',
        headers := jsonb_build_object(
          'Content-Type', 'application/json',
          'Authorization', 'Bearer 4cd6c3fb-d2ec-4426-b955-51e7e3faa4b6'
        ),
        body := jsonb_build_object(
          'to', job_record.contact_email,
          'subject', notification_subject,
          'message', notification_template
        )
      );

      -- Log the notification
      INSERT INTO admin_audit_log (
        action,
        entity_type,
        entity_id,
        details
      ) VALUES (
        'job_expiration_notification',
        'jobs',
        job_record.id,
        jsonb_build_object(
          'days_until_expiry', days_until_expiry,
          'notification_sent_at', CURRENT_TIMESTAMP,
          'recipient_email', job_record.contact_email
        )
      );
    END IF;
  END LOOP;
END;
$$;

-- Create a comment explaining the function
COMMENT ON FUNCTION check_job_expiration() IS 'Checks for jobs expiring soon and sends notification emails to employers';

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION check_job_expiration() TO authenticated;