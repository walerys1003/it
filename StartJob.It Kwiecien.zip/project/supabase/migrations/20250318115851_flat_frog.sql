/*
  # Fix password hashing functionality

  1. Changes
    - Enable pgcrypto extension
    - Update password hashing function
    - Fix user creation

  2. Security
    - Use proper password hashing with pgcrypto
    - Maintain secure password storage
*/

-- Enable pgcrypto extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Drop existing function
DROP FUNCTION IF EXISTS create_admin_user(text, text, text, text);

-- Create improved function with proper password handling
CREATE OR REPLACE FUNCTION create_admin_user(
  p_email text,
  p_password text,
  p_name text,
  p_role text
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_result json;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Validate role
  IF p_role NOT IN ('admin', 'editor', 'moderator') THEN
    RAISE EXCEPTION 'Invalid role specified';
  END IF;

  -- Create user in auth.users
  INSERT INTO auth.users (
    instance_id,
    id,
    aud,
    role,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at,
    confirmation_token,
    email_change_token_current,
    recovery_token
  ) VALUES (
    '00000000-0000-0000-0000-000000000000',
    gen_random_uuid(),
    'authenticated',
    'authenticated',
    p_email,
    crypt(p_password, gen_salt('bf', 10)),
    now(),
    '{"provider": "email", "providers": ["email"]}',
    jsonb_build_object('name', p_name),
    now(),
    now(),
    encode(gen_random_bytes(32), 'hex'),
    encode(gen_random_bytes(32), 'hex'),
    encode(gen_random_bytes(32), 'hex')
  )
  RETURNING id INTO v_user_id;

  -- Insert into admin_users
  INSERT INTO admin_users (id, role, permissions)
  VALUES (v_user_id, p_role, '[]'::jsonb);

  -- Log the action
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'create_admin_user',
    'admin_users',
    v_user_id,
    jsonb_build_object(
      'email', p_email,
      'name', p_name,
      'role', p_role
    )
  );

  -- Return user data
  v_result := jsonb_build_object(
    'user', jsonb_build_object(
      'id', v_user_id,
      'email', p_email,
      'name', p_name,
      'role', p_role
    )
  );

  RETURN v_result;
EXCEPTION
  WHEN unique_violation THEN
    RAISE EXCEPTION 'Email already exists';
  WHEN others THEN
    RAISE EXCEPTION 'Error creating user: %', SQLERRM;
END;
$$;