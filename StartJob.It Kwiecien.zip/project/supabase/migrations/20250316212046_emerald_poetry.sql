/*
  # Add job deletion policy for admins

  1. Changes
    - Add RLS policy allowing admins to delete jobs
    - Keep existing policies for job viewing and creation

  2. Security
    - Only admins can delete jobs
    - Maintains existing access controls
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Anyone can create jobs" ON jobs;

-- Create new policies
CREATE POLICY "Public can create jobs"
  ON jobs
  FOR INSERT
  TO public
  WITH CHECK (true);

-- Add policy for job deletion
CREATE POLICY "Admins can delete jobs"
  ON jobs
  FOR DELETE
  TO public
  USING (is_admin());

-- Add policy for job updates
CREATE POLICY "Admins can update jobs"
  ON jobs
  FOR UPDATE
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());