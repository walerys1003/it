/*
  # Add category management functions

  1. New Functions
    - `manage_job_category`: Function to create or update job categories
    - `delete_job_category`: Function to safely delete job categories
    - Both functions handle parent-child relationships

  2. Security
    - Functions are security definer
    - Only admins can execute
    - Proper error handling and logging
*/

-- Create function to manage job categories
CREATE OR REPLACE FUNCTION manage_job_category(
  p_id uuid,
  p_name text,
  p_code text,
  p_parent_id uuid DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_category_id uuid;
  v_existing_code text;
BEGIN
  -- Check if user has admin privileges
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Check if code already exists for a different category
  IF p_id IS NULL THEN
    SELECT id INTO v_category_id
    FROM job_categories
    WHERE code = p_code;
    
    IF FOUND THEN
      RAISE EXCEPTION 'Category with code % already exists', p_code;
    END IF;
  END IF;

  -- Insert or update category
  IF p_id IS NULL THEN
    -- Create new category
    INSERT INTO job_categories (
      name,
      code,
      parent_id
    )
    VALUES (
      p_name,
      p_code,
      p_parent_id
    )
    RETURNING id INTO v_category_id;

    -- Log the creation
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      'create_job_category',
      'job_categories',
      v_category_id,
      jsonb_build_object(
        'name', p_name,
        'code', p_code,
        'parent_id', p_parent_id
      )
    );
  ELSE
    -- Update existing category
    UPDATE job_categories
    SET
      name = p_name,
      code = p_code,
      parent_id = p_parent_id,
      updated_at = now()
    WHERE id = p_id
    RETURNING id INTO v_category_id;

    -- Log the update
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      'update_job_category',
      'job_categories',
      v_category_id,
      jsonb_build_object(
        'name', p_name,
        'code', p_code,
        'parent_id', p_parent_id
      )
    );
  END IF;

  RETURN v_category_id;
EXCEPTION
  WHEN others THEN
    -- Log error
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      details
    ) VALUES (
      'job_category_error',
      'job_categories',
      jsonb_build_object(
        'error', SQLERRM,
        'name', p_name,
        'code', p_code,
        'parent_id', p_parent_id
      )
    );
    RAISE;
END;
$$;

-- Create function to delete job categories
CREATE OR REPLACE FUNCTION delete_job_category(p_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_category_name text;
  v_has_subcategories boolean;
  v_has_jobs boolean;
BEGIN
  -- Check if user has admin privileges
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Get category name for logging
  SELECT name INTO v_category_name
  FROM job_categories
  WHERE id = p_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Category not found';
  END IF;

  -- Check for subcategories
  SELECT EXISTS (
    SELECT 1 FROM job_categories WHERE parent_id = p_id
  ) INTO v_has_subcategories;

  IF v_has_subcategories THEN
    RAISE EXCEPTION 'Cannot delete category that has subcategories';
  END IF;

  -- Check for jobs using this category
  SELECT EXISTS (
    SELECT 1 FROM jobs WHERE category = v_category_name
  ) INTO v_has_jobs;

  IF v_has_jobs THEN
    RAISE EXCEPTION 'Cannot delete category that is used by jobs';
  END IF;

  -- Delete the category
  DELETE FROM job_categories WHERE id = p_id;

  -- Log the deletion
  INSERT INTO admin_audit_log (
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    'delete_job_category',
    'job_categories',
    p_id,
    jsonb_build_object(
      'name', v_category_name,
      'deleted_at', now()
    )
  );

  RETURN true;
EXCEPTION
  WHEN others THEN
    -- Log error
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      'job_category_delete_error',
      'job_categories',
      p_id,
      jsonb_build_object(
        'error', SQLERRM,
        'name', v_category_name
      )
    );
    RETURN false;
END;
$$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION manage_job_category(uuid, text, text, uuid) TO public;
GRANT EXECUTE ON FUNCTION delete_job_category(uuid) TO public;

-- Add comments
COMMENT ON FUNCTION manage_job_category(uuid, text, text, uuid) IS 'Creates or updates a job category with proper validation and logging';
COMMENT ON FUNCTION delete_job_category(uuid) IS 'Safely deletes a job category if it has no subcategories or jobs';