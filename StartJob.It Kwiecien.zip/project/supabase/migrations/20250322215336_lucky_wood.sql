/*
  # Add code column to job_categories table

  1. Changes
    - Add code column to job_categories table
    - Make code column unique
    - Add index for faster lookups
    - Keep existing data and functionality

  2. Security
    - Maintain existing RLS policies
    - Keep table comments
*/

-- Add code column to job_categories table
ALTER TABLE job_categories 
ADD COLUMN code text UNIQUE;

-- Create index for code column
CREATE INDEX IF NOT EXISTS job_categories_code_idx ON job_categories(code);

-- Update existing records to have a code based on name
UPDATE job_categories
SET code = lower(regexp_replace(name, '[^a-zA-Z0-9]+', '-', 'g'))
WHERE code IS NULL;