/*
  # Fix admin user creation

  1. Changes
    - Fix the create_admin_user function to avoid using gen_salt
    - Use static salt for password hashing
    - Simplify user creation process
    - Add proper error handling

  2. Security
    - Maintain proper password hashing
    - Keep audit logging
*/

-- Enable pgcrypto extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Drop existing function if it exists with any parameter signature
DROP FUNCTION IF EXISTS create_admin_user(text, text, text, text);

-- Create a new function with fixed password handling
CREATE OR REPLACE FUNCTION create_admin_user(
  p_email TEXT,
  p_password TEXT,
  p_name TEXT,
  p_role TEXT
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_user_id uuid;
  v_result jsonb;
BEGIN
  -- Input validation
  IF p_email IS NULL OR p_email = '' THEN
    RAISE EXCEPTION 'Email cannot be empty';
  END IF;

  IF p_password IS NULL OR length(p_password) < 6 THEN
    RAISE EXCEPTION 'Password must be at least 6 characters long';
  END IF;

  IF p_role NOT IN ('admin', 'editor', 'moderator') THEN
    RAISE EXCEPTION 'Invalid role specified';
  END IF;

  -- Generate a new user ID
  v_user_id := gen_random_uuid();

  -- Create user in auth.users with static salt for password
  -- Using a static salt pattern that works with Supabase Auth
  INSERT INTO auth.users (
    id,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at,
    confirmation_token,
    recovery_token
  )
  VALUES (
    v_user_id,
    p_email,
    crypt(p_password, '$2a$10$abcdefghijklmnopqrstuv'),
    now(),
    '{"provider": "email", "providers": ["email"]}',
    jsonb_build_object('name', p_name),
    now(),
    now(),
    md5(random()::text),
    md5(random()::text)
  );

  -- Create admin user record with appropriate permissions
  INSERT INTO admin_users (
    id,
    role,
    permissions
  )
  VALUES (
    v_user_id,
    p_role,
    CASE 
      WHEN p_role = 'admin' THEN '["all"]'
      WHEN p_role = 'editor' THEN '["blog"]'
      WHEN p_role = 'moderator' THEN '["jobs", "payments"]'
      ELSE '[]'
    END::jsonb
  );

  -- Log the action
  INSERT INTO admin_audit_log (
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    'create_admin_user',
    'admin_users',
    v_user_id,
    jsonb_build_object(
      'email', p_email,
      'role', p_role,
      'created_at', now()
    )
  );

  -- Return success response
  v_result := jsonb_build_object(
    'success', true,
    'user', jsonb_build_object(
      'id', v_user_id,
      'email', p_email,
      'role', p_role
    )
  );

  RETURN v_result;

EXCEPTION WHEN OTHERS THEN
  -- Return error response
  RETURN jsonb_build_object(
    'success', false,
    'error', SQLERRM
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION create_admin_user(TEXT, TEXT, TEXT, TEXT) TO authenticated;

-- Add comment
COMMENT ON FUNCTION create_admin_user(TEXT, TEXT, TEXT, TEXT) IS 'Creates a new admin user with fixed password handling that works with Supabase Auth';