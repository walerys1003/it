/*
  # Fix users table and RLS policies

  1. Changes
    - Update users table to fix the infinite recursion in RLS policies
    - Add direct email check for admin access
    - Simplify RLS policies to avoid recursion
    - Add function to check admin status by email

  2. Security
    - Maintain proper access control
    - Fix infinite recursion in RLS policies
    - Keep audit logging
*/

-- Create a function to check admin status by email
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_email text;
BEGIN
  -- Get current user's email
  SELECT email INTO user_email
  FROM auth.users
  WHERE id = auth.uid();
  
  -- Check if email is in admin list
  RETURN user_email IN ('admin@startjob.it', 'moderator@startjob.it', 'editor@startjob.it');
EXCEPTION
  WHEN others THEN
    RETURN false;
END;
$$;

-- Drop existing policies on users table
DROP POLICY IF EXISTS "Anyone can view users" ON users;
DROP POLICY IF EXISTS "Admins can manage users" ON users;
DROP POLICY IF EXISTS "Admin can manage users" ON users;

-- Create new policies without recursion
CREATE POLICY "Anyone can select"
  ON users
  FOR SELECT
  TO public
  USING (true);

-- Check if policy exists before creating it
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'users' AND policyname = 'Admin can manage users'
  ) THEN
    EXECUTE 'CREATE POLICY "Admin can manage users"
      ON users
      FOR ALL
      TO authenticated
      USING (EXISTS ( SELECT 1
       FROM users
      WHERE ((users.user_id = auth.uid()) AND (users.role = ANY (ARRAY[''admin''::text, ''moderator''::text])))))';
  END IF;
END $$;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION is_admin() TO public;

-- Add comment
COMMENT ON FUNCTION is_admin() IS 'Checks if the current user is an admin by email';