/*
  # Add foreign key constraint to admin_audit_log

  1. Changes
    - Add foreign key constraint from admin_audit_log.admin_id to admin_users.id
    - This enables proper joins between admin_audit_log and admin_users tables
    - Fixes the error when trying to fetch admin email in the dashboard

  2. Security
    - Maintains existing RLS policies
    - Ensures referential integrity
*/

-- Add foreign key constraint if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 
    FROM information_schema.table_constraints 
    WHERE constraint_name = 'admin_audit_log_admin_id_fkey'
  ) THEN
    ALTER TABLE public.admin_audit_log
    ADD CONSTRAINT admin_audit_log_admin_id_fkey
    FOREIGN KEY (admin_id)
    REFERENCES public.admin_users (id);
  END IF;
END $$;