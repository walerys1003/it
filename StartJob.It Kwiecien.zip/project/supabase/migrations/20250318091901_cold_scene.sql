/*
  # Fix user creation functionality

  1. Changes
    - Add proper user creation with password
    - Update RPC function to handle auth
    - Add better error handling
    - Add validation

  2. Security
    - Secure password handling
    - Proper access control
    - Audit logging
*/

-- Create function to create admin user with password
CREATE OR REPLACE FUNCTION create_admin_user(
  p_email text,
  p_password text,
  p_name text,
  p_role text
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_result json;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Validate role
  IF p_role NOT IN ('admin', 'editor', 'moderator') THEN
    RAISE EXCEPTION 'Invalid role specified';
  END IF;

  -- Create user in auth.users
  v_user_id := (
    SELECT id FROM auth.users
    WHERE email = p_email
    LIMIT 1
  );

  IF v_user_id IS NULL THEN
    v_user_id := extensions.uuid_generate_v4();
    
    -- Insert user into auth.users
    INSERT INTO auth.users (
      id,
      email,
      raw_user_meta_data,
      email_confirmed_at,
      created_at,
      updated_at,
      confirmation_token,
      email_change_token_current,
      recovery_token
    ) VALUES (
      v_user_id,
      p_email,
      jsonb_build_object('name', p_name),
      now(),
      now(),
      now(),
      encode(extensions.gen_random_bytes(32), 'hex'),
      encode(extensions.gen_random_bytes(32), 'hex'),
      encode(extensions.gen_random_bytes(32), 'hex')
    );

    -- Set user password
    UPDATE auth.users
    SET encrypted_password = extensions.crypt(p_password, extensions.gen_salt('bf'))
    WHERE id = v_user_id;
  END IF;
  
  -- Insert into admin_users
  INSERT INTO admin_users (id, role, permissions)
  VALUES (v_user_id, p_role, '[]'::jsonb)
  ON CONFLICT (id) DO UPDATE
  SET role = EXCLUDED.role;

  -- Log the action
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'create_admin_user',
    'admin_users',
    v_user_id,
    jsonb_build_object(
      'email', p_email,
      'name', p_name,
      'role', p_role
    )
  );

  -- Return user data
  v_result := jsonb_build_object(
    'user', jsonb_build_object(
      'id', v_user_id,
      'email', p_email,
      'name', p_name,
      'role', p_role
    )
  );

  RETURN v_result;
END;
$$;