/*
  # Fix admin user update functionality

  1. Changes
    - Add function to update admin user role and metadata
    - Ensure proper transaction handling
    - Add detailed error logging
    - Fix issue with admin_users table not being updated

  2. Security
    - Maintain security definer
    - Keep admin access check
    - Add proper audit logging
*/

-- Create function to update admin user
CREATE OR REPLACE FUNCTION update_admin_user(
  p_user_id uuid,
  p_name text,
  p_role text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_old_role text;
  v_email text;
  v_old_metadata jsonb;
  v_new_metadata jsonb;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Validate role
  IF p_role NOT IN ('admin', 'editor', 'moderator') THEN
    RAISE EXCEPTION 'Invalid role specified';
  END IF;

  -- Start transaction
  BEGIN
    -- Get current user data for logging
    SELECT 
      u.email,
      u.raw_user_meta_data,
      au.role
    INTO 
      v_email,
      v_old_metadata,
      v_old_role
    FROM 
      auth.users u
    JOIN 
      admin_users au ON u.id = au.id
    WHERE 
      u.id = p_user_id;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'User not found';
    END IF;

    -- Update user metadata
    v_new_metadata := v_old_metadata || jsonb_build_object('name', p_name);
    
    UPDATE auth.users
    SET 
      raw_user_meta_data = v_new_metadata,
      updated_at = now()
    WHERE id = p_user_id;

    -- Update admin role
    UPDATE admin_users
    SET 
      role = p_role,
      updated_at = now()
    WHERE id = p_user_id;

    -- Log the action
    INSERT INTO admin_audit_log (
      admin_id,
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'update_admin_user',
      'admin_users',
      p_user_id,
      jsonb_build_object(
        'email', v_email,
        'old_role', v_old_role,
        'new_role', p_role,
        'old_metadata', v_old_metadata,
        'new_metadata', v_new_metadata,
        'updated_at', now()
      )
    );

    RETURN true;
  EXCEPTION
    WHEN others THEN
      -- Rollback is automatic in case of exception
      RAISE NOTICE 'Error updating user: %', SQLERRM;
      
      -- Log the error
      INSERT INTO admin_audit_log (
        admin_id,
        action,
        entity_type,
        entity_id,
        details
      ) VALUES (
        auth.uid(),
        'update_admin_user_error',
        'admin_users',
        p_user_id,
        jsonb_build_object(
          'error', SQLERRM,
          'email', v_email,
          'old_role', v_old_role,
          'new_role', p_role
        )
      );
      
      RETURN false;
  END;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION update_admin_user(uuid, text, text) TO authenticated;

-- Add comment
COMMENT ON FUNCTION update_admin_user(uuid, text, text) IS 'Updates an admin user role and metadata with proper transaction handling';