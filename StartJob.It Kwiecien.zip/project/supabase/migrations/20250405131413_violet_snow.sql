/*
  # Update admin_user_view to include role

  1. Changes
    - Update admin_user_view to include role from admin_users
    - Simplify access control to use hasAdminAccess function
    - Ensure proper joins between tables

  2. Security
    - Maintain existing RLS policies
    - Keep audit logging
*/

-- Drop existing view
DROP VIEW IF EXISTS admin_user_view;

-- Create improved view with role information
CREATE OR REPLACE VIEW admin_user_view AS
SELECT 
  u.id,
  u.email,
  u.raw_user_meta_data as user_metadata,
  u.created_at,
  au.role as admin_role
FROM auth.users u
LEFT JOIN admin_users au ON au.id = u.id
WHERE EXISTS (
  SELECT 1 
  FROM admin_users 
  WHERE id = auth.uid()
);

-- Grant necessary permissions
GRANT SELECT ON admin_user_view TO authenticated;

-- Add comment
COMMENT ON VIEW admin_user_view IS 'Secure view for admin users to manage system users';