/*
  # Add payment status update function

  1. New Functions
    - `update_payment_status`: Updates payment status and related job status
      - Takes payment_id and new_status as parameters
      - Updates payment status and paid_at timestamp
      - Updates job is_active status when payment is completed
      - Returns boolean indicating success

  2. Security
    - Function is available to public
    - Includes error handling and logging
*/

-- Create function to update payment status
CREATE OR REPLACE FUNCTION update_payment_status(
  payment_id uuid,
  new_status text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  payment_record payments;
BEGIN
  -- Validate status
  IF new_status NOT IN ('pending', 'completed', 'failed', 'refunded') THEN
    RAISE EXCEPTION 'Invalid payment status: %', new_status;
  END IF;

  -- Get payment record
  SELECT * INTO payment_record
  FROM payments
  WHERE id = payment_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Payment not found: %', payment_id;
  END IF;

  -- Update payment status
  UPDATE payments
  SET 
    status = new_status,
    updated_at = now(),
    paid_at = CASE 
      WHEN new_status = 'completed' THEN now()
      ELSE paid_at
    END
  WHERE id = payment_id;

  -- If payment is completed, activate the job
  IF new_status = 'completed' THEN
    UPDATE jobs
    SET is_active = true
    WHERE id = payment_record.job_id;
  END IF;

  -- Log the status change
  INSERT INTO payment_logs (
    attempted_at,
    job_data,
    payment_data,
    success,
    created_payment_id
  )
  VALUES (
    now(),
    jsonb_build_object('job_id', payment_record.job_id),
    jsonb_build_object(
      'payment_id', payment_id,
      'old_status', payment_record.status,
      'new_status', new_status
    ),
    true,
    payment_id
  );

  RETURN true;
EXCEPTION
  WHEN others THEN
    -- Log the error
    INSERT INTO payment_logs (
      attempted_at,
      payment_data,
      error_message,
      error_detail,
      success,
      created_payment_id
    )
    VALUES (
      now(),
      jsonb_build_object(
        'payment_id', payment_id,
        'new_status', new_status
      ),
      SQLERRM,
      SQLSTATE,
      false,
      payment_id
    );
    
    RETURN false;
END;
$$;

-- Grant execute permission to public
GRANT EXECUTE ON FUNCTION update_payment_status(uuid, text) TO public;