/*
  # Fix admin user login issues

  1. Changes
    - Update existing admin users with proper provider information
    - Ensure all admin users have confirmed emails
    - Set proper password hashing for all admin users
    - Create example users with correct credentials

  2. Security
    - Maintain existing RLS policies
    - Keep audit logging
*/

-- Enable pgcrypto extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Temporarily disable admin user validation trigger
ALTER TABLE admin_users DISABLE TRIGGER validate_admin_user_operation;

-- Update existing users to have proper provider information and verified email
UPDATE auth.users
SET 
  raw_app_meta_data = '{"provider": "email", "providers": ["email"]}'::jsonb,
  email_confirmed_at = COALESCE(email_confirmed_at, now())
WHERE id IN (SELECT id FROM admin_users);

-- Create or update example users with proper credentials
DO $$
DECLARE
  admin_id uuid := '14293968-0fe7-476d-a8e5-e821d191ca46';
  moderator_id uuid;
  editor_id uuid;
  hashed_password TEXT;
BEGIN
  -- Generate hashed password using bcrypt
  hashed_password := crypt('Startjob25!', gen_salt('bf'));
  
  -- Check if admin exists and update password if needed
  IF EXISTS (SELECT 1 FROM auth.users WHERE id = admin_id) THEN
    -- Update admin password
    UPDATE auth.users
    SET 
      encrypted_password = hashed_password,
      email_confirmed_at = now(),
      raw_app_meta_data = '{"provider": "email", "providers": ["email"]}'::jsonb,
      updated_at = now(),
      aud = 'authenticated',
      role = 'authenticated'
    WHERE id = admin_id;
    
    RAISE NOTICE 'Updated admin user password';
  END IF;
  
  -- Create moderator user if not exists
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE email = 'moderator@startjob.it') THEN
    -- Generate a new UUID for the moderator
    moderator_id := gen_random_uuid();
    
    -- Insert moderator into auth.users
    INSERT INTO auth.users (
      id,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      aud,
      role
    ) VALUES (
      moderator_id,
      'moderator@startjob.it',
      hashed_password,
      now(),
      '{"provider": "email", "providers": ["email"]}'::jsonb,
      '{"name": "Moderator User"}'::jsonb,
      now(),
      now(),
      'authenticated',
      'authenticated'
    );
    
    -- Insert moderator into admin_users
    INSERT INTO admin_users (id, role, permissions)
    VALUES (moderator_id, 'moderator', '["jobs", "payments"]'::jsonb);
    
    RAISE NOTICE 'Created moderator user';
  ELSE
    -- Get moderator ID
    SELECT id INTO moderator_id FROM auth.users WHERE email = 'moderator@startjob.it';
    
    -- Update existing moderator
    UPDATE auth.users
    SET 
      encrypted_password = hashed_password,
      email_confirmed_at = now(),
      raw_app_meta_data = '{"provider": "email", "providers": ["email"]}'::jsonb,
      updated_at = now(),
      aud = 'authenticated',
      role = 'authenticated'
    WHERE email = 'moderator@startjob.it';
    
    -- Ensure moderator has admin_users record
    INSERT INTO admin_users (id, role, permissions)
    VALUES (moderator_id, 'moderator', '["jobs", "payments"]'::jsonb)
    ON CONFLICT (id) DO UPDATE
    SET role = 'moderator', permissions = '["jobs", "payments"]'::jsonb;
    
    RAISE NOTICE 'Updated moderator user password';
  END IF;
  
  -- Create editor user if not exists
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE email = 'editor@startjob.it') THEN
    -- Generate a new UUID for the editor
    editor_id := gen_random_uuid();
    
    -- Insert editor into auth.users
    INSERT INTO auth.users (
      id,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      aud,
      role
    ) VALUES (
      editor_id,
      'editor@startjob.it',
      hashed_password,
      now(),
      '{"provider": "email", "providers": ["email"]}'::jsonb,
      '{"name": "Editor User"}'::jsonb,
      now(),
      now(),
      'authenticated',
      'authenticated'
    );
    
    -- Insert editor into admin_users
    INSERT INTO admin_users (id, role, permissions)
    VALUES (editor_id, 'editor', '["blog"]'::jsonb);
    
    RAISE NOTICE 'Created editor user';
  ELSE
    -- Get editor ID
    SELECT id INTO editor_id FROM auth.users WHERE email = 'editor@startjob.it';
    
    -- Update existing editor
    UPDATE auth.users
    SET 
      encrypted_password = hashed_password,
      email_confirmed_at = now(),
      raw_app_meta_data = '{"provider": "email", "providers": ["email"]}'::jsonb,
      updated_at = now(),
      aud = 'authenticated',
      role = 'authenticated'
    WHERE email = 'editor@startjob.it';
    
    -- Ensure editor has admin_users record
    INSERT INTO admin_users (id, role, permissions)
    VALUES (editor_id, 'editor', '["blog"]'::jsonb)
    ON CONFLICT (id) DO UPDATE
    SET role = 'editor', permissions = '["blog"]'::jsonb;
    
    RAISE NOTICE 'Updated editor user password';
  END IF;
  
  -- Log the action
  INSERT INTO admin_audit_log (
    action,
    entity_type,
    details
  ) VALUES (
    'fix_admin_users_login',
    'admin_users',
    jsonb_build_object(
      'fixed_at', now(),
      'description', 'Fixed admin users login issues'
    )
  );
END $$;

-- Re-enable admin user validation trigger
ALTER TABLE admin_users ENABLE TRIGGER validate_admin_user_operation;