/*
  # Fix job categories creation

  1. Changes
    - Update manage_job_category function to properly set created_at
    - Fix error handling
    - Add validation for empty values

  2. Security
    - Maintain existing security checks
    - Keep audit logging
*/

-- Drop existing function
DROP FUNCTION IF EXISTS manage_job_category(uuid, text, text, uuid);

-- Create improved function with proper timestamp handling
CREATE OR REPLACE FUNCTION manage_job_category(
  p_id uuid,
  p_name text,
  p_code text,
  p_parent_id uuid DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_category_id uuid;
  v_existing_code text;
  v_now timestamptz;
BEGIN
  -- Input validation
  IF p_name IS NULL OR trim(p_name) = '' THEN
    RAISE EXCEPTION 'Category name cannot be empty';
  END IF;

  IF p_code IS NULL OR trim(p_code) = '' THEN
    RAISE EXCEPTION 'Category code cannot be empty';
  END IF;

  -- Check if user has admin privileges
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Get current timestamp
  v_now := now();

  -- Check if code already exists for a different category
  IF p_id IS NULL THEN
    SELECT id INTO v_category_id
    FROM job_categories
    WHERE code = p_code;
    
    IF FOUND THEN
      RAISE EXCEPTION 'Category with code % already exists', p_code;
    END IF;
  END IF;

  -- Insert or update category
  IF p_id IS NULL THEN
    -- Create new category
    INSERT INTO job_categories (
      name,
      code,
      parent_id,
      created_at,
      updated_at
    )
    VALUES (
      p_name,
      p_code,
      p_parent_id,
      v_now,
      v_now
    )
    RETURNING id INTO v_category_id;

    -- Log the creation
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      'create_job_category',
      'job_categories',
      v_category_id,
      jsonb_build_object(
        'name', p_name,
        'code', p_code,
        'parent_id', p_parent_id,
        'created_at', v_now
      )
    );
  ELSE
    -- Update existing category
    UPDATE job_categories
    SET
      name = p_name,
      code = p_code,
      parent_id = p_parent_id,
      updated_at = v_now
    WHERE id = p_id
    RETURNING id INTO v_category_id;

    -- Log the update
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      'update_job_category',
      'job_categories',
      v_category_id,
      jsonb_build_object(
        'name', p_name,
        'code', p_code,
        'parent_id', p_parent_id,
        'updated_at', v_now
      )
    );
  END IF;

  RETURN v_category_id;
EXCEPTION
  WHEN others THEN
    -- Log error
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      details
    ) VALUES (
      'job_category_error',
      'job_categories',
      jsonb_build_object(
        'error', SQLERRM,
        'name', p_name,
        'code', p_code,
        'parent_id', p_parent_id
      )
    );
    RAISE;
END;
$$;

-- Grant execute permission to public
GRANT EXECUTE ON FUNCTION manage_job_category(uuid, text, text, uuid) TO public;

-- Add comment
COMMENT ON FUNCTION manage_job_category(uuid, text, text, uuid) IS 'Creates or updates a job category with proper validation, timestamps and logging';