/*
  # Add sample blog posts

  1. New Data
    - Add 5 example blog posts with realistic content
    - Link posts to existing categories
    - Add tags to posts
    - Include all required metadata (author, dates, etc.)

  2. Posts Added:
    - "10 Essential Tips for Remote Work in IT"
    - "The Future of AI in Software Development"
    - "How to Prepare for a Technical Interview"
    - "DevOps Best Practices for 2025"
    - "Work-Life Balance in the Tech Industry"
*/

-- Get category IDs
WITH categories AS (
  SELECT id, name FROM blog_taxonomies WHERE type = 'category'
)
-- Insert sample blog posts
INSERT INTO blog_posts (
  title,
  subtitle,
  content,
  excerpt,
  thumbnail_url,
  author_name,
  author_role,
  author_avatar_url,
  category_id,
  published_at,
  is_published,
  is_featured
)
VALUES
-- Post 1: Remote Work Tips
(
  '10 Essential Tips for Remote Work in IT',
  'Maximize Your Productivity and Well-being While Working Remotely',
  E'Working remotely in the IT industry has become increasingly common, especially after recent global changes. Here are 10 essential tips to help you succeed in your remote work journey.\n\n
1. Set Up a Dedicated Workspace\n
Create a comfortable, ergonomic workspace that''s solely dedicated to work. This helps maintain work-life boundaries and increases productivity.\n\n
2. Establish a Routine\n
Maintain regular working hours and create a daily routine that includes breaks and exercise. Structure helps maintain focus and prevents burnout.\n\n
3. Use the Right Tools\n
Invest in reliable tools for communication, project management, and development. Essential tools include:\n
- Video conferencing software
- Project management platforms
- Version control systems
- Cloud storage solutions\n\n
4. Communicate Effectively\n
Over-communication is better than under-communication in remote work. Keep your team updated on:\n
- Project progress
- Availability
- Potential blockers
- Important decisions\n\n
5. Take Regular Breaks\n
Use techniques like the Pomodoro Method to maintain productivity and prevent fatigue.\n\n
6. Stay Secure\n
Implement proper security measures:\n
- Use a VPN
- Enable two-factor authentication
- Keep software updated
- Follow company security protocols\n\n
7. Network Virtually\n
Stay connected with the tech community through:\n
- Online meetups
- Virtual conferences
- Professional social networks
- Community forums\n\n
8. Maintain Work-Life Balance\n
Set clear boundaries between work and personal life:\n
- Define working hours
- Create end-of-day rituals
- Turn off notifications after hours\n\n
9. Invest in Professional Development\n
Use the flexibility of remote work to improve your skills:\n
- Take online courses
- Participate in virtual workshops
- Read technical blogs
- Contribute to open-source projects\n\n
10. Practice Self-Care\n
Don''t forget about your physical and mental health:\n
- Exercise regularly
- Maintain social connections
- Take time off when needed
- Practice mindfulness\n\n
Remember, successful remote work is about finding the right balance between productivity and well-being. Experiment with these tips and adapt them to your personal situation.',
  'Discover essential strategies for maintaining productivity, work-life balance, and professional growth while working remotely in the IT industry.',
  'https://images.unsplash.com/photo-1591382696684-38c427c7547a?auto=format&fit=crop&w=1200&q=80',
  'Anna Kowalska',
  'Senior IT Recruiter',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150',
  (SELECT id FROM categories WHERE name = 'Porady dla Kandydatów'),
  NOW() - INTERVAL '2 days',
  true,
  true
),

-- Post 2: AI in Software Development
(
  'The Future of AI in Software Development',
  'How Artificial Intelligence is Transforming the Way We Code',
  E'Artificial Intelligence is revolutionizing software development, making processes more efficient and enabling new possibilities. Let''s explore how AI is shaping the future of programming.\n\n
The Current State of AI in Development\n
AI tools are already making an impact in various areas:\n
- Code completion and suggestions
- Bug detection and fixing
- Code review automation
- Test generation
- Performance optimization\n\n
Key AI Technologies in Software Development\n\n
1. Large Language Models (LLMs)\n
- Code generation from natural language
- Documentation writing
- Code explanation and analysis
- Refactoring suggestions\n\n
2. Machine Learning for Code Analysis\n
- Pattern recognition in codebases
- Security vulnerability detection
- Code quality assessment
- Performance bottleneck identification\n\n
3. Automated Testing\n
- Test case generation
- UI testing automation
- API testing
- Load testing optimization\n\n
Impact on Developer Roles\n\n
The role of developers is evolving with AI:\n
- Focus shifts to high-level design and architecture
- More time for creative problem-solving
- Increased emphasis on AI tool expertise
- New specializations in AI-assisted development\n\n
Challenges and Considerations\n\n
1. Code Quality and Review\n
- Ensuring AI-generated code meets standards
- Maintaining code readability
- Managing technical debt
- Balancing automation with human oversight\n\n
2. Security Concerns\n
- Validating AI suggestions
- Protecting sensitive code
- Managing dependencies
- Ensuring compliance\n\n
3. Skills Adaptation\n
- Learning to work with AI tools
- Understanding AI limitations
- Developing prompt engineering skills
- Maintaining core programming expertise\n\n
Future Trends\n\n
1. Enhanced Developer Experience\n
- More sophisticated code completion
- Natural language programming
- Automated documentation
- Intelligent debugging\n\n
2. AI-Driven Architecture\n
- Automated system design
- Performance optimization
- Scalability analysis
- Resource allocation\n\n
3. Democratization of Development\n
- Low-code/no-code platforms
- AI-assisted learning
- Accessible development tools
- Simplified deployment\n\n
Preparing for the Future\n\n
Developers should:\n
1. Stay informed about AI developments
2. Experiment with AI tools
3. Focus on high-level skills
4. Understand AI limitations
5. Maintain ethical considerations\n\n
Conclusion\n
AI in software development is not about replacing developers but augmenting their capabilities. The future belongs to those who can effectively collaborate with AI tools while maintaining their core development expertise.',
  'Explore how artificial intelligence is revolutionizing software development and what it means for developers in 2025 and beyond.',
  'https://images.unsplash.com/photo-1555949963-ff9fe0c870eb?auto=format&fit=crop&w=1200&q=80',
  'Dr. Marek Wiśniewski',
  'AI Research Lead',
  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=150&h=150',
  (SELECT id FROM categories WHERE name = 'Trendy w Branży IT'),
  NOW() - INTERVAL '5 days',
  true,
  true
),

-- Post 3: Technical Interview Preparation
(
  'How to Prepare for a Technical Interview',
  'A Comprehensive Guide to Acing Your Next Tech Interview',
  E'Technical interviews can be challenging, but with proper preparation, you can approach them with confidence. Here''s a comprehensive guide to help you succeed.\n\n
Before the Interview\n\n
1. Review Fundamentals\n
- Data structures
- Algorithms
- Time and space complexity
- System design basics
- Your primary programming languages\n\n
2. Practice Problem Solving\n
- LeetCode/HackerRank exercises
- System design questions
- Whiteboard coding
- Time-boxed challenges\n\n
3. Research the Company\n
- Technology stack
- Products and services
- Recent news and developments
- Company culture and values\n\n
During the Interview\n\n
1. Problem-Solving Approach\n
- Listen carefully to the problem
- Ask clarifying questions
- Discuss your approach before coding
- Think aloud while solving
- Consider edge cases\n\n
2. Communication Tips\n
- Explain your thought process
- Be open to feedback
- Ask meaningful questions
- Stay calm and professional
- Show enthusiasm\n\n
3. Technical Discussion\n
- Be honest about your experience
- Provide specific examples
- Discuss past projects
- Explain technical decisions
- Share lessons learned\n\n
Common Interview Topics\n\n
1. Coding Questions\n
- Array manipulation
- String processing
- Tree traversal
- Graph algorithms
- Dynamic programming\n\n
2. System Design\n
- Scalability
- Database design
- API design
- Microservices
- Caching strategies\n\n
3. Behavioral Questions\n
- Team collaboration
- Conflict resolution
- Project management
- Technical leadership
- Learning from failures\n\n
After the Interview\n\n
1. Follow Up\n
- Send a thank-you email
- Address any missed points
- Express continued interest
- Ask about next steps\n\n
2. Self-Review\n
- Analyze your performance
- Note areas for improvement
- Research topics you struggled with
- Maintain positive attitude\n\n
Interview Success Tips\n\n
1. Stay Calm\n
- Take deep breaths
- Pause when needed
- Ask for clarification
- Stay focused\n\n
2. Show Growth Mindset\n
- Embrace challenges
- Learn from feedback
- Demonstrate adaptability
- Show enthusiasm for learning\n\n
3. Be Authentic\n
- Share real experiences
- Admit when you don''t know
- Show personality
- Be professional\n\n
Remember, preparation is key to interview success. Focus on both technical skills and soft skills to present yourself as a well-rounded candidate.',
  'Learn how to effectively prepare for technical interviews in the IT industry with our comprehensive guide covering all aspects from preparation to follow-up.',
  'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=1200&q=80',
  'Piotr Nowak',
  'Tech Recruitment Manager',
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&h=150',
  (SELECT id FROM categories WHERE name = 'Porady dla Kandydatów'),
  NOW() - INTERVAL '7 days',
  true,
  false
),

-- Post 4: DevOps Best Practices
(
  'DevOps Best Practices for 2025',
  'Modern Approaches to Development Operations and Continuous Integration',
  E'DevOps practices continue to evolve with new technologies and methodologies. Here are the current best practices for successful DevOps implementation.\n\n
Infrastructure as Code (IaC)\n\n
1. Version Control\n
- Use Git for infrastructure code
- Implement branching strategies
- Review infrastructure changes
- Maintain documentation\n\n
2. Configuration Management\n
- Automate configuration
- Use templates
- Implement drift detection
- Maintain consistency\n\n
Continuous Integration/Continuous Deployment (CI/CD)\n\n
1. Automated Testing\n
- Unit tests
- Integration tests
- Security scans
- Performance testing\n\n
2. Deployment Strategies\n
- Blue-green deployment
- Canary releases
- Feature flags
- Rollback procedures\n\n
Monitoring and Observability\n\n
1. Metrics Collection\n
- System performance
- Application metrics
- User experience
- Business KPIs\n\n
2. Logging and Tracing\n
- Centralized logging
- Distributed tracing
- Error tracking
- Performance monitoring\n\n
Security (DevSecOps)\n\n
1. Security Automation\n
- Automated security testing
- Vulnerability scanning
- Compliance checking
- Secret management\n\n
2. Access Control\n
- Role-based access
- Least privilege principle
- Audit logging
- Identity management\n\n
Container Orchestration\n\n
1. Kubernetes Best Practices\n
- Resource management
- High availability
- Auto-scaling
- Network policies\n\n
2. Container Security\n
- Image scanning
- Runtime security
- Network isolation
- Access control\n\n
Collaboration and Communication\n\n
1. Team Integration\n
- Cross-functional teams
- Shared responsibilities
- Knowledge sharing
- Regular meetings\n\n
2. Documentation\n
- Architecture diagrams
- Runbooks
- Incident response plans
- Knowledge base\n\n
Remember, successful DevOps implementation requires a balance of automation, security, and team collaboration.',
  'Discover the latest DevOps best practices for 2025, including infrastructure as code, CI/CD, monitoring, and security considerations.',
  'https://images.unsplash.com/photo-1667372393119-3d4c48d07fc9?auto=format&fit=crop&w=1200&q=80',
  'Tomasz Kowalczyk',
  'Senior DevOps Engineer',
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=150&h=150',
  (SELECT id FROM categories WHERE name = 'Trendy w Branży IT'),
  NOW() - INTERVAL '10 days',
  true,
  false
),

-- Post 5: Work-Life Balance
(
  'Work-Life Balance in the Tech Industry',
  'Finding Harmony Between Professional Growth and Personal Well-being',
  E'Maintaining work-life balance in the fast-paced tech industry can be challenging. Here''s how to achieve harmony while advancing your career.\n\n
Understanding Work-Life Balance\n\n
1. What It Means\n
- Setting boundaries
- Managing time effectively
- Prioritizing health
- Making time for personal life\n\n
2. Why It''s Important\n
- Prevents burnout
- Increases productivity
- Improves mental health
- Enhances creativity\n\n
Common Challenges in Tech\n\n
1. Industry Pressures\n
- Rapid technology changes
- Project deadlines
- On-call duties
- Continuous learning\n\n
2. Remote Work Issues\n
- Blurred boundaries
- Extended hours
- Digital fatigue
- Isolation\n\n
Strategies for Balance\n\n
1. Time Management\n
- Set working hours
- Take regular breaks
- Use time-blocking
- Prioritize tasks\n\n
2. Physical Health\n
- Regular exercise
- Proper ergonomics
- Healthy eating
- Adequate sleep\n\n
3. Mental Well-being\n
- Practice mindfulness
- Set boundaries
- Take vacations
- Pursue hobbies\n\n
4. Professional Development\n
- Scheduled learning time
- Career planning
- Skill development
- Networking\n\n
Creating Boundaries\n\n
1. Digital Boundaries\n
- Turn off notifications
- Separate work devices
- Set availability hours
- Use do-not-disturb\n\n
2. Physical Boundaries\n
- Dedicated workspace
- Regular schedule
- Clear start/end times
- Transition rituals\n\n
Company Culture\n\n
1. Positive Environment\n
- Flexible hours
- Remote options
- Mental health support
- Professional development\n\n
2. Team Practices\n
- Respect time off
- Efficient meetings
- Clear communication
- Support systems\n\n
Success Stories\n\n
Real examples of tech professionals who have achieved work-life balance while advancing their careers.\n\n
Conclusion\n
Work-life balance is achievable in tech with the right strategies and support. It''s essential for long-term success and satisfaction in your career.',
  'Learn how to maintain a healthy work-life balance in the demanding tech industry while continuing to grow professionally.',
  'https://images.unsplash.com/photo-1499750310107-5fef28a66643?auto=format&fit=crop&w=1200&q=80',
  'Magdalena Nowak',
  'Wellness Coach & Former Developer',
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&h=150',
  (SELECT id FROM categories WHERE name = 'Porady dla Kandydatów'),
  NOW() - INTERVAL '14 days',
  true,
  false
);

-- Add tags to posts
WITH posts AS (
  SELECT id, title FROM blog_posts
),
tags AS (
  SELECT id, name FROM blog_taxonomies WHERE type = 'tag'
)
INSERT INTO blog_post_tags (post_id, tag_id)
SELECT 
  p.id,
  t.id
FROM posts p
CROSS JOIN tags t
WHERE 
  (p.title LIKE '%Remote Work%' AND t.name IN ('Remote Work', 'Work-Life Balance')) OR
  (p.title LIKE '%AI%' AND t.name IN ('AI', 'Machine Learning')) OR
  (p.title LIKE '%Technical Interview%' AND t.name IN ('Interview Tips', 'Career Development')) OR
  (p.title LIKE '%DevOps%' AND t.name IN ('DevOps', 'Best Practices')) OR
  (p.title LIKE '%Work-Life Balance%' AND t.name IN ('Work-Life Balance', 'Career Development'));