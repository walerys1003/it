/*
  # Fix admin user creation and login

  1. Changes
    - Create a new function that properly sets user passwords
    - Use Supabase auth.users table structure correctly
    - Add proper error handling and validation
    - Fix password hashing

  2. Security
    - Ensure passwords are properly hashed
    - Maintain admin access control
    - Keep audit logging
*/

-- Drop existing function
DROP FUNCTION IF EXISTS create_admin_user(text, text, text, text);

-- Create improved function with proper password handling
CREATE OR REPLACE FUNCTION create_admin_user(
  p_email text,
  p_password text,
  p_name text,
  p_role text
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_result json;
  v_error text;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Validate role
  IF p_role NOT IN ('admin', 'editor', 'moderator') THEN
    RAISE EXCEPTION 'Invalid role specified';
  END IF;

  -- Validate password
  IF length(p_password) < 6 THEN
    RAISE EXCEPTION 'Password must be at least 6 characters long';
  END IF;

  -- Generate a new user ID
  v_user_id := gen_random_uuid();

  -- Create user in auth.users with proper password hashing
  BEGIN
    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      recovery_sent_at,
      last_sign_in_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at,
      confirmation_token,
      email_change_token_current,
      recovery_token
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      v_user_id,
      'authenticated',
      'authenticated',
      p_email,
      crypt(p_password, gen_salt('bf')),
      now(),
      now(),
      now(),
      '{"provider": "email", "providers": ["email"]}',
      jsonb_build_object('name', p_name),
      now(),
      now(),
      encode(sha256(random()::text::bytea), 'hex'),
      encode(sha256(random()::text::bytea), 'hex'),
      encode(sha256(random()::text::bytea), 'hex')
    );
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_error = PG_EXCEPTION_DETAIL;
    RAISE EXCEPTION 'Error inserting user: % (Detail: %)', SQLERRM, v_error;
  END;

  -- Insert into admin_users
  BEGIN
    INSERT INTO admin_users (id, role, permissions)
    VALUES (v_user_id, p_role, '[]'::jsonb);
  EXCEPTION WHEN OTHERS THEN
    -- Clean up the user if admin_user creation fails
    DELETE FROM auth.users WHERE id = v_user_id;
    GET STACKED DIAGNOSTICS v_error = PG_EXCEPTION_DETAIL;
    RAISE EXCEPTION 'Error inserting admin user: % (Detail: %)', SQLERRM, v_error;
  END;

  -- Log the action
  BEGIN
    INSERT INTO admin_audit_log (
      admin_id,
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'create_admin_user',
      'admin_users',
      v_user_id,
      jsonb_build_object(
        'email', p_email,
        'name', p_name,
        'role', p_role
      )
    );
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Error logging admin action: %', SQLERRM;
  END;

  -- Return user data
  v_result := jsonb_build_object(
    'user', jsonb_build_object(
      'id', v_user_id,
      'email', p_email,
      'name', p_name,
      'role', p_role
    )
  );

  RETURN v_result;
EXCEPTION
  WHEN unique_violation THEN
    RAISE EXCEPTION 'Email already exists';
  WHEN others THEN
    GET STACKED DIAGNOSTICS v_error = PG_EXCEPTION_DETAIL;
    RAISE EXCEPTION 'Error creating user: % (Detail: %)', SQLERRM, v_error;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION create_admin_user(text, text, text, text) TO authenticated;

-- Add comment
COMMENT ON FUNCTION create_admin_user(text, text, text, text) IS 'Creates a new admin user with proper password hashing and error handling';