/*
  # Remove description from promotion services

  1. Changes
    - Update promotion_services in site_settings
    - Remove description field from each service
    - Keep existing service data structure
*/

-- Update promotion services to remove description
UPDATE site_settings 
SET value = (
  SELECT jsonb_agg(
    jsonb_build_object(
      'id', service->>'id',
      'name', service->>'name',
      'price', (service->>'price')::numeric
    )
  )
  FROM jsonb_array_elements(value) service
)
WHERE key = 'promotion_services';