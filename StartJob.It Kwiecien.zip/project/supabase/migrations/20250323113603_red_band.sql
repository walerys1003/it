/*
  # Add technology deletion function

  1. Changes
    - Add RPC function for safely deleting technologies
    - Add proper error handling
    - Add audit logging

  2. Security
    - Function is security definer
    - Only admins can delete technologies
    - Maintain audit trail
*/

-- Create function to delete technology
CREATE OR REPLACE FUNCTION delete_technology(technology_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  tech_record technologies;
BEGIN
  -- Check if user has admin privileges
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Get technology details for logging
  SELECT * INTO tech_record
  FROM technologies
  WHERE id = technology_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Technology not found';
  END IF;

  -- Delete the technology
  DELETE FROM technologies WHERE id = technology_id;

  -- Log the deletion
  INSERT INTO admin_audit_log (
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    'delete_technology',
    'technologies',
    technology_id,
    jsonb_build_object(
      'name', tech_record.name,
      'code', tech_record.code,
      'category', tech_record.category,
      'deleted_at', now()
    )
  );

  RETURN true;
EXCEPTION
  WHEN others THEN
    -- Log error details
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      'delete_technology_error',
      'technologies',
      technology_id,
      jsonb_build_object(
        'error', SQLERRM,
        'error_detail', SQLSTATE
      )
    );
    
    RETURN false;
END;
$$;

-- Grant execute permission to public
GRANT EXECUTE ON FUNCTION delete_technology(uuid) TO public;

-- Add comment
COMMENT ON FUNCTION delete_technology(uuid) IS 'Safely deletes a technology with proper access control and logging';