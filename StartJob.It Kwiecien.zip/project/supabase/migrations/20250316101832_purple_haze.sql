/*
  # Add payment handling functions

  1. New Functions
    - `handle_job_payment`: Function to handle job posting payment process
      - Creates inactive job posting
      - Creates pending payment record
      - Returns payment ID for tracking

  2. Notes
    - Ensures atomic transaction handling
    - Maintains data consistency between jobs and payments tables
*/

-- Function to handle job posting payment process
CREATE OR REPLACE FUNCTION handle_job_payment(
  job_data jsonb,
  payment_data jsonb
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  new_job_id uuid;
  new_payment_id uuid;
BEGIN
  -- Insert job with is_active = false
  INSERT INTO jobs (
    title,
    category,
    description,
    responsibilities,
    requirements,
    nice_to_have,
    technologies,
    work_mode,
    experience_level,
    contract_type,
    salary_from,
    salary_to,
    currency,
    benefits,
    location_country,
    location_voivodeship,
    location_city,
    languages,
    company_name,
    company_description,
    company_size,
    company_logo,
    contact_name,
    contact_position,
    contact_email,
    contact_phone,
    valid_until,
    is_active,
    is_featured,
    is_premium,
    user_id
  )
  SELECT
    (job_data->>'title')::text,
    (job_data->>'category')::text,
    (job_data->>'description')::text,
    (job_data->>'responsibilities')::text[],
    (job_data->>'requirements')::text[],
    COALESCE((job_data->>'niceToHave')::text[], '{}'),
    (job_data->>'technologies')::text[],
    (job_data->>'workMode')::text,
    (job_data->>'experienceLevel')::text,
    (job_data->>'contractType')::text,
    (job_data->>'salaryFrom')::integer,
    (job_data->>'salaryTo')::integer,
    COALESCE((job_data->>'currency')::text, 'PLN'),
    COALESCE((job_data->>'benefits')::text[], '{}'),
    (job_data->>'location'->>'country')::text,
    (job_data->>'location'->>'voivodeship')::text,
    (job_data->>'location'->>'city')::text,
    COALESCE((job_data->>'languages')::jsonb[], '{}'),
    (job_data->>'company'->>'name')::text,
    (job_data->>'company'->>'description')::text,
    (job_data->>'company'->>'size')::text,
    (job_data->>'company'->>'logo')::text,
    (job_data->>'contact'->>'name')::text,
    (job_data->>'contact'->>'position')::text,
    (job_data->>'contact'->>'email')::text,
    (job_data->>'contact'->>'phone')::text,
    CURRENT_TIMESTAMP + INTERVAL '90 days',
    false,
    (job_data->>'packageType')::text = 'premium',
    (job_data->>'packageType')::text = 'premium',
    auth.uid()
  RETURNING id INTO new_job_id;

  -- Insert payment record with pending status
  INSERT INTO payments (
    job_id,
    amount,
    currency,
    status,
    package_type,
    payment_method,
    invoice_data
  )
  VALUES (
    new_job_id,
    CASE 
      WHEN (job_data->>'packageType')::text = 'premium' THEN 899.00
      ELSE 599.00
    END,
    'PLN',
    'pending',
    (job_data->>'packageType')::text,
    (payment_data->>'paymentMethod')::text,
    payment_data->'invoiceData'
  )
  RETURNING id INTO new_payment_id;

  RETURN new_payment_id;
END;
$$;