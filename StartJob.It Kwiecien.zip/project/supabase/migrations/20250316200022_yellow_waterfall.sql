/*
  # Fix admin audit log RLS policy

  1. Changes
    - Add policy for inserting records into admin_audit_log table
    - Keep existing policies for viewing logs

  2. Security
    - Allow public insert access to admin_audit_log
    - Maintain existing read access policies
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Public can view payment logs" ON admin_audit_log;

-- Create new policies
CREATE POLICY "Anyone can create audit logs"
  ON admin_audit_log
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can view audit logs"
  ON admin_audit_log
  FOR SELECT
  TO public
  USING (true);