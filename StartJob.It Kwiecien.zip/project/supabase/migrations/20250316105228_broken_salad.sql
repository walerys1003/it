/*
  # Update payment handling

  1. Changes
    - Remove job creation from handle_job_payment function
    - Only log payment attempts in payment_logs table
    - Add payment status update functionality

  2. Security
    - Maintain public access to function
    - Keep existing RLS policies
*/

-- Drop existing function
DROP FUNCTION IF EXISTS handle_job_payment(jsonb, jsonb);

-- Create new function that only handles payment logging
CREATE OR REPLACE FUNCTION handle_job_payment(
  job_data jsonb,
  payment_data jsonb
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  log_id uuid;
BEGIN
  -- Create log entry
  INSERT INTO payment_logs (
    job_data,
    payment_data,
    success,
    error_message
  )
  VALUES (
    job_data,
    payment_data,
    false,
    'Payment failed'
  )
  RETURNING id INTO log_id;

  RETURN log_id;
END;
$$;

-- Grant execute permission to public
GRANT EXECUTE ON FUNCTION handle_job_payment(jsonb, jsonb) TO public;