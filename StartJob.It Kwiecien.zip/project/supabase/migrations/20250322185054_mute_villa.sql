/*
  # Add job options tables

  1. New Tables
    - `job_categories`: Available job categories and subcategories
    - `working_modes`: Available working modes (remote, hybrid, office)
    - `experience_levels`: Available experience levels (junior, mid, senior, etc.)
    - `contract_types`: Available contract types (B2B, employment, etc.)
    - `benefits`: Available benefits (healthcare, sports card, etc.)
    - `languages`: Available languages with their codes
    - `company_sizes`: Available company size ranges

  2. Security
    - Enable RLS on all tables
    - Add policies for public read access
    - Add policies for admin write access

  3. Notes
    - Each table includes id, name, and optional additional fields
    - Includes initial data for each table
*/

-- Create job_categories table
CREATE TABLE IF NOT EXISTS job_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  parent_id uuid REFERENCES job_categories(id),
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create working_modes table
CREATE TABLE IF NOT EXISTS working_modes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create experience_levels table
CREATE TABLE IF NOT EXISTS experience_levels (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create contract_types table
CREATE TABLE IF NOT EXISTS contract_types (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create benefits table
CREATE TABLE IF NOT EXISTS benefits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  icon text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create languages table
CREATE TABLE IF NOT EXISTS languages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  native_name text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create company_sizes table
CREATE TABLE IF NOT EXISTS company_sizes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  range_from integer,
  range_to integer,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Add triggers for updating updated_at
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_job_categories_updated_at') THEN
    CREATE TRIGGER update_job_categories_updated_at
      BEFORE UPDATE ON job_categories
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_working_modes_updated_at') THEN
    CREATE TRIGGER update_working_modes_updated_at
      BEFORE UPDATE ON working_modes
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_experience_levels_updated_at') THEN
    CREATE TRIGGER update_experience_levels_updated_at
      BEFORE UPDATE ON experience_levels
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_contract_types_updated_at') THEN
    CREATE TRIGGER update_contract_types_updated_at
      BEFORE UPDATE ON contract_types
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_benefits_updated_at') THEN
    CREATE TRIGGER update_benefits_updated_at
      BEFORE UPDATE ON benefits
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_languages_updated_at') THEN
    CREATE TRIGGER update_languages_updated_at
      BEFORE UPDATE ON languages
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;

  IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname = 'update_company_sizes_updated_at') THEN
    CREATE TRIGGER update_company_sizes_updated_at
      BEFORE UPDATE ON company_sizes
      FOR EACH ROW
      EXECUTE FUNCTION update_updated_at_column();
  END IF;
END $$;

-- Enable RLS
ALTER TABLE job_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE working_modes ENABLE ROW LEVEL SECURITY;
ALTER TABLE experience_levels ENABLE ROW LEVEL SECURITY;
ALTER TABLE contract_types ENABLE ROW LEVEL SECURITY;
ALTER TABLE benefits ENABLE ROW LEVEL SECURITY;
ALTER TABLE languages ENABLE ROW LEVEL SECURITY;
ALTER TABLE company_sizes ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Public can view job categories" ON job_categories;
DROP POLICY IF EXISTS "Public can view working modes" ON working_modes;
DROP POLICY IF EXISTS "Public can view experience levels" ON experience_levels;
DROP POLICY IF EXISTS "Public can view contract types" ON contract_types;
DROP POLICY IF EXISTS "Public can view benefits" ON benefits;
DROP POLICY IF EXISTS "Public can view languages" ON languages;
DROP POLICY IF EXISTS "Public can view company sizes" ON company_sizes;

DROP POLICY IF EXISTS "Admins can manage job categories" ON job_categories;
DROP POLICY IF EXISTS "Admins can manage working modes" ON working_modes;
DROP POLICY IF EXISTS "Admins can manage experience levels" ON experience_levels;
DROP POLICY IF EXISTS "Admins can manage contract types" ON contract_types;
DROP POLICY IF EXISTS "Admins can manage benefits" ON benefits;
DROP POLICY IF EXISTS "Admins can manage languages" ON languages;
DROP POLICY IF EXISTS "Admins can manage company sizes" ON company_sizes;

-- Add RLS policies
CREATE POLICY "Public can view job categories"
  ON job_categories
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can view working modes"
  ON working_modes
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can view experience levels"
  ON experience_levels
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can view contract types"
  ON contract_types
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can view benefits"
  ON benefits
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can view languages"
  ON languages
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can view company sizes"
  ON company_sizes
  FOR SELECT
  TO public
  USING (true);

-- Add admin policies
CREATE POLICY "Admins can manage job categories"
  ON job_categories
  FOR ALL
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "Admins can manage working modes"
  ON working_modes
  FOR ALL
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "Admins can manage experience levels"
  ON experience_levels
  FOR ALL
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "Admins can manage contract types"
  ON contract_types
  FOR ALL
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "Admins can manage benefits"
  ON benefits
  FOR ALL
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "Admins can manage languages"
  ON languages
  FOR ALL
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());

CREATE POLICY "Admins can manage company sizes"
  ON company_sizes
  FOR ALL
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());

-- Insert initial data
INSERT INTO job_categories (name, parent_id, sort_order) VALUES
-- Main categories
('Inżynieria Oprogramowania', NULL, 10),
('Inżynieria danych i sztuczna inteligencja', NULL, 20),
('Inżynieria Systemów i Operacje', NULL, 30),
('Zarządzanie Projektami i Analiza Biznesowa', NULL, 40),
('Architektura systemów', NULL, 50),
('Projektowanie UX/UI', NULL, 60),
('Kategorie inżynierskie', NULL, 70),
('Specjalistyczne i inne', NULL, 80)
ON CONFLICT (id) DO NOTHING;

-- Insert working modes
INSERT INTO working_modes (name, code, sort_order) VALUES
('Praca zdalna', 'remote', 10),
('Praca hybrydowa', 'hybrid', 20),
('Praca w biurze', 'office', 30)
ON CONFLICT (code) DO NOTHING;

-- Insert experience levels
INSERT INTO experience_levels (name, code, sort_order) VALUES
('Junior', 'junior', 10),
('Mid', 'mid', 20),
('Senior', 'senior', 30),
('Expert/Lead', 'lead', 40)
ON CONFLICT (code) DO NOTHING;

-- Insert contract types
INSERT INTO contract_types (name, code, sort_order) VALUES
('Umowa o pracę', 'employment', 10),
('Kontrakt B2B', 'b2b', 20),
('Umowa zlecenie', 'mandate', 30),
('Umowa o dzieło', 'work', 40)
ON CONFLICT (code) DO NOTHING;

-- Insert benefits
INSERT INTO benefits (name, code, icon, sort_order) VALUES
('Elastyczne godziny pracy', 'flexible-hours', 'Clock', 10),
('4-dniowy tydzień pracy', '4-day-week', 'Calendar', 20),
('Budżet na szkolenia', 'training-budget', 'GraduationCap', 30),
('Prywatna opieka medyczna', 'medical', 'Heart', 40),
('Pakiet sportowy', 'sports-card', 'Dumbbell', 50),
('Opcje na akcje', 'stock-options', 'TrendingUp', 60),
('Sprzęt firmowy', 'equipment', 'Laptop', 70),
('Możliwość pracy za granicą', 'abroad', 'Globe', 80)
ON CONFLICT (code) DO NOTHING;

-- Insert languages
INSERT INTO languages (name, code, native_name, sort_order) VALUES
('Polski', 'pl', 'Polski', 10),
('Angielski', 'en', 'English', 20),
('Niemiecki', 'de', 'Deutsch', 30),
('Francuski', 'fr', 'Français', 40),
('Hiszpański', 'es', 'Español', 50),
('Włoski', 'it', 'Italiano', 60),
('Rosyjski', 'ru', 'Русский', 70),
('Ukraiński', 'uk', 'Українська', 80),
('Czeski', 'cs', 'Čeština', 90),
('Słowacki', 'sk', 'Slovenčina', 100)
ON CONFLICT (code) DO NOTHING;

-- Insert company sizes
INSERT INTO company_sizes (name, code, range_from, range_to, sort_order) VALUES
('1-10 pracowników', '1-10', 1, 10, 10),
('11-50 pracowników', '11-50', 11, 50, 20),
('51-200 pracowników', '51-200', 51, 200, 30),
('201-500 pracowników', '201-500', 201, 500, 40),
('501-1000 pracowników', '501-1000', 501, 1000, 50),
('1000+ pracowników', '1000+', 1001, NULL, 60)
ON CONFLICT (code) DO NOTHING;

-- Add comments
COMMENT ON TABLE job_categories IS 'Available job categories and subcategories';
COMMENT ON TABLE working_modes IS 'Available working modes (remote, hybrid, office)';
COMMENT ON TABLE experience_levels IS 'Available experience levels (junior, mid, senior, etc.)';
COMMENT ON TABLE contract_types IS 'Available contract types (B2B, employment, etc.)';
COMMENT ON TABLE benefits IS 'Available benefits (healthcare, sports card, etc.)';
COMMENT ON TABLE languages IS 'Available languages with their codes';
COMMENT ON TABLE company_sizes IS 'Available company size ranges';