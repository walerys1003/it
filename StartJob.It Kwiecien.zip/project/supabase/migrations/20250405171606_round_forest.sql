/*
  # Add SEO pages table

  1. New Tables
    - `seo_pages`
      - `id` (uuid, primary key)
      - `path` (text, unique)
      - `title` (text)
      - `description` (text)
      - `keywords` (text)
      - `og_title` (text)
      - `og_description` (text)
      - `og_image` (text)
      - `og_type` (text)
      - `schema_type` (text)
      - `schema_data` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on `seo_pages` table
    - Add policy for public read access
    - Add policy for admin write access

  3. Notes
    - Stores SEO metadata for each page in the site
    - Includes OpenGraph tags and schema.org data
    - Allows customization of meta tags for each page
*/

-- Create seo_pages table
CREATE TABLE IF NOT EXISTS seo_pages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  path text NOT NULL UNIQUE,
  title text NOT NULL,
  description text,
  keywords text,
  og_title text,
  og_description text,
  og_image text,
  og_type text DEFAULT 'website',
  schema_type text DEFAULT 'WebPage',
  schema_data jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create index for path
CREATE INDEX seo_pages_path_idx ON seo_pages(path);

-- Add trigger for updating updated_at
CREATE TRIGGER update_seo_pages_updated_at
  BEFORE UPDATE ON seo_pages
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE seo_pages ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Public can view SEO pages"
  ON seo_pages
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admins can manage SEO pages"
  ON seo_pages
  FOR ALL
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());

-- Insert default SEO pages
INSERT INTO seo_pages (path, title, description, keywords, og_title, og_description, og_type, schema_type)
VALUES
  ('/', 'StartJob.IT - Znajdź swoją wymarzoną pracę w IT', 'StartJob.IT to platforma łącząca specjalistów IT z najlepszymi pracodawcami. Znajdź swoją wymarzoną pracę w branży IT.', 'praca IT, oferty pracy, programista, developer, IT jobs', 'StartJob.IT - Znajdź swoją wymarzoną pracę w IT', 'StartJob.IT to platforma łącząca specjalistów IT z najlepszymi pracodawcami. Znajdź swoją wymarzoną pracę w branży IT.', 'website', 'WebPage'),
  ('/cennik', 'Cennik | StartJob.IT', 'Sprawdź cennik usług StartJob.IT. Oferujemy konkurencyjne ceny za publikację ogłoszeń o pracę w branży IT.', 'cennik, ceny, ogłoszenia, praca IT', 'Cennik | StartJob.IT', 'Sprawdź cennik usług StartJob.IT. Oferujemy konkurencyjne ceny za publikację ogłoszeń o pracę w branży IT.', 'website', 'WebPage'),
  ('/blog', 'Blog | StartJob.IT', 'Blog StartJob.IT - Wiedza i Trendy dla Branży IT. Najnowsze artykuły, porady i informacje z branży IT.', 'blog IT, trendy IT, porady, kariera IT', 'Blog | StartJob.IT', 'Blog StartJob.IT - Wiedza i Trendy dla Branży IT. Najnowsze artykuły, porady i informacje z branży IT.', 'website', 'Blog'),
  ('/kontakt', 'Kontakt | StartJob.IT', 'Skontaktuj się z nami. StartJob.IT - Twój partner w rekrutacji IT.', 'kontakt, pomoc, wsparcie, StartJob.IT', 'Kontakt | StartJob.IT', 'Skontaktuj się z nami. StartJob.IT - Twój partner w rekrutacji IT.', 'website', 'ContactPage')
ON CONFLICT (path) DO NOTHING;

-- Add comment
COMMENT ON TABLE seo_pages IS 'Stores SEO metadata for each page in the site';