/*
  # Fix admin logging function

  1. Changes
    - Fix log_admin_operation function to use proper trigger argument syntax
    - Update trigger to pass operation type as a string literal
    - Keep existing functionality

  2. Security
    - Maintain existing RLS policies
    - Keep audit logging
*/

-- Drop existing trigger
DROP TRIGGER IF EXISTS log_admin_user_operation ON admin_users;

-- Recreate admin operations logging function with fixed parameter handling
CREATE OR REPLACE FUNCTION log_admin_operation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    TG_ARGV[0],
    TG_TABLE_NAME,
    NEW.id,
    row_to_json(NEW)
  );
  RETURN NEW;
END;
$$;

-- Recreate trigger with proper argument passing
CREATE TRIGGER log_admin_user_operation
  AFTER INSERT OR UPDATE
  ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION log_admin_operation('admin_user_modified');

-- Add comment
COMMENT ON FUNCTION log_admin_operation() IS 'Logs admin operations for audit purposes';