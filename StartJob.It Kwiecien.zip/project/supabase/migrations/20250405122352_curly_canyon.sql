/*
  # Fix admin user creation function

  1. Changes
    - Remove dependency on gen_random_bytes function
    - Use UUID generation for tokens instead
    - Simplify user creation process
    - Add detailed error logging

  2. Security
    - Maintain secure user creation
    - Keep audit logging
    - Preserve access control
*/

-- Drop existing function
DROP FUNCTION IF EXISTS create_admin_user(text, text, text, text);

-- Create improved function without gen_random_bytes dependency
CREATE OR REPLACE FUNCTION create_admin_user(
  p_email text,
  p_password text,
  p_name text,
  p_role text
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_result json;
  v_error text;
  v_token text;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Validate role
  IF p_role NOT IN ('admin', 'editor', 'moderator') THEN
    RAISE EXCEPTION 'Invalid role specified';
  END IF;

  -- Generate a new user ID
  v_user_id := gen_random_uuid();
  
  -- Generate tokens using UUID instead of gen_random_bytes
  v_token := replace(gen_random_uuid()::text, '-', '');

  -- Create user in auth.users with minimal required fields
  BEGIN
    INSERT INTO auth.users (
      id,
      email,
      raw_user_meta_data,
      created_at,
      updated_at,
      email_confirmed_at,
      confirmation_token,
      email_change_token_current,
      recovery_token
    ) VALUES (
      v_user_id,
      p_email,
      jsonb_build_object('name', p_name),
      now(),
      now(),
      now(),
      v_token,
      v_token,
      v_token
    );
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_error = PG_EXCEPTION_DETAIL;
    RAISE EXCEPTION 'Error inserting user: % (Detail: %)', SQLERRM, v_error;
  END;

  -- Insert into admin_users
  BEGIN
    INSERT INTO admin_users (id, role, permissions)
    VALUES (v_user_id, p_role, '[]'::jsonb);
  EXCEPTION WHEN OTHERS THEN
    GET STACKED DIAGNOSTICS v_error = PG_EXCEPTION_DETAIL;
    RAISE EXCEPTION 'Error inserting admin user: % (Detail: %)', SQLERRM, v_error;
  END;

  -- Log the action
  BEGIN
    INSERT INTO admin_audit_log (
      admin_id,
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'create_admin_user',
      'admin_users',
      v_user_id,
      jsonb_build_object(
        'email', p_email,
        'name', p_name,
        'role', p_role
      )
    );
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE 'Error logging admin action: %', SQLERRM;
  END;

  -- Return user data
  v_result := jsonb_build_object(
    'user', jsonb_build_object(
      'id', v_user_id,
      'email', p_email,
      'name', p_name,
      'role', p_role
    )
  );

  RETURN v_result;
EXCEPTION
  WHEN unique_violation THEN
    RAISE EXCEPTION 'Email already exists';
  WHEN others THEN
    GET STACKED DIAGNOSTICS v_error = PG_EXCEPTION_DETAIL;
    RAISE EXCEPTION 'Error creating user: % (Detail: %)', SQLERRM, v_error;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION create_admin_user(text, text, text, text) TO authenticated;

-- Add comment
COMMENT ON FUNCTION create_admin_user(text, text, text, text) IS 'Creates a new admin user without using gen_random_bytes function';