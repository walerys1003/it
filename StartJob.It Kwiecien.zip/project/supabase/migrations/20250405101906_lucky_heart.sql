/*
  # Fix admin email access in admin_audit_log

  1. Changes
    - Create a view to simplify access to admin user emails
    - The view joins admin_users with auth.users to get email addresses
    - This avoids complex nested joins in queries

  2. Security
    - Maintain existing RLS policies
    - Keep audit logging functionality
*/

-- Create a view to simplify access to admin user emails
CREATE OR REPLACE VIEW admin_user_emails AS
SELECT 
  au.id,
  au.role,
  u.email
FROM 
  admin_users au
JOIN 
  auth.users u ON au.id = u.id;

-- Grant necessary permissions
GRANT SELECT ON admin_user_emails TO authenticated;

-- Add comment
COMMENT ON VIEW admin_user_emails IS 'View that joins admin_users with auth.users to provide easy access to admin emails';