/*
  # Add site settings table

  1. New Tables
    - `site_settings`
      - `id` (uuid, primary key)
      - `key` (text, unique)
      - `value` (jsonb)
      - `category` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policy for public read access
    - Add policy for admin write access

  3. Initial Data
    - Contact information
    - Social media links
    - Pricing settings
    - Promotion service prices
*/

-- Create site_settings table
CREATE TABLE IF NOT EXISTS site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key text NOT NULL UNIQUE,
  value jsonb NOT NULL,
  category text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create index for faster lookups
CREATE INDEX site_settings_category_idx ON site_settings(category);

-- Add trigger for updating updated_at
CREATE TRIGGER update_site_settings_updated_at
  BEFORE UPDATE ON site_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Public can view settings"
  ON site_settings
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admins can manage settings"
  ON site_settings
  FOR ALL
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());

-- Insert initial settings
INSERT INTO site_settings (key, value, category) VALUES
-- Contact Information
('contact_phone', '"(+48) 501 42 00 42"', 'contact'),
('contact_email', '"kontakt@startjob.it"', 'contact'),
('contact_address', jsonb_build_object(
  'street', 'ul. Świeradowska 47',
  'city', 'Warszawa',
  'postal_code', '02-662',
  'country', 'Polska'
), 'contact'),

-- Social Media Links
('social_media', jsonb_build_object(
  'facebook', 'https://facebook.com/startjob.it',
  'linkedin', 'https://linkedin.com/company/startjob-it',
  'instagram', 'https://instagram.com/startjob.it'
), 'social'),

-- Currency Settings
('currency', '"PLN"', 'pricing'),

-- Job Posting Prices
('job_posting_price_standard', '599', 'pricing'),
('job_posting_price_premium', '899', 'pricing'),

-- Promotion Services Prices
('promotion_services', jsonb_build_array(
  jsonb_build_object(
    'id', 'advertising-campaigns',
    'name', 'Kampanie reklamowe',
    'price', 899,
    'description', 'Reklamy w social mediach, kampanie Google Ads i YouTube'
  ),
  jsonb_build_object(
    'id', 'video-listing',
    'name', 'Video ogłoszenie',
    'price', 799,
    'description', 'Produkcja i promocja 30-60 sekundowego wideo'
  ),
  jsonb_build_object(
    'id', 'geo-targeted',
    'name', 'Geo-targetowana reklama',
    'price', 999,
    'description', 'Reklamy targetowane geograficznie'
  ),
  jsonb_build_object(
    'id', 'headhunting-premium',
    'name', 'Headhunting Premium',
    'price', 3499,
    'description', 'Dedykowany headhunting i weryfikacja kandydatów'
  ),
  jsonb_build_object(
    'id', 'email-marketing',
    'name', 'Email Marketing',
    'price', 799,
    'description', 'Kampanie email do bazy specjalistów IT'
  ),
  jsonb_build_object(
    'id', 'social-pack',
    'name', 'Social Media Pack',
    'price', 399,
    'description', 'Promocja w mediach społecznościowych'
  )
), 'promotion_services');

-- Add comment
COMMENT ON TABLE site_settings IS 'Stores global site settings and configuration';