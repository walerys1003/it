/*
  # Update admin user passwords

  1. Changes
    - Set password "Startjob25!" for all existing admin users
    - Use proper password hashing with pgcrypto
    - Maintain existing user data and roles

  2. Security
    - Passwords are properly hashed using bcrypt
    - Only updates existing users
    - Logs password updates in audit log
*/

-- Enable pgcrypto extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Update passwords for all admin users
DO $$
DECLARE
  admin_record RECORD;
  new_password TEXT := 'Startjob25!';
  hashed_password TEXT;
BEGIN
  -- Generate hashed password using bcrypt
  hashed_password := crypt(new_password, gen_salt('bf'));
  
  -- Get all admin users
  FOR admin_record IN 
    SELECT au.id, au.role, u.email 
    FROM admin_users au
    JOIN auth.users u ON au.id = u.id
  LOOP
    -- Update password in auth.users table
    UPDATE auth.users
    SET 
      encrypted_password = hashed_password,
      updated_at = now()
    WHERE id = admin_record.id;
    
    -- Log the password update
    INSERT INTO admin_audit_log (
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      'update_user_password',
      'admin_users',
      admin_record.id,
      jsonb_build_object(
        'email', admin_record.email,
        'role', admin_record.role,
        'updated_at', now()
      )
    );
    
    RAISE NOTICE 'Updated password for user %', admin_record.email;
  END LOOP;
END $$;

-- Create a view to simplify access to admin user emails if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_views WHERE viewname = 'admin_user_emails') THEN
    CREATE OR REPLACE VIEW admin_user_emails AS
    SELECT 
      au.id,
      au.role,
      u.email
    FROM 
      admin_users au
    JOIN 
      auth.users u ON au.id = u.id;
      
    GRANT SELECT ON admin_user_emails TO authenticated;
  END IF;
END $$;