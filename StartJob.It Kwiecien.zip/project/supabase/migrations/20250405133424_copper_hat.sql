/*
  # Fix user deletion functionality

  1. Changes
    - Fix delete_admin_user function to properly delete from both tables
    - Add proper error handling and transaction management
    - Ensure admin_users table is updated when a user is deleted

  2. Security
    - Maintain security definer
    - Keep admin access check
    - Add proper audit logging
*/

-- Drop existing function if it exists
DROP FUNCTION IF EXISTS delete_admin_user(uuid);

-- Create improved function for user deletion
CREATE OR REPLACE FUNCTION delete_admin_user(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text;
  v_role text;
  v_name text;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Start transaction
  BEGIN
    -- Get user details for logging
    SELECT 
      u.email, 
      au.role,
      (u.raw_user_meta_data->>'name')::text
    INTO 
      v_email, 
      v_role,
      v_name
    FROM auth.users u
    JOIN admin_users au ON au.id = u.id
    WHERE u.id = user_id;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'User not found';
    END IF;

    -- Delete from admin_users first (this will not cascade to auth.users)
    DELETE FROM admin_users WHERE id = user_id;
    
    -- Now delete from auth.users
    DELETE FROM auth.users WHERE id = user_id;

    -- Log the action
    INSERT INTO admin_audit_log (
      admin_id,
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'delete_admin_user',
      'admin_users',
      user_id,
      jsonb_build_object(
        'email', v_email,
        'role', v_role,
        'name', v_name,
        'deleted_at', now()
      )
    );

    RETURN true;
  EXCEPTION
    WHEN others THEN
      -- Rollback is automatic in case of exception
      RAISE NOTICE 'Error deleting user: %', SQLERRM;
      
      -- Log the error
      INSERT INTO admin_audit_log (
        admin_id,
        action,
        entity_type,
        entity_id,
        details
      ) VALUES (
        auth.uid(),
        'delete_admin_user_error',
        'admin_users',
        user_id,
        jsonb_build_object(
          'error', SQLERRM,
          'email', v_email,
          'role', v_role,
          'name', v_name
        )
      );
      
      RETURN false;
  END;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION delete_admin_user(uuid) TO authenticated;

-- Add comment
COMMENT ON FUNCTION delete_admin_user(uuid) IS 'Safely deletes a user from both auth.users and admin_users tables with proper transaction handling';