/*
  # Add SEO fields to blog_posts table

  1. New Columns
    - `seo_title` (text, nullable)
    - `seo_description` (text, nullable)
    - `seo_keywords` (text, nullable)
    - `og_title` (text, nullable)
    - `og_description` (text, nullable)
    - `og_image` (text, nullable)
    - `schema_type` (text, default 'BlogPosting')
    - `schema_data` (jsonb, default '{}')

  2. Notes
    - These fields allow for custom SEO settings per blog post
    - If not set, the system will use default values based on post content
*/

-- Add SEO fields to blog_posts table
ALTER TABLE blog_posts
ADD COLUMN IF NOT EXISTS seo_title text,
ADD COLUMN IF NOT EXISTS seo_description text,
ADD COLUMN IF NOT EXISTS seo_keywords text,
ADD COLUMN IF NOT EXISTS og_title text,
ADD COLUMN IF NOT EXISTS og_description text,
ADD COLUMN IF NOT EXISTS og_image text,
ADD COLUMN IF NOT EXISTS schema_type text DEFAULT 'BlogPosting',
ADD COLUMN IF NOT EXISTS schema_data jsonb DEFAULT '{}'::jsonb;

-- Add comment explaining the fields
COMMENT ON COLUMN blog_posts.seo_title IS 'Custom meta title for SEO';
COMMENT ON COLUMN blog_posts.seo_description IS 'Custom meta description for SEO';
COMMENT ON COLUMN blog_posts.seo_keywords IS 'Custom meta keywords for SEO';
COMMENT ON COLUMN blog_posts.og_title IS 'Custom OpenGraph title';
COMMENT ON COLUMN blog_posts.og_description IS 'Custom OpenGraph description';
COMMENT ON COLUMN blog_posts.og_image IS 'Custom OpenGraph image URL';
COMMENT ON COLUMN blog_posts.schema_type IS 'Schema.org type (BlogPosting, Article, etc.)';
COMMENT ON COLUMN blog_posts.schema_data IS 'Custom Schema.org JSON-LD data';