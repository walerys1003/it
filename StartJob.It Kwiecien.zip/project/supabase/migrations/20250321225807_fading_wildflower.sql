/*
  # Add job events table

  1. New Tables
    - `job_events`
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key to jobs)
      - `event_type` (text, constrained to allowed values)
      - `event_time` (timestamp with timezone)

  2. Security
    - Enable RLS
    - Add policy for public insert access
    - Add policy for public read access

  3. Indexes
    - Index on job_id for faster lookups
    - Index on event_type for filtering
    - Index on event_time for sorting
*/

-- Create job_events table
CREATE TABLE IF NOT EXISTS job_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES jobs(id) ON DELETE CASCADE,
  event_type text NOT NULL CHECK (event_type IN ('click', 'view', 'application')),
  event_time timestamptz NOT NULL DEFAULT now()
);

-- Create indexes
CREATE INDEX job_events_job_id_idx ON job_events(job_id);
CREATE INDEX job_events_event_type_idx ON job_events(event_type);
CREATE INDEX job_events_event_time_idx ON job_events(event_time);

-- Enable RLS
ALTER TABLE job_events ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Anyone can create job events"
  ON job_events
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Anyone can view job events"
  ON job_events
  FOR SELECT
  TO public
  USING (true);

-- Add table comment
COMMENT ON TABLE job_events IS 'Stores job posting events like views, clicks, and applications';