/*
  # Add city search function

  1. New Functions
    - `search_cities`: Function to search cities from existing job postings
    - Returns city names and job counts
    - Case-insensitive search with partial matching

  2. Security
    - Function is available to public
    - Returns only cities from active jobs
*/

-- Create function to search cities
CREATE OR REPLACE FUNCTION search_cities(search_query text)
RETURNS TABLE (
  city text,
  count bigint
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    location_city as city,
    COUNT(*) as count
  FROM jobs
  WHERE 
    location_city ILIKE '%' || search_query || '%'
    AND is_active = true
    AND valid_until > now()
  GROUP BY location_city
  ORDER BY count DESC, city ASC
  LIMIT 10;
END;
$$;

-- Grant execute permission to public
GRANT EXECUTE ON FUNCTION search_cities(text) TO public;

-- Add comment
COMMENT ON FUNCTION search_cities(text) IS 'Searches for cities in active job postings with counts';