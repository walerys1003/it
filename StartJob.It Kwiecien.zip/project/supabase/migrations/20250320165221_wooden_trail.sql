/*
  # Fix job expiration notifications

  1. Changes
    - Update email sending to use form data instead of JSON
    - Fix API key handling to match email service requirements
    - Keep existing functionality and logging

  2. Security
    - Maintain security definer
    - Keep existing permissions
*/

-- Drop existing function
DROP FUNCTION IF EXISTS check_job_expiration();

-- Create improved function with correct email format
CREATE OR REPLACE FUNCTION check_job_expiration()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  job_record RECORD;
  days_until_expiry INTEGER;
  notification_template TEXT;
  notification_subject TEXT;
  form_data TEXT;
BEGIN
  -- Get all active jobs
  FOR job_record IN 
    SELECT 
      id,
      title,
      company_name,
      contact_email,
      valid_until,
      EXTRACT(DAY FROM valid_until - CURRENT_TIMESTAMP) as days_left
    FROM jobs 
    WHERE 
      is_active = true 
      AND valid_until > CURRENT_TIMESTAMP
      AND valid_until <= CURRENT_TIMESTAMP + INTERVAL '7 days'
  LOOP
    days_until_expiry := job_record.days_left::INTEGER;
    
    -- Only send notifications for 7, 3, and 1 days before expiry
    IF days_until_expiry IN (7, 3, 1) THEN
      -- Prepare notification content
      notification_subject := CASE 
        WHEN days_until_expiry = 7 THEN 'Twoje ogłoszenie wygaśnie za 7 dni'
        WHEN days_until_expiry = 3 THEN 'Twoje ogłoszenie wygaśnie za 3 dni'
        WHEN days_until_expiry = 1 THEN 'Twoje ogłoszenie wygaśnie jutro'
      END;

      notification_template := '
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #4a3471;">Przypomnienie o wygasającym ogłoszeniu</h2>
          
          <p>Witaj,</p>
          
          <p>Twoje ogłoszenie <strong>"' || job_record.title || '"</strong> w serwisie StartJob.IT wygaśnie za ' || days_until_expiry || ' dni.</p>
          
          <p>Szczegóły ogłoszenia:</p>
          <ul>
            <li>Firma: ' || job_record.company_name || '</li>
            <li>Data wygaśnięcia: ' || to_char(job_record.valid_until, 'YYYY-MM-DD') || '</li>
          </ul>
          
          <p>Aby przedłużyć ważność ogłoszenia, zaloguj się do panelu pracodawcy i wybierz opcję przedłużenia.</p>
          
          <p style="margin-top: 30px; color: #666; font-size: 14px;">
            Pozdrawiamy,<br>
            Zespół StartJob.IT
          </p>
        </div>
      ';

      -- Prepare form data
      form_data := 'mail_to=' || job_record.contact_email || 
                   '&subject=' || url_encode(notification_subject) || 
                   '&message=' || url_encode(notification_template) ||
                   '&api_key=4cd6c3fb-d2ec-4426-b955-51e7e3faa4b6';

      -- Send email notification
      PERFORM net.http_post(
        url := 'https://mail-api.startjob.it/email.php',
        headers := jsonb_build_object(
          'Content-Type', 'application/x-www-form-urlencoded'
        ),
        body := form_data
      );

      -- Log the notification
      INSERT INTO admin_audit_log (
        action,
        entity_type,
        entity_id,
        details
      ) VALUES (
        'job_expiration_notification',
        'jobs',
        job_record.id,
        jsonb_build_object(
          'days_until_expiry', days_until_expiry,
          'notification_sent_at', CURRENT_TIMESTAMP,
          'recipient_email', job_record.contact_email
        )
      );
    END IF;
  END LOOP;
END;
$$;

-- Create helper function for URL encoding
CREATE OR REPLACE FUNCTION url_encode(data text) RETURNS text AS $$
  SELECT regexp_replace(
    regexp_replace(
      encode(convert_to($1, 'UTF8'), 'base64'),
      E'\\n', '', 'g'
    ),
    '=+$', ''
  );
$$ LANGUAGE SQL IMMUTABLE STRICT;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION check_job_expiration() TO authenticated;
GRANT EXECUTE ON FUNCTION url_encode(text) TO authenticated;

-- Add comments
COMMENT ON FUNCTION check_job_expiration() IS 'Checks for jobs expiring soon and sends notification emails to employers';
COMMENT ON FUNCTION url_encode(text) IS 'Helper function to encode text for URL transmission';