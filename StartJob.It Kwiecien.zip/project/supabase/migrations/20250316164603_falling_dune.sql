/*
  # Update jobs RLS policy

  1. Changes
    - Modify the jobs table RLS policy to allow admins to view all jobs
    - Regular users can still only see active jobs

  2. Security
    - Admins can view all jobs
    - Public users can only view active jobs that haven't expired
*/

DROP POLICY IF EXISTS "Anyone can view active jobs" ON jobs;

CREATE POLICY "Jobs viewing policy" ON jobs
  FOR SELECT TO public
  USING (
    (is_admin() OR (is_active = true AND valid_until > now()))
  );