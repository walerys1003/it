/*
  # Create blog tables

  1. New Tables
    - `blog_taxonomies`
      - `id` (uuid, primary key)
      - `name` (text, unique)
      - `type` (text, category or tag)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

    - `blog_posts`
      - `id` (uuid, primary key)
      - `title` (text)
      - `subtitle` (text)
      - `content` (text)
      - `excerpt` (text)
      - `thumbnail_url` (text)
      - `author_name` (text)
      - `author_role` (text)
      - `author_avatar_url` (text)
      - `category_id` (uuid, foreign key to blog_taxonomies)
      - `published_at` (timestamp)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `is_published` (boolean)
      - `is_featured` (boolean)
      - `views_count` (integer)

    - `blog_post_tags`
      - `post_id` (uuid, foreign key to blog_posts)
      - `tag_id` (uuid, foreign key to blog_taxonomies)
      - Primary key on (post_id, tag_id)

  2. Security
    - Enable RLS on all tables
    - Add policies for public read access
    - Add policies for admin write access

  3. Indexes
    - Indexes for foreign keys
    - Indexes for common queries
*/

-- Create blog_taxonomies table
CREATE TABLE IF NOT EXISTS blog_taxonomies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  type text NOT NULL CHECK (type IN ('category', 'tag')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create blog_posts table
CREATE TABLE IF NOT EXISTS blog_posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  subtitle text,
  content text NOT NULL,
  excerpt text,
  thumbnail_url text,
  author_name text NOT NULL,
  author_role text,
  author_avatar_url text,
  category_id uuid REFERENCES blog_taxonomies(id),
  published_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  is_published boolean NOT NULL DEFAULT false,
  is_featured boolean NOT NULL DEFAULT false,
  views_count integer NOT NULL DEFAULT 0
);

-- Create blog_post_tags table for many-to-many relationship
CREATE TABLE IF NOT EXISTS blog_post_tags (
  post_id uuid REFERENCES blog_posts(id) ON DELETE CASCADE,
  tag_id uuid REFERENCES blog_taxonomies(id) ON DELETE CASCADE,
  PRIMARY KEY (post_id, tag_id)
);

-- Create indexes
CREATE INDEX blog_taxonomies_type_idx ON blog_taxonomies(type);
CREATE INDEX blog_posts_category_id_idx ON blog_posts(category_id);
CREATE INDEX blog_posts_published_at_idx ON blog_posts(published_at);
CREATE INDEX blog_posts_is_published_idx ON blog_posts(is_published);
CREATE INDEX blog_posts_is_featured_idx ON blog_posts(is_featured);
CREATE INDEX blog_post_tags_tag_id_idx ON blog_post_tags(tag_id);

-- Add triggers for updating updated_at
CREATE TRIGGER update_blog_taxonomies_updated_at
  BEFORE UPDATE ON blog_taxonomies
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_blog_posts_updated_at
  BEFORE UPDATE ON blog_posts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE blog_taxonomies ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_posts ENABLE ROW LEVEL SECURITY;
ALTER TABLE blog_post_tags ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Public can view taxonomies"
  ON blog_taxonomies
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Public can view published posts"
  ON blog_posts
  FOR SELECT
  TO public
  USING (is_published = true);

CREATE POLICY "Public can view post tags"
  ON blog_post_tags
  FOR SELECT
  TO public
  USING (true);

-- Add comments
COMMENT ON TABLE blog_taxonomies IS 'Stores blog categories and tags';
COMMENT ON TABLE blog_posts IS 'Stores blog posts with their content and metadata';
COMMENT ON TABLE blog_post_tags IS 'Links blog posts with their tags';

-- Insert some initial categories
INSERT INTO blog_taxonomies (name, type) VALUES
  ('Porady dla Kandydatów', 'category'),
  ('Porady dla Pracodawców', 'category'),
  ('Trendy w Branży IT', 'category'),
  ('Wydarzenia i Szkolenia', 'category'),
  ('Edukacja i Rozwój Zawodowy', 'category'),
  ('Innowacje i Przyszłość IT', 'category');

-- Insert some initial tags
INSERT INTO blog_taxonomies (name, type) VALUES
  ('React', 'tag'),
  ('JavaScript', 'tag'),
  ('Python', 'tag'),
  ('DevOps', 'tag'),
  ('Cloud', 'tag'),
  ('AI', 'tag'),
  ('Machine Learning', 'tag'),
  ('Blockchain', 'tag'),
  ('Cybersecurity', 'tag'),
  ('Remote Work', 'tag'),
  ('Career Development', 'tag'),
  ('Best Practices', 'tag'),
  ('Interview Tips', 'tag'),
  ('Salary Negotiation', 'tag'),
  ('Work-Life Balance', 'tag');

-- Create function to validate taxonomy types
CREATE OR REPLACE FUNCTION validate_taxonomy_references()
RETURNS TRIGGER AS $$
BEGIN
  -- For blog_posts, ensure category_id references a category
  IF TG_TABLE_NAME = 'blog_posts' THEN
    IF NEW.category_id IS NOT NULL THEN
      IF NOT EXISTS (
        SELECT 1 FROM blog_taxonomies
        WHERE id = NEW.category_id AND type = 'category'
      ) THEN
        RAISE EXCEPTION 'Category ID must reference a taxonomy of type "category"';
      END IF;
    END IF;
  END IF;

  -- For blog_post_tags, ensure tag_id references a tag
  IF TG_TABLE_NAME = 'blog_post_tags' THEN
    IF NOT EXISTS (
      SELECT 1 FROM blog_taxonomies
      WHERE id = NEW.tag_id AND type = 'tag'
    ) THEN
      RAISE EXCEPTION 'Tag ID must reference a taxonomy of type "tag"';
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for taxonomy validation
CREATE TRIGGER validate_blog_post_category
  BEFORE INSERT OR UPDATE ON blog_posts
  FOR EACH ROW
  EXECUTE FUNCTION validate_taxonomy_references();

CREATE TRIGGER validate_blog_post_tag
  BEFORE INSERT OR UPDATE ON blog_post_tags
  FOR EACH ROW
  EXECUTE FUNCTION validate_taxonomy_references();