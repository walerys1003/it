/*
  # Add new job postings

  1. New Data
    - Adds 3 new job postings with standardized benefits
    - Uses standardized benefit IDs that match the frontend options
    - All required fields are populated with realistic data

  2. Benefits Used
    - flexible-hours (Elastyczne godziny pracy)
    - medical (Prywatna opieka medyczna)
    - sports-card (Pakiet sportowy)
    - training-budget (Budżet na szkolenia)
    - equipment (Sprzęt firmowy)
    - stock-options (Opcje na akcje)
    - abroad (Możliwość pracy za granicą)
    - 4-day-week (4-dniowy tydzień pracy)
*/

-- Get an existing user_id from the jobs table
DO $$ 
DECLARE
  existing_user_id uuid;
BEGIN
  -- Get the first user_id from existing jobs
  SELECT user_id INTO existing_user_id FROM jobs LIMIT 1;

  -- Insert new jobs using the existing user_id
  INSERT INTO jobs (
    title,
    category,
    description,
    responsibilities,
    requirements,
    nice_to_have,
    technologies,
    work_mode,
    experience_level,
    contract_type,
    salary_from,
    salary_to,
    currency,
    benefits,
    location_country,
    location_voivodeship,
    location_city,
    company_name,
    company_description,
    company_size,
    company_logo,
    contact_name,
    contact_position,
    contact_email,
    contact_phone,
    valid_until,
    is_active,
    is_featured,
    user_id
  ) VALUES
  -- Senior Full Stack Developer
  (
    'Senior Full Stack Developer',
    'Fullstack',
    'Poszukujemy doświadczonego Full Stack Developera do rozwoju naszej platformy e-commerce.',
    ARRAY['Rozwój aplikacji w React i Node.js', 'Projektowanie architektury systemu', 'Code review', 'Mentoring juniorów'],
    ARRAY['Min. 5 lat doświadczenia w Full Stack', 'Biegła znajomość React i Node.js', 'Znajomość TypeScript', 'Doświadczenie z bazami SQL i NoSQL'],
    ARRAY['Znajomość AWS', 'Doświadczenie z Kubernetes', 'Certyfikaty cloud'],
    ARRAY['React.js', 'Node.js', 'TypeScript', 'PostgreSQL', 'MongoDB', 'Docker'],
    'hybrid',
    'senior',
    'b2b',
    18000,
    25000,
    'PLN',
    ARRAY['flexible-hours', 'medical', 'sports-card', 'training-budget', 'equipment'],
    'Polska',
    'mazowieckie',
    'Warszawa',
    'TechCommerce Solutions',
    'Tworzymy innowacyjne rozwiązania e-commerce dla klientów enterprise',
    '100-200',
    'https://images.unsplash.com/photo-1549924231-f129b911e442?w=64&h=64&fit=crop&crop=faces',
    'Anna Kowalska',
    'Senior Tech Recruiter',
    'rekrutacja@techcommerce.pl',
    '+48 500 100 200',
    (CURRENT_DATE + INTERVAL '60 days')::timestamp with time zone,
    true,
    true,
    existing_user_id
  ),

  -- DevOps Engineer
  (
    'DevOps Engineer',
    'DevOps',
    'Szukamy DevOps Engineera do zespołu Cloud Infrastructure.',
    ARRAY['Zarządzanie infrastrukturą AWS', 'Automatyzacja procesów CI/CD', 'Monitoring i optymalizacja', 'Wdrażanie nowych rozwiązań'],
    ARRAY['3+ lata w DevOps', 'Znajomość AWS', 'Doświadczenie z Kubernetes', 'Terraform, Ansible'],
    ARRAY['Certyfikaty AWS', 'GoLang', 'Python'],
    ARRAY['AWS', 'Kubernetes', 'Docker', 'Terraform', 'Jenkins', 'Ansible'],
    'remote',
    'mid',
    'employment',
    15000,
    20000,
    'PLN',
    ARRAY['4-day-week', 'medical', 'training-budget', 'equipment', 'stock-options'],
    'Polska',
    'malopolskie',
    'Kraków',
    'Cloud Systems Pro',
    'Dostarczamy rozwiązania chmurowe dla firm z całego świata',
    '50-100',
    'https://images.unsplash.com/photo-1552664730-d307ca884978?w=64&h=64&fit=crop&crop=faces',
    'Piotr Nowak',
    'Technical Recruiter',
    'careers@cloudsystems.pro',
    '+48 500 300 400',
    (CURRENT_DATE + INTERVAL '45 days')::timestamp with time zone,
    true,
    false,
    existing_user_id
  ),

  -- Frontend Tech Lead
  (
    'Frontend Tech Lead',
    'Frontend',
    'Dołącz do nas jako Frontend Tech Lead i rozwijaj międzynarodowe projekty.',
    ARRAY['Prowadzenie zespołu frontend', 'Architektura aplikacji', 'Code review', 'Rozwój procesów i standardów'],
    ARRAY['5+ lat z React', 'Doświadczenie w prowadzeniu zespołu', 'Biegły TypeScript', 'Znajomość wzorców projektowych'],
    ARRAY['Vue.js', 'React Native', 'Microfrontends'],
    ARRAY['React.js', 'TypeScript', 'Redux', 'Next.js', 'Webpack', 'Jest'],
    'remote',
    'lead',
    'b2b',
    22000,
    28000,
    'PLN',
    ARRAY['flexible-hours', 'medical', 'training-budget', 'equipment', 'abroad', 'stock-options'],
    'Polska',
    'pomorskie',
    'Gdańsk',
    'Global Software House',
    'Międzynarodowy software house specjalizujący się w rozwoju aplikacji webowych',
    '200+',
    'https://images.unsplash.com/photo-1549924231-f129b911e442?w=64&h=64&fit=crop&crop=faces',
    'Marta Wiśniewska',
    'Head of People',
    'jobs@globalsoftware.com',
    '+48 500 500 600',
    (CURRENT_DATE + INTERVAL '30 days')::timestamp with time zone,
    true,
    true,
    existing_user_id
  );
END $$;