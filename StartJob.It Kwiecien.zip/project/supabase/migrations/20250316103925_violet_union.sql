/*
  # Add payment logging and improve error handling

  1. Changes
    - Add detailed logging table for payment attempts
    - Add trigger for logging payment attempts
    - Improve error handling in payment function
    - Add input validation logging
*/

-- Create payment_logs table
CREATE TABLE IF NOT EXISTS payment_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  attempted_at timestamptz NOT NULL DEFAULT now(),
  user_id uuid REFERENCES auth.users(id),
  job_data jsonb,
  payment_data jsonb,
  error_message text,
  error_detail text,
  success boolean,
  created_job_id uuid,
  created_payment_id uuid
);

-- Enable RLS
ALTER TABLE payment_logs ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to view their own logs
CREATE POLICY "Users can view their own payment logs"
  ON payment_logs
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Drop existing function
DROP FUNCTION IF EXISTS handle_job_payment(jsonb, jsonb);

-- Create improved function with logging
CREATE OR REPLACE FUNCTION handle_job_payment(
  job_data jsonb,
  payment_data jsonb
) RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_job_id uuid;
  new_payment_id uuid;
  log_id uuid;
BEGIN
  -- Create initial log entry
  INSERT INTO payment_logs (user_id, job_data, payment_data)
  VALUES (auth.uid(), job_data, payment_data)
  RETURNING id INTO log_id;

  -- Input validation with detailed logging
  IF job_data IS NULL THEN
    UPDATE payment_logs 
    SET error_message = 'job_data cannot be null',
        success = false 
    WHERE id = log_id;
    RAISE EXCEPTION 'job_data cannot be null';
  END IF;

  IF payment_data IS NULL THEN
    UPDATE payment_logs 
    SET error_message = 'payment_data cannot be null',
        success = false 
    WHERE id = log_id;
    RAISE EXCEPTION 'payment_data cannot be null';
  END IF;

  -- Log the exact data structure
  RAISE NOTICE 'Processing job data: %', job_data;
  RAISE NOTICE 'Processing payment data: %', payment_data;

  -- Start transaction
  BEGIN
    -- Insert job
    INSERT INTO jobs (
      title,
      category,
      description,
      responsibilities,
      requirements,
      nice_to_have,
      technologies,
      work_mode,
      experience_level,
      contract_type,
      salary_from,
      salary_to,
      currency,
      benefits,
      location_country,
      location_voivodeship,
      location_city,
      languages,
      company_name,
      company_description,
      company_size,
      company_logo,
      contact_name,
      contact_position,
      contact_email,
      contact_phone,
      valid_until,
      is_active,
      is_featured,
      is_premium,
      user_id
    )
    VALUES (
      job_data->>'title',
      job_data->>'category',
      job_data->>'description',
      ARRAY(SELECT jsonb_array_elements_text(job_data->'responsibilities')),
      ARRAY(SELECT jsonb_array_elements_text(job_data->'requirements')),
      ARRAY(SELECT jsonb_array_elements_text(COALESCE(job_data->'niceToHave', '[]'::jsonb))),
      ARRAY(SELECT jsonb_array_elements_text(job_data->'technologies')),
      job_data->>'workMode',
      job_data->>'experienceLevel',
      job_data->>'contractType',
      (job_data->>'salaryFrom')::integer,
      (job_data->>'salaryTo')::integer,
      COALESCE(job_data->>'currency', 'PLN'),
      ARRAY(SELECT jsonb_array_elements_text(COALESCE(job_data->'benefits', '[]'::jsonb))),
      job_data->'location'->>'country',
      job_data->'location'->>'voivodeship',
      job_data->'location'->>'city',
      ARRAY(SELECT jsonb_array_elements(COALESCE(job_data->'languages', '[]'::jsonb))),
      job_data->'company'->>'name',
      job_data->'company'->>'description',
      job_data->'company'->>'size',
      job_data->'company'->>'logo',
      job_data->'contact'->>'name',
      job_data->'contact'->>'position',
      job_data->'contact'->>'email',
      job_data->'contact'->>'phone',
      CURRENT_TIMESTAMP + INTERVAL '90 days',
      false,
      job_data->>'packageType' = 'premium',
      job_data->>'packageType' = 'premium',
      auth.uid()
    )
    RETURNING id INTO new_job_id;

    RAISE NOTICE 'Created job with ID: %', new_job_id;

    -- Insert payment
    INSERT INTO payments (
      job_id,
      amount,
      currency,
      status,
      package_type,
      payment_method,
      invoice_data
    )
    VALUES (
      new_job_id,
      CASE 
        WHEN job_data->>'packageType' = 'premium' THEN 899.00
        ELSE 599.00
      END,
      'PLN',
      'pending',
      job_data->>'packageType',
      payment_data->>'paymentMethod',
      payment_data->'invoiceData'
    )
    RETURNING id INTO new_payment_id;

    RAISE NOTICE 'Created payment with ID: %', new_payment_id;

    -- Update log with success
    UPDATE payment_logs 
    SET success = true,
        created_job_id = new_job_id,
        created_payment_id = new_payment_id
    WHERE id = log_id;

    RETURN new_payment_id;
  EXCEPTION
    WHEN others THEN
      -- Log the error details
      UPDATE payment_logs 
      SET error_message = SQLERRM,
          error_detail = SQLSTATE,
          success = false
      WHERE id = log_id;
      
      RAISE NOTICE 'Error in transaction: %, SQLSTATE: %', SQLERRM, SQLSTATE;
      RAISE;
  END;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION handle_job_payment(jsonb, jsonb) TO authenticated;