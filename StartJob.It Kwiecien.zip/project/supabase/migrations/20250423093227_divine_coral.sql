/*
  # Delete admin_users table and simplify admin system

  1. Changes
    - Drop admin_users table completely
    - Create a simple is_admin function that checks email directly
    - Update RLS policies to use the new function
    - Remove all role-based functionality

  2. Security
    - Maintain basic admin access control
    - Keep audit logging for admin actions
*/

-- Create a list of admin emails to preserve
CREATE TEMPORARY TABLE admin_emails AS
SELECT email FROM auth.users WHERE email = 'admin@startjob.it';

-- Drop views that depend on admin_users
DROP VIEW IF EXISTS admin_user_view;
DROP VIEW IF EXISTS admin_user_emails;

-- Drop triggers on admin_users if they exist
DO $$
DECLARE
  trigger_name text;
BEGIN
  FOR trigger_name IN (
    SELECT tgname 
    FROM pg_trigger 
    WHERE tgrelid = 'admin_users'::regclass
  )
  LOOP
    EXECUTE 'DROP TRIGGER IF EXISTS ' || trigger_name || ' ON admin_users';
  END LOOP;
END $$;

-- Drop functions that depend on admin_users
DROP FUNCTION IF EXISTS is_admin() CASCADE;
DROP FUNCTION IF EXISTS has_admin_role() CASCADE;
DROP FUNCTION IF EXISTS validate_admin_operation() CASCADE;
DROP FUNCTION IF EXISTS validate_admin_operation_v2() CASCADE;
DROP FUNCTION IF EXISTS get_user_role(uuid) CASCADE;
DROP FUNCTION IF EXISTS has_permission(text) CASCADE;
DROP FUNCTION IF EXISTS get_role_landing_page() CASCADE;
DROP FUNCTION IF EXISTS create_admin_user(text, text, text, text) CASCADE;
DROP FUNCTION IF EXISTS update_admin_user(uuid, text, text) CASCADE;
DROP FUNCTION IF EXISTS delete_user_completely(uuid) CASCADE;
DROP FUNCTION IF EXISTS update_user_metadata(uuid, text) CASCADE;
DROP FUNCTION IF EXISTS log_admin_operation() CASCADE;
DROP FUNCTION IF EXISTS handle_auth_user_deletion() CASCADE;
DROP FUNCTION IF EXISTS is_admin_user() CASCADE;

-- Drop admin_users table
DROP TABLE IF EXISTS admin_users CASCADE;

-- Create a simple is_admin function that checks email directly
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM auth.users 
    WHERE id = auth.uid() 
    AND email IN (SELECT email FROM admin_emails)
  );
END;
$$;

-- Create a simple function to log admin actions
CREATE OR REPLACE FUNCTION log_admin_action(
  action text,
  entity_type text,
  entity_id uuid DEFAULT NULL,
  details jsonb DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  log_id uuid;
BEGIN
  -- Check if user is admin
  IF NOT is_admin() THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Insert log entry
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    action,
    entity_type,
    entity_id,
    details
  )
  RETURNING id INTO log_id;

  RETURN log_id;
END;
$$;

-- Create a function for RLS policies
CREATE OR REPLACE FUNCTION is_admin_user()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM auth.users 
    WHERE id = auth.uid() 
    AND email IN (SELECT email FROM admin_emails)
  );
END;
$$;

-- Update RLS policies for admin-managed tables
DO $$
DECLARE
  table_name text;
BEGIN
  -- List of tables that had admin-only policies
  FOR table_name IN (
    SELECT tablename FROM pg_tables 
    WHERE schemaname = 'public' 
    AND tablename IN (
      'blog_posts', 'blog_taxonomies', 'blog_post_tags',
      'job_categories', 'working_modes', 'experience_levels',
      'contract_types', 'benefits', 'languages',
      'company_sizes', 'technologies', 'seo_pages',
      'site_settings'
    )
  )
  LOOP
    -- Drop existing admin policies
    EXECUTE 'DROP POLICY IF EXISTS "Admins can manage ' || table_name || '" ON ' || table_name;
    
    -- Create new admin policies
    EXECUTE '
      CREATE POLICY "Admins can manage ' || table_name || '"
      ON ' || table_name || '
      FOR ALL
      TO public
      USING (is_admin())
      WITH CHECK (is_admin())
    ';
  END LOOP;
END $$;

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION is_admin() TO authenticated;
GRANT EXECUTE ON FUNCTION is_admin_user() TO authenticated;
GRANT EXECUTE ON FUNCTION log_admin_action(text, text, uuid, jsonb) TO authenticated;

-- Add comments
COMMENT ON FUNCTION is_admin() IS 'Checks if the current user is an admin';
COMMENT ON FUNCTION is_admin_user() IS 'Checks if the current user is an admin for RLS policies';
COMMENT ON FUNCTION log_admin_action(text, text, uuid, jsonb) IS 'Logs admin actions with proper access control';

-- Drop temporary table
DROP TABLE admin_emails;

-- Insert a log entry about this change
INSERT INTO admin_audit_log (
  action,
  entity_type,
  details
)
VALUES (
  'simplify_admin_system',
  'system',
  jsonb_build_object(
    'description', 'Simplified admin system by removing role-based access control',
    'timestamp', now()
  )
);