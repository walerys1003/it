/*
  # Fix blog RLS policies

  1. Changes
    - Add RLS policies for blog posts editing
    - Add RLS policies for blog post tags editing
    - Allow admins to manage blog content

  2. Security
    - Only admins can edit blog posts and tags
    - Maintain existing public read access
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Public can view published posts" ON blog_posts;
DROP POLICY IF EXISTS "Public can view post tags" ON blog_post_tags;

-- Create new policies for blog_posts
CREATE POLICY "Blog posts viewing and editing policy"
  ON blog_posts
  FOR ALL
  TO public
  USING (
    CASE 
      WHEN is_admin() THEN true
      ELSE is_published = true
    END
  )
  WITH CHECK (is_admin());

-- Create new policies for blog_post_tags
CREATE POLICY "Blog post tags viewing and editing policy"
  ON blog_post_tags
  FOR ALL
  TO public
  USING (
    CASE
      WHEN is_admin() THEN true
      ELSE EXISTS (
        SELECT 1 FROM blog_posts
        WHERE id = post_id AND is_published = true
      )
    END
  )
  WITH CHECK (is_admin());