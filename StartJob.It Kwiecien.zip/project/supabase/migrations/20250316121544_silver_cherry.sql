/*
  # Update applications table RLS policies

  1. Changes
    - Remove existing RLS policies
    - Add new policy allowing anyone to view applications
    - Keep policy allowing anyone to create applications

  2. Security
    - Applications will be publicly readable and writable
    - No authentication required
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view their own applications" ON applications;

-- Create new public read policy
CREATE POLICY "Anyone can view applications"
  ON applications
  FOR SELECT
  TO public
  USING (true);