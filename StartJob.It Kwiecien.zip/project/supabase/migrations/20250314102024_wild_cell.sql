/*
  # Update benefits data

  1. Changes
    - Updates the benefits column in jobs table to use standardized values matching the frontend options
    - Ensures all benefits match the available options in the UI:
      - 'flexible-hours' (Elastyczne godziny pracy)
      - '4-day-week' (4-dniowy tydzień pracy)
      - 'training-budget' (Budżet na szkolenia)
      - 'medical' (Prywatna opieka medyczna)
      - 'sports-card' (Pakiet sportowy)
      - 'stock-options' (Opcje na akcje)
      - 'equipment' (Sprzęt firmowy)
      - 'abroad' (Możliwość pracy za granicą)

  2. Data Consistency
    - Ensures benefits data matches between frontend and backend
    - Maintains existing benefits where possible by mapping to new standardized values
*/

-- Create a temporary function to clean benefits array
CREATE OR REPLACE FUNCTION clean_benefits(benefits_array text[])
RETURNS text[] AS $$
DECLARE
  result text[] := '{}';
BEGIN
  -- Add standardized benefits if they match any variations
  IF 'flexible-hours' = ANY(benefits_array) OR 'elastyczne godziny' = ANY(benefits_array) OR 'flexible hours' = ANY(benefits_array) THEN
    result := array_append(result, 'flexible-hours');
  END IF;
  
  IF '4-day-week' = ANY(benefits_array) OR '4 day week' = ANY(benefits_array) THEN
    result := array_append(result, '4-day-week');
  END IF;
  
  IF 'training-budget' = ANY(benefits_array) OR 'szkolenia' = ANY(benefits_array) OR 'training' = ANY(benefits_array) THEN
    result := array_append(result, 'training-budget');
  END IF;
  
  IF 'medical' = ANY(benefits_array) OR 'opieka medyczna' = ANY(benefits_array) OR 'healthcare' = ANY(benefits_array) THEN
    result := array_append(result, 'medical');
  END IF;
  
  IF 'sports-card' = ANY(benefits_array) OR 'karta sportowa' = ANY(benefits_array) OR 'multisport' = ANY(benefits_array) THEN
    result := array_append(result, 'sports-card');
  END IF;
  
  IF 'stock-options' = ANY(benefits_array) OR 'akcje' = ANY(benefits_array) THEN
    result := array_append(result, 'stock-options');
  END IF;
  
  IF 'equipment' = ANY(benefits_array) OR 'sprzęt' = ANY(benefits_array) OR 'laptop' = ANY(benefits_array) THEN
    result := array_append(result, 'equipment');
  END IF;
  
  IF 'abroad' = ANY(benefits_array) OR 'praca za granicą' = ANY(benefits_array) OR 'relocation' = ANY(benefits_array) THEN
    result := array_append(result, 'abroad');
  END IF;
  
  RETURN result;
END;
$$ LANGUAGE plpgsql;

-- Update benefits in jobs table
UPDATE jobs
SET benefits = clean_benefits(benefits)
WHERE benefits IS NOT NULL;

-- Drop the temporary function
DROP FUNCTION clean_benefits(text[]);