/*
  # Add function to update user metadata

  1. New Functions
    - `update_user_metadata`: Function to update user metadata in auth.users
    - Allows updating name and other metadata fields
    - Includes proper error handling and logging

  2. Security
    - Function is security definer
    - Only admins can update user metadata
    - Maintains audit logging
*/

-- Create function to update user metadata
CREATE OR REPLACE FUNCTION update_user_metadata(
  user_id uuid,
  user_name text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_old_metadata jsonb;
  v_new_metadata jsonb;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Get current metadata
  SELECT raw_user_meta_data INTO v_old_metadata
  FROM auth.users
  WHERE id = user_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- Create new metadata by merging old with new values
  v_new_metadata := v_old_metadata || jsonb_build_object('name', user_name);

  -- Update user metadata
  UPDATE auth.users
  SET 
    raw_user_meta_data = v_new_metadata,
    updated_at = now()
  WHERE id = user_id;

  -- Log the update
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'update_user_metadata',
    'users',
    user_id,
    jsonb_build_object(
      'old_metadata', v_old_metadata,
      'new_metadata', v_new_metadata
    )
  );

  RETURN true;
EXCEPTION
  WHEN others THEN
    -- Log error
    INSERT INTO admin_audit_log (
      admin_id,
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'update_user_metadata_error',
      'users',
      user_id,
      jsonb_build_object(
        'error', SQLERRM,
        'user_name', user_name
      )
    );
    
    RAISE;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION update_user_metadata(uuid, text) TO authenticated;

-- Add comment
COMMENT ON FUNCTION update_user_metadata(uuid, text) IS 'Updates user metadata with proper access control and logging';