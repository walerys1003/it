/*
  # Implement role-based access control

  1. Changes
    - Update admin_users table to store role-specific permissions
    - Create function to check role-specific access
    - Update existing functions to respect role permissions
    - Fix user creation and deletion

  2. Security
    - Maintain existing RLS policies
    - Ensure proper role-based access control
    - Keep audit logging
*/

-- Enable pgcrypto extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Temporarily disable admin user validation trigger
ALTER TABLE admin_users DISABLE TRIGGER validate_admin_user_operation;

-- Update admin_users to ensure proper role-based permissions
UPDATE admin_users
SET permissions = CASE 
    WHEN role = 'admin' THEN '["all"]'::jsonb
    WHEN role = 'editor' THEN '["blog"]'::jsonb
    WHEN role = 'moderator' THEN '["jobs", "payments"]'::jsonb
    ELSE '[]'::jsonb
  END
WHERE TRUE;

-- Create function to check role-specific access
CREATE OR REPLACE FUNCTION has_permission(permission text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role text;
  v_permissions jsonb;
BEGIN
  -- Get user role and permissions
  SELECT role, permissions INTO v_role, v_permissions
  FROM admin_users
  WHERE id = auth.uid();
  
  IF NOT FOUND THEN
    RETURN false;
  END IF;
  
  -- Admin role has access to everything
  IF v_role = 'admin' THEN
    RETURN true;
  END IF;
  
  -- Check if the user has the specific permission
  RETURN permission = ANY(ARRAY(SELECT jsonb_array_elements_text(v_permissions)));
EXCEPTION
  WHEN others THEN
    RETURN false;
END;
$$;

-- Create function to get default landing page based on role
CREATE OR REPLACE FUNCTION get_role_landing_page()
RETURNS text
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_role text;
BEGIN
  -- Get user role
  SELECT role INTO v_role
  FROM admin_users
  WHERE id = auth.uid();
  
  IF NOT FOUND THEN
    RETURN '/admin/login';
  END IF;
  
  -- Return appropriate landing page based on role
  RETURN CASE 
    WHEN v_role = 'admin' THEN '/admin'
    WHEN v_role = 'editor' THEN '/admin/blog'
    WHEN v_role = 'moderator' THEN '/admin/jobs'
    ELSE '/admin/login'
  END;
EXCEPTION
  WHEN others THEN
    RETURN '/admin/login';
END;
$$;

-- Update create_admin_user function to set proper role-based permissions
CREATE OR REPLACE FUNCTION create_admin_user(
  p_email TEXT,
  p_password TEXT,
  p_name TEXT,
  p_role TEXT
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_result jsonb;
  v_permissions jsonb;
BEGIN
  -- Input validation
  IF p_email IS NULL OR p_email = '' THEN
    RAISE EXCEPTION 'Email cannot be empty';
  END IF;

  IF p_password IS NULL OR length(p_password) < 6 THEN
    RAISE EXCEPTION 'Password must be at least 6 characters long';
  END IF;

  IF p_role NOT IN ('admin', 'editor', 'moderator') THEN
    RAISE EXCEPTION 'Invalid role specified';
  END IF;

  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Set permissions based on role
  v_permissions := CASE 
    WHEN p_role = 'admin' THEN '["all"]'
    WHEN p_role = 'editor' THEN '["blog"]'
    WHEN p_role = 'moderator' THEN '["jobs", "payments"]'
    ELSE '[]'
  END::jsonb;

  -- Generate a new user ID
  v_user_id := gen_random_uuid();

  -- Create user in auth.users with proper email verification
  INSERT INTO auth.users (
    id,
    email,
    encrypted_password,
    email_confirmed_at,
    raw_app_meta_data,
    raw_user_meta_data,
    created_at,
    updated_at,
    aud,
    role
  )
  VALUES (
    v_user_id,
    p_email,
    crypt(p_password, gen_salt('bf')),
    now(),
    '{"provider": "email", "providers": ["email"]}',
    jsonb_build_object('name', p_name),
    now(),
    now(),
    'authenticated',
    'authenticated'
  );

  -- Create admin user record with appropriate permissions
  INSERT INTO admin_users (
    id,
    role,
    permissions
  )
  VALUES (
    v_user_id,
    p_role,
    v_permissions
  );

  -- Log the action
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'create_admin_user',
    'admin_users',
    v_user_id,
    jsonb_build_object(
      'email', p_email,
      'role', p_role,
      'permissions', v_permissions,
      'created_at', now()
    )
  );

  -- Return success response
  v_result := jsonb_build_object(
    'success', true,
    'user', jsonb_build_object(
      'id', v_user_id,
      'email', p_email,
      'role', p_role
    )
  );

  RETURN v_result;

EXCEPTION WHEN OTHERS THEN
  -- Return error response
  RETURN jsonb_build_object(
    'success', false,
    'error', SQLERRM
  );
END;
$$;

-- Update update_admin_user function to set proper role-based permissions
CREATE OR REPLACE FUNCTION update_admin_user(
  p_user_id uuid,
  p_name text,
  p_role text
)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_old_role text;
  v_email text;
  v_old_metadata jsonb;
  v_new_metadata jsonb;
  v_permissions jsonb;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Validate role
  IF p_role NOT IN ('admin', 'editor', 'moderator') THEN
    RAISE EXCEPTION 'Invalid role specified';
  END IF;

  -- Set permissions based on role
  v_permissions := CASE 
    WHEN p_role = 'admin' THEN '["all"]'
    WHEN p_role = 'editor' THEN '["blog"]'
    WHEN p_role = 'moderator' THEN '["jobs", "payments"]'
    ELSE '[]'
  END::jsonb;

  -- Start transaction
  BEGIN
    -- Get current user data for logging
    SELECT 
      u.email,
      u.raw_user_meta_data,
      au.role
    INTO 
      v_email,
      v_old_metadata,
      v_old_role
    FROM 
      auth.users u
    JOIN 
      admin_users au ON u.id = au.id
    WHERE 
      u.id = p_user_id;

    IF NOT FOUND THEN
      RAISE EXCEPTION 'User not found';
    END IF;

    -- Update user metadata
    v_new_metadata := v_old_metadata || jsonb_build_object('name', p_name);
    
    UPDATE auth.users
    SET 
      raw_user_meta_data = v_new_metadata,
      updated_at = now()
    WHERE id = p_user_id;

    -- Update admin role and permissions
    UPDATE admin_users
    SET 
      role = p_role,
      permissions = v_permissions,
      updated_at = now()
    WHERE id = p_user_id;

    -- Log the action
    INSERT INTO admin_audit_log (
      admin_id,
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'update_admin_user',
      'admin_users',
      p_user_id,
      jsonb_build_object(
        'email', v_email,
        'old_role', v_old_role,
        'new_role', p_role,
        'permissions', v_permissions,
        'old_metadata', v_old_metadata,
        'new_metadata', v_new_metadata,
        'updated_at', now()
      )
    );

    RETURN true;
  EXCEPTION
    WHEN others THEN
      -- Rollback is automatic in case of exception
      RAISE NOTICE 'Error updating user: %', SQLERRM;
      
      -- Log the error
      INSERT INTO admin_audit_log (
        admin_id,
        action,
        entity_type,
        entity_id,
        details
      ) VALUES (
        auth.uid(),
        'update_admin_user_error',
        'admin_users',
        p_user_id,
        jsonb_build_object(
          'error', SQLERRM,
          'email', v_email,
          'old_role', v_old_role,
          'new_role', p_role
        )
      );
      
      RETURN false;
  END;
END;
$$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION has_permission(text) TO authenticated;
GRANT EXECUTE ON FUNCTION get_role_landing_page() TO authenticated;
GRANT EXECUTE ON FUNCTION create_admin_user(TEXT, TEXT, TEXT, TEXT) TO authenticated;
GRANT EXECUTE ON FUNCTION update_admin_user(uuid, text, text) TO authenticated;

-- Re-enable admin user validation trigger
ALTER TABLE admin_users ENABLE TRIGGER validate_admin_user_operation;

-- Add comments
COMMENT ON FUNCTION has_permission(text) IS 'Checks if the current user has a specific permission based on their role';
COMMENT ON FUNCTION get_role_landing_page() IS 'Returns the appropriate landing page URL based on user role';
COMMENT ON FUNCTION create_admin_user(TEXT, TEXT, TEXT, TEXT) IS 'Creates a new admin user with role-based permissions';
COMMENT ON FUNCTION update_admin_user(uuid, text, text) IS 'Updates an admin user with role-based permissions';