/*
  # Fix admin view access

  1. Changes
    - Drop and recreate admin view with proper security
    - Add RLS policies for admin access
    - Fix user fetching functionality

  2. Security
    - Maintain secure access control
    - Keep audit logging
*/

-- Drop existing view if exists
DROP VIEW IF EXISTS admin_user_view;

-- Create improved view with better access control
CREATE OR REPLACE VIEW admin_user_view WITH (security_invoker = true) AS
SELECT 
  u.id,
  u.email,
  u.raw_user_meta_data as user_metadata,
  u.created_at,
  au.role as admin_role
FROM auth.users u
LEFT JOIN admin_users au ON au.id = u.id
WHERE EXISTS (
  SELECT 1 
  FROM admin_users 
  WHERE id = auth.uid()
);

-- Grant necessary permissions
GRANT SELECT ON admin_user_view TO authenticated;

-- Create helper function to check admin access
CREATE OR REPLACE FUNCTION check_admin_access()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid()
  );
END;
$$;

-- Add comment
COMMENT ON VIEW admin_user_view IS 'Secure view for admin users to manage system users';