/*
  # Fix user deletion functionality

  1. Changes
    - Create new function for proper user deletion
    - Handle deletion in both auth.users and admin_users
    - Add proper error handling and logging

  2. Security
    - Maintain secure deletion process
    - Keep audit logging
*/

-- Drop existing function if exists
DROP FUNCTION IF EXISTS delete_admin_user(uuid);

-- Create improved function for user deletion
CREATE OR REPLACE FUNCTION delete_admin_user(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text;
  v_role text;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Get user details for logging
  SELECT email, au.role 
  INTO v_email, v_role
  FROM auth.users u
  JOIN admin_users au ON au.id = u.id
  WHERE u.id = user_id;

  -- Delete from admin_users first
  DELETE FROM admin_users WHERE id = user_id;

  -- Delete from auth.users
  DELETE FROM auth.users WHERE id = user_id;

  -- Log the action
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'delete_admin_user',
    'admin_users',
    user_id,
    jsonb_build_object(
      'email', v_email,
      'role', v_role,
      'deleted_at', now()
    )
  );

  RETURN true;
EXCEPTION
  WHEN others THEN
    RAISE NOTICE 'Error deleting user: %', SQLERRM;
    RETURN false;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION delete_admin_user(uuid) TO authenticated;