/*
  # Add parent_id to blog_taxonomies table

  1. Changes
    - Add parent_id column to blog_taxonomies table
    - Add foreign key constraint to self-reference
    - Add index for faster lookups
    - Add code column for URL slugs

  2. Security
    - Maintain existing RLS policies
    - Keep existing data
*/

-- Add parent_id column to blog_taxonomies table
ALTER TABLE blog_taxonomies 
ADD COLUMN parent_id uuid REFERENCES blog_taxonomies(id);

-- Add code column for URL slugs
ALTER TABLE blog_taxonomies
ADD COLUMN code text;

-- Create index for parent_id column
CREATE INDEX IF NOT EXISTS blog_taxonomies_parent_id_idx ON blog_taxonomies(parent_id);

-- Create index for code column
CREATE INDEX IF NOT EXISTS blog_taxonomies_code_idx ON blog_taxonomies(code);

-- Update existing records to have a code based on name
UPDATE blog_taxonomies
SET code = lower(regexp_replace(name, '[^a-zA-Z0-9]+', '-', 'g'))
WHERE code IS NULL;

-- Add unique constraint to code column
ALTER TABLE blog_taxonomies
ADD CONSTRAINT blog_taxonomies_code_key UNIQUE (code);

-- Add comment explaining the changes
COMMENT ON COLUMN blog_taxonomies.parent_id IS 'Reference to parent category for hierarchical categories';
COMMENT ON COLUMN blog_taxonomies.code IS 'URL-friendly slug for the taxonomy';