/*
  # Remove company_size_order function

  1. Changes
    - Drop the company_size_order function
    - Drop the associated index
    - Clean up unused database objects

  2. Reason
    - Company sizes are now hardcoded in the application
    - The function is no longer needed for ordering
*/

-- Drop the index first
DROP INDEX IF EXISTS company_sizes_order_idx;

-- Drop the function
DROP FUNCTION IF EXISTS company_size_order(company_sizes);

-- Add comment explaining the change
COMMENT ON TABLE company_sizes IS 'DEPRECATED: Company sizes are now hardcoded in the application';