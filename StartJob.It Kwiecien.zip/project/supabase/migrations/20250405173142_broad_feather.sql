/*
  # Update blog category SEO template

  1. Changes
    - Update the blog category SEO template to use a more descriptive title and description
    - Add more detailed schema.org structured data
    - Ensure proper SEO for category pages

  2. Notes
    - The actual category name will be dynamically inserted by the frontend
    - This provides a template for all blog category pages
*/

-- Update blog category page template with better SEO
UPDATE seo_pages
SET 
  title = 'Kategoria: %s - Blog StartJob.IT',
  description = 'Artykuły z kategorii %s na blogu StartJob.IT. Najnowsze trendy, porady i informacje z branży IT.',
  keywords = 'blog IT, %s, artykuły, trendy IT, kariera IT',
  og_title = 'Kategoria: %s - Blog StartJob.IT',
  og_description = 'Artykuły z kategorii %s na blogu StartJob.IT. Najnowsze trendy, porady i informacje z branży IT.',
  schema_data = jsonb_build_object(
    'name', 'Kategoria %s - Blog StartJob.IT',
    'description', 'Artykuły z kategorii %s na blogu StartJob.IT. Wiedza i trendy dla branży IT.',
    'publisher', jsonb_build_object(
      '@type', 'Organization',
      'name', 'StartJob.IT',
      'logo', jsonb_build_object(
        '@type', 'ImageObject',
        'url', 'https://startjob.it/logo.png'
      )
    )
  )
WHERE path = '/blog/category';