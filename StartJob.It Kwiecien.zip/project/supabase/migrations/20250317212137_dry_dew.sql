/*
  # Fix admin access permissions

  1. Changes
    - Add admin access check functions
    - Create policies for admin operations
    - Grant necessary permissions
    - Add helper functions for admin operations

  2. Security
    - Maintain secure access control
    - Use proper permission scoping
    - Keep audit logging
*/

-- Create function to check admin access
CREATE OR REPLACE FUNCTION is_admin_user()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  );
END;
$$;

-- Create function to validate admin operations
CREATE OR REPLACE FUNCTION validate_admin_operation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT is_admin_user() THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;
  RETURN NEW;
END;
$$;

-- Create admin operations logging function
CREATE OR REPLACE FUNCTION log_admin_operation()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    TG_ARGV[0],
    TG_TABLE_NAME,
    NEW.id,
    row_to_json(NEW)
  );
  RETURN NEW;
END;
$$;

-- Grant necessary permissions
GRANT USAGE ON SCHEMA auth TO authenticated;
GRANT SELECT ON auth.users TO authenticated;
GRANT SELECT ON auth.users TO service_role;

-- Create policies for admin operations
CREATE POLICY "Enable admin read access"
  ON auth.users
  FOR SELECT
  TO authenticated
  USING (is_admin_user());

CREATE POLICY "Enable admin write access"
  ON auth.users
  FOR ALL
  TO authenticated
  USING (is_admin_user())
  WITH CHECK (is_admin_user());

-- Add triggers for admin operations
CREATE TRIGGER validate_admin_user_operation
  BEFORE INSERT OR UPDATE OR DELETE
  ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION validate_admin_operation();

CREATE TRIGGER log_admin_user_operation
  AFTER INSERT OR UPDATE
  ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION log_admin_operation('admin_user_modified');

-- Add comments
COMMENT ON FUNCTION is_admin_user() IS 'Checks if the current user has admin privileges';
COMMENT ON FUNCTION validate_admin_operation() IS 'Validates admin operations before execution';
COMMENT ON FUNCTION log_admin_operation() IS 'Logs admin operations for audit purposes';