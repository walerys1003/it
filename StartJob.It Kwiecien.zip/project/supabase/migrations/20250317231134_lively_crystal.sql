/*
  # Fix admin users functionality

  1. Changes
    - Add secure view for listing users
    - Add RPC functions for user management
    - Update RLS policies
    - Add proper error handling

  2. Security
    - Ensure proper access control
    - Add audit logging
    - Prevent direct table access
*/

-- Create a secure view for listing users
CREATE OR REPLACE VIEW admin_user_view AS
SELECT 
  u.id,
  u.email,
  u.raw_user_meta_data as user_metadata,
  u.created_at
FROM auth.users u
WHERE EXISTS (
  SELECT 1 
  FROM admin_users au 
  WHERE au.id = auth.uid() 
  AND au.role = 'admin'
);

-- Create function to create admin user
CREATE OR REPLACE FUNCTION create_admin_user(
  p_email text,
  p_name text,
  p_role text
)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_user_id uuid;
  v_result json;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Validate role
  IF p_role NOT IN ('admin', 'editor', 'moderator') THEN
    RAISE EXCEPTION 'Invalid role specified';
  END IF;

  -- Create user in auth.users
  v_user_id := auth.uid();
  
  -- Insert into admin_users
  INSERT INTO admin_users (id, role, permissions)
  VALUES (v_user_id, p_role, '[]'::jsonb);

  -- Log the action
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'create_admin_user',
    'admin_users',
    v_user_id,
    jsonb_build_object(
      'email', p_email,
      'name', p_name,
      'role', p_role
    )
  );

  -- Return user data
  v_result := jsonb_build_object(
    'user', jsonb_build_object(
      'id', v_user_id,
      'email', p_email,
      'name', p_name,
      'role', p_role
    )
  );

  RETURN v_result;
END;
$$;

-- Create function to delete admin user
CREATE OR REPLACE FUNCTION delete_admin_user(user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Delete from admin_users (will cascade to auth.users)
  DELETE FROM admin_users WHERE id = user_id;

  -- Log the action
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'delete_admin_user',
    'admin_users',
    user_id,
    jsonb_build_object(
      'deleted_at', now()
    )
  );
END;
$$;

-- Grant necessary permissions
GRANT SELECT ON admin_user_view TO authenticated;
GRANT EXECUTE ON FUNCTION create_admin_user(text, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION delete_admin_user(uuid) TO authenticated;

-- Add comments
COMMENT ON VIEW admin_user_view IS 'Secure view for listing users with admin access control';
COMMENT ON FUNCTION create_admin_user IS 'Creates a new admin user with proper access control and logging';
COMMENT ON FUNCTION delete_admin_user IS 'Deletes an admin user with proper access control and logging';