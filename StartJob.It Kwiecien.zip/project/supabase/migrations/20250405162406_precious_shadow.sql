/*
  # Allow direct admin_users deletion from Supabase dashboard

  1. Changes
    - Add a special RLS policy for direct database access
    - Create a function to check if request is coming from Supabase dashboard
    - Maintain security for API access
    - Keep existing validation for API requests

  2. Security
    - Only allow direct deletion from Supabase dashboard
    - Maintain audit logging
    - Keep existing validation for API requests
*/

-- Create function to check if request is coming from Supabase dashboard
CREATE OR REPLACE FUNCTION is_supabase_dashboard()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Check if the request is coming from the Supabase dashboard
  -- This is a simplified check that assumes direct database access
  -- is only happening from the Supabase dashboard
  RETURN current_setting('request.jwt.claim.role', true) IS NULL;
EXCEPTION
  WHEN OTHERS THEN
    -- If there's an error getting the setting, assume it's direct access
    RETURN true;
END;
$$;

-- Create a policy that allows direct deletion from Supabase dashboard
CREATE POLICY "Allow direct admin_users deletion from dashboard"
  ON admin_users
  FOR DELETE
  USING (is_supabase_dashboard());

-- Add comment
COMMENT ON FUNCTION is_supabase_dashboard() IS 'Checks if the current request is coming directly from the Supabase dashboard';