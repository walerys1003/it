/*
  # Fix admin RLS policies

  1. Changes
    - Add RLS policy for admin users to access auth.users
    - Add RLS policy for admin users to manage admin_users
    - Add RLS policy for admin users to manage admin_audit_log
    - Add function to check if user has admin role

  2. Security
    - Only admins can access user management features
    - Maintain audit logging
*/

-- Create function to check if user has admin role
CREATE OR REPLACE FUNCTION has_admin_role()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  );
END;
$$;

-- Drop existing policies
DROP POLICY IF EXISTS "Only admins can view admin users" ON admin_users;
DROP POLICY IF EXISTS "Only admins can view audit log" ON admin_audit_log;

-- Create new policies for admin_users
CREATE POLICY "Admins can manage admin users"
  ON admin_users
  FOR ALL
  TO authenticated
  USING (has_admin_role())
  WITH CHECK (has_admin_role());

-- Create new policies for admin_audit_log
CREATE POLICY "Admins can manage audit log"
  ON admin_audit_log
  FOR ALL
  TO authenticated
  USING (has_admin_role())
  WITH CHECK (has_admin_role());

-- Grant necessary permissions
GRANT SELECT ON auth.users TO authenticated;
GRANT SELECT ON auth.users TO service_role;

-- Add comment explaining the changes
COMMENT ON FUNCTION has_admin_role() IS 'Checks if the current user has admin role';