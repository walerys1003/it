/*
  # Add jobs in Warsaw and Stockholm

  1. New Jobs
    - Senior Java Developer at Allegro (Warsaw)
    - Frontend Developer at Klarna (Stockholm)

  2. Details
    - Both jobs include comprehensive descriptions, requirements, and benefits
    - Location-specific salary ranges and currencies
    - Company information and contact details
*/

INSERT INTO jobs (
  title, category, description, responsibilities, requirements, nice_to_have,
  technologies, work_mode, experience_level, contract_type, salary_from, salary_to,
  currency, benefits, location_country, location_city, languages, company_name,
  company_description, company_size, company_logo, contact_name, contact_position,
  contact_email, contact_phone, valid_until, is_active, is_featured, is_premium,
  user_id
) VALUES
-- Senior Java Developer at Allegro
(
  'Senior Java Developer',
  'Backend',
  'Join Allegro, the largest e-commerce platform in Poland. We''re looking for a Senior Java Developer to help us build and scale our microservices architecture.',
  ARRAY['Design and develop high-performance microservices', 'Optimize existing backend systems', 'Mentor junior developers', 'Participate in architecture decisions', 'Drive technical improvements'],
  ARRAY['6+ years of Java development experience', 'Strong knowledge of Spring Boot', 'Experience with microservices architecture', 'Proficiency in SQL and NoSQL databases', 'Understanding of distributed systems'],
  ARRAY['Experience with Kotlin', 'Knowledge of Apache Kafka', 'Kubernetes expertise', 'Performance optimization skills'],
  ARRAY['Java', 'Spring Boot', 'Kubernetes', 'PostgreSQL', 'Kafka'],
  'hybrid',
  'senior',
  'employment',
  25000,
  35000,
  'PLN',
  ARRAY['Private healthcare', 'SportCard', 'Learning budget 12000 PLN/year', 'Stock options', 'Life insurance', 'Remote work options'],
  'pl',
  'Warszawa',
  ARRAY['{"language": "Polski", "level": "C1"}', '{"language": "Angielski", "level": "B2"}']::jsonb[],
  'Allegro',
  'Allegro is the largest e-commerce platform in Poland and one of the largest in Europe, serving millions of customers daily.',
  '5000+ employees',
  'https://images.unsplash.com/photo-1549924231-f129b911e442?w=64&h=64&fit=crop&crop=faces',
  'Marta Kowalczyk',
  'Senior Tech Recruiter',
  'tech.careers@allegro.pl',
  '+48 500 100 200',
  NOW() + INTERVAL '90 days',
  true,
  true,
  true,
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a'
),

-- Frontend Developer at Klarna
(
  'Frontend Developer',
  'Frontend',
  'Join Klarna''s product team in Stockholm and help build the future of financial services. We''re looking for a talented Frontend Developer to create exceptional user experiences.',
  ARRAY['Develop new features for Klarna''s web applications', 'Collaborate with UX/UI designers', 'Implement responsive designs', 'Write unit and integration tests', 'Optimize frontend performance'],
  ARRAY['3+ years of frontend development', 'Strong React and TypeScript skills', 'Experience with modern CSS', 'Knowledge of frontend testing', 'Understanding of web accessibility'],
  ARRAY['Experience with Next.js', 'Knowledge of GraphQL', 'Performance optimization', 'Mobile-first development'],
  ARRAY['React', 'TypeScript', 'Next.js', 'Jest', 'Styled Components'],
  'hybrid',
  'mid',
  'employment',
  55000,
  65000,
  'EUR',
  ARRAY['Competitive salary', 'Stock options', 'Wellness allowance', '30 days vacation', 'Relocation support', 'Learning & development budget'],
  'se',
  'Stockholm',
  ARRAY['{"language": "Angielski", "level": "C1"}', '{"language": "Svenska", "level": "A2"}']::jsonb[],
  'Klarna',
  'Klarna is a leading global retail bank, payments, and shopping service. We''re reimagining payments and shopping to make it smarter, more delightful, and safer for customers.',
  '5000+ employees',
  'https://images.unsplash.com/photo-1496200186974-4293800e2c20?w=64&h=64&fit=crop&crop=faces',
  'Erik Andersson',
  'Tech Talent Acquisition',
  'jobs@klarna.com',
  '+46 8 120 120 00',
  NOW() + INTERVAL '90 days',
  true,
  true,
  true,
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a'
);