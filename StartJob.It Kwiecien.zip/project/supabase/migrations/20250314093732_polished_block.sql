/*
  # Insert test user and example job postings

  1. Data Insertion
    - Create a test user in auth.users
    - Add 5 diverse job postings linked to the test user:
      - Senior React Developer
      - DevOps Engineer
      - Python Developer (AI/ML)
      - Frontend Developer
      - Full Stack Developer

  2. Notes
    - All jobs are set as active
    - Valid dates are set 60-90 days in the future
    - Includes a mix of regular and premium listings
*/

-- First, create a test user
INSERT INTO auth.users (
  id,
  email,
  raw_user_meta_data
) VALUES (
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a',
  'test@startjob.it',
  '{"name": "Test User"}'
) ON CONFLICT (id) DO NOTHING;

-- Now insert the job postings
INSERT INTO jobs (
  title, category, description, responsibilities, requirements, nice_to_have,
  technologies, work_mode, experience_level, contract_type, salary_from, salary_to,
  currency, benefits, location_country, location_city, languages, company_name,
  company_description, company_size, company_logo, contact_name, contact_position,
  contact_email, contact_phone, valid_until, is_active, is_featured, is_premium,
  user_id
) VALUES
-- Senior React Developer
(
  'Senior React Developer',
  'Frontend',
  'Poszukujemy doświadczonego React Developera do pracy przy innowacyjnych projektach e-commerce.',
  ARRAY['Rozwój i utrzymanie aplikacji w React.js', 'Projektowanie i implementacja nowych funkcjonalności', 'Code review i mentoring młodszych programistów', 'Współpraca z zespołem UX/UI', 'Optymalizacja wydajności aplikacji'],
  ARRAY['Min. 5 lat doświadczenia w React.js', 'Bardzo dobra znajomość TypeScript', 'Doświadczenie w Node.js i Express', 'Znajomość AWS i architektury cloud', 'Umiejętność pracy w metodologii Agile'],
  ARRAY['Doświadczenie w React Native', 'Znajomość GraphQL', 'Contributions do open source', 'Certyfikaty AWS'],
  ARRAY['React', 'TypeScript', 'Node.js', 'AWS', 'Docker'],
  'hybrid',
  'senior',
  'b2b',
  18000,
  25000,
  'PLN',
  ARRAY['Prywatna opieka medyczna', 'Karta Multisport', 'Budżet szkoleniowy 8000 PLN/rok', 'Elastyczne godziny pracy', 'Możliwość pracy zdalnej'],
  'pl',
  'Warszawa',
  ARRAY['{"language": "Polski", "level": "B2"}', '{"language": "Angielski", "level": "C1"}']::jsonb[],
  'TechCorp Solutions',
  'TechCorp Solutions to wiodący software house specjalizujący się w tworzeniu innowacyjnych rozwiązań dla klientów z całego świata.',
  '200+ pracowników',
  'https://images.unsplash.com/photo-1549924231-f129b911e442?w=64&h=64&fit=crop&crop=faces',
  'Anna Kowalska',
  'Senior IT Recruiter',
  'rekrutacja@techcorp.pl',
  '+48 500 600 700',
  NOW() + INTERVAL '90 days',
  true,
  true,
  true,
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a'
),

-- DevOps Engineer
(
  'DevOps Engineer',
  'DevOps',
  'Poszukujemy DevOps Engineer do zespołu Cloud Infrastructure. Oferujemy możliwość pracy z najnowszymi technologiami chmurowymi.',
  ARRAY['Zarządzanie infrastrukturą AWS', 'Automatyzacja procesów CI/CD', 'Monitoring i optymalizacja systemów', 'Wdrażanie rozwiązań containerowych', 'Zapewnienie bezpieczeństwa infrastruktury'],
  ARRAY['Min. 3 lata doświadczenia w DevOps', 'Praktyczna znajomość AWS', 'Doświadczenie z Kubernetes i Docker', 'Znajomość Terraform i Ansible', 'Umiejętność pisania skryptów (Python/Bash)'],
  ARRAY['Certyfikaty AWS', 'Doświadczenie z Azure lub GCP', 'Znajomość ELK Stack', 'Doświadczenie z Prometheus i Grafana'],
  ARRAY['Kubernetes', 'Docker', 'AWS', 'Terraform', 'Ansible'],
  'remote',
  'mid',
  'employment',
  15000,
  22000,
  'PLN',
  ARRAY['100% zdalnej pracy', 'Prywatna opieka medyczna', 'Dofinansowanie do sprzętu', 'Elastyczne godziny pracy'],
  'pl',
  'Kraków',
  ARRAY['{"language": "Polski", "level": "Ojczysty"}', '{"language": "Angielski", "level": "B2"}']::jsonb[],
  'Cloud Systems',
  'Cloud Systems to dynamicznie rozwijająca się firma specjalizująca się w rozwiązaniach chmurowych dla biznesu.',
  '50-100 pracowników',
  'https://images.unsplash.com/photo-1552664730-d307ca884978?w=64&h=64&fit=crop&crop=faces',
  'Piotr Nowak',
  'Technical Recruiter',
  'careers@cloudsystems.pl',
  '+48 500 100 200',
  NOW() + INTERVAL '60 days',
  true,
  false,
  false,
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a'
),

-- Python Developer (AI/ML)
(
  'Python Developer (AI/ML)',
  'AI/ML',
  'Szukamy Python Developera do pracy przy projektach z zakresu AI i Machine Learning.',
  ARRAY['Rozwój modeli ML', 'Implementacja algorytmów AI', 'Analiza i przetwarzanie danych', 'Optymalizacja istniejących rozwiązań'],
  ARRAY['Min. 3 lata doświadczenia w Python', 'Znajomość TensorFlow lub PyTorch', 'Doświadczenie w ML/AI', 'Znajomość SQL'],
  ARRAY['Doświadczenie z Big Data', 'Znajomość Apache Spark', 'Publikacje naukowe'],
  ARRAY['Python', 'TensorFlow', 'PyTorch', 'SQL', 'Docker'],
  'hybrid',
  'senior',
  'b2b',
  16000,
  23000,
  'PLN',
  ARRAY['Praca przy innowacyjnych projektach', 'Konferencje międzynarodowe', 'Prywatna opieka medyczna', 'Karta Multisport'],
  'pl',
  'Wrocław',
  ARRAY['{"language": "Polski", "level": "B2"}', '{"language": "Angielski", "level": "C1"}']::jsonb[],
  'AI Solutions Lab',
  'Tworzymy innowacyjne rozwiązania AI dla biznesu i nauki.',
  '20-50 pracowników',
  'https://images.unsplash.com/photo-1551434678-e076c223a692?w=64&h=64&fit=crop&crop=faces',
  'Maria Wiśniewska',
  'Head of Talent',
  'praca@aisolutions.pl',
  '+48 700 800 900',
  NOW() + INTERVAL '90 days',
  true,
  true,
  true,
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a'
),

-- Frontend Developer
(
  'Frontend Developer',
  'Frontend',
  'Dołącz do naszego zespołu jako Frontend Developer i twórz nowoczesne interfejsy użytkownika.',
  ARRAY['Rozwój aplikacji w React i Vue.js', 'Implementacja responsywnych interfejsów', 'Optymalizacja wydajności frontend', 'Współpraca z zespołem UX'],
  ARRAY['2+ lata doświadczenia w JavaScript', 'Znajomość React lub Vue.js', 'Dobra znajomość HTML5 i CSS3', 'Podstawy TypeScript'],
  ARRAY['Znajomość Next.js', 'Doświadczenie z Tailwind CSS', 'Znajomość testów jednostkowych'],
  ARRAY['JavaScript', 'React', 'Vue.js', 'HTML', 'CSS'],
  'office',
  'mid',
  'employment',
  12000,
  16000,
  'PLN',
  ARRAY['Prywatna opieka medyczna', 'Karta sportowa', 'Szkolenia', 'Owoce w biurze'],
  'pl',
  'Poznań',
  ARRAY['{"language": "Polski", "level": "Ojczysty"}', '{"language": "Angielski", "level": "B1"}']::jsonb[],
  'WebTech Solutions',
  'Tworzymy nowoczesne rozwiązania webowe dla klientów z całego świata.',
  '10-50 pracowników',
  'https://images.unsplash.com/photo-1572044162444-ad60f128bdea?w=64&h=64&fit=crop&crop=faces',
  'Tomasz Kowalczyk',
  'HR Manager',
  'kariera@webtech.pl',
  '+48 600 700 800',
  NOW() + INTERVAL '60 days',
  true,
  false,
  false,
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a'
),

-- Full Stack Developer
(
  'Full Stack Developer',
  'Fullstack',
  'Poszukujemy Full Stack Developera do pracy przy projektach wykorzystujących MERN stack.',
  ARRAY['Rozwój aplikacji w React i Node.js', 'Projektowanie architektury aplikacji', 'Implementacja API', 'Optymalizacja baz danych'],
  ARRAY['3+ lata doświadczenia Full Stack', 'Znajomość MERN stack', 'Doświadczenie z bazami NoSQL', 'Znajomość REST API'],
  ARRAY['Znajomość GraphQL', 'Doświadczenie z mikrousługami', 'Certyfikaty cloud'],
  ARRAY['React', 'Node.js', 'MongoDB', 'Express', 'TypeScript'],
  'hybrid',
  'senior',
  'b2b',
  16000,
  22000,
  'PLN',
  ARRAY['Elastyczne godziny', 'Praca zdalna', 'Budżet szkoleniowy', 'Prywatna opieka medyczna'],
  'pl',
  'Gdańsk',
  ARRAY['{"language": "Polski", "level": "B2"}', '{"language": "Angielski", "level": "B2"}']::jsonb[],
  'Digital Craft',
  'Specjalizujemy się w tworzeniu zaawansowanych aplikacji webowych.',
  '20-50 pracowników',
  'https://images.unsplash.com/photo-1560179707-f14e90ef3623?w=64&h=64&fit=crop&crop=faces',
  'Magdalena Nowak',
  'Tech Recruiter',
  'praca@digitalcraft.pl',
  '+48 500 600 700',
  NOW() + INTERVAL '90 days',
  true,
  true,
  false,
  'f8b9b1a0-5c1a-4e1d-9b1a-5c1a4e1d9b1a'
);