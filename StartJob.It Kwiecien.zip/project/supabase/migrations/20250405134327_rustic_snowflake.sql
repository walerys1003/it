/*
  # Fix admin user deletion

  1. Changes
    - Create a trigger to automatically delete admin_users records when auth.users records are deleted
    - Ensure proper cascading deletion between auth.users and admin_users
    - Add function to properly delete users from both tables

  2. Security
    - Maintain existing RLS policies
    - Keep audit logging
*/

-- Create function to handle user deletion from auth.users
CREATE OR REPLACE FUNCTION handle_auth_user_deletion()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Delete corresponding record from admin_users if it exists
  DELETE FROM admin_users WHERE id = OLD.id;
  
  -- Log the deletion
  INSERT INTO admin_audit_log (
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    'cascade_delete_admin_user',
    'admin_users',
    OLD.id,
    jsonb_build_object(
      'email', OLD.email,
      'deleted_at', now(),
      'deleted_by', 'system_trigger'
    )
  );
  
  RETURN OLD;
END;
$$;

-- Create trigger to handle user deletion
DROP TRIGGER IF EXISTS on_auth_user_delete ON auth.users;
CREATE TRIGGER on_auth_user_delete
  BEFORE DELETE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_auth_user_deletion();

-- Create improved function for user deletion that handles both tables
CREATE OR REPLACE FUNCTION delete_user_completely(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_email text;
  v_role text;
  v_name text;
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Get user details for logging
  SELECT 
    u.email, 
    COALESCE(au.role, 'none'),
    COALESCE(u.raw_user_meta_data->>'name', 'Unknown')
  INTO 
    v_email, 
    v_role,
    v_name
  FROM auth.users u
  LEFT JOIN admin_users au ON au.id = u.id
  WHERE u.id = user_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'User not found';
  END IF;

  -- Log the deletion attempt
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'delete_user_attempt',
    'users',
    user_id,
    jsonb_build_object(
      'email', v_email,
      'role', v_role,
      'name', v_name,
      'attempted_at', now()
    )
  );

  -- Delete from auth.users (will cascade to admin_users via trigger)
  DELETE FROM auth.users WHERE id = user_id;

  -- Log successful deletion
  INSERT INTO admin_audit_log (
    admin_id,
    action,
    entity_type,
    entity_id,
    details
  ) VALUES (
    auth.uid(),
    'delete_user_success',
    'users',
    user_id,
    jsonb_build_object(
      'email', v_email,
      'role', v_role,
      'name', v_name,
      'deleted_at', now()
    )
  );

  RETURN true;
EXCEPTION
  WHEN others THEN
    -- Log the error
    INSERT INTO admin_audit_log (
      admin_id,
      action,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'delete_user_error',
      'users',
      user_id,
      jsonb_build_object(
        'error', SQLERRM,
        'email', v_email,
        'role', v_role,
        'name', v_name
      )
    );
    
    RETURN false;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION delete_user_completely(uuid) TO authenticated;

-- Add comment
COMMENT ON FUNCTION delete_user_completely(uuid) IS 'Completely deletes a user from both auth.users and admin_users tables with proper logging';
COMMENT ON FUNCTION handle_auth_user_deletion() IS 'Trigger function to handle cascading deletion from auth.users to admin_users';