/*
  # Fix users query functionality

  1. Changes
    - Create a secure function for accessing auth.users data
    - Add proper access control to the function
    - Simplify user data access

  2. Security
    - Maintain proper access control
    - Keep audit logging
*/

-- Create a function to securely access auth.users data
CREATE OR REPLACE FUNCTION get_auth_user_details(user_id uuid)
RETURNS TABLE (
  id uuid,
  email text,
  raw_user_meta_data jsonb,
  created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Check if user has admin access
  IF NOT EXISTS (
    SELECT 1 
    FROM users 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Return user details
  RETURN QUERY
  SELECT 
    u.id,
    u.email,
    u.raw_user_meta_data,
    u.created_at
  FROM 
    auth.users u
  WHERE 
    u.id = user_id;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION get_auth_user_details(uuid) TO authenticated;

-- Add comment
COMMENT ON FUNCTION get_auth_user_details(uuid) IS 'Securely access auth.users data with proper access control';

-- Create a function to get all auth users for admins
CREATE OR REPLACE FUNCTION get_all_auth_users()
RETURNS TABLE (
  id uuid,
  email text,
  raw_user_meta_data jsonb,
  created_at timestamptz
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Check if user has admin access
  IF NOT EXISTS (
    SELECT 1 
    FROM users 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Return all users
  RETURN QUERY
  SELECT 
    u.id,
    u.email,
    u.raw_user_meta_data,
    u.created_at
  FROM 
    auth.users u;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION get_all_auth_users() TO authenticated;

-- Add comment
COMMENT ON FUNCTION get_all_auth_users() IS 'Get all auth users for admin users with proper access control';