/*
  # Add technologies table and settings

  1. New Tables
    - `technologies`
      - `id` (uuid, primary key)
      - `name` (text)
      - `code` (text, unique)
      - `category` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS
    - Add policies for public read access
    - Add policies for admin write access

  3. Initial Data
    - Add predefined technology categories and items
*/

-- Create technologies table
CREATE TABLE IF NOT EXISTS technologies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  code text NOT NULL UNIQUE,
  category text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create indexes
CREATE INDEX technologies_category_idx ON technologies(category);
CREATE INDEX technologies_name_idx ON technologies(name);

-- Add trigger for updating updated_at
CREATE TRIGGER update_technologies_updated_at
  BEFORE UPDATE ON technologies
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE technologies ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Public can view technologies"
  ON technologies
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "Admins can manage technologies"
  ON technologies
  FOR ALL
  TO public
  USING (is_admin())
  WITH CHECK (is_admin());

-- Insert initial data
INSERT INTO technologies (name, code, category) VALUES
-- Frontend
('JavaScript', 'javascript', 'Języki programowania i technologie front-end'),
('TypeScript', 'typescript', 'Języki programowania i technologie front-end'),
('HTML', 'html', 'Języki programowania i technologie front-end'),
('CSS', 'css', 'Języki programowania i technologie front-end'),
('React.js', 'react', 'Języki programowania i technologie front-end'),
('Angular', 'angular', 'Języki programowania i technologie front-end'),
('Vue.js', 'vue', 'Języki programowania i technologie front-end'),
('Sass', 'sass', 'Języki programowania i technologie front-end'),
('Bootstrap', 'bootstrap', 'Języki programowania i technologie front-end'),

-- Backend
('Python', 'python', 'Języki programowania i technologie back-end'),
('Java', 'java', 'Języki programowania i technologie back-end'),
('C# (.NET)', 'csharp', 'Języki programowania i technologie back-end'),
('C++', 'cpp', 'Języki programowania i technologie back-end'),
('C', 'c', 'Języki programowania i technologie back-end'),
('PHP', 'php', 'Języki programowania i technologie back-end'),
('Ruby', 'ruby', 'Języki programowania i technologie back-end'),
('Node.js', 'nodejs', 'Języki programowania i technologie back-end'),
('Express.js', 'express', 'Języki programowania i technologie back-end'),
('Go (Golang)', 'golang', 'Języki programowania i technologie back-end'),
('Scala', 'scala', 'Języki programowania i technologie back-end'),
('Elixir', 'elixir', 'Języki programowania i technologie back-end'),
('Rust', 'rust', 'Języki programowania i technologie back-end'),
('Perl', 'perl', 'Języki programowania i technologie back-end'),
('Shell/Bash', 'shell', 'Języki programowania i technologie back-end'),

-- Mobile
('Swift', 'swift', 'Programowanie mobilne'),
('Kotlin', 'kotlin', 'Programowanie mobilne'),
('React Native', 'react-native', 'Programowanie mobilne'),
('Flutter', 'flutter', 'Programowanie mobilne'),
('Objective-C', 'objective-c', 'Programowanie mobilne'),
('Dart', 'dart', 'Programowanie mobilne'),

-- Cloud & DevOps
('AWS', 'aws', 'Technologie chmurowe i DevOps'),
('Microsoft Azure', 'azure', 'Technologie chmurowe i DevOps'),
('Google Cloud Platform', 'gcp', 'Technologie chmurowe i DevOps'),
('Docker', 'docker', 'Technologie chmurowe i DevOps'),
('Kubernetes', 'kubernetes', 'Technologie chmurowe i DevOps'),
('Terraform', 'terraform', 'Technologie chmurowe i DevOps'),
('Ansible', 'ansible', 'Technologie chmurowe i DevOps'),
('Jenkins', 'jenkins', 'Technologie chmurowe i DevOps'),
('Prometheus', 'prometheus', 'Technologie chmurowe i DevOps'),
('Grafana', 'grafana', 'Technologie chmurowe i DevOps'),

-- Databases
('MySQL', 'mysql', 'Bazy danych i zarządzanie danymi'),
('PostgreSQL', 'postgresql', 'Bazy danych i zarządzanie danymi'),
('MongoDB', 'mongodb', 'Bazy danych i zarządzanie danymi'),
('Redis', 'redis', 'Bazy danych i zarządzanie danymi'),
('Elasticsearch', 'elasticsearch', 'Bazy danych i zarządzanie danymi'),
('SQLite', 'sqlite', 'Bazy danych i zarządzanie danymi'),
('Firebase', 'firebase', 'Bazy danych i zarządzanie danymi'),
('Oracle', 'oracle', 'Bazy danych i zarządzanie danymi'),

-- API
('REST API', 'rest-api', 'API i technologie komunikacyjne'),
('GraphQL', 'graphql', 'API i technologie komunikacyjne'),
('gRPC', 'grpc', 'API i technologie komunikacyjne'),
('SOAP', 'soap', 'API i technologie komunikacyjne'),

-- AI/ML
('TensorFlow', 'tensorflow', 'Uczenie maszynowe i sztuczna inteligencja'),
('PyTorch', 'pytorch', 'Uczenie maszynowe i sztuczna inteligencja'),
('Scikit-Learn', 'scikit-learn', 'Uczenie maszynowe i sztuczna inteligencja'),
('OpenAI API', 'openai-api', 'Uczenie maszynowe i sztuczna inteligencja'),
('Apache Spark', 'apache-spark', 'Uczenie maszynowe i sztuczna inteligencja'),
('Hadoop', 'hadoop', 'Uczenie maszynowe i sztuczna inteligencja'),

-- Security
('SSL/TLS', 'ssl-tls', 'Bezpieczeństwo IT'),
('OAuth', 'oauth', 'Bezpieczeństwo IT'),
('JWT', 'jwt', 'Bezpieczeństwo IT'),
('SIEM', 'siem', 'Bezpieczeństwo IT'),

-- Data Analysis
('Power BI', 'power-bi', 'Narzędzia do analizy danych'),
('Tableau', 'tableau', 'Narzędzia do analizy danych'),
('Jupyter Notebook', 'jupyter', 'Narzędzia do analizy danych'),
('Apache Kafka', 'kafka', 'Narzędzia do analizy danych'),

-- Other Tools
('.NET Core', 'dotnet-core', 'Inne popularne technologie i narzędzia'),
('Spring Boot', 'spring-boot', 'Inne popularne technologie i narzędzia'),
('Laravel', 'laravel', 'Inne popularne technologie i narzędzia'),
('WordPress', 'wordpress', 'Inne popularne technologie i narzędzia'),
('Selenium', 'selenium', 'Inne popularne technologie i narzędzia'),
('Solidity', 'solidity', 'Inne popularne technologie i narzędzia'),
('Unity', 'unity', 'Inne popularne technologie i narzędzia'),
('Blender', 'blender', 'Inne popularne technologie i narzędzia'),

-- Project Management
('Git & GitHub', 'git', 'Zarządzanie projektami i współpraca'),
('Jira', 'jira', 'Zarządzanie projektami i współpraca'),
('Confluence', 'confluence', 'Zarządzanie projektami i współpraca'),
('Slack', 'slack', 'Zarządzanie projektami i współpraca'),
('Trello', 'trello', 'Zarządzanie projektami i współpraca'),

-- Future Tech
('Blockchain', 'blockchain', 'Technologie przyszłości'),
('IoT', 'iot', 'Technologie przyszłości'),
('AR/VR', 'ar-vr', 'Technologie przyszłości'),
('5G', '5g', 'Technologie przyszłości')
ON CONFLICT (code) DO NOTHING;

-- Add comment
COMMENT ON TABLE technologies IS 'Available technologies for job postings';