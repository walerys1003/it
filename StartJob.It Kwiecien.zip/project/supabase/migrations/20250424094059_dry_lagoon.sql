-- Drop the existing function first
DROP FUNCTION IF EXISTS get_all_auth_users();

-- Create function to get all auth users
CREATE OR REPLACE FUNCTION get_all_auth_users()
RETURNS TABLE (
  id uuid,
  email text,
  created_at timestamptz,
  user_metadata jsonb
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Check if user has admin privileges
  IF NOT EXISTS (
    SELECT 1 FROM users 
    WHERE user_id = auth.uid() 
    AND role = 'admin'
  ) THEN
    RAISE EXCEPTION 'Access denied: Admin privileges required';
  END IF;

  -- Return all users from auth.users
  RETURN QUERY
  SELECT 
    u.id,
    u.email::text,
    u.created_at,
    u.raw_user_meta_data AS user_metadata
  FROM auth.users u;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION get_all_auth_users() TO authenticated;

-- Add comment
COMMENT ON FUNCTION get_all_auth_users() IS 'Gets all users from auth.users table, only accessible to admins';