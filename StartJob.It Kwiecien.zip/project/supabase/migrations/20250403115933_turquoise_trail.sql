/*
  # Add storage bucket for job assets

  1. New Storage Bucket
    - `job_assets`: Stores job-related files like company logos
    - Public access for reading
    - Authenticated access for writing
    - RLS policies for secure access

  2. Security
    - Enable RLS on the bucket
    - Add policies for public read access
    - Add policies for authenticated write access
*/

-- Create storage bucket for job assets
INSERT INTO storage.buckets (id, name, public)
VALUES ('job_assets', 'job_assets', true)
ON CONFLICT (id) DO NOTHING;

-- Enable RLS on the bucket
UPDATE storage.buckets
SET public = true
WHERE id = 'job_assets';

-- Create policy for public read access
CREATE POLICY "Public can read job assets"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'job_assets');

-- Create policy for authenticated write access
CREATE POLICY "Authenticated users can upload job assets"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'job_assets');

-- Create policy for authenticated delete access
CREATE POLICY "Authenticated users can delete their own job assets"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'job_assets');

-- Add trigger to delete job assets when job is deleted
CREATE OR REPLACE FUNCTION delete_job_assets()
RETURNS TRIGGER AS $$
BEGIN
  -- Delete company logo if it's stored in our bucket
  IF OLD.company_logo LIKE '%/job_assets/%' THEN
    -- Extract the path from the URL
    DECLARE
      path_parts text[];
      file_path text;
    BEGIN
      path_parts := string_to_array(OLD.company_logo, '/');
      file_path := array_to_string(path_parts[array_upper(path_parts, 1) - 1:array_upper(path_parts, 1)], '/');
      
      -- Delete the file
      DELETE FROM storage.objects
      WHERE bucket_id = 'job_assets'
      AND name LIKE '%' || file_path;
    END;
  END IF;
  
  RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to delete job assets when job is deleted
CREATE TRIGGER delete_job_assets_trigger
BEFORE DELETE ON jobs
FOR EACH ROW
EXECUTE FUNCTION delete_job_assets();