/*
  # Add applications table

  1. New Tables
    - `applications`
      - `id` (uuid, primary key)
      - `job_id` (uuid, foreign key to jobs)
      - `candidate_name` (text)
      - `candidate_email` (text)
      - `candidate_phone` (text, optional)
      - `message` (text)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
      - `cv_url` (text)
      - `status` (text)

  2. Security
    - Enable RLS on `applications` table
    - Add policies for:
      - Public can create applications
      - Public can view their own applications (by email)

  3. Indexes
    - Index on job_id for faster lookups
    - Index on candidate_email for filtering
    - Index on created_at for sorting
*/

-- Create applications table
CREATE TABLE IF NOT EXISTS applications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid REFERENCES jobs(id) ON DELETE CASCADE,
  candidate_name text NOT NULL,
  candidate_email text NOT NULL,
  candidate_phone text,
  message text NOT NULL,
  cv_url text NOT NULL,
  status text NOT NULL DEFAULT 'new' CHECK (status IN ('new', 'reviewed', 'contacted', 'rejected')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Create indexes
CREATE INDEX applications_job_id_idx ON applications(job_id);
CREATE INDEX applications_candidate_email_idx ON applications(candidate_email);
CREATE INDEX applications_created_at_idx ON applications(created_at);

-- Add trigger for updating updated_at
CREATE TRIGGER update_applications_updated_at
  BEFORE UPDATE ON applications
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- Enable RLS
ALTER TABLE applications ENABLE ROW LEVEL SECURITY;

-- Add RLS policies
CREATE POLICY "Anyone can create applications"
  ON applications
  FOR INSERT
  TO public
  WITH CHECK (true);

CREATE POLICY "Users can view their own applications"
  ON applications
  FOR SELECT
  TO public
  USING (candidate_email = current_setting('app.user_email', true));

-- Add example comment
COMMENT ON TABLE applications IS 'Stores job applications submitted by candidates';