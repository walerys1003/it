/*
  # Add SEO pages for remaining routes

  1. New Data
    - Add SEO metadata for all remaining pages in the site
    - Ensure all routes have proper SEO configuration
    - Add appropriate schema.org structured data for each page type

  2. Pages Added:
    - /uslugi-promocji (Promotion Services)
    - /social-media (Social Media)
    - /dodaj-ogloszenie/podsumowanie (Job Posting Summary)
    - /oferta/:id (Job Posting Page)
    - /platnosc (Payment Page)
    - /blog/category/:id (Blog Category Page)
*/

-- Insert SEO pages for remaining routes
INSERT INTO seo_pages (path, title, description, keywords, og_title, og_description, og_type, schema_type, schema_data)
VALUES
  -- Promotion Services
  ('/uslugi-promocji', 'Usługi Promocji | StartJob.IT', 'Usługi promocji ogłoszeń o pracę w IT. Zwiększ widoczność swoich ofert pracy i przyciągnij najlepszych kandydatów.', 'promocja, marketing, ogłoszenia, rekrutacja IT, widoczność', 'Usługi Promocji | StartJob.IT', 'Usługi promocji ogłoszeń o pracę w IT. Zwiększ widoczność swoich ofert pracy i przyciągnij najlepszych kandydatów.', 'website', 'Service', 
  jsonb_build_object(
    'name', 'Usługi Promocji StartJob.IT',
    'description', 'Usługi promocji ogłoszeń o pracę w IT. Zwiększ widoczność swoich ofert pracy.',
    'provider', jsonb_build_object(
      '@type', 'Organization',
      'name', 'StartJob.IT',
      'url', 'https://startjob.it'
    ),
    'serviceType', 'Job Promotion Service',
    'offers', jsonb_build_array(
      jsonb_build_object(
        '@type', 'Offer',
        'name', 'Kampanie reklamowe',
        'description', 'Reklamy w social mediach, kampanie Google Ads i YouTube'
      ),
      jsonb_build_object(
        '@type', 'Offer',
        'name', 'Video ogłoszenie',
        'description', 'Produkcja i promocja 30-60 sekundowego wideo'
      ),
      jsonb_build_object(
        '@type', 'Offer',
        'name', 'Headhunting Premium',
        'description', 'Dedykowany headhunting i weryfikacja kandydatów'
      )
    )
  )),

  -- Social Media
  ('/social-media', 'Social Media | StartJob.IT', 'Dołącz do społeczności specjalistów IT i bądź na bieżąco z najlepszymi ofertami pracy oraz trendami w branży!', 'social media, Facebook, LinkedIn, Instagram, społeczność IT', 'Social Media | StartJob.IT', 'Dołącz do społeczności specjalistów IT i bądź na bieżąco z najlepszymi ofertami pracy oraz trendami w branży!', 'website', 'WebPage',
  jsonb_build_object(
    'name', 'Social Media StartJob.IT',
    'description', 'Dołącz do społeczności specjalistów IT i bądź na bieżąco z najlepszymi ofertami pracy oraz trendami w branży!',
    'mainEntity', jsonb_build_object(
      '@type', 'ItemList',
      'itemListElement', jsonb_build_array(
        jsonb_build_object(
          '@type', 'ListItem',
          'position', 1,
          'item', jsonb_build_object(
            '@type', 'SocialMediaPosting',
            'headline', 'Facebook - Grupa dla Specjalistów IT',
            'url', 'https://facebook.com/startjob.it'
          )
        ),
        jsonb_build_object(
          '@type', 'ListItem',
          'position', 2,
          'item', jsonb_build_object(
            '@type', 'SocialMediaPosting',
            'headline', 'LinkedIn - Profesjonalna Sieć dla IT',
            'url', 'https://linkedin.com/company/startjob-it'
          )
        ),
        jsonb_build_object(
          '@type', 'ListItem',
          'position', 3,
          'item', jsonb_build_object(
            '@type', 'SocialMediaPosting',
            'headline', 'Instagram - Życie i Kariera w IT',
            'url', 'https://instagram.com/startjob.it'
          )
        )
      )
    )
  )),

  -- Job Posting Summary
  ('/dodaj-ogloszenie/podsumowanie', 'Podsumowanie ogłoszenia | StartJob.IT', 'Podsumowanie ogłoszenia o pracę przed publikacją. Sprawdź poprawność wprowadzonych danych.', 'podsumowanie, ogłoszenie, praca IT, publikacja', 'Podsumowanie ogłoszenia | StartJob.IT', 'Podsumowanie ogłoszenia o pracę przed publikacją. Sprawdź poprawność wprowadzonych danych.', 'website', 'WebPage',
  jsonb_build_object(
    'name', 'Podsumowanie ogłoszenia o pracę',
    'description', 'Podsumowanie ogłoszenia o pracę przed publikacją. Sprawdź poprawność wprowadzonych danych.',
    'mainEntity', jsonb_build_object(
      '@type', 'Service',
      'serviceType', 'Job Posting Service',
      'provider', jsonb_build_object(
        '@type', 'Organization',
        'name', 'StartJob.IT',
        'url', 'https://startjob.it'
      )
    )
  )),

  -- Job Posting Page Template
  ('/oferta', 'Oferta pracy | StartJob.IT', 'Szczegóły oferty pracy w branży IT. Sprawdź wymagania, obowiązki i benefity.', 'oferta pracy, praca IT, rekrutacja, kariera IT', 'Oferta pracy | StartJob.IT', 'Szczegóły oferty pracy w branży IT. Sprawdź wymagania, obowiązki i benefity.', 'website', 'JobPosting',
  jsonb_build_object(
    'title', 'Oferta pracy w IT',
    'description', 'Szczegóły oferty pracy w branży IT. Sprawdź wymagania, obowiązki i benefity.',
    'employmentType', 'FULL_TIME',
    'hiringOrganization', jsonb_build_object(
      '@type', 'Organization',
      'name', 'StartJob.IT',
      'url', 'https://startjob.it'
    ),
    'jobLocation', jsonb_build_object(
      '@type', 'Place',
      'address', jsonb_build_object(
        '@type', 'PostalAddress',
        'addressCountry', 'PL'
      )
    )
  )),

  -- Payment Page
  ('/platnosc', 'Płatność | StartJob.IT', 'Bezpieczna płatność za ogłoszenie o pracę na StartJob.IT.', 'płatność, ogłoszenie, praca IT, bezpieczne płatności', 'Płatność | StartJob.IT', 'Bezpieczna płatność za ogłoszenie o pracę na StartJob.IT.', 'website', 'WebPage',
  jsonb_build_object(
    'name', 'Płatność za ogłoszenie',
    'description', 'Bezpieczna płatność za ogłoszenie o pracę na StartJob.IT.',
    'mainEntity', jsonb_build_object(
      '@type', 'Service',
      'serviceType', 'Payment Service',
      'provider', jsonb_build_object(
        '@type', 'Organization',
        'name', 'StartJob.IT',
        'url', 'https://startjob.it'
      )
    )
  )),

  -- Blog Category Page Template
  ('/blog/category', 'Kategoria bloga | StartJob.IT', 'Artykuły z wybranej kategorii na blogu StartJob.IT. Wiedza i trendy dla branży IT.', 'blog IT, kategoria, artykuły, trendy IT', 'Kategoria bloga | StartJob.IT', 'Artykuły z wybranej kategorii na blogu StartJob.IT. Wiedza i trendy dla branży IT.', 'website', 'CollectionPage',
  jsonb_build_object(
    'name', 'Kategoria bloga StartJob.IT',
    'description', 'Artykuły z wybranej kategorii na blogu StartJob.IT. Wiedza i trendy dla branży IT.',
    'publisher', jsonb_build_object(
      '@type', 'Organization',
      'name', 'StartJob.IT',
      'logo', jsonb_build_object(
        '@type', 'ImageObject',
        'url', 'https://startjob.it/logo.png'
      )
    )
  ))
ON CONFLICT (path) DO UPDATE
SET 
  title = EXCLUDED.title,
  description = EXCLUDED.description,
  keywords = EXCLUDED.keywords,
  og_title = EXCLUDED.og_title,
  og_description = EXCLUDED.og_description,
  og_type = EXCLUDED.og_type,
  schema_type = EXCLUDED.schema_type,
  schema_data = EXCLUDED.schema_data,
  updated_at = now();