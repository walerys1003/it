/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      screens: {
        'xs': '375px',
        'sm': '640px',
        'md': '768px',
        'lg': '1024px',
        'xl': '1280px',
        '2xl': '1536px',
      },
      spacing: {
        '18': '4.5rem',
        '22': '5.5rem',
        '30': '7.5rem',
      },
      maxWidth: {
        '8xl': '88rem',
        '9xl': '96rem',
      },
      fontSize: {
        'xxs': '0.625rem',
        'tiny': '0.75rem',
      },
      colors: {
        purple: {
          50: '#f5f3fa',
          100: '#ebe7f6',
          200: '#d6d0eb',
          300: '#b7acdc',
          400: '#9283cb',
          500: '#7c69be',
          600: '#6a4ea5',
          700: '#5a4089',
          800: '#4a3471',
          900: '#361d53',
        },
        yellow: {
          50: '#fffaeb',
          100: '#fff3c7',
          200: '#ffe488',
          300: '#ffd055',
          400: '#ffc022',
          500: '#ffa603',
          600: '#ef8400',
          700: '#c66102',
          800: '#9c490a',
          900: '#7e3c0e',
        }
      },
      typography: {
        DEFAULT: {
          css: {
            color: '#361d53',
            h2: {
              color: '#361d53',
              fontWeight: '700',
              marginTop: '2em',
              marginBottom: '1em',
            },
            h3: {
              color: '#361d53',
              fontWeight: '600',
              marginTop: '1.5em',
              marginBottom: '0.75em',
            },
            'ul > li': {
              color: '#5a4089',
            },
            a: {
              color: '#6a4ea5',
              '&:hover': {
                color: '#4a3471',
              },
            },
          },
        },
      },
      fontFamily: {
        sans: ['Poppins', 'Inter', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        '2xl': '1rem',
        '3xl': '1.5rem',
        '4xl': '2rem',
      },
      scale: {
        '102': '1.02',
      },
      transitionDuration: {
        '400': '400ms',
      },
      animation: {
        'spin-slow': 'spin 3s linear infinite',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
      },
      height: {
        'screen-75': '75vh',
        'screen-85': '85vh',
      },
      minHeight: {
        '0': '0',
        '1/4': '25%',
        '1/2': '50%',
        '3/4': '75%',
        'full': '100%',
      },
      zIndex: {
        '60': '60',
        '70': '70',
        '80': '80',
        '90': '90',
        '100': '100',
      }
    },
  },
  plugins: [
    require('@tailwindcss/typography'),
  ],
};